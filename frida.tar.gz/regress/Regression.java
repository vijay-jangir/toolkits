/*----------------------------------------------------------------------
  File    : Regression.java
  Contents: multivariate polynomial regression
  Author  : Christian Borgelt
  History : 2004.05.22 file created from file regress.c
            2004.05.23 prettier description creation added
            2007.03.15 javadoc added, model reading improved
            2007.05.16 constructor from a data table mapper added
            2007.05.30 linear regression treated separately in prods()
            2007.07.19 adapted to changed Table class
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package regress;

import java.io.IOException;
import java.io.FileReader;

import table.RealType;
import table.IntegerType;
import table.Column;
import table.Table;
import table.TableMapper;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for multivariate polynomial regression models.
 *  @author Christian Borgelt
 *  @since  2004.05.22 */
/*--------------------------------------------------------------------*/
public class Regression {

  /*------------------------------------------------------------------*/
  /**  instance variables                                             */
  /*------------------------------------------------------------------*/
  /** the degree of the regression polynomial */
  private int         deg  = 0;
  /** the number of data variables (including the output/response) */
  private int         dim  = 0;
  /** the number of regression coefficients */
  private int         cnt  = 0;
  /** the table of section sizes */
  private int[]       tab  = null;
  /** the buffer for the power products */
  private double[]    buf  = null;
  /** the regression matrix (coefficients of equation system) */
  private double[][]  mat  = null;
  /** the right hand side of the equation system */
  private double[]    rhs  = null;
  /** the regression coefficients */
  private double[]    cfs  = null;
  /** the exponents of the regression terms */
  private int[][]     exps = null;
  /** the sum of the data vector weights */
  private double      sum  = 0;
  /** the sum of the squared output values */
  private double      so2  = 0;
  /** the minimum for a logit transformation */
  private double      min  = 0;
  /** the maximum for a logit transformation */
  private double      max  = 0;
  /** the initial Tikhonov regularization */
  private double      reg  = 0;
  /** the limit for the Tikhonov regularization */
  private double      lim  = 0;
  /** the sum of squared errors */
  private double      sse  = -1;
  /** the underlying data table mapper (if any) */
  private TableMapper map  = null;
  /** the domain descriptions for the regression model (if any) */
  private Table       atts = null;

  /*------------------------------------------------------------------*/
  /** Compute logistic function.
   *  @param  x    the function argument
   *  @return the logistic function value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static double logistic (double x)
  { return ((x) > -709.0) ? 1.0 /(1.0 +Math.exp(-x)) : 0.0; }

  /*------------------------------------------------------------------*/
  /** Create a multivariate polynomial regression model.
   *  @param  atts the underlying variables
   *  @param  deg  the degree of the polynomial
   *  @throws RegException if there are too many regression terms
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Regression (Table atts, int deg) throws RegException
  { this(new TableMapper(atts), deg); }

  /*------------------------------------------------------------------*/
  /** Create a multivariate polynomial regression model.
   *  @param  map the underlying table mapper
   *  @param  deg the degree of the polynomial
   *  @throws RegException if there are too many regression terms
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Regression (TableMapper map, int deg) throws RegException
  {                             /* --- create a regression model */
    this(map.getInOutCount(), deg);
    this.map  = map;            /* store the table mapper */
    this.atts = new Table(map.getTable().getName());
    int n = map.getColumnCount();  /* traverse the mapped columns */
    for (int i = 0; i < n; i++)    /* and copy their domains */
      this.atts.addColumn(map.getColumn(i).cloneAsType());
  }  /* Regression() */

  /*------------------------------------------------------------------*/
  /** Create a multivariate polynomial regression model.
   *  @param  dim the number of variables of the data
   *              (including the output variable)
   *  @param  deg the degree of the polynomial
   *  @throws RegException if there are too many regression terms
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Regression (int dim, int deg) throws RegException
  {                             /* --- create a regression model */
    this.dim  = dim;            /* note the number of variables */
    this.deg  = deg;            /* and the degree of the polynomial */
    this.tab  = new int[dim];   /* create the table of sizes and */
    this.cnt  = this.count();   /* compute the number of parameters */
    this.buf  = new double[this.cnt];
    this.mat  = new double[this.cnt][this.cnt];
    this.rhs  = new double[this.cnt];
    this.sum  = this.so2 = 0;   /* allocate buffers and clear sums */
    this.sse  = -1;             /* invalidate sum of squared errors */
    this.min  = this.max = 0;   /* default: no transformation */
    this.exps = null;           /* exponents are computed on demand */
  }  /* init() */

  /*------------------------------------------------------------------*/
  /** Compute the number of parameters.
   *  @throws RegException if there are too many regression terms
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private int count () throws RegException
  {                             /* --- compute number of parameters */
    int i, k;                   /* loop variables */

    if ((this.dim <= 2)         /* if single variable regression */
    ||  (this.deg <= 2)) {      /* or linear/quadratic regression */
      if (this.deg <= 1) return this.dim;
      if (this.dim <= 2) return this.deg +1;
      return (this.dim *(this.dim +1)) >> 1;
    }                           /* compute the number directly */
    for (k = this.dim; --k >= 0; ) /* initialize table element k-1 to */
      this.tab[k] = k+1;        /* k choose 1 = k (sizes for deg = 1) */
    for (i = this.deg-1; --i >= 0; ) {  /* compute the number as */
      for (k = 0; ++k < this.dim; ) {   /* (dim +deg -1) choose deg */
        if (this.tab[k] > Integer.MAX_VALUE -this.tab[k-1])
          throw new RegException("too many regression terms");
        this.tab[k] += this.tab[k-1];
      }                         /* compute next binomial coefficient */
    }                           /* finally get the number of params. */
    return this.tab[this.dim-1];/* from the last table field */
  }  /* count() */

  /*------------------------------------------------------------------*/
  /** Get the domains of the variables.
   *  <p>Domains of the variables are available only if the regression
   *  model has been created from a table or a table mapper.</p>
   *  @return the domains of the variables as a table
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getDomains ()
  { return this.atts; }

  /*------------------------------------------------------------------*/
  /** Get the underlying table mapper.
   *  <p>A table mapper is available only if the regression model
   *  has been created from a table or a table mapper.</p>
   *  @return the underlying table mapper
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableMapper getMapper ()
  { return this.map; }

  /*------------------------------------------------------------------*/
  /** Set the minimum for a logit transformation.
   *  @param  min the minimum for a logit transformation
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMin (double min)
  { this.min = min; }

  /*------------------------------------------------------------------*/
  /** Get the minimum for a logit transformation.
   *  @return the minimum for a logit transformation
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMin ()
  { return this.min; }

  /*------------------------------------------------------------------*/
  /** Set the maximum for a logit transformation.
   *  @param  max the maximum for a logit transformation
   *  @since  2007.04.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMax (double max)
  { this.max = max; }

  /*------------------------------------------------------------------*/
  /** Get the maximum for a logit transformation.
   *  @return the maximum for a logit transformation
   *  @since  2007.04.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMax ()
  { return this.max; }

  /*------------------------------------------------------------------*/
  /** Set the range for a logit transformation.
   *  @param  min the minimum for a logit transformation
   *  @param  max the maximum for a logit transformation
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMinMax (double min, double max)
  { this.min = min; this.max = max; }

  /*------------------------------------------------------------------*/
  /** Set the initial Tikhonov regularization.
   *  @param  reg the initial regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setReg (double reg)
  { this.reg = reg; }

  /*------------------------------------------------------------------*/
  /** Get the initial Tikhonov regularization.
   *  @return the initial regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getReg ()
  { return this.reg; }

  /*------------------------------------------------------------------*/
  /** Set the limit for the Tikhonov regularization.
   *  @param  lim the limit for the regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setLim (double lim)
  { this.lim = lim; }

  /*------------------------------------------------------------------*/
  /** Get the limit for the Tikhonov regularization.
   *  @return the limit for the regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getLim ()
  { return this.lim; }

  /*------------------------------------------------------------------*/
  /** Set initial value and limit for the Tikhonov regularization.
   *  @param  reg the initial regularization value
   *  @param  lim the limit for the regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRegLim (double reg, double lim)
  { this.reg = reg; this.lim = lim; }

  /*------------------------------------------------------------------*/
  /** Get the degree of the regression polynomial.
   *  @return the degree of the regression polynomial
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getDegree ()
  { return this.deg; }

  /*------------------------------------------------------------------*/
  /** Get the number of variables (including the output).
   *  @return the number of variables
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getVarCount ()
  { return this.dim; }

  /*------------------------------------------------------------------*/
  /** Get the name of a variable.
   *  @param  id the index of the variable
   *  @return the name of the i-th variable
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getVarName (int id)
  {                             /* --- get the name of a variable */
    if (this.map != null) return this.map.getVarName(id);
    if (id >= this.dim-1) return "y";
    if (this.dim <= 2)    return "x";
    return "x_" +(id +1);       /* create variable name if necessary */
  }  /* getVarName() */

  /*------------------------------------------------------------------*/
  /** Get the number of regression coefficients.
   *  @return the number of regression coefficients
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getCoeffCount ()
  { return this.cnt; }

  /*------------------------------------------------------------------*/
  /** Get a regression coefficient.
   *  @param  i the index of the regression coefficient
   *  @return the i-th regression coefficient
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getCoeff (int i)
  { return this.cfs[i]; }

  /*------------------------------------------------------------------*/
  /** Get all regression coefficients.
   *  @return the regression coefficients
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double[] getAllCoeffs ()
  { return this.cfs; }

  /*------------------------------------------------------------------*/
  /** Get the exponents of a regression term.
   *  @param  i the index of the regression term
   *  @return the exponents of the i-th regression term
   *  @since  2007.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int[] getExpos (int i)
  { return this.getAllExpos()[i]; }

  /*------------------------------------------------------------------*/
  /** Get the exponents of all regression terms.
   *  @return the exponents of all regression terms
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int[][] getAllExpos ()
  {                             /* --- get exponents of reg. terms */
    int i, j, k;                /* loop variables */

    if (this.exps != null)      /* if the exponents are determined, */
      return this.exps;         /* simply return them */
    this.exps = new int[this.cnt][this.dim-1];
    if      (this.dim <= 2) {   /* --- if single variable regression */
      for (k = 0, i = this.cnt; --i >= 0; k++)
        this.exps[k][0] = i; }
    else if (this.deg <= 1) {   /* --- if linear regression */
      for (i = k = 0; ++i < this.dim; k++)
        this.exps[k][k] = 1; }
    else if (this.deg <= 2) {   /* --- if quadratic regression */
      for (i = k = 0; ++i < this.dim; k++) {
        for (j = 0; ++j < i; k++)
          this.exps[k][i-1] = this.exps[k][j-1] = 1;
        this.exps[k][i-1] = 2;  /* store the mixed terms */
      }                         /* and the quadratic terms */
      for (i = 0; ++i < this.dim; k++) {
        this.exps[k][i-1] = 1;  /* store the linear terms */
      } }
    else {                      /* --- if general regression */
      this.tab[i = this.dim-2] = this.deg +1;
      while (--i >= 0)          /* init. the table of exponents to */
        this.tab[i] = 0;        /* x_n^(deg+1), i.e. "previous" state */
      for (k = 0, i = this.cnt; --i > 0; k++) {
        if (this.tab[0] > 0) {  /* update the table of exponents */
          this.tab[1]++;        /* if first exponent is not zero, */
          this.tab[0]--; }      /* shift a 1 from first to second */
        else {                  /* otherwise find first nonzero exp. */
          for (j = 0; this.tab[++j] <= 0; );
          this.tab[0] = this.tab[j]-1;
          this.tab[j] = 0; this.tab[j+1]++;
        }                       /* move exps. back to first */
        System.arraycopy(this.tab, 0, this.exps[k], 0, this.dim-1);
      }                         /* copy the computed exponents */
    }                           /* to the corresponding table row */
    return this.exps;           /* return the created exponent table */
  }  /* getAllExpos() */

  /*------------------------------------------------------------------*/
  /** Get the sum of the data vector weights.
   *  @return the sum of the data vector weights
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getSum ()
  { return this.sum; }

  /*------------------------------------------------------------------*/
  /** Compute the power products of the variables (monomials).
   *  <p>This function uses a dynamic programming scheme to avoid
   *  redundant computations and thus is maximally efficient.
   *  The computation time is linear in the number of monomials
   *  (that is, the time needed per monomial is constant).</p>
   *  @param  vec the data vector
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void prods (double[] vec)
  {                             /* --- compute products of variables */
    int i, k, m, n, t;          /* loop variables, buffers */

    n = this.cnt -1;            /* traverse the buffer */
    if (this.deg <= 1) {        /* if linear regression */
      for (i = this.dim -1; --i >= 0; )
        this.buf[--n] = vec[i]; /* simply copy the data vector */
      return;                   /* to the internal buffer and */
    }                           /* then abort the function */
    for (i = this.dim -1; --i >= 0; ) {
      this.buf[--n] = vec[i];   /* copy the linear terms to the end */
      this.tab[i]   = i+1;      /* and set the initial section sizes */
    }                           /* (elems. to combine per variable) */
    for (k = 2; true; ) {       /* traverse the exponent sums */
      t = n;                    /* note start of previous section */
      for (i = this.dim -1; --i >= 0; ) {
        for (m = this.tab[i]; --m >= 0; )
          this.buf[--n] = this.buf[t+m] *vec[i];
      }                         /* compute next section (next exp.) */
      if (++k > this.deg) break;/* if highest degree reached, abort */
      for (i = 0; ++i < this.dim; )
        this.tab[i] += this.tab[i-1];
    }                           /* compute next section sizes */
  }  /* prods() */

  /*------------------------------------------------------------------*/
  /** Add the matrix product of a vector to the regression matrix.
   *  @param  vec the vector the matrix product of which to add
   *  @param  wgt the weight of the vector
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void addmp (double[] vec, double wgt)
  {                             /* --- add matrix product of vector */
    int      row, col;          /* loop variables */
    double   t;                 /* temporary buffer */
    double[] r;                 /* to access the matrix row */

    this.sum += wgt;            /* sum the vector weight */
    for (row = this.cnt; --row >= 0; ) {
      this.rhs[row] += t = vec[row] *wgt;
      r = this.mat[row];        /* sum the weighted vector */
      for (col = this.cnt; --col >= row; )
        r[col] += vec[col] *t;  /* sum the weighted matrix product */
    }                           /* of the vector with itself */
  }  /* addmp() */

  /*------------------------------------------------------------------*/
  /** Aggregate a data vector.
   *  <p>It is assumed that the value of the output/response variable
   *  is in the element with index <code>getVarCount()-1</code>.</p>
   *  @param  vec the data vector
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void aggregate (double[] vec, double wgt) throws RegException
  {                             /* --- aggregate a data vector */
    int    i, k, n;             /* loop variables */
    double t, o = 0;            /* temporary buffers */

    if (this.max > this.min) {  /* if logit transformation */
      o = vec[this.dim-1];      /* get the output value */
      if ((o <= this.min) || (o >= this.max))
        throw new RegException("logit transformation failed: " +o);
      vec[this.dim-1] = Math.log((this.max -o) / (o -this.min));
    }                           /* transform the output value */
    if      (this.deg <= 1)     /* --- if linear regression */
      this.addmp(vec, wgt);     /* aggregate the data vector directly */
    else if (this.dim <= 2) {   /* --- if single variable regression */
      i = this.deg;             /* compute the needed powers */
      this.buf[  i] = vec[1];   /* of the regressor variable */
      this.buf[--i] = t = vec[0];
      while (--i >= 0) { this.buf[i] = t *= vec[0]; }
      this.addmp(this.buf,wgt);}/* aggregate the vector of powers */
    else if (this.deg <= 2) {   /* --- if quadratic regression */
      n = this.cnt;             /* traverse the buffer */
      for (i = this.dim; --i >= 0; )
        this.buf[--n] = vec[i]; /* copy linear terms to the end */
      for (i = this.dim-1; --i >= 0; )
        for (k = i+1; --k >= 0; ) /* compute squared values */
          this.buf[--n] = vec[i]*vec[k]; /* and mixed terms */
      this.addmp(this.buf,wgt);}/* aggregate the vector of products */
    else {                      /* --- if general regression */
      this.prods(vec);          /* compute products of the variables */
      this.buf[this.cnt-1] = vec[this.dim-1];
      this.addmp(this.buf,wgt); /* store the output variable and */
    }                           /* aggregate the vector of products */
    if (this.max > this.min)    /* if logit transformation, */
      vec[this.dim-1] = o;      /* restore the output value */
  }  /* aggregate() */

  /*------------------------------------------------------------------*/
  /** Cholesky decomposition of the coefficient matrix.
   *  @return -1 if decomposition failed, 0 otherwise
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private int decom ()
  {                             /* --- Cholesky decomposition */
    int      row, col, i;       /* loop variables, counter */
    double[] s, d;              /* to traverse the matrix rows */
    double   t, q;              /* temporary buffers */

    for (row = 0; row < this.cnt; row++) {
      s = this.mat[row];        /* traverse the matrix rows */
      t = s[row];               /* compute square of diag. element */
      for (i = row; --i >= 0; ) t -= s[i] *s[i];
      if (t <= 0) return -1;    /* if not positive definite, abort */
      s[row] = t = Math.sqrt(t);/* store the diagonal element */
      if (t <= 0) return -1;    /* if not positive definite, abort */
      this.buf[row] = q = 1/t;  /* compute the corresponding factor */
      for (col = row; ++col < this.cnt; ) {
        d = this.mat[col]; t = s[col];
        for (i = row; --i >= 0; ) t -= s[i] *d[i];
        d[row] = t*q;           /* compute the off-diagonal elements */
      }                         /* (the lower triangular matrix) */
    }                           /* and store them in the matrix */
    return 0;                   /* return 'ok' */
  }  /* decom() */

  /*------------------------------------------------------------------*/
  /** Set up and solve the regression equation system.
   *  @throws RegException if the computation failed
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void solve () throws RegException
  {                             /* --- solve regression eq. system */
    int      row, col, i, n;    /* loop variables, counter */
    double[] s, d;              /* to traverse the matrix rows */
    double   x, y;              /* regularization value, limit */
    double   t, q;              /* temporary buffers */
    double[] diag;              /* buffer for matrix diagonal */

    /* --- set up system of normal equations --- */
    this.cfs = new double[this.cnt]; /* create the coefficients array */
    for (row = n = this.cnt-1; --row >= 0; ) {
      t = this.rhs[row]; this.rhs[row] = this.mat[row][n];
      this.mat[row][n] = t;     /* exchange the right hand side and */
    }                           /* the last column of the matrix */
    this.so2 = this.mat[n][n];  /* note the sum of squared outputs */
    this.mat[n][n] = this.sum;  /* store the sum of vector weights */

    /* --- Cholesky decomposition --- */
    y = this.lim *this.lim;     /* compute regularization limit */
    x = this.reg *this.reg;     /* and initial regularization value */
    diag = new double[this.cnt];/* save diagonal for regularization */
    for (i = 0; i < this.cnt; i++) diag[i] = this.mat[i][i];
    if (this.reg > 0) {         /* if to use Tikhonov regularization */
      for (i = 0; i < this.cnt; i++) this.mat[i][i] += x;
      x *= 4;                   /* apply initial regularization */
    }                           /* and update regularization value */
    while (true) {              /* equation system solution loop */
      i = this.decom();         /* try Cholesky decomposition */
      if (i == 0) break;        /* on success abort loop */
      if (x >  y)               /* limit regularization steps */
        throw new RegException("Cholesky decomposition failed");
      for (i = 0; i < this.cnt; i++) this.mat[i][i] = diag[i] +x;
      x *= 4;                   /* add regularization to diagonal */
    }                           /* and update regularization value */

    /* --- solve the equation system --- */
    for (row = 0; row < this.cnt; row++) {
      s = this.mat[row]; t = this.rhs[row];
      for (col = row; --col >= 0; )
        t -= this.cfs[col] *s[col];
      this.cfs[row] = t *this.buf[row];
    }                           /* do forward substitution with L */
    for (row = this.cnt; --row >= 0; ) {
      s = this.mat[row]; t = this.cfs[row];
      for (col = row; ++col < this.cnt; )
        t -= this.cfs[col] *this.mat[col][row];
      this.cfs[row] = t *this.buf[row];
    }                           /* do backward substitution with L^T */
  }  /* solve() */

  /*------------------------------------------------------------------*/
  /** Compute the sum of squared errors.
   *  <p>This functions computes the sum of squared errors from the
   *  regression coefficients and the Cholesky decomposition of the
   *  regression matrix. As this is numerically unstable, the result
   *  should be taken with a grain of salt.</p>
   *  @return the sum of squared errors
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getSSE ()
  {                             /* --- compute sum of squared errors */
    int      i, k;              /* loop variables */
    double[] p;                 /* to access the matrix rows */
    double   t = 0;             /* buffer for computations */

    if (this.sse >= 0)          /* if sum of squared errors is known, */
      return this.sse;          /* simply return it */
    i = this.cnt -1;            /* compute the sum of squared errors */
    this.sse = this.so2 +this.cfs[i] *this.cfs[i] *this.sum
                        -this.cfs[i] *this.rhs[i] *2;
    while (--i >= 0) {          /* traverse the matrix rows */
      p = this.mat[i];          /* except the last one */
      for (t = 0, k = i+1; --k >= 0; )
        t += p[k] *p[k];        /* recompute the matrix diagonal */
      this.sse += this.cfs[i] *this.cfs[i] *t;
      for (t = -this.rhs[i], k = this.cnt; --k > i; )
        t += this.cfs[k] *p[k]; /* compute c^T * M * c -c^T * r +y^2, */
      this.sse += this.cfs[i] *t *2;   /* (M is the original matrix, */
    }                           /* r the right hand side of the LES) */
    if (this.sse < 0) this.sse = 0;
    return this.sse;            /* return the sum of squared errors */
  }  /* getSSE() */

  /*------------------------------------------------------------------*/
  /** Execute a regression function.
   *  @param  vec the data vector for which to execute the function
   *  @return the value of the regression function
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double execute (double[] vec)
  {                             /* --- execute the regression model */
    int    i, k, n;             /* loop variables */
    double r, t;                /* value of regression func., buffer */

    if      (this.deg <= 1) {   /* --- if linear regression */
      r = this.cfs[i = this.dim-1];    /* compute linear function */
      while (--i >= 0) r += this.cfs[i] *vec[i]; }
    else if (this.dim <= 2) {   /* --- if single variable regression */
      r = this.cfs[i = this.deg-1];
      r += this.cfs[--i] *(t = vec[0]);
      while (--i > 0)           /* multiply the different powers */
        r += this.cfs[i] *(t *= vec[0]); }   /* with the coeffs. */
    else if (this.deg <= 2) {   /* --- if quadratic regression */
      r = this.cfs[n = this.cnt-1];
      for (i = this.dim-1; --i >= 0; )
        r += this.cfs[--n] *vec[i];  /* add the linear terms */
    for (i = this.dim-1; --i >= 0; ) {
      for (k = i+1; --k >= 0; ) /* add the squared values */
        r += this.cfs[--n] *vec[i]*vec[k];
    } }                         /* and the mixed terms */
    else {                      /* --- if general regression */
      this.prods(vec);          /* compute products of variables */
      r = this.cfs[n = this.cnt-1];
      while (--n >= 0)          /* multiply the different products */
        r += this.cfs[n] * this.buf[n];
    }                           /* with the corresponding coeffs. */
    if (this.max > this.min)    /* if logistic regression, transform */
      r = (this.max -this.min) *logistic(r) +this.min;
    return r;                   /* return the value of the */
  }  /* execute() */            /* regression function */

  /*------------------------------------------------------------------*/
  /** Get the regression model as a table.
   *  @return the regression model as a table
   *  @since  2007.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getAsTable ()
  { return this.getAsTable(true, -1.0); }

  /*------------------------------------------------------------------*/
  /** Get the regression model as a table.
   *  @param  zeros whether to show zero exponents
   *  @return the regression model as a table
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getAsTable (boolean zeros)
  { return this.getAsTable(zeros, -1.0); }

  /*------------------------------------------------------------------*/
  /** Get the regression model as a table.
   *  @param  min the minimum absolute value of a coefficient
   *  @return the regression model as a table
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getAsTable (double min)
  { return this.getAsTable(false, min); }

  /*------------------------------------------------------------------*/
  /** Get the regression model as a table.
   *  @param  zeros whether to show zero exponents
   *  @param  min   the minimum absolute value of a coefficient
   *  @return the regression model as a table
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getAsTable (boolean zeros, double min)
  {                             /* --- get reg. model as a table */
    int      i, k, n = 0;       /* loop variable, counter */
    int      x;                 /* buffer for exponents */
    Table    reg;               /* created table for the model */
    Column   col;               /* buffer for a column */
    double[] tcfs;              /* table array for coefficients */
    int[][]  texs;              /* table arrays for exponents */
    String   name;              /* name of the coefficient column */

    this.getAllExpos();         /* create the exponents and a table */
    reg = new Table((this.atts == null) ? "Regression"
                   : this.getVarName(this.dim-1));
    name = "coefficient";       /* get the name for the coefficients */
    if (this.atts != null) {    /* if there are attribute names */
      for (i = 0; this.atts.findColumn(name) >= 0; )
        name = "coefficient_" +(++i);
    }                           /* make sure the name is unique */
    col = new Column(name, new RealType());
    reg.addColumn(col);         /* add a column for the coefficients */
    for (i = 0; i < this.dim-1; i++) {
      col = new Column(this.getVarName(i), new IntegerType());
      reg.addColumn(col);       /* add a column for each variable */
    }                           /* (for the power in the monomial) */
    for (i = this.cnt; --i >= 0; )
      if (Math.abs(this.cfs[i]) >= min)
        n++;                    /* count the qualifying coefficients */
    reg.resize(n);              /* create the needed table rows */
    col  = reg.getColumn(0);    /* get the coefficient array */
    tcfs = (double[])col.getData();
    texs = new int[this.dim-1][];
    for (k = this.dim; --k > 0;)/* get the exponent arrays */
      texs[k-1] = (int[])reg.getColumn(k).getData();
    for (i = this.cnt; --i >= 0; ) {
      if (Math.abs(this.cfs[i]) < min) continue;
      tcfs[--n] = this.cfs[i];  /* copy the coefficient */
      for (k = this.dim-1; --k >= 0; ) {
        x = this.exps[i][k];    /* copy the variable exponents */
        if ((x != 0) || zeros) texs[k][n] = x;
        else texs[k][n] = IntegerType.NULL;
      }                         /* zero exponents are represented */
    }                           /* by null values if requested */
    return reg;                 /* return the created table */
  }  /* getAsTable() */

  /*------------------------------------------------------------------*/
  /** Describe the regression function.
   *  @return a description of the regression function
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  { return this.toString("regression polynomial"); }

  /*------------------------------------------------------------------*/
  /** Describe the regression function.
   *  @param  header the text to add as a header
   *  @return a description of the regression function
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString (String header)
  {                             /* --- create a description */
    int           i;            /* loop variable */
    StringBuilder s;            /* buffer for writing */
    String        indent;       /* indentation string */

    s = new StringBuilder();    /* create a string buffer */
    if (header != null) {       /* if to add a header */
      s.append("/*");           /* create a header (as a comment) */
      for (i = 70; --i >= 0; ) s.append('-');
      s.append("\n  " +header +"\n");
      for (i = 70; --i >= 0; ) s.append('-');
      s.append("*/\n");         /* terminate the header */
    }
    if (this.atts == null) {    /* if there are no domains */
      s.append("vars   = ");    /* state the number of variables */
      s.append(this.dim); s.append(";\n");
      indent = ""; }            /* do not indent the description */
    else {                      /* if there are domains */
      s.append("regression(");  /* store enclosing frame description */
      s.append(this.getVarName(this.dim-1));
      s.append(") = {\n");      /* print target variable name */
      indent = "  ";            /* and start the description */
    }                           /* indent by two characters */
    s.append(indent);           /* store degree of the polynomial */
    s.append("degree = "); s.append(this.deg); s.append(";\n");
    if (this.max > this.min) {  /* if logistic regression, */
      s.append(indent);         /* store range for transformation */
      s.append("logit  = "); s.append(this.min);
      s.append(",");         s.append(this.max); s.append(";\n");
    }                           /* then start the coefficients */
    s.append(indent); s.append("coeffs = {");
    for (i = 0; i < this.cnt; i++) {
      if (i > 0)        s.append(',');
      if ((i % 3) != 0) s.append(' ');
      else { s.append("\n  "); s.append(indent); }
      s.append(this.cfs[i]);    /* traverse and print */
    }                           /* the regression coefficients */
    s.append(" };\n");          /* terminate the coefficient list */
    if (this.atts != null)      /* if there are domains */
      s.append("};\n");         /* terminate frame description */
    return s.toString();        /* return the created description */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Print a coefficient (with sign).
   *  @param  i the index of the coefficient
   *  @since  2007.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String coeff (int i)
  { return ((this.cfs[i] > 0) ? "" : "+") +this.cfs[i]; }

  /*------------------------------------------------------------------*/
  /** Describe the regression function.
   *  @param  min the minimum absolute value of a coefficient
   *  @return a description of the regression function
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString (double min)
  {                             /* --- create a description */
    int i, j, k, n = 0;         /* loop variables, counter */
    StringBuilder s;            /* buffer for writing */

    s = new StringBuilder(this.getVarName(this.dim-1));
    s.append(" =");             /* start with the output variable */
    if      (this.dim <= 2) {   /* if single variable regression */
      for (k = 0, i = this.deg+1; --i > 1; k++) {
        if (Math.abs(this.cfs[k]) < min)
          continue;             /* skip negligible terms */
        s.append("\n"); s.append(this.coeff(k));
        s.append(" ");  s.append(this.getVarName(0));
        s.append("^");  s.append(i);
        n++;                    /* print coeffs. of different powers */
      }                         /* and count the printed terms */
      if (Math.abs(this.cfs[k]) >= min) {
        s.append("\n"); s.append(this.coeff(k));
        s.append(" ");  s.append(this.getVarName(0));
        n++;                    /* if linear term is not negligible */
      } k++; }                  /* print and count it */
    else if (this.deg <= 1) {   /* --- if linear regression */
      for (i = k = 0; ++i < this.dim; k++) {
        if (Math.abs(this.cfs[k]) < min)
          continue;             /* skip negligible terms */
        s.append("\n"); s.append(this.coeff(k));
        s.append(" ");  s.append(this.getVarName(k));
      } }                       /* print the linear terms */
    else if (this.deg <= 2) {   /* --- if quadratic regression */
      for (i = k = 0; ++i < this.dim; k++) {
        for (j = 0; ++j < i; k++) {
          if (Math.abs(this.cfs[k]) < min)
            continue;           /* skip negligible terms */
          s.append("\n"); s.append(this.coeff(k));
          s.append(" ");  s.append(this.getVarName(j-1));
                          s.append(this.getVarName(i-1));
          n++;                  /* print the mixed terms */
        }                       /* and count them */
        if (Math.abs(this.cfs[k]) < min)
          continue;             /* skip negligible terms */
        s.append("\n"); s.append(this.coeff(k));
        s.append(" ");  s.append(this.getVarName(i-1));
        s.append("^2"); n++;    /* print the squares */
      }                         /* and count them */
      for (i = 0; ++i < this.dim; k++) {
        if (Math.abs(this.cfs[k]) < min)
          continue;             /* skip negligible terms */
        s.append("\n"); s.append(this.coeff(k));
        s.append(" ");  s.append(this.getVarName(i-1));
        n++;                    /* print the linear terms */
      } }                       /* and count them */
    else {                      /* --- if general regression */
      this.tab[i = this.dim-2] = this.deg +1;
      while (--i >= 0)          /* init. the table of exponents to */
        this.tab[i] = 0;        /* x_n^(deg+1), i.e. "previous" state */
      for (k = 0, i = this.cnt; --i > 0; k++) {
        if (this.tab[0] > 0) {  /* update the table of exponents */
          this.tab[1]++;        /* if first exponent is not zero, */
          this.tab[0]--; }      /* shift a 1 from first to second */
        else {                  /* otherwise find first nonzero exp. */
          for (j = 0; this.tab[++j] <= 0; );
          this.tab[0] = this.tab[j]-1;
          this.tab[j] = 0; this.tab[j+1]++;
        }                       /* move exps. back to first */
        if (Math.abs(this.cfs[k]) < min)
          continue;             /* skip negligible terms */
        s.append("\n"); s.append(this.coeff(k));
        for (j = 0; ++j < this.dim; ) {
          if (this.tab[j-1] <= 0) continue;
          s.append(" "); s.append(this.getVarName(j-1));
          if (this.tab[j-1] <= 1) continue;
          s.append("^"); s.append(this.tab[j-1]);
        }                       /* print coefficients of */
        n++;                    /* the different products and */
      }                         /* a description the products, */
    }                           /* then count the term */
    if (Math.abs(this.cfs[k]) >= min) { /* print the constant term */
      s.append("\n"); s.append(this.coeff(k)); s.append("\n"); }
    else if (n <= 0)            /* if no term was printed yet, */
      s.append(" 0\n");         /* print a zero as a fallback */
    return s.toString();        /* return the created description */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Get an integer number.
   *  @param  scan the scanner to read from
   *  @param  key1 the first  keyword to check for
   *  @param  key2 the second keyword to check for
   *  @param  min  the minimum for the value to read
   *  @return the parsed integer number
   *  @throws IOException if a read error occurs
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static int getInt (Scanner scan, String key1,
                             String key2, int min)
    throws IOException
  {                             /* --- get an integer number */
    int n;                      /* parse number */

    scan.getID();               /* check for one of the keywords */
    if (!scan.value.equals(key1)
    &&  !scan.value.equals(key2))
      throw new IOException("'" +key1 +"' expected" +scan.lno());
    scan.getChar('=');          /* check for '=' */
    scan.getNumber();           /* check for a number */
    try { n = Integer.parseInt(scan.value); }
    catch (NumberFormatException e) {
      throw new IOException("malformed number "+scan.value+scan.lno());}
    if (n < min)                /* check value against minimum */
      throw new IOException("illegal value "   +scan.value+scan.lno());
    scan.getChar(';');          /* check for ';' */
    return n;                   /* return the parsed number */
  }  /* getInt() */

  /*------------------------------------------------------------------*/
  /** Parse a regression description.
   *  @param  reg  the regression model to initialize
   *  @param  scan the scanner to read the description from
   *  @throws IOException if a read error occurs
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static void parse (Regression reg, Scanner scan)
    throws IOException
  {                             /* --- parse a regression model */
    scan.getID();               /* check for 'logit' or 'max' */
    if (scan.value.equals("logit")
    ||  scan.value.equals("range")) {
      scan.getChar('=');        /* check for '=' */
      scan.getNumber();         /* check for a number */
      try { reg.max = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) { reg.max = 0; }
      if (scan.nextToken() != ',') {
        scan.pushBack();        /* if no second value follows, */
        reg.min = 0; }          /* set the minimum to zero */
      else {                    /* if a second value follows */
        scan.getNumber();       /* check for a number */
        reg.min = reg.max;      /* first value is range minimum */
        try { reg.max = Double.parseDouble(scan.value); }
        catch (NumberFormatException e) { reg.max = 0; }
      }                         /* get the maximum of the range */
      scan.getChar(';');        /* check for ';' */
      scan.getID();             /* check for an identifier */
    }
    if (!scan.value.equals("coefficients")
    &&  !scan.value.equals("coeffs"))
      throw new IOException("'coeffs' expected" +scan.lno());
    scan.getChar('=');          /* check for '=' */
    scan.getChar('{');          /* check for '{' */
    reg.cfs = new double[reg.cnt]; /* create the coefficients array */
    for (int i = 0; i < reg.cnt; i++) {
      if (i > 0) scan.getChar(',');
      scan.getNumber();         /* traverse the coefficients */
      try { reg.cfs[i] = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) { }
    }                           /* parse a regression coefficient */
    scan.getChar('}');          /* check for '}' */
    scan.getChar(';');          /* check for ';' */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse a regression description.
   *  @param  scan the scanner to read the description from
   *  @throws IOException if a read error occurs
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Regression parse (Scanner scan)
    throws IOException
  {                             /* --- parse a regression model */
    int        dim, deg;        /* number of variables and degree */
    Regression reg;             /* created regression model */
    String     val;             /* buffer for a token value */

    scan.getID();               /* read first token in order */
    val = scan.value;           /* to determine the model type, */
    scan.pushBack();            /* then parse the regression model */
    if (val.equals("dom"))      /* (read domains if present) */
      return Regression.parse(scan, null);
    dim = Regression.getInt(scan, "vars",   "dim", 2);
    deg = Regression.getInt(scan, "degree", "deg", 2);
    try { reg = new Regression(dim, deg); }
    catch (RegException e) {    /* create a regression model */
      throw new IOException(e.getMessage()); }
    Regression.parse(reg,scan); /* parse the remaining parameters */
    return reg;                 /* return created regression model */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse a regression description.
   *  @param  scan the scanner to read the description from
   *  @param  atts the variable domains as a table
   *  @throws IOException if a read error occurs
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Regression parse (Scanner scan, Table atts)
    throws IOException
  {                             /* --- parse a regression model */
    int         trgid;          /* id of the target column */
    int         deg;            /* degree of the polynomial */
    Regression  reg;            /* created regression model */
    TableMapper map;            /* created table mapper */

    if (atts == null)           /* parse domains if necessary */
      atts = Table.parse("domains", scan);
    scan.getID();               /* check for 'polynomial' */
    if (!scan.value.equals("polynomial")
    &&  !scan.value.equals("poly")
    &&  !scan.value.equals("regression")
    &&  !scan.value.equals("regress")
    &&  !scan.value.equals("reg"))
      throw new IOException("'polynomial' expected" +scan.lno());
    scan.getChar('(');          /* check for '(' */
    scan.getID();               /* check for an identifier */
    trgid = atts.findColumn(scan.value);
    if (trgid < 0)              /* get the target column */
      throw new IOException("unknown target " +scan.value +scan.lno());
    map = new TableMapper(atts);/* create a table mapper */
    map.setTarget(trgid);       /* and set the target column */
    if (map.getOutputCount() != 1)
      throw new IOException("illegal target " +scan.value +scan.lno());
    scan.getChar(')');          /* check for '(' */
    scan.getChar('=');          /* check for '=' */
    scan.getChar('{');          /* check for '{' */
    deg = Regression.getInt(scan, "degree", "deg", 1);
    try { reg = new Regression(map, deg); }
    catch (RegException e) {    /* create a regression model */
      throw new IOException(e.getMessage()); }
    Regression.parse(reg,scan); /* parse the regression parameters */
    scan.getChar('}');          /* check for '}' */
    scan.getChar(';');          /* check for ';' */
    return reg;                 /* return created regression model */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    Scanner    scan;            /* scanner to read from */
    Regression reg;             /* created table */

    if (args.length <= 0) {     /* if no arguments are given */
      System.out.println("usage: java " +Regression.class.getName()
                              +" regfile");
      return;                   /* print a usage message */
    }                           /* and abort the program */
    try {                       /* basic functionality test */
      scan = new Scanner(new FileReader(args[0]));
      reg  = Regression.parse(scan);
      if (scan.nextToken() != Scanner.T_EOF)
        throw new IOException("garbage at end of file " +scan.lno());
      scan.close();             /* check for proper parsing */
      System.out.println(reg.getDomains());
      System.out.print(reg); }  /* print the regression model */
    catch (IOException e) {     /* catch any i/o errors */
      System.out.println(e.getMessage()); return; }
  }  /* main() */

}  /* class Regression */
