/*----------------------------------------------------------------------
  File    : RegInducer.java
  Contents: multivariate polynomial regression inducer
  Author  : Christian Borgelt
  History : 2007.05.16 file created
            2014.10.23 changed from LGPL license to MIT license
----------------------------------------------------------------------*/
package regress;

import java.io.IOException;
import java.io.Writer;
import java.io.FileWriter;
import java.io.FileReader;

import util.ASCIICoder;
import util.Executable;
import util.TableReader;
import util.Scanner;
import table.Table;
import table.TableMapper;

/*--------------------------------------------------------------------*/
/** Class for inducing multivariate polynomial regression models.
 *  @author Christian Borgelt
 *  @since  2007.05.14 */
/*--------------------------------------------------------------------*/
public class RegInducer implements Executable {

  /*------------------------------------------------------------------*/
  /**  constants                                                      */
  /*------------------------------------------------------------------*/
  /** the program description */
  public static final String DESCRIPTION =
    "multivariate polynomial regression inducer";
  /** the version of this program */
  public static final String VERSION =
    "2.2 (2014.10.23)";
  /** the copyright information for this program */
  public static final String COPYRIGHT =
    "(c) 2004-2014 Christian Borgelt";

  /*------------------------------------------------------------------*/
  /**  instance variables                                             */
  /*------------------------------------------------------------------*/
  /** the name of the domain description file */
  private String      fn_dom  = null;
  /** the scanner for the domains file */
  private Scanner     scan    = null;
  /** the name of the target column */
  private String      target  = null;
  /** the id of the target column */
  private int         trgid   = -1;
  /** the name of the data table file */
  private String      fn_tab  = null;
  /** the record  separators */
  private String      recseps = null;
  /** the field   separators */
  private String      fldseps = null;
  /** the blank   characters */
  private String      blanks  = null;
  /** the comment characters */
  private String      comment = null;
  /** the read mode for the data table */
  private int         mode    = 0;
  /** the table reader to read the data from */
  private TableReader reader  = null;
  /** the input data table / domain descriptions */
  private Table       tab     = null;
  /** the table mapper for the mapping to a vector */
  private TableMapper map     = null;
  /** the degree of the regression polynomial */
  private int         deg     = 1;
  /** the maximum for a possible logit transformation */
  private double      min     = 0;
  /** the maximum for a possible logit transformation */
  private double      max     = 0;
  /** the initial Tikhonov regularization */
  private double      trp     = 0;
  /** the limit for the Tikhonov regularization */
  private double      lim     = 0;
  /** the name of the regression model file */
  private String      fn_reg  = null;
  /** the writer for the regression model file */
  private Writer      writer  = null;
  /** the induced regression model */
  private Regression  reg     = null;
  /** the number of processed table rows */
  private int         rowcnt  = 0;
  /** whether the induction was externally aborted */
  private volatile boolean stop = false;

  /*------------------------------------------------------------------*/
  /** Create a regression model inducer.
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RegInducer ()
  { }

  /*------------------------------------------------------------------*/
  /** Set the domain description file.
   *  @param  fn_dom the name of the domain description file
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomains (String fn_dom)
  { this.fn_dom = fn_dom; }

  /*------------------------------------------------------------------*/
  /** Set the scanner to read the domain descriptions from.
   *  @param  scan the scanner to read the domain descriptions from
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomains (Scanner scan)
  { this.scan = scan; }

  /*------------------------------------------------------------------*/
  /** Set the domain descriptions.
   *  @param  tab the domain descriptions
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomains (Table tab)
  { this.tab = tab; }

  /*------------------------------------------------------------------*/
  /** Set the name of the target column.
   *  @param  target the name of the target column
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTarget (String target)
  { this.target = target; }

  /*------------------------------------------------------------------*/
  /** Set the id of the target column.
   *  @param  trgid the id of the target column
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTarget (int trgid)
  { this.trgid = trgid; }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab the name of the data table file
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab)
  { this.setInput(fn_tab, "\n", " ,\t", " \t\r", "#", 0); }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab the name of the data table file
   *  @param  mode   the read mode
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab, int mode)
  { this.setInput(fn_tab, "\n", " ,\t", " \t\r", "#", mode); }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab  the name of the data table file
   *  @param  recseps the record  separators
   *  @param  fldseps the field   separators
   *  @param  blanks  the blank   characters
   *  @param  comment the comment characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab, String recseps, String fldseps,
                                       String blanks,  String comment)
  { this.setInput(fn_tab, recseps, fldseps, blanks, comment, 0); }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab  the name of the data table file
   *  @param  recseps the record  separators
   *  @param  fldseps the field   separators
   *  @param  blanks  the blank   characters
   *  @param  comment the comment characters
   *  @param  mode    the read mode
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab, String recseps, String fldseps,
                        String blanks, String comment, int mode)
  {                             /* --- set the table input file */
    this.fn_tab  = fn_tab;
    this.recseps = recseps; this.fldseps = fldseps;
    this.blanks  = blanks;  this.comment = comment;
    this.mode    = mode | Table.NONULLS;
  }  /* setInput() */

  /*------------------------------------------------------------------*/
  /** Set the table reader and read mode.
   *  @param  reader the table reader
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (TableReader reader)
  { this.setInput(reader, 0); }

  /*------------------------------------------------------------------*/
  /** Set the table reader and read mode.
   *  @param  reader the table reader
   *  @param  mode   the read mode
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (TableReader reader, int mode)
  { this.reader = reader; this.mode = mode | Table.NONULLS; }

  /*------------------------------------------------------------------*/
  /** Set the input data table.
   *  @param  tab the input data table
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (Table tab)
  { this.tab = tab; }

  /*------------------------------------------------------------------*/
  /** Set the degree of the regression polynomial.
   *  <p>The default degree is 1.</p>
   *  @param  deg the degree of the regression polynomial
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDegree (int deg)
  { this.deg = deg; }

  /*------------------------------------------------------------------*/
  /** Set the minimum for a logit transformation.
   *  @param  min the maximum for a logit transformation
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMin (double min)
  { this.min = min; }

  /*------------------------------------------------------------------*/
  /** Set the maximum for a logit transformation.
   *  @param  max the maximum for a logit transformation
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMax (double max)
  { this.max = max; }

  /*------------------------------------------------------------------*/
  /** Set the range for a logit transformation.
   *  @param  min the minimum for a logit transformation
   *  @param  max the maximum for a logit transformation
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMinMax (double min, double max)
  { this.min = min; this.max = max; }

  /*------------------------------------------------------------------*/
  /** Set the initial Tikhonov regularization.
   *  @param  reg the initial regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setReg (double reg)
  { this.trp = reg; }

  /*------------------------------------------------------------------*/
  /** Set the limit for the Tikhonov regularization.
   *  @param  lim the limit for the regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setLim (double lim)
  { this.lim = lim; }

  /*------------------------------------------------------------------*/
  /** Set initial value and limit for the Tikhonov regularization.
   *  @param  reg the initial regularization value
   *  @param  lim the limit for the regularization value
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRegLim (double reg, double lim)
  { this.trp = reg; this.lim = lim; }

  /*------------------------------------------------------------------*/
  /** Set the output file.
   *  @param  fn_reg the name of the regression model file
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutput (String fn_reg)
  { this.fn_reg = fn_reg; }

  /*------------------------------------------------------------------*/
  /** Set the output file writer.
   *  @param  writer the output file writer
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutput (Writer writer)
  { this.writer = writer; }

  /*------------------------------------------------------------------*/
  /** Get the induced regression model.
   *  @return the induced regression model
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Regression getRegression ()
  { return this.reg; }

  /*------------------------------------------------------------------*/
  /** Aggregate a table row.
   *  @param  row the table row to write
   *  @param  vec the vector buffer
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private double[] aggregate (int row, double[] vec) throws RegException
  {                             /* --- aggregate a table row */
    vec = this.map.exec(row, vec);
    this.reg.aggregate(vec, 1); /* map and aggregate the table row */
    this.rowcnt++;              /* count the processed row */
    return vec;                 /* return the (new) vector buffer */
  }  /* aggregate() */

  /*------------------------------------------------------------------*/
  /** Induce a regression model.
   *  @throws IOException if an i/o error occurs
   *  @throws RegException if there are too many regression terms
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void induce () throws IOException, RegException
  {                             /* --- induce a regression model */
    int      i, k;              /* loop variable, buffer */
    double[] vec = null;        /* vector for mapping/aggregation */
    long     t   = 0;           /* for time measurements */

    this.stop = false;          /* induction has not been stopped yet */

    /* --- read domain descriptions --- */
    if (this.fn_dom != null) {  /* if a domain file is to be read */
      System.err.print("reading " +this.fn_dom +" ... ");
      t = System.currentTimeMillis();
      if (this.scan == null)    /* create a scanner for the domains */
        this.scan = new Scanner(new FileReader(this.fn_dom));
      this.tab = Table.parse("domains", this.scan);
      if (this.scan.nextToken() != Scanner.T_EOF)
        throw new IOException("garbage at end of domains file "
                              +scan.lno());
      this.scan.close();        /* parse the domain descriptions */
      k = this.tab.getColumnCount();
      i = (this.target == null) /* get the target column index */
        ? k-1 : this.tab.findColumn(this.target);
      if (this.trgid >= 0) i = this.trgid;
      this.target = this.tab.getColumnName(i);
      if (i < 0) throw new IOException("unknown target: " +this.target);
      this.map = new TableMapper(tab);    /* create a table mapper */
      this.map.setTarget(i);    /* and set the target column in it */
      if (this.map.getOutputCount() != 1)
        throw new IOException("illegal target: " +this.target);
      if (this.map.getInOutCount()  <  2)
        throw new IOException("too few variables (need at least 2)");
      System.err.print("[" +k +" variable(s)] ");
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/1000.0) +"s].");
    }

    /* --- create and configure table scanner --- */
    if (this.fn_tab != null) {  /* if to read a table file */
      System.err.print("reading " +this.fn_tab +" ... ");
      t = System.currentTimeMillis();
      if (this.reader == null){ /* if there is no table reader */
        this.reader = new TableReader(new FileReader(this.fn_tab));
        this.reader.setChars(this.recseps, this.fldseps,
                             this.blanks, "", this.comment);
      }                         /* create a table scanner */
    }                           /* and configure it */

    /* --- induce a regression model --- */
    this.reg = new Regression(this.map, this.deg);
    this.reg.setMinMax(this.min, this.max);
    this.reg.setRegLim(this.trp, this.lim);
    this.rowcnt = 0;            /* initialize the row counter */
    if (this.reader == null) {  /* if direct induction from a table */
      if (this.tab == null)     /* get the table from the mapper */
        this.tab = this.map.getTable();
      for (i = k = this.tab.getRowCount(); --i >= 0; ) {
        if (this.stop) return;  /* traverse the table rows */
        vec = this.aggregate(i, vec);
      } }                       /* map and aggregate the rows */
    else {                      /* if to read data from a stream */
      this.tab.readHeader(this.reader, this.mode);
      this.tab.resize(1);       /* read the table header */
      while (this.tab.readRow(0, this.reader, this.mode)) {
        if (this.stop) return;  /* while there is another record */
        vec = this.aggregate(0, vec);
      }                         /* read the next record and */
    }                           /* aggregate it for the regression */

    /* --- finish reading the table file --- */
    if (this.fn_tab != null) {  /* if to read a table file */
      System.err.print("[" +this.rowcnt +" row(s)] ");
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/1000.0) +"s].");
    }                           /* write a log message */

    /* --- compute regression coefficients --- */
    System.err.print("computing regression ... ");
    t = System.currentTimeMillis();
    this.reg.solve();           /* solve the regression eq. system */
    System.err.print("[sse: " +(float)this.reg.getSSE() + "] ");
    t = System.currentTimeMillis() -t;
    System.err.println("done [" +(t/1000.0) +"s].");

    /* --- write the regression result --- */
    if (this.fn_reg != null) {  /* if a file name is given */
      System.err.print("writing " +this.fn_reg +" ... ");
      t = System.currentTimeMillis();
      if (this.writer == null)  /* open the output file */
        this.writer = new FileWriter(this.fn_reg);
    }
    this.writer.write(this.reg.getDomains().toString());
    this.writer.write('\n');    /* write the domain descriptions */
    this.writer.write(this.reg.toString());
    this.writer.close();        /* write the regression model */
    if (this.fn_reg != null) {  /* if a file name is given */
      System.err.print("[" +this.reg.getCoeffCount() +" parameters] ");
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/1000.0) +"s].");
    }                           /* write a log message */
  }  /* induce() */

  /*------------------------------------------------------------------*/
  /** Execute the model induction.
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void exec () throws Exception
  { this.induce(); }

  /*------------------------------------------------------------------*/
  /** Abort a regression model induction.
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void abort ()
  { this.stop = true; }

  /*------------------------------------------------------------------*/
  /** Get the number of processed table rows.
   *  @return the number of processed table rows
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return this.rowcnt; }

  /*------------------------------------------------------------------*/
  /** Get the number of processed table rows.
   *  @return the number of processed table rows
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static int getDblVec (String s, double[] vec)
  {                             /* --- get vector of doubles */
    int    i, k;                /* loop variables */
    String t;                   /* buffer for a string */

    for (i = 0; i < s.length()-1; i++) {
      k = s.indexOf(':');       /* traverse the vector elements */
      if (k < 0) break;         /* if only one element left */
      vec[i] = Double.parseDouble(s.substring(0, k));
      s = s.substring(k+1);     /* parse a vector element */
    }                           /* and reduce the string */
    vec[i] = Double.parseDouble(s);
    return i+1;                 /* parse the last vector element */
  }  /* getDblVec() */

  /*------------------------------------------------------------------*/
  /** Main function for command line execution.
   *  @param  args the command line arguments
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- test function */
    int    i, k = 0, n;         /* loop variables */
    String s;                   /* to traverse the arguments */
    String fn_dom  = null;      /* name of the domain decs. file */
    String fn_tab  = null;      /* name of the data table file */
    String fn_reg  = null;      /* name of the regression model file */
    String target  = null;      /* name of the target column */
    String blanks  = null;      /* blank   characters */
    String fldseps = null;      /* field   separators */
    String recseps = null;      /* record  separators */
    String comment = null;      /* comment characters */
    int    deg     =  1;        /* degree of regression polynomial */
    double logit[] = { 0, 0 };  /* range for logit transformation */
    double trpar[] = { 0, 0 };  /* regularization parameters */
    int    mode    =  0;        /* read mode for the data */
    double x;                   /* exchange buffer */
    RegInducer ind;             /* inducer for the regression model */

    if (args.length > 0) {      /* if no arguments are given */
      System.err.print  (RegInducer.class.getName());
      System.err.println(" - " +DESCRIPTION);
      System.err.println("version " +VERSION +"    " +COPYRIGHT); }
    else {                      /* if no arguments are given */
      System.out.println("usage: java " +RegInducer.class.getName()
                        +" [options] domfile tabfile regfile");
      System.out.println("-o#      output/target attribute name     "
                                + "(default: last attribute)");
      System.out.println("-x#      degree of regression polynomial  "
                                + "(default: " +deg +")");
      System.out.println("-l#[:#]  range for logit transformation   "
                                + "(default: normal regression)");
      System.out.println("-t#[:#]  regularization parameters        "
                        +"(default: "+trpar[0]+":"+trpar[1]+")");
      System.out.println("-b#      blank   characters               "
                                + "(default: \" \\t\\r\")");
      System.out.println("-f#      field   separators               "
                                + "(default: \" ,\\t\")");
      System.out.println("-r#      record  separators               "
                                + "(default: \"\\n\")");
      System.out.println("-C#      comment characters               "
                                + "(default: \"#\")");
      System.out.println("-d       use default field names          "
                                + "(default: read from file)");
      System.out.println("domfile  file containing "
                                + "domain descriptions");
      System.out.println("tabfile  table file to read "
                                + "(field names in first record)");
      System.out.println("regfile  file to write "
                                + "the regression model to");
      return;                   /* print a usage message */
    }                           /* and abort the program */

    for (i = 0; i < args.length; i++) {
      s = args[i];              /* traverse the arguments */
      if ((s.length() > 0)      /* if the argument is an option */
      &&  (s.charAt(0) == '-')) {
        switch (s.charAt(1)) {  /* evaluate option */
          case 'x': deg     = Integer.parseInt(s.substring(2)); break;
          case 'l': getDblVec(s.substring(2), logit);           break;
          case 't': getDblVec(s.substring(2), trpar);           break;
          case 'o': target  = s.substring(2);                   break;
          case 'b': blanks  = s.substring(2);                   break;
          case 'f': fldseps = s.substring(2);                   break;
          case 'r': recseps = s.substring(2);                   break;
          case 'C': comment = s.substring(2);                   break;
          case 'd': mode   |= Table.NOHEADER;                   break;
          default : System.err.print("Error: unknown option -");
                    System.err.println(s.charAt(1)); return;
        } }
      else {                    /* if the argument is no option */
        switch (k++) {          /* evaluate non-option */
          case  0: fn_dom = s; break;
          case  1: fn_tab = s; break;
          case  2: fn_reg = s; break;
          default: System.err.println("too many arguments"); return;
        }                       /* there should be three fixed args. */
      }
    }
    if (k != 3) {               /* check the number of arguments */
      System.err.println("wrong number of arguments"); return; }
    if (logit[0] > logit[1]) {  /* ensure a proper range */
      x = logit[0]; logit[0] = logit[1]; logit[1] = x; }
    try {                       /* build regression model */
      ind = new RegInducer();   /* create an reg. model inducer */
      ind.setDomains(fn_dom);   /* and configure it */
      ind.setTarget(target);
      ind.setInput(fn_tab, ASCIICoder.decode(recseps),
                           ASCIICoder.decode(fldseps),
                           ASCIICoder.decode(blanks),
                           ASCIICoder.decode(comment), mode);
      ind.setDegree(deg);
      ind.setMinMax(logit[0], logit[1]);
      ind.setRegLim(trpar[0], trpar[1]);
      ind.setOutput(fn_reg);
      ind.induce(); }           /* finally execute the inducer */
    catch (IOException e) {     /* check for an error */
      System.out.println("\n" +e.getMessage()); return; }
    catch (RegException e) {    /* check for an error */
      System.out.println("\n" +e.getMessage()); return; }
  }  /* main() */

}  /* class RegInducer */
