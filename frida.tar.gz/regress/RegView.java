/*----------------------------------------------------------------------
  File    : RegView.java
  Contents: frame class for a regression model viewer
  Author  : Christian Borgelt
  History : 2007.03.19 file created
            2007.05.21 viewing parameters extended (zero exponents)
            2007.06.07 loading and saving simplified
            2014.10.23 changed from LGPL license to MIT license
----------------------------------------------------------------------*/
package regress;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.BorderFactory;

import util.Scanner;
import table.Table;
import dialog.DialogPanel;
import dialog.AboutDialog;

/*--------------------------------------------------------------------*/
/** Class for a regression model.
 *  @author Christian Borgelt
 *  @since  2007.03.19 */
/*--------------------------------------------------------------------*/
public class RegView extends JFrame implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010004L;
  public  static final String VERSION = "1.4 (2014.10.23)";

  /** mode flag: the viewer is a stand-alone program */
  public final static int PROGRAM    = 1;
  /** mode flag: add menu items for loading tables */
  public final static int LOAD_ITEMS = 2;
  /** mode flag: add menu items for saving  tables */
  public final static int SAVE_ITEMS = 4;
  /** mode flag: add menu items for loading and saving tables */
  public final static int FILE_ITEMS = LOAD_ITEMS | SAVE_ITEMS;
  /** mode flag: all optional menu items */
  public final static int ALL_ITEMS  = FILE_ITEMS;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this table viewer */
  private Component    owner   = null;
  /** the mode flags */
  private int          mode    = 0;
  /** the displayed regression model */
  private Regression   reg     = null;
  /** whether to show zero exponents */
  private boolean      zeros   = false;
  /** the minimum absolute value of a coefficient */
  private double       eps     = 1e-6;
  /** the context sensitive menu items */
  private JMenuItem[]  items   = null;
  /** the scroll pane for the viewport */
  private JScrollPane  scroll  = null;
  /** the table view */
  private JTable       view    = null;
  /** the status bar for messages */
  private JTextField   stat    = null;
  /** the file chooser */
  private JFileChooser chooser = null;
  /** the current regression model file */
  private File         curr    = null;
  /** the dialog for setting viewing parameters */
  private JDialog      params  = null;
  /** the check box for zero exponents treatment  */
  private JCheckBox    zerocb  = null;
  /** the text field for setting epsilon */
  private JTextField   epstxt  = null;
  /** the "About..." dialog box */
  private AboutDialog  about   = null;

  /*------------------------------------------------------------------*/
  /** Create a regression model viewer.
   *  @param  mode the mode flags
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RegView (int mode)
  {                             /* --- create a regression viewer */
    this.owner = null;          /* clear the owner and */
    this.mode  = mode;          /* note the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* RegView() */

  /*------------------------------------------------------------------*/
  /** Create a regression model viewer.
   *  @param  owner the component that is to own this viewer
   *  @param  mode  the mode flags
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RegView (Component owner, int mode)
  {                             /* --- create a regression viewer */
    this.owner = owner;         /* note the owner */
    this.mode  = mode;          /* and the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* RegView() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    if ((this.mode & PROGRAM) != 0)
      this.mode |= LOAD_ITEMS;  /* check and adapt the mode */
    this.items = new JMenuItem[2];

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    if ((this.mode & LOAD_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Load Regression...", 'l'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          RegView.this.loadRegression(null); } } );
      item = menu.add(new JMenuItem("Reload Regression", 'r'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          RegView.this.loadRegression(RegView.this.curr); } } );
      menu.addSeparator();
    }
    if ((this.mode & SAVE_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Save Regression...", 's'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          RegView.this.saveRegression(RegView.this.curr); } } );
      this.items[0] = item; item.setEnabled(false);
      item = menu.add(new JMenuItem("Save Regression As...", 'a'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          RegView.this.saveRegression(null); } } );
      this.items[1] = item; item.setEnabled(false);
      menu.addSeparator();
    }
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item = menu.add(new JMenuItem("Quit", 'q'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item = menu.add(new JMenuItem("Quit", 'q'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          RegView.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("View"));
    menu.setMnemonic('v');
    item = menu.add(new JMenuItem("Set Parameters...", 'e'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        RegView.this.getParamsDlg().setVisible(true);
        RegView.this.params.toFront();
      } } );

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (RegView.this.about == null)
          RegView.this.about = new AboutDialog(RegView.this,
             "About RegView...", "RegView\n"
            +"A Simple Regression Model Viewer\n"
            +"Version " +RegView.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        RegView.this.about.setVisible(true);
        RegView.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    this.view   = new JTable(); /* create a table viewer */
    this.scroll = new JScrollPane(this.view);
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(this.scroll, BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    this.stat = new JTextField("");
    this.stat.setEditable(false);
    content.add(this.stat,   BorderLayout.SOUTH);

    /* --- configure and show the frame window --- */
    this.setTitle("RegView");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser (create if necessary).
   *  @return the file chooser
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure file chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Get the viewing parameters dialog.
   *  @return the viewing parameters dialog
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getParamsDlg ()
  {                             /* --- get viewing parameters dialog */
    DialogPanel tab;            /* panel for the dialog fields */
    JPanel      bbar;           /* panel for the button bar */
    JButton     button;         /* button for apply and close */

    if (this.params != null)    /* if the dialog box exists, */
      return this.params;       /* simply return it */
    this.params = new JDialog(this);
    tab = new DialogPanel();    /* create the main panel */

    tab.addLabel("Show zero exponents:");
    this.zerocb = tab.addCheckBox(false);

    tab.addLabel("Epsilon for coefficients:");
    this.epstxt = tab.addNumberInput(String.valueOf(this.eps));
    tab.addHelp("All coefficients with an absolute value\n"
               +"less than epsilon will not be displayed.");

    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegView.this.setZeros(RegView.this.zerocb.isSelected());
        try { double eps =
                Double.parseDouble(RegView.this.epstxt.getText());
              RegView.this.setEpsilon(eps); }
        catch (NumberFormatException x) { };
      } } );                    /* set the new layout parameters */
    bbar.add(button = new JButton("Close"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegView.this.params.setVisible(false); } } );

    this.params.getContentPane().add(tab,  BorderLayout.CENTER);
    this.params.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.params.setTitle("Set Parameters...");
    this.params.setLocationRelativeTo(this);
    this.params.pack();
    return this.params;
  }  /* getParams() */

  /*------------------------------------------------------------------*/
  /** Set the message to display in the status line.
   *  @param  msg the message to display
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.stat.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Set the regression model to display.
   *  @param  reg the regression model to display
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRegression (Regression reg)
  {                             /* --- set the regression to display */
    Table     table;            /* regression model as a table */
    Dimension size;             /* size of the table view */

    this.reg = reg;             /* store the new regression model */
    this.view.setModel(table = reg.getAsTable(this.zeros, this.eps));
    size = this.view.getPreferredSize();
    if (size.width  > 400) size.width  = 400;
    if (size.height > 400) size.height = 400;
    this.view.setPreferredScrollableViewportSize(size);
    this.pack();                /* re-layout the window */
    for (int i = this.items.length; --i >= 0; )
      if (this.items[i] != null)/* enable/disable menu items */
        this.items[i].setEnabled(reg != null);
    this.stat.setText("regression for " +table.getName());
  }  /* setRegression() */

  /*------------------------------------------------------------------*/
  /** Set the flag for zero exponents.
   *  @param  zeros whether to display zero exponents
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setZeros (boolean zeros)
  {                             /* --- set zero exponents flag */
    if (zeros != this.zeros) {  /* if the flag has changed, */
      this.zeros = zeros;       /* note the new flag value */
      this.setRegression(this.reg);
    }                           /* update the display */
    if (this.zerocb != null)    /* update the dialog box */
     this.zerocb.setSelected(zeros);
  }  /* setZeros() */

  /*------------------------------------------------------------------*/
  /** Set the epsilon for the coefficient display.
   *  @param  eps the epsilon for the coefficient display
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setEpsilon (double eps)
  {                             /* --- set epsilon for coefficients */
    if (eps != this.eps) {      /* if the epsilon has changed, */
      this.eps = eps;           /* note the new epsilon value */
      this.setRegression(this.reg);
    }                           /* update the display */
    if (this.epstxt != null)    /* update the dialog box */
      this.epstxt.setText(String.valueOf(eps));
  }  /* setEpsilon() */

  /*------------------------------------------------------------------*/
  /** Get the currently displayed regression model.
   *  @return the currently displayed regression model
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Regression getRegression ()
  { return this.reg; }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void reportError (String msg)
  {                             /* --- report an i/o error */
    this.stat.setText(msg);     /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this, msg,
      "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load the regression model to display.
   *  @param  file the file to load the regression model from
   *  @return whether the file was successfully loaded
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadRegression (File file)
  {                             /* --- load a regression model */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a scanner for the file */
      System.err.print("reading " +file +" ... ");
      Scanner    scan = new Scanner(new FileReader(file));
      Regression treg = Regression.parse(scan, null);
      scan.close();             /* parse the regression model */
      this.setRegression(treg); /* and set it for display */
      System.err.print("[" +treg.getCoeffCount());
      System.err.println(" coefficient(s)] done."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.stat.setText(this.stat.getText() +" (" +file.getPath() +")");
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadRegression() */

  /*------------------------------------------------------------------*/
  /** Save the displayed regression model.
   *  @param  file the file to save the regression model to
   *  @return whether the file was successfully saved
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveRegression (File file)
  {                             /* --- save the displayed regression */
    if (this.reg == null)       /* if there is no regression model */
      return false;             /* simply abort the function */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* load the regression model */
      System.err.print("writing " +file +" ... ");
      FileWriter writer = new FileWriter(file);
      writer.write(this.reg.toString());
      writer.close();           /* write the regression to a file */
      System.err.print("[" +this.reg.getCoeffCount());
      System.err.println(" coefficient(s)] done."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.curr = file;           /* note the new file name */
    return true;                /* return 'saving successful' */
  }  /* saveRegression() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    RegView rv = new RegView(PROGRAM|ALL_ITEMS);
    if (args.length > 0) rv.loadRegression(new File(args[0]));
    rv.setVisible(true);        /* create and show regression viewer */
  }  /* main() */

}  /* class RegView */
