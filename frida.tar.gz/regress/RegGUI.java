/*----------------------------------------------------------------------
  File    : RegGUI.java
  Contents: multivariate polynomial regression graphical user interface
  Author  : Christian Borgelt
  History : 2007.03.19 file created
            2007.05.17 optional use of external programs added
            2007.06.05 numeric inputs changed to JFormattedTextField
            2007.07.07 adapted to new class DialogPanel
            2013.08.06 bugs in functions create..Obj() fixed (getMode)
            2014.10.23 terminal added, changed from LGPL to MIT license
            2018.11.14 replaced some deprecated functions
----------------------------------------------------------------------*/
package regress;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JSpinner;

import util.Executable;
import util.Executor;
import util.ObjExecutor;
import util.CmdExecutor;
import dialog.TabbedGUI;
import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.DomainsPanel;
import dialog.AboutPanel;

/*--------------------------------------------------------------------*/
/** Class for a user interface to the regression program.
 *  @author Christian Borgelt
 *  @since  2007.03.19 */
/*--------------------------------------------------------------------*/
public class RegGUI extends TabbedGUI {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00020009L;
  public  static final String VERSION = "2.9 (2018.11.14)";

  /** tab index: domain determination */
  private static final int DOMAINS   = 1;
  /** tab index: regression model induction */
  private static final int INDUCTION = 2;
  /** tab index: regression model execution */
  private static final int EXECUTION = 4;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /* --- induction --- */
  /** the domain description file to read */
  private JTextField fn_dom  = null;
  /** the table file to read */
  private JTextField fn_tab  = null;
  /** the target column name */
  private JTextField target  = null;
  /** the regression model file to write */
  private JTextField fn_reg  = null;

  /* --- parameters --- */
  /** the degree of the polynomial (highest sum of exponents) */
  private JSpinner   degree  = null;
  /** the minimum for a logit transformation */
  private JTextField min     = null;
  /** the maximum for a logit transformation */
  private JTextField max     = null;
  /** the initial value for a Tikhonov regularization */
  private JTextField reg     = null;
  /** the limit   value for a Tikhonov regularization */
  private JTextField lim     = null;
  /** the limit   value for a Tikhonov regularization */
  private JCheckBox  logreg  = null;

  /* --- execution --- */
  /** the input table file to read */
  private JTextField fn_in   = null;
  /** the regression model file to execute */
  private JTextField fn_exe  = null;
  /** the prediction field name */
  private JTextField pred    = null;
  /** the confidence field name */
  private JTextField conf    = null;
  /** the classification threshold */
  private JTextField thresh  = null;
  /** the output table file to write */
  private JTextField fn_out  = null;

  /*------------------------------------------------------------------*/
  /** Create a multivariate polynomial regression GUI.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RegGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a multivariate polynomial regression GUI.
   *  @param  owner the component that is to own this dialog
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RegGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    DialogPanel tab;            /* current tab of the tabbed pane */
    JPanel      bar;            /* bar of input fields */
    Component   c;              /* buffer for components */

    /* --- basic tabs --- */
    this.base("Multivariate Polynomial Regression Tools");
    this.addFormatTab (FormatPanel.HEADER
                     | FormatPanel.NONULLS);
    this.addDomainsTab(DomainsPanel.EXTERNAL
                     | DomainsPanel.LOCATE).setExternal(false);

    /* --- Induction --- */
    tab = this.addTab("Induction");

    tab.addLabel("Domains file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.getFileName(RegGUI.this.fn_dom); } } );
    tab.addButton("Edit", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.editDomains(RegGUI.this.fn_dom); } } );
    this.fn_dom = tab.addFileInput("noname.dom");

    tab.addLabel("Data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.getFileName(RegGUI.this.fn_tab); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.showTable(RegGUI.this.fn_tab); } } );
    this.fn_tab = tab.addFileInput("noname.tab");

    tab.addLabel("Target attribute:");
    this.target = tab.addTextInput("");
    tab.addHelp("The target attribute must be metric or binary. "
               +"If no target is\nspecified, the attribute "
               +"listed last in the domains file is used.");

    tab.addLabel("Regression model file:  ");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.getFileName(RegGUI.this.fn_reg); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.showRegression(RegGUI.this.fn_reg); } } );
    this.fn_reg = tab.addFileInput("noname.reg");
    tab.addFiller(0);

    /* --- Parameters --- */
    tab = this.addTab("Parameters");

    tab.addLabel("Degree of polynomial:");
    this.degree = tab.addSpinner(1, 0, 32, 1);

    tab.addLabel("Logit transformation:");
    bar = new JPanel(new GridLayout(1, 2, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.min = DialogPanel.createNumberInput(""));
    this.min.setFont(DialogPanel.BOLD);
    bar.add(this.max = DialogPanel.createNumberInput(""));
    this.max.setFont(DialogPanel.BOLD);
    tab.addHelp("Range for a logit transformation "
               +"of the target attribute.\nIf applicable, "
               +"this allows for a logistic regression in one step.\n"
               +"If not specified, "
               +"the target attribute is not transformed.");

    /* >>> activate the following once implemented in Java */
    c = tab.addLabel("Logistic regression:");
    c.setVisible(false);
    this.logreg = tab.addCheckBox(false);
    this.logreg.setVisible(false);
    c = tab.addHelp("Compute a logistic regression maximizing "
                   +"data likelihood;\n"
                   +"starting from a linear/polynomial regression "
                   +"(for two classes).\n"
                   +"If active, the above transformation is linear "
                   +"rather than logit.");
    c.setVisible(false);

    tab.addLabel("Regularization:");
    bar = new JPanel(new GridLayout(1, 2, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.reg = DialogPanel.createNumberInput("-0.001"));
    this.reg.setFont(DialogPanel.BOLD);
    bar.add(this.lim = DialogPanel.createNumberInput("1"));
    this.lim.setFont(DialogPanel.BOLD);
    tab.addHelp("Initial and limiting regularization value "
               +"(eigenvalue shifting).\n"
               +"If the initial value is negative, regularization "
               +"is only applied\nif needed (that is, only if a "
               +"Cholesky decomposition of the\ncoefficient matrix "
               +"fails). If the initial value is positive, it is\n"
               +"always applied before a Cholesky decomposition.");
    tab.addFiller(0);

    /* --- Execution --- */
    tab = this.addTab("Execution");

    tab.addLabel("Regression model file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.getFileName(RegGUI.this.fn_exe); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.showRegression(RegGUI.this.fn_exe); } } );
    this.fn_exe = tab.addFileInput("noname.reg");

    tab.addLabel("Input data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.getFileName(RegGUI.this.fn_in); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.showTable(RegGUI.this.fn_in); } } );
    this.fn_in = tab.addFileInput("noname.tab");

    tab.addLabel("Prediction field name:");
    this.pred = tab.addTextInput("reg");
    tab.addLabel("Confidence field name:");
    this.conf = tab.addTextInput("");
    tab.addHelp("A confidence can be computed only for "
               +"a binary target.\nIt indicates how reliable "
               +"the classification is.");

    tab.addFiller(3);
    tab.addLabel("Classification threshold:");
    this.thresh = tab.addNumberInput("0.5");
    tab.addHelp("A classification threshold is used only "
               +"for a binary target.");

    tab.addFiller(3);
    tab.addLabel("Output data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.getFileName(RegGUI.this.fn_out); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RegGUI.this.showTable(RegGUI.this.fn_out); } } );
    this.fn_out = tab.addFileInput("noname.out");
    tab.addFiller(0);

    /* --- Terminal --- */
    this.addTerminalTab("Terminal output of external programs");

    /* --- about --- */
    this.addTab("About", new AboutPanel(
       "Multivariate Polynomial Regression Tools",
       "A simple user interface for the regression program.\n\n"
      +"Version " +RegGUI.VERSION +"\n"
      +"written by Christian Borgelt\n"
      +"European Center for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.pack();
    this.selectTab(INDUCTION);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  {                             /* --- set the domains file */
    this.domains.setDomainsFile(file);
    this.fn_dom.setText(file.getPath());
  }  /* setDomainsFile() */

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  {                             /* --- set the data file */
    this.domains.setDataFile(file);
    this.fn_tab.setText(file.getPath());
  }  /* setDataFile() */

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  { this.fn_in.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Show a regression model.
   *  @param  txt the text field containing the file name
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showRegression (JTextField txt)
  { this.showRegression(new File(txt.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a regression model.
   *  @param  file the file to load the regression model from
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showRegression (File file)
  {                             /* --- show a decision tree */
    RegView view = new RegView(this, RegView.FILE_ITEMS);
    if (!view.loadRegression(file)) return;
    view.setVisible(true); view.toFront();
  }  /* showRegression() */

  /*------------------------------------------------------------------*/
  /** Create a command for inducing a regression model.
   *  @return a command for inducing a regression model
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String[] createInducerCmd ()
  {                             /* --- create an inducer command */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s, t;              /* buffer for arguments */

    cmd    = new String[32];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"mpr";
    n = this.format.addFormatArgs(cmd, FormatPanel.HEADER);
    s = this.target.getText();  /* target attribute */
    if (s.length() > 0) cmd[n++] = "-o" +s;
    cmd[n++] = "-x" +this.degree.getValue();
    s = this.min.getText().trim(); /* degree of polynomial and */
    t = this.max.getText().trim(); /* range for logit transformation */
    if ((s.length() > 0) && (t.length() > 0)) {
      try { cmd[n++] = "-l" +Double.parseDouble(s)
                     +  ":" +Double.parseDouble(t); }
      catch (NumberFormatException e) { } }
    else if (t.length() > 0) {
      try { cmd[n++] = "-l" +Double.parseDouble(t); }
      catch (NumberFormatException e) { }
    }                           /* range for logit transformation */
    s = this.reg.getText().trim(); /* degree of polynomial and */
    t = this.lim.getText().trim(); /* range for logit transformation */
    if ((s.length() > 0) && (t.length() > 0)) {
      try { cmd[n++] = "-t" +Double.parseDouble(s)
                     +  ":" +Double.parseDouble(t); }
      catch (NumberFormatException e) { } }
    else if (s.length() > 0) {
      try { cmd[n++] = "-t" +Double.parseDouble(s); }
      catch (NumberFormatException e) { }
    }                           /* range for logit transformation */
    cmd[n++] = this.fn_dom.getText();
    cmd[n++] = this.fn_tab.getText();
    cmd[n++] = this.fn_reg.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createInducerCmd() */

  /*------------------------------------------------------------------*/
  /** Create a regression model inducer.
   *  @return a regression model inducer
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executable createInducerObj ()
  {                             /* --- create reg. model inducer */
    RegInducer ind;             /* created regression model inducer */
    String     txt;             /* buffer for an input text */

    ind = new RegInducer();     /* create a regression model inducer */
    ind.setDomains(this.fn_dom.getText());
    ind.setInput  (this.fn_tab.getText(),
                   this.format.getRecSeps(),
                   this.format.getFldSeps(),
                   this.format.getBlanks(),
                   this.format.getComment(),
                   this.format.getTableMode());
    ind.setDegree (((Integer)this.degree.getValue()).intValue());
    ind.setOutput (this.fn_reg.getText());
    txt = this.target.getText();
    if (txt.length() > 0) ind.setTarget(txt);
    txt = this.min.getText();
    try { if (txt.length() > 0) ind.setMin(Double.parseDouble(txt)); }
    catch (NumberFormatException e) { ind.setMin(0); }
    txt = this.max.getText();
    try { if (txt.length() > 0) ind.setMax(Double.parseDouble(txt)); }
    catch (NumberFormatException e) { ind.setMax(0); }
    return ind;                 /* return the created inducer */
  }  /* createInducerObj() */

  /*------------------------------------------------------------------*/
  /** Create a command for applying a regression model.
   *  @return a command for applying a regression model
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String[] createApplierCmd ()
  {                             /* --- create an applier command */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[16];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"mpx";
    n = this.format.addFormatArgs(cmd, FormatPanel.HEADER);
    s = this.pred.getText();    /* prediction field name */
    if (s.length() <= 0) this.pred.setText(s = "reg");
    cmd[n++] = "-p" +s;
    s = this.conf.getText();    /* confidence field name */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    s = this.thresh.getText().trim();  /* classification threshold */
    try { if (s.length() > 0) cmd[n++] = "-t" +Double.parseDouble(s); }
    catch (NumberFormatException e) { }
    cmd[n++] = this.fn_exe.getText();
    cmd[n++] = this.fn_in.getText();
    s = this.fn_out.getText();  /* add output only if not empty */
    if (s.length() > 0) cmd[n++] = s;
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createApplierCmd() */

  /*------------------------------------------------------------------*/
  /** Create a regression model inducer.
   *  @return a regression model inducer
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executable createApplierObj ()
  {                             /* --- create reg. model inducer */
    RegApplier app;             /* created regression model applier */
    String     txt;             /* buffer for an input text */

    app = new RegApplier();     /* create a regression model applier */
    app.setRegression(this.fn_exe.getText());
    app.setInput     (this.fn_in.getText(),
                      this.format.getRecSeps(),
                      this.format.getFldSeps(),
                      this.format.getBlanks(),
                      this.format.getComment(),
                      this.format.getTableMode());
    app.setOutput    (this.fn_out.getText());
    txt = this.pred.getText();
    if (txt.length() <= 0) this.pred.setText(txt = "reg");
    app.setPredName  (txt);
    app.setConfName  (this.conf.getText());
    txt = this.thresh.getText();
    try { if (txt.length() > 0)
            app.setThreshold(Double.parseDouble(txt)); }
    catch (NumberFormatException e) { }
    return app;                 /* return the created applier */
  }  /* createApplierObj() */

  /*------------------------------------------------------------------*/
  /** Get the executor for a dialog tab.
   *  @param  i the index of the dialog tab
   *  @return the executor for the <code>i</code>-th dialog tab
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- get the executor for a tab */
    String[]   cmd;             /* command for external program */
    Executable obj;             /* executable object */

    if (this.domains.useExternal()) {
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS  : cmd = this.createDomainsCmd(); break;
        case INDUCTION: cmd = this.createInducerCmd(); break;
        case EXECUTION: cmd = this.createApplierCmd(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new CmdExecutor(cmd, this); }
    else {                      /* if to use internal programs */
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS  : obj = this.createDomainsObj(); break;
        case INDUCTION: obj = this.createInducerObj(); break;
        case EXECUTION: obj = this.createApplierObj(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new ObjExecutor(obj, this);
    }                           /* create and return the executor */
  }  /* createExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    int        i, k;            /* index variables */
    String     txt, msg;        /* buffers for messages */
    RegInducer ind;             /* regression model inducer */
    RegApplier app;             /* regression model applier */
    Regression reg;             /* regression model */
    double     sse;             /* sum of squared errors */

    if (this.index == DOMAINS)  /* if domain determination */
      return this.getDomainsMsg();

    if (this.index == INDUCTION) { /* if regression model induction */
      if (this.executor instanceof CmdExecutor) {
        txt = ((CmdExecutor)this.executor).getErrorData();
        i   = txt.lastIndexOf("[", txt.indexOf("parameters]"));
        k   = txt.indexOf("]", i); /* extract parameter report */
        msg = txt.substring(i+1, k);
        i   = txt.lastIndexOf("[sse: ");
        k   = txt.indexOf("]", i);
        txt = txt.substring(i+6, k); }
      else {                    /* if internal routines used */
        ind = (RegInducer)((ObjExecutor)this.executor).getObject();
        reg = ind.getRegression();/* get the induced reg. model */
        msg = reg.getCoeffCount() +" parameters";
        txt = (float)reg.getSSE() +"";
      }                         /* get number of coeffs. and SSE */
      return "Created regression model has " +msg
            +"\n(sum of squared errors: " +txt +").";
    }                           /* build the result message */

    if (this.index == EXECUTION) { /* if regression model execution */
      if (this.executor instanceof CmdExecutor)
        msg = ((CmdExecutor)this.executor).getLastErrorLine();
      else {                    /* if internal routines used */
        app = (RegApplier)((ObjExecutor)this.executor).getObject();
        k   = app.getRowCount();
        i   = app.getErrors();  /* get number of misclassifications */
        if (i >= 0) {           /* if binary target, */
          msg = i +"error(s)";  /* compute error rate */
          if (k > 0) msg += " (" +(float)(100.0 *i/k) +"%)"; }
        else {                  /* if metric target */
          sse = app.getSSE();   /* get the sum of squared errors */
          if (sse < 0) return "Regression execution successful.";
          msg = "sse: " +(float)sse;
          if (k > 0) msg += ", mse: " +(float)(sse/k)
                         + ", rmse: " +(float)Math.sqrt(sse/k);
        }                       /* format the error information */
      }
      return "Regression model execution leads to\n" +msg +".";
    }                           /* build the result message */
    return null;                /* otherwise there is no message */
  }  /* getResultMsg() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  {                             /* --- load configuration file */
    if (file == null) {         /* if no file name is given */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Load Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileReader reader = new FileReader(file);
      /* --- Format & Domains --- */
      this.format.loadConfig(reader);
      this.domains.loadConfig(reader);
      /* --- text parameters --- */
      /* --- Induction --- */
      this.fn_dom.setText(this.readLine(reader));
      this.fn_tab.setText(this.readLine(reader));
      this.fn_reg.setText(this.readLine(reader));
      this.target.setText(this.readLine(reader));
      /* --- Induction --- */
      this.min.setText   (this.readLine(reader));
      this.max.setText   (this.readLine(reader));
      this.reg.setText   (this.readLine(reader));
      this.lim.setText   (this.readLine(reader));
      /* --- Execution --- */
      this.fn_in.setText (this.readLine(reader));
      this.fn_exe.setText(this.readLine(reader));
      this.fn_out.setText(this.readLine(reader));
      this.pred.setText  (this.readLine(reader));
      this.conf.setText  (this.readLine(reader));
      this.thresh.setText(this.readLine(reader));
      /* --- flags and indices --- */
      /* --- Induction --- */
      this.degree.setValue(Integer.valueOf(this.readInt(reader)));
      this.logreg.setSelected(this.readInt(reader) != 0);
      reader.close(); }         /* read the configuration values */
    catch (IOException e) {     /* and close the input file */
      JOptionPane.showMessageDialog(this,
        "Error reading configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* check for successful reading */
    this.status.setText("configuration loaded: " +file.getName());
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  {                             /* --- save configuration file */
    if (file == null) {         /* if no file name is given, */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Save Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileWriter writer = new FileWriter(file);
      /* --- Format & Domains --- */
      this.format.saveConfig(writer);
      this.domains.saveConfig(writer);
      /* --- text parameters --- */
      /* --- Induction --- */
      writer.write(this.fn_dom.getText()); writer.write('\n');
      writer.write(this.fn_tab.getText()); writer.write('\n');
      writer.write(this.fn_reg.getText()); writer.write('\n');
      writer.write(this.target.getText()); writer.write('\n');
      /* --- Parameters --- */
      writer.write(this.min.getText());    writer.write('\n');
      writer.write(this.max.getText());    writer.write('\n');
      writer.write(this.reg.getText());    writer.write('\n');
      writer.write(this.lim.getText());    writer.write('\n');
      /* --- Execution --- */
      writer.write(this.fn_in.getText());  writer.write('\n');
      writer.write(this.fn_exe.getText()); writer.write('\n');
      writer.write(this.fn_out.getText()); writer.write('\n');
      writer.write(this.pred.getText());   writer.write('\n');
      writer.write(this.conf.getText());   writer.write('\n');
      writer.write(this.thresh.getText()); writer.write('\n');
      /* --- flags and indices --- */
      /* --- Parameters --- */
      writer.write(((Integer)this.degree.getValue()).intValue() +",");
      writer.write(this.logreg.isSelected() ? "1," : "0,");
      writer.write('\n');       /* write the configuration values */
      writer.close(); }         /* and close the output file */
    catch (IOException e) {     /* check for successful writing */
      JOptionPane.showMessageDialog(this,
        "Error writing configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show a status message */
    this.status.setText("configuration saved: " +file.getName());
  }  /* saveConfig() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.03.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    RegGUI gui = new RegGUI();  /* create a regression user interface */
    if (args.length > 0)        /* load configuration if necessary */
      gui.loadConfig(new File(args[0]));
    gui.setVisible(true);       /* show the user interface */
  }  /* main() */

}  /* class RegGUI */
