/*----------------------------------------------------------------------
  File    : RegApplier.java
  Contents: multivariate polynomial regression applier
  Author  : Christian Borgelt
  History : 2007.05.18 file created
            2007.07.19 adapted to changed Table class
            2014.10.23 changed from LGPL license to MIT license
----------------------------------------------------------------------*/
package regress;

import java.io.IOException;
import java.io.FileWriter;
import java.io.FileReader;

import util.ASCIICoder;
import util.Executable;
import util.Scanner;
import util.TableReader;
import util.TableWriter;
import table.NominalType;
import table.RealType;
import table.Column;
import table.Table;
import table.TableMapper;

/*--------------------------------------------------------------------*/
/** Class for applying multivariate polynomial regression models.
 *  @author Christian Borgelt
 *  @since  2007.05.14 */
/*--------------------------------------------------------------------*/
public class RegApplier implements Executable {

  /*------------------------------------------------------------------*/
  /**  constants                                                      */
  /*------------------------------------------------------------------*/
  /** the program description */
  public static final String DESCRIPTION =
    "multivariate polynomial regression applier";
  /** the version of this program */
  public static final String VERSION =
    "1.2 (2014.10.23)";
  /** the copyright information for this program */
  public static final String COPYRIGHT =
    "(c) 2004-2014 Christian Borgelt";

  /*------------------------------------------------------------------*/
  /**  instance variables                                             */
  /*------------------------------------------------------------------*/
  /** the name of the regression model file */
  private String       fn_reg  = null;
  /** the scanner for the regression model file */
  private Scanner      scan    = null;
  /** the regression model to apply */
  private Regression   reg     = null;
  /** whether the target is binary */
  private boolean      bin     = false;
  /** the name of the prediction column */
  private String       pred    = null;
  /** the name of the confidence column */
  private String       conf    = null;
  /** the classification threshold */
  private double       thresh  = 0.5;
  /** the name of the input data table file */
  private String       fn_in   = null;
  /** the record  separators */
  private String       recseps = null;
  /** the field   separators */
  private String       fldseps = null;
  /** the blank   characters */
  private String       blanks  = null;
  /** the comment characters */
  private String       comment = null;
  /** the read mode for the data table */
  private int          mode    = 0;
  /** the table reader to read the input data from */
  private TableReader  reader  = null;
  /** the input data table */
  private Table        tab     = null;
  /** the table mapper for the mapping to a vector */
  private TableMapper  map     = null;
  /** the target column (if it exists) */
  private Column       trg     = null;
  /** the result column (prediction column) */
  private Column       res     = null;
  /** the prediction confidence column */
  private Column       pcc     = null;
  /** the name of the output data table file */
  private String       fn_out  = null;
  /** the writer for the output data table file */
  private TableWriter  writer  = null;
  /** the number of processed table rows */
  private int          rowcnt  = 0;
  /** the sum of squared errors */
  private double       sse     = 0.0;
  /** the number of misclassifications */
  private int          errors  = 0;
  /** whether the induction was externally aborted */
  private volatile boolean stop = false;

  /*------------------------------------------------------------------*/
  /** Create a regression model applier.
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RegApplier ()
  { }

  /*------------------------------------------------------------------*/
  /** Set the regression model file.
   *  @param  fn_reg the name of the regression model file
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRegression (String fn_reg)
  { this.fn_reg = fn_reg; }

  /*------------------------------------------------------------------*/
  /** Set the regression model.
   *  @param  reg the regression model
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRegression (Regression reg)
  { this.reg = reg; }

  /*------------------------------------------------------------------*/
  /** Set the name of the prediction column.
   *  @param  name the name of the prediction column
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPredName (String name)
  { this.pred = name; }

  /*------------------------------------------------------------------*/
  /** Set the name of the confidence column.
   *  @param  name the name of the confidence column
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setConfName (String name)
  { this.conf = name; }

  /*------------------------------------------------------------------*/
  /** Set the classification threshold.
   *  @param  thresh the classification threshold
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setThreshold (double thresh)
  { this.thresh = thresh; }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab the name of the data table file
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab)
  { this.setInput(fn_tab, 0); }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab the name of the data table file
   *  @param  mode   the read mode
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab, int mode)
  { this.setInput(fn_tab, "\n", " ,\t", " \t\r", "#", mode); }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab  the name of the data table file
   *  @param  recseps the record  separators
   *  @param  fldseps the field   separators
   *  @param  blanks  the blank   characters
   *  @param  comment the comment characters
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab, String recseps, String fldseps,
                                       String blanks,  String comment)
  { this.setInput(fn_tab, recseps, fldseps, blanks, comment, 0); }

  /*------------------------------------------------------------------*/
  /** Set the table input file and corresponding parameters.
   *  @param  fn_tab  the name of the data table file
   *  @param  recseps the record  separators
   *  @param  fldseps the field   separators
   *  @param  blanks  the blank   characters
   *  @param  comment the comment characters
   *  @param  mode    the read mode
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab, String recseps, String fldseps,
                        String blanks, String comment, int mode)
  {                             /* --- set the table input file */
    this.fn_in   = fn_tab;
    this.recseps = recseps; this.fldseps = fldseps;
    this.blanks  = blanks;  this.comment = comment;
    this.mode    = mode | Table.NONULLS;
  }  /* setInput() */

  /*------------------------------------------------------------------*/
  /** Set the table reader and read mode.
   *  @param  reader the table reader
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (TableReader reader)
  { this.setInput(reader, 0); }

  /*------------------------------------------------------------------*/
  /** Set the table reader and read mode.
   *  @param  reader the table reader
   *  @param  mode   the read mode
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (TableReader reader, int mode)
  { this.reader = reader; this.mode = mode | Table.NONULLS; }

  /*------------------------------------------------------------------*/
  /** Set the input data table.
   *  @param  tab the input data table
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (Table tab)
  { this.tab = tab; }

  /*------------------------------------------------------------------*/
  /** Set the output data table file.
   *  @param  fn_tab the name of the output data table file
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutput (String fn_tab)
  { this.fn_out = fn_tab; }

  /*------------------------------------------------------------------*/
  /** Set the output file writer.
   *  @param  writer the output file writer
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutput (TableWriter writer)
  { this.writer = writer; }

  /*------------------------------------------------------------------*/
  /** Get the regression model.
   *  @return the regression model
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Regression getRegression ()
  { return this.reg; }

  /*------------------------------------------------------------------*/
  /** Write the result of a regression model application.
   *  @param  row the table row to write
   *  @param  vec the vector buffer
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private double[] apply (int row, double[] vec) throws IOException
  {                             /* --- apply regression model */
    double result;              /* application result */
    double diff;                /* target value for comparisons */
    int    cls;                 /* predicted class */

    vec    = this.map.exec(row, TableMapper.INPUTS, vec);
    result = this.reg.execute(vec);
    if (!this.bin) {            /* if real-valued target */
      if (this.res != null)     /* store the result if possible */
        ((double[])this.res.getData())[row] = result;
      if ((this.trg != null)    /* if a target column is present */
      &&  !this.trg.isNull(row)) {     /* and its value is known */
        diff = this.trg.getNumberAt(row) -result;
        this.sse += diff *diff; /* if the target value is known, */
      } }                       /* sum the squared errors */
    else {                      /* if binary target */
      if (result < thresh) {       cls = 0; }
      else { result = 1.0 -result; cls = 1; }
      if (this.res != null)     /* store the result if possible */
        ((int[])this.res.getData())[row] = cls;
      if ((this.trg != null)    /* if a target column is present */
      &&  !this.trg.isNull(row) /* and its value is known */
      &&  (cls != ((int[])this.trg.getData())[row])) {
        this.errors += 1;       /* count the misclassifications */
        this.sse    += result *result;
      }                         /* sum the squared errors */
      if (this.pcc != null)     /* if a confidence column exists */
        ((double[])this.pcc.getData())[row] = result;
    }                           /* set the confidence value */
    if (this.writer != null)    /* write the output file */
      this.tab.writeRow(row, this.writer, this.mode);
    this.rowcnt++;              /* count the processed table row */
    return vec;                 /* return the (new) vector buffer */
  }  /* apply() */

  /*------------------------------------------------------------------*/
  /** Apply a regression model.
   *  @throws IOException  if an i/o error occurs
   *  @throws RegException if there are too many regression terms
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void apply () throws IOException, RegException
  {                             /* --- induce a regression model */
    int      i, k;              /* loop variable, buffers */
    double[] vec = null;        /* vector for mapping/aggregation */
    long     t   = 0;           /* for time measurements */
    Table    atts;              /* attributes of the regression model */

    this.stop = false;          /* induction has not been stopped yet */

    /* --- read regression model --- */
    if (this.fn_reg != null) {  /* if to read a regression model */
      System.err.print("reading " +this.fn_reg +" ... ");
      t = System.currentTimeMillis();
      this.scan = new Scanner(new FileReader(this.fn_reg));
      atts = Table.parse("domains", scan);
      this.reg = Regression.parse(this.scan, atts);
      if (scan.nextToken() != Scanner.T_EOF)
        throw new IOException("garbage at end of domains file "
                              +scan.lno());
      scan.close();             /* parse the regression model */
      System.err.print("[" +atts.getColumnCount() +" parameters] ");
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/1000.0) +"s].");
    }                           /* get the table mapper */
    this.map = this.reg.getMapper();
    this.trg = this.map.getColumn(-1);
    this.bin = this.trg.getType() instanceof NominalType;
    for (i = this.map.getColumnCount(); --i >= 0; )
      this.map.getColumn(i).setMark(1);
    this.trg.setMark(0);        /* mark target column as optional */

    /* --- create and configure table reader --- */
    if (this.fn_in != null) {   /* if to read a table file */
      System.err.print("reading " +this.fn_in +" ... ");
      t = System.currentTimeMillis();
      if (this.reader == null){ /* if there is no table reader */
        this.reader = new TableReader(new FileReader(this.fn_in));
        this.reader.setChars(this.recseps, this.fldseps,
                             this.blanks, "", this.comment);
      }                         /* create a table reader */
    }                           /* and configure it */

    /* --- create and configure the writer --- */
    if ((this.fn_out != null)   /* if an output file name is given */
    &&  (this.pred   != null)   /* and a prediction field name */
    &&  (this.pred.length() > 0)/* (needed for meaningful output), */
    &&  (this.writer == null)){ /* create a table writer */
      this.writer = new TableWriter(new FileWriter(this.fn_out));
      if (this.recseps != null) /* set record separator */
        this.writer.setRecSep(this.recseps.charAt(0));
      if (this.fldseps != null) /* set field separator */
        this.writer.setFldSep(this.fldseps.charAt(0));
      if (this.blanks  != null) /* set blank character */
        this.writer.setBlank(this.blanks.charAt(0));
      this.writer.setNullChar(-1);
    }                           /* null values are not allowed */
    if ((this.pred == null)     /* if no pred. column name is given */
    ||  (this.pred.length() <= 0))
      this.writer = null;       /* no output needs to be written */

    /* --- apply the regression model --- */
    if (this.reader == null) {  /* if direct application to a table */
      throw new IOException("table application not implemented yet"); }
    else {                      /* if to read data from a stream */
      this.tab = this.map.getTable();   /* read the table header */
      this.tab.readHeader(this.reader, this.mode|Table.MARKED);
      if ((this.pred == null)   /* if no pred. column name is given */
      ||  (this.pred.length() <= 0)) {
        if (this.trg.getMark() < 0)   /* the target must be present */
          throw new IOException("missing target or prediction field"); }
      else {                    /* if a pred. column name is given */
        k = this.tab.getRowCount();   /* get the number of rows */
        if (this.trg.getMark() < 0) { /* if the target is not present */
          this.tab.renameColumn(this.map.getTargetId(), this.pred);
          this.res = this.trg;  /* the target column can be used */
          this.trg = null; }    /* for the prediction, so rename it */
        else {                  /* if the target is present */
          this.res = (this.bin) /* create a prediction column */
                   ? new Column(this.pred, new NominalType(), k)
                   : new Column(this.pred, new RealType(),    k);
          this.tab.addColumn(this.res);
        }                       /* add the prediction column */
        if (this.bin            /* if the target is binary */
        &&  (this.conf != null) /* and a conf. column name is given */
        &&  (this.conf.length() > 0)) {
          this.pcc = new Column(this.conf, new RealType(), k);
          this.tab.addColumn(this.pcc);
        }                       /* add a confidence column */
      }
      if (this.writer != null)  /* write the table header */
        this.tab.writeHeader(this.writer, this.mode);
      this.tab.resize(1);       /* create a table row */
      this.errors = this.rowcnt = 0;
      this.sse    = 0.0;        /* initialize the error variables */
      while (this.tab.readRow(0, this.reader, this.mode)) {
        if (this.stop) return;  /* while there is another record */
        vec = this.apply(0, vec);
      }                         /* read the next record and */
    }                           /* apply the regression model */
    if (this.writer != null)    /* if written to a file, */
      this.writer.close();      /* close the file writer */

    /* --- finish reading the table file --- */
    if (this.fn_in != null) {   /* if to read a table file */
      System.err.print("[" +this.rowcnt +" row(s)] ");
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/1000.0) +"s].");
    }                           /* write a log message */

    /* --- print error information --- */
    if (this.trg == null) { this.sse = -1; return; }
    System.err.print("sse: " +(float)this.sse);
    if (this.rowcnt > 0) {      /* if there is at least one row */
      double mse = this.sse/this.rowcnt;
      System.err.print(", mse: "  +(float)(mse)
                     + ", rmse: " +(float)Math.sqrt(mse));
    }                           /* compute mse and rmse */
    System.err.println();       /* terminate the output */
  }  /* apply() */

  /*------------------------------------------------------------------*/
  /** Execute the model induction.
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void exec () throws Exception
  { this.apply(); }

  /*------------------------------------------------------------------*/
  /** Abort a regression model induction.
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void abort ()
  { this.stop = true; }

  /*------------------------------------------------------------------*/
  /** Get the sum of squared errors.
   *  @return the sum of squared errors
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getSSE ()
  { return this.sse; }

  /*------------------------------------------------------------------*/
  /** Get the number of misclassifications.
   *  @return the number of misclassifications
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getErrors ()
  { return (this.bin) ? this.errors : -1; }

  /*------------------------------------------------------------------*/
  /** Get the number of processed table rows.
   *  @return the number of processed table rows
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return this.rowcnt; }

  /*------------------------------------------------------------------*/
  /** Main function for command line execution.
   *  @param  args the command line arguments
   *  @since  2007.05.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- test function */
    int    i, k = 0;            /* loop variables */
    String s;                   /* to traverse the arguments */
    String fn_reg  = null;      /* name of the regression model file */
    String fn_in   = null;      /* name of the input  data table file */
    String fn_out  = null;      /* name of the output data table file */
    String pred    = null;      /* name of the prediction column */
    String conf    = null;      /* name of the confidence column */
    double thresh  = 0.5;       /* classification threshold */
    String blanks  = null;      /* blank   characters */
    String fldseps = null;      /* field   separators */
    String recseps = null;      /* record  separators */
    String comment = null;      /* comment characters */
    int    mode    = 0;         /* read mode for the data */
    RegApplier app;             /* inducer for the regression model */

    if (args.length > 0) {      /* if no arguments are given */
      System.err.print  (RegApplier.class.getName());
      System.err.println(" - " +DESCRIPTION);
      System.err.println("version " +VERSION +"    " +COPYRIGHT); }
    else {                      /* if no arguments are given */
      System.out.println("usage: java " +RegApplier.class.getName()
                        +" [options] regfile infile [outfile]");
      System.out.println("-p#      prediction field name "
                                + "(default: \"reg\")");
      System.out.println("-c#      confidence field name "
                                + "(default: no confidence field)");
      System.out.println("-t#      classification threshold "
                                + "(default: 0.5)");
      System.out.println("-b#      blank   characters "
                                + "(default: \" \\t\\r\")");
      System.out.println("-f#      field   separators "
                                + "(default: \" ,\\t\")");
      System.out.println("-r#      record  separators "
                                + "(default: \"\\n\")");
      System.out.println("-C#      comment characters "
                                + "(default: \"#\")");
      System.out.println("-d       use default field names "
                                + "(default: read from file)");
      System.out.println("regfile  file to read "
                                + "the regression model from");
      System.out.println("infile   table file to read "
                                + "(field names in first record)");
      System.out.println("outfile  table file to write (optional)");
      return;                   /* print a usage message */
    }                           /* and abort the program */

    for (i = 0; i < args.length; i++) {
      s = args[i];              /* traverse the arguments */
      if ((s.length() > 0)      /* if the argument is an option */
      &&  (s.charAt(0) == '-')) {
        switch (s.charAt(1)) {  /* evaluate option */
          case 'p': pred    = s.substring(2);                     break;
          case 'c': conf    = s.substring(2);                     break;
          case 't': thresh  = Double.parseDouble(s.substring(2)); break;
          case 'b': blanks  = s.substring(2);                     break;
          case 'f': fldseps = s.substring(2);                     break;
          case 'r': recseps = s.substring(2);                     break;
          case 'C': comment = s.substring(2);                     break;
          case 'd': mode   |= Table.NOHEADER;                     break;
          default : System.err.print("Error: unknown option -");
                    System.err.println(s.charAt(1)); return;
        } }
      else {                    /* if the argument is no option */
        switch (k++) {          /* evaluate non-option */
          case  0: fn_reg = s; break;
          case  1: fn_in  = s; break;
          case  2: fn_out = s; break;
          default: System.err.println("too many arguments"); return;
        }                       /* there should be three fixed args. */
      }
    }
    if ((k != 2) && (k != 3)) { /* check the number of arguments */
      System.err.println("wrong number of arguments"); return; }
    try {                       /* build regression model */
      app = new RegApplier();   /* create an reg. model applier */
      app.setRegression(fn_reg);/* and configure it */
      app.setPredName(pred);
      app.setConfName(conf);
      app.setThreshold(thresh);
      app.setInput(fn_in, ASCIICoder.decode(recseps),
                          ASCIICoder.decode(fldseps),
                          ASCIICoder.decode(blanks),
                          ASCIICoder.decode(comment), mode);
      app.setOutput(fn_out);
      app.apply(); }            /* finally execute the applier */
    catch (IOException e) {     /* check for an i/o error */
      System.out.println("\n" +e.getMessage()); return; }
    catch (RegException e) {    /* check for a regression error */
      System.out.println("\n" +e.getMessage()); return; }
  }  /* main() */

}  /* class RegApplier */
