/*----------------------------------------------------------------------
  File    : RegException.java
  Contents: regression exception
  Author  : Christian Borgelt
  History : 2004.05.22 file created as part of Regression.java
            2007.03.18 made a separate file
----------------------------------------------------------------------*/
package regress;

/*--------------------------------------------------------------------*/
/** Class for a regression exception.
 *  @author Christian Borgelt
 *  @since  2004.05.22 */
/*--------------------------------------------------------------------*/
public class RegException extends Exception {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /** Create a regression exception.
   *  @param  msg the message associated with the exception
   *  @since  2004.05.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RegException (String msg)
  { super(msg); }

}  /* class RegException */
