/*----------------------------------------------------------------------
  File    : BayesGUI.java
  Contents: graphical user interface for Bayes classifier programs
  Author  : Christian Borgelt
  History : 2007.06.05 file created
            2007.07.07 adapted to new class DialogPanel
            2013.04.22 adapted to type argument of JComboBox
            2014.10.21 trimming of spaces from number arguments added
            2014.10.23 terminal added, changed from LGPL to MIT license
----------------------------------------------------------------------*/
package bayes;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import util.Executable;
import util.Executor;
import util.ObjExecutor;
import util.CmdExecutor;
import dialog.TabbedGUI;
import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.DomainsPanel;
import dialog.AboutPanel;

/*--------------------------------------------------------------------*/
/** Class for a user interface to the multilayer perceptron programs.
 *  @author Christian Borgelt
 *  @since  2007.06.05 */
/*--------------------------------------------------------------------*/
public class BayesGUI extends TabbedGUI implements ItemListener {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010006L;
  public  static final String VERSION = "1.6 (2015.08.12)";

  /** tab index: domain determination */
  private static final int DOMAINS   = 1;
  /** tab index: induction parameters */
  private static final int PARAMS    = 2;
  /** tab index: Bayes classifier induction */
  private static final int INDUCTION = 3;
  /** tab index: Bayes classifier execution */
  private static final int EXECUTION = 4;

  /** the names of the classifier types */
  private static final String[] typenames = {
    "naive Bayes", "full Bayes" };

  /** the names of the class frequency balancing methods */
  private static final String[] balnames = {
    "no", "lower", "boost", "shift" };
  /** the codes of the class frequency balancing methods */
  private static final String[] balcodes = {
    "", "l", "b", "s" };

  /** the names of the classifier simplification strategies */
  private static final String[] simpnames = {
    "no simplification",
    "forward selection",
    "backward elimination" };
  /** the codes of the update methods */
  private static final String[] simpcodes = {
    "", "a", "r" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /* --- induction parameters --- */
  /** the classifier type */
  private JComboBox<String> type    = null;
  /** the flag for a full classifier */
  private boolean           full    = false;
  /** the simplification strategy */
  private JComboBox<String> simp    = null;
  /** whether to balance the class frequencies */
  private JComboBox<String> balance = null;
  /** the Laplace correction */
  private JTextField        laplace = null;
  /** whether to distribute the weight of null values */
  private JCheckBox         distrib = null;
  /** the initial value for a Tikhonov regularization */
  private JTextField        reg     = null;
  /** the limit   value for a Tikhonov regularization */
  private JTextField        lim     = null;
  /** the labels that can be disabled in the tab */
  private JLabel[]          labels  = null;

  /* --- induction --- */
  /** the name of the domains file */
  private JTextField        fn_dom  = null;
  /** the name of the target attribute */
  private JTextField        target  = null;
  /** the name of the table/pattern file */
  private JTextField        fn_tab  = null;
  /** the name of the Bayes classifier file */
  private JTextField        fn_bc   = null;

  /* --- execution --- */
  /** the name of the multilayer perceptron file */
  private JTextField        fn_exec = null;
  /** the name of the table input file */
  private JTextField        fn_in   = null;
  /** the name of the prediction field */
  private JTextField        pred    = null;
  /** the name of the confidence field */
  private JTextField        conf    = null;
  /** the classification threshold (binary target) */
  private JTextField        thresh  = null;
  /** whether to write the field names to the first record */
  private JCheckBox         write   = null;
  /** the name of the table output file */
  private JTextField        fn_out  = null;

  /*------------------------------------------------------------------*/
  /** Create a Bayes classifier graphical user interface.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2007.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public BayesGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a Bayes classifier graphical user interface.
   *  @param  owner the component that is to own this dialog
   *  @since  2007.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public BayesGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Update the parameter context after a type selection.
   *  @since  2007.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void itemStateChanged (ItemEvent e)
  {                             /* --- process a type selection */
    boolean state = (this.type.getSelectedIndex() == 0);
    this.labels[0].setEnabled(state); this.simp.setEnabled(state);
    this.labels[1].setEnabled(state); this.laplace.setEnabled(state);
    this.labels[2].setEnabled(state); this.thresh.setEnabled(state);
  }  /* itemStateChanged() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    DialogPanel tab;            /* current tab of the tabbed pane */
    JPanel      bar;            /* bar of input fields */

    /* --- basic tabs --- */
    this.base("Bayes Classifier Tools");
    this.addFormatTab (FormatPanel.ALL);
    this.addDomainsTab(DomainsPanel.LOCATE);
    this.labels = new JLabel[3];

    /* --- induction parameters --- */
    tab = this.addTab("Parameters");

    tab.addLabel("Classifier type:");
    this.type = tab.addComboBox(BayesGUI.typenames);
    this.type.addItemListener(this);
    tab.addHelp("Naive: attributes conditionally independent "
               +"given the class.\nFull: conditional multivariate "
               +"normal distributions.");

    this.labels[0] = tab.addLabel("Simplification:");
    this.simp = tab.addComboBox(BayesGUI.simpnames);
    tab.addHelp("A naive Bayes classifier may be simplified "
               +"by greedily\nadding or removing attributes "
               +"if this improves performance.");

    this.labels[1] = tab.addLabel("Laplace correction:");
    this.laplace = tab.addNumberInput("");
    tab.addHelp("Laplace correction introduces a bias towards "
               +"equal probabilities.");

    this.labels[2] = tab.addLabel("Distribute weight:");
    this.distrib = tab.addCheckBox(false);
    tab.addHelp("By default null values are ignored. However, "
               +"for nominal\nattributes their weight may also "
               +"be distributed uniformly.");

    tab.addLabel("Regularization:");
    bar = new JPanel(new GridLayout(1, 2, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.reg = DialogPanel.createNumberInput("-0.001"));
    this.reg.setFont(DialogPanel.BOLD);
    bar.add(this.lim = DialogPanel.createNumberInput("1"));
    this.lim.setFont(DialogPanel.BOLD);
    tab.addHelp("Initial and limiting regularization value "
               +"(eigenvalue shifting).\n"
               +"If the initial value is negative, regularization "
               +"is only applied\nif needed (that is, only if a "
               +"Cholesky decomposition of a\ncovariance matrix "
               +"fails). Otherwise it is always applied.");
    tab.addFiller(0);

    /* --- Bayes classifier induction --- */
    tab = this.addTab("Induction");

    tab.addLabel("Domains file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.getFileName(BayesGUI.this.fn_dom); } } );
    tab.addButton("Edit", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.editDomains(BayesGUI.this.fn_dom); } } );
    this.fn_dom = tab.addFileInput("noname.dom");

    tab.addLabel("Target/class field:");
    this.target = tab.addTextInput("");
    tab.addHelp("If no target attribute is specified, the one listed "
               +"last in the\ndomains file is used. The target "
               +"attribute must be nominal.\nNote that for a full "
               +"Bayes classifier all nominal attributes\n(except, "
               +"of course, the target/class) are ignored.");

    tab.addLabel("Data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.getFileName(BayesGUI.this.fn_tab); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.showTable(BayesGUI.this.fn_tab); } } );
    this.fn_tab = tab.addFileInput("noname.tab");

    tab.addLabel("Balance classes:");
    this.balance = tab.addComboBox(BayesGUI.balnames);
    tab.addHelp("Balancing helps with highly uneven class "
               +"distributions.\nHowever, it distorts the "
               +"statistics of the data set.");

    tab.addLabel("Bayes classifier file:     ");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.getFileName(BayesGUI.this.fn_bc); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.showBayes(BayesGUI.this.fn_bc,
                                BayesGUI.this.fn_tab); } } );
    this.fn_bc = tab.addFileInput("noname.bc");
    tab.addFiller(0);

    /* --- Bayes classifier execution --- */
    tab = this.addTab("Execution");

    tab.addLabel("Classifier file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.getFileName(BayesGUI.this.fn_exec); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.showBayes(BayesGUI.this.fn_exec,
                                BayesGUI.this.fn_in); } } );
    this.fn_exec = tab.addFileInput("noname.bc");

    tab.addLabel("Input data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.getFileName(BayesGUI.this.fn_in); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.showTable(BayesGUI.this.fn_in); } } );
    this.fn_in = tab.addFileInput("noname.tab");

    tab.addLabel("Prediction field name:");
    this.pred = tab.addTextInput("bc");
    tab.addLabel("Confidence field name:");
    this.conf = tab.addTextInput("");
    tab.addHelp("The confidence indicates "
               +"how reliable the prediction is.");

    tab.addLabel("Classification threshold:");
    this.thresh = tab.addNumberInput("0.5");
    tab.addHelp("A classification threshold is used only "
               +"for a binary target.");

    tab.addLabel("Write field names:");
    this.write = tab.addCheckBox(true);

    tab.addLabel("Output data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.getFileName(BayesGUI.this.fn_out); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BayesGUI.this.showTable(BayesGUI.this.fn_out); } } );
    this.fn_out = tab.addFileInput("noname.out");
    tab.addFiller(0);

    /* --- Terminal --- */
    this.addTerminalTab("Terminal output of external programs");

    /* --- About --- */
    this.addTab("About", new AboutPanel(
       "Bayes Classifier Tools",
       "A simple user interface for the bayes programs.\n\n"
      +"Version " +BayesGUI.VERSION +"\n"
      +"written by Christian Borgelt\n"
      +"European Center for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.pack();
    this.selectTab(INDUCTION);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  {                             /* --- set the domains file */
    this.domains.setDomainsFile(file);
    this.fn_dom.setText(file.getPath());
  }  /* setDomainsFile() */

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  {                             /* --- set the data file */
    this.domains.setDataFile(file);
    this.fn_tab.setText(file.getPath());
  }  /* setDataFile() */

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  { this.fn_in.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Show a Bayes classifier.
   *  @param  bcls the text field with the classifier file name
   *  @param  data the text field with the data file name
   *  @since  2007.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showBayes (JTextField bcls, JTextField data)
  { this.showBayes(new File(bcls.getText()),
                   new File(data.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a cluster model.
   *  @param  bcls the file to load the cluster model from
   *  @param  data the file to load the table data from
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showBayes (File bcls, File data)
  {                             /* --- show a Bayes classifier */
    String cmd[] = new String[3];
    cmd[0] = System.getProperty("os.name").startsWith("Windows")
           ? "wbcview" : "xbcview";
    cmd[1] = bcls.getPath();    /* build the command to start */
    cmd[2] = data.getPath();    /* the visualization program */
    try { Runtime.getRuntime().exec(cmd); }
    catch (IOException e) {     /* try to start the process */
      System.err.println(e.getMessage()); }
  }  /* showBayes() */

  /*------------------------------------------------------------------*/
  /** Create a command to induce a Bayes classifier.
   *  @return the command to inducea Bayes classifier
   *  @since  2007.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createInductionCmd ()
  {                             /* --- induce a Bayes classifier */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s, t;              /* buffer for arguments */

    cmd    = new String[32];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"bci";
    n = this.format.addFormatArgs(cmd);
    this.full = (this.type.getSelectedIndex() > 0);
    if (this.full) cmd[n++] = "-F";  /* full Bayes classifier */
    s = this.target.getText();  /* target field name */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    s = BayesGUI.balcodes [this.balance.getSelectedIndex()];
    if (s.length() > 0) cmd[n++] = "-q" +s;
    s = BayesGUI.simpcodes[this.simp.getSelectedIndex()];
    if (s.length() > 0) cmd[n++] = "-s" +s;
    s = this.laplace.getText().trim(); /* Laplace correction */
    if (s.length() > 0) cmd[n++] = "-L" +s;
    if (this.distrib.isSelected())
      cmd[n++] = "-T";          /* distribute weights of null values */
    s = this.reg.getText().trim(); /* degree of polynomial and */
    t = this.lim.getText().trim(); /* range for logit transformation */
    if ((s.length() > 0) && (t.length() > 0)) {
      try { cmd[n++] = "-t" +Double.parseDouble(s)
                     +  ":" +Double.parseDouble(t); }
      catch (NumberFormatException e) { } }
    else if (s.length() > 0) {
      try { cmd[n++] = "-t" +Double.parseDouble(s); }
      catch (NumberFormatException e) { }
    }                           /* range for logit transformation */
    cmd[n++] = this.fn_dom.getText();
    cmd[n++] = this.fn_tab.getText();
    cmd[n++] = this.fn_bc.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createInductionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a command to execute a multilayer perceptron.
   *  @return the command to execute a multilayer perceptron
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createExecutionCmd ()
  {                             /* --- execute a Bayes classifier */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[20];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"bcx";
    n = this.format.addFormatArgs(cmd);
    s = this.pred.getText();    /* prediction field name */
    if (s.length() <= 0) this.pred.setText(s = "bc");
    cmd[n++] = "-p" +s;         /* (use 'bc' as default field name) */
    s = this.conf.getText();    /* confidence field name */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    s = this.laplace.getText().trim(); /* Laplace correction */
    if (s.length() > 0) cmd[n++] = "-L" +s;
    s = this.thresh.getText().trim();  /* classification threshold */
    if (s.length() > 0) cmd[n++] = "-t" +s;
    if (!this.write.isSelected())
      cmd[n++] = "-w";          /* do not write field names */
    cmd[n++] = this.fn_exec.getText();
    cmd[n++] = this.fn_in.getText();
    cmd[n++] = this.fn_out.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createExecutionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Get the executor for a dialog tab.
   *  @param  i the index of the dialog tab
   *  @return the executor for the <code>i</code>-th dialog tab
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- get the executor for a tab */
    String[]   cmd;             /* command for external program */
    Executable obj;             /* executable object */

    if (this.domains.useExternal()) {
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS  : cmd = this.createDomainsCmd();   break;
        case PARAMS   :
        case INDUCTION: cmd = this.createInductionCmd();  break;
        case EXECUTION: cmd = this.createExecutionCmd(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new CmdExecutor(cmd, this); }
    else {                      /* if to use internal programs */
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS: obj = this.createDomainsObj(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new ObjExecutor(obj, this);
    }                           /* create and return the executor */
  }  /* createExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    if (this.index == DOMAINS)  /* if domain determination */
      return this.getDomainsMsg();
    if ((this.index == PARAMS)  /* if classifier induction */
    ||  (this.index == INDUCTION)) {
      String msg = ((CmdExecutor)this.executor).getLastErrorLine();
      int    i   = msg.lastIndexOf("[", msg.indexOf("attribute(s)]"));
      return ((this.full) ? "Full" : "Naive") +" Bayes classifier with\n"
           + msg.substring(i+1, msg.indexOf("]", i)) +" created.";
    }                           /* extract classifier description */
    if (this.index == EXECUTION) {  /* if classifier execution */
      String msg = ((CmdExecutor)this.executor).getLastErrorLine();
      return "Bayes classifier execution leads to\n" +msg +".";
    }                           /* extract error information */
    return null;                /* otherwise there is no message */
  }  /* getResultMsg() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  {                             /* --- load configuration file */
    if (file == null) {         /* if no file name is given */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Load Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileReader reader = new FileReader(file);
      /* --- Format & Domains --- */
      this.format.loadConfig(reader);
      this.domains.loadConfig(reader);
      /* --- text parameters --- */
      /* --- Parameters --- */
      this.laplace.setText(this.readLine(reader));
      this.reg.setText    (this.readLine(reader));
      this.lim.setText    (this.readLine(reader));
      /* --- Induction --- */
      this.fn_dom.setText (this.readLine(reader));
      this.fn_tab.setText (this.readLine(reader));
      this.fn_bc.setText  (this.readLine(reader));
      /* --- Execution --- */
      this.fn_exec.setText(this.readLine(reader));
      this.fn_in.setText  (this.readLine(reader));
      this.fn_out.setText (this.readLine(reader));
      this.target.setText (this.readLine(reader));
      this.pred.setText   (this.readLine(reader));
      this.conf.setText   (this.readLine(reader));
      this.thresh.setText (this.readLine(reader));
      /* --- flags & indices --- */
      /* --- Parameters --- */
      this.type.setSelectedIndex   (this.readInt(reader));
      this.simp.setSelectedIndex   (this.readInt(reader));
      this.distrib.setSelected     (this.readInt(reader) != 0);
      /* --- Induction --- */
      this.balance.setSelectedIndex(this.readInt(reader));
      /* --- Execution --- */
      this.write.setSelected       (this.readInt(reader) != 0);
      reader.close(); }         /* read the configuration values */
    catch (IOException e) {     /* and close the input file */
      JOptionPane.showMessageDialog(this,
        "Error reading configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* check for successful reading */
    this.status.setText("configuration loaded: " +file.getName());
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  {                             /* --- save configuration file */
    if (file == null) {         /* if no file name is given, */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Save Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileWriter writer = new FileWriter(file);
      /* --- Format & Domains --- */
      this.format.saveConfig(writer);
      this.domains.saveConfig(writer);
      /* --- text parameters --- */
      /* --- Parameters --- */
      writer.write(this.laplace.getText()); writer.write('\n');
      writer.write(this.reg.getText());     writer.write('\n');
      writer.write(this.lim.getText());     writer.write('\n');
      /* --- Induction --- */
      writer.write(this.fn_dom.getText());  writer.write('\n');
      writer.write(this.fn_tab.getText());  writer.write('\n');
      writer.write(this.fn_bc.getText());   writer.write('\n');
      /* --- Execution --- */
      writer.write(this.fn_exec.getText()); writer.write('\n');
      writer.write(this.fn_in.getText());   writer.write('\n');
      writer.write(this.fn_out.getText());  writer.write('\n');
      writer.write(this.target.getText());  writer.write('\n');
      writer.write(this.pred.getText());    writer.write('\n');
      writer.write(this.conf.getText());    writer.write('\n');
      writer.write(this.thresh.getText());  writer.write('\n');
      /* --- flags & indices --- */
      /* --- Parameters --- */
      writer.write(this.type.getSelectedIndex() +",");
      writer.write(this.simp.getSelectedIndex() +",");
      writer.write(this.distrib.isSelected() ? "1," : "0,");
      /* --- Induction --- */
      writer.write(this.balance.getSelectedIndex() +",");
      /* --- Execution --- */
      writer.write(this.write.isSelected()   ? "1," : "0,");
      writer.write('\n');       /* write the configuration values */
      writer.close(); }         /* and close the output file */
    catch (IOException e) {     /* check for successful writing */
      JOptionPane.showMessageDialog(this,
        "Error writing configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show a status message */
    this.status.setText("configuration saved: " +file.getName());
  }  /* saveConfig() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    BayesGUI gui = new BayesGUI();
    if (args.length > 0)        /* load configuration if necessary */
      gui.loadConfig(new File(args[0]));
    gui.setVisible(true);       /* show the user interface */
  }  /* main() */

}  /* class BayesGUI */
