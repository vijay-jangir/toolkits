/*----------------------------------------------------------------------
  File    : SeqMine.java
  Contents: mining (all/closed/maximal) frequent sequences
  Author  : Christian Borgelt
  History : 2017.06.26 file created
            2017.06.27 debugging and basic testing
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.FileReader;
import java.io.Writer;
import java.io.FileWriter;
import java.util.Arrays;

import util.IdMap;
import util.TableReader;

/*--------------------------------------------------------------------*/
/** Class for (weighted) transaction suffixes
 *  @author Christian Borgelt
 *  @since 2017.06.26 */
/*--------------------------------------------------------------------*/
class TrActSuffix implements Comparable<TrActSuffix> {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the items of a transaction containing the suffix */
  public int[] items;
  /** the offset to the suffix in the transaction */
  public int   off;
  /** the total weight of all transactions sharing the suffix */
  public int   wgt;

  /*------------------------------------------------------------------*/
  /** Create a (weighted) transaction suffix.
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrActSuffix()
  { }

  /*------------------------------------------------------------------*/
  /** Create a (weighted) transaction suffix.
   *  @param  items the items of the underlying transaction
   *  @param  off   the offset to the transaction suffix
   *  @param  wgt   the weight of the underlying transactions
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrActSuffix (int[] items, int off, int wgt)
  {                             /* --- create a transaction suffix */
    this.items = items;
    this.off   = off;
    this.wgt   = wgt;
  }  /* TrActSuffix() */

  /*------------------------------------------------------------------*/
  /** Compare two transaction suffixes.
   *  @param  tsfx the transaction suffix to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as this suffix is less than, equal to, or greater than
   *          the suffix given as an argument
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int compareTo (TrActSuffix tsfx)
  {                             /* --- compare transaction suffixes */
    int i = this.off;           /* start comparing at the offsets */
    int k = tsfx.off;           /* and traverse the suffixes */
    while ((i < this.items.length)
    &&     (k < tsfx.items.length)) {
      if (this.items[i] > tsfx.items[k]) return +1;
      if (this.items[i] < tsfx.items[k]) return -1;
      i++; k++;                 /* if suffixes differ, return result, */
    }                           /* if equal items, go to next items */
    if (i >= this.items.length) return -1;
    if (k >= tsfx.items.length) return +1;
    return 0;                   /* compare suffixes by length */
  }  /* compareTo() */

  /*------------------------------------------------------------------*/
  /** Show a transaction suffix (for debugging purposes).
   *  @param  indent the number of indentation steps to print
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show (int indent)
  {                             /* --- show a transaction suffix */
    while (--indent >= 0)       /* print indentation for each step */
      System.out.print("   ");
    for (int i = 0; i < this.items.length; i++) {
      if (i == this.off)        /* if at the occurrence offset, */
        System.out.print("| "); /* print a suffix start marker */
      System.out.print(this.items[i]);
      System.out.print(' ');    /* print the transaction items */
    }                           /* separated by blanks */
    System.out.println(" [" +this.wgt +"]");
  }  /* show() */               /* append the transaction weight */

}  /* class TrActSuffix */


/*------------------------------------------------------------------*/
/** Class for item pattern occurrence lists
 *  @author Christian Borgelt
 *  @since  2017.06.26 */
/*------------------------------------------------------------------*/
class OccList {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** the threshold for suffix array reduction */
  private static final int REDTHRESH = 2;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the number of transactions */
  public int           size;
  /** the support of the occurrences */
  public int           supp;
  /** the (weighted) suffixes after the occurrences */
  public TrActSuffix[] sfxs;

  /*------------------------------------------------------------------*/
  /** Create an item pattern occurrences object.
   *  @param  nmax the maximum number of transactions to accomodate
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public OccList (int nmax)
  {                             /* --- create an occurrence list */
    this.size = this.supp = 0;
    this.sfxs = new TrActSuffix[nmax];
  }  /* OccList() */

  /*------------------------------------------------------------------*/
  /** Reduce an item pattern occurrence list to unique suffixes.
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void reduce ()
  {                             /* --- reduce pattern occurrences */
    if (this.size < REDTHRESH)  /* if less than threshold, */
      return;                   /* keep all pattern occurrences */
    Arrays.sort(this.sfxs, 0, this.size);
    int src, dst;               /* sort suffixes lexicographically */
    for (src = dst = 0; ++src < this.size; ) {
      if (this.sfxs[src].compareTo(this.sfxs[dst]) != 0)
        this.sfxs[++dst]    = this.sfxs[src];
      else                      /* if suffixes are the same */
        this.sfxs[src].wgt += this.sfxs[dst].wgt;
    }                           /* combine the suffixes */
    this.size = dst +1;         /* set the new number of suffixes */
  }  /* reduce() */

  /*------------------------------------------------------------------*/
  /** Show item pattern occurrences (for debugging purposes).
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show (int indent)
  {                             /* --- show item pattern occurrences */
    for (int i = 0; i < this.size; i++)
      this.sfxs[i].show(indent);/* print each transaction suffix */
    while (--indent >= 0)       /* print indentation for each step */
      System.out.print("   ");  /* and show summary information */
    System.out.print  ("count: "   +this.size +" ");
    System.out.println("support: " +this.supp);
  }  /* show() */

}  /* class OccList */


/*--------------------------------------------------------------------*/
/** Class for mining (all/closed/maximal) frequent sequences.
 *  @author Christian Borgelt
 *  @since  2017.06.26 */
/*--------------------------------------------------------------------*/
public class SeqMine implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants: version information                                  */
  /*------------------------------------------------------------------*/
  /** the program description */
  public static final String DESCRIPTION =
    "find (all/closed/maximal) frequent sequences";
  /** the version of this program */
  public static final String VERSION     =
    "1.2 (2017.07.03)";
  /** the copyright information for this program */
  public static final String COPYRIGHT   =
    "(c) 2017 Christian Borgelt";

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** target pattern type mask;
   *  to extract the main target pattern type, that is,
   *  <code>ITEMSET</code> or <code>SEQUENCE</code> */
  public static final int TYPEMASK    = CloMaxFilter.TYPEMASK;
  /** target pattern subtype mask;
   *  to extract the target pattern subtype, that is,
   *  <code>FREQUENT</code>, <code>CLOSED</code> or
   *  <code>MAXIMAL</code> */
  public static final int SUBTYPEMASK = CloMaxFilter.SUBTYPEMASK;
  /** target pattern type: item sets (item order is ignored) */
  public static final int ITEMSET     = CloMaxFilter.ITEMSET;
  /** target pattern type: item sequence */
  public static final int SEQUENCE    = CloMaxFilter.SEQUENCE;
  /** target pattern subtype: simple frequent item patterns;
   *  to be combined with <code>SEQUENCE</code> */
  public static final int FREQUENT    = CloMaxFilter.FREQUENT;
  /** target pattern subtype: closed frequent item patterns;
   *  to combined with <code>SEQUENCE</code> */
  public static final int CLOSED      = CloMaxFilter.CLOSED;
  /** target pattern subtype: maximal frequent item patterns;
   *  to be combined with <code>SEQUENCE</code> */
  public static final int MAXIMAL     = CloMaxFilter.MAXIMAL;
  /** operation mode: default setting */
  public static final int DEFAULT     = 0x0000;
  /** operation mode: no special operation, identical to
   *  <code>DEFAULT</code> */
  public static final int NONE        = DEFAULT;
  /** operation mode: reduce transaction suffix lists */
  public static final int REDUCE      = 0x0001;
  /** operation mode: use a chain of prefix trees
   *  to filter for closed/maximal patterns */
  public static final int CMCHAIN     = 0x0010;
  /** operation mode: use a single prefix tree
   *  to filter for closed/maximal patterns */
  public static final int CMTREE      = 0x0020;
  /** operation mode: check for closed/maximal patterns
   *  via extensions */
  public static final int CMEXTS      = 0x0080;
  /** mask for operation mode flags concerning closed/maximal filtering
   *  with a prefix tree repository (single tree or tree chain) */
  public static final int CMTREEMASK  = CMCHAIN|CMTREE;
  /** mask for operation mode flags concerning
   *  closed/maximal filtering */
  public static final int CMMASK      = CMTREEMASK|CMEXTS;
  /** operation mode: force pre-check pruning for closed/maximal mining
   *  (attention: may lead to wrong results!) */
  public static final int PREPRUNE    = 0x0100;
  /** the difference between 1.0 and the smallest number greater
   *  than 1.0 that is representable as a double precision number;
   *  used for handling rounding errors
   *  <p>Note that this value differs from <code>double.EPSILON</code>,
   *  which is rather the smallest positive number
   *  that is representable as a double precision number.</p> */
  public static final double EPSILON  = 2.2204460492503131e-16;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the transactions to mine in a threaded mining run */
  protected TrActBag     tabag;
  /** the target pattern type and subtype of the search
   *  (<code>ITEMSET</code> or <code>SEQUENCE</code> as the main target
   *  pattern type and <code>FREQUENT</code>, <code>CLOSED</code> or
   *  <code>MAXIMAL</code> as the target pattern subtype) */
  protected int          itarget;
  /** the minimum support of an item pattern
   *  (set by <code>initMining()</code>) */
  protected double       ismin;
  /** the minimum length of an item pattern
   *  (number of items, set by <code>initMining()</code>) */
  protected int          izmin;
  /** the maximum length of an item pattern
   *  (number of items, set by <code>initMining()</code>) */
  protected int          izmax;
  /** the operation mode
   *  (<code>DEFAULT</code> or <code>REDUCE</code>,
   *   set by <code>initMining()</code>) */
  protected int          imode;
  /** the number of times an item may be used in a pattern
   *  (set by <code>initMining()</code>) */
  protected int          iumax;
  /** the thread of a threaded mining run */
  private Thread         thread;
  /** the underlying item base */
  protected IdMap        ibase;
  /** the target pattern type and subtype of the search */
  protected int          target;
  /** the minimum support of an item pattern (item sequence) */
  protected int          smin;
  /** the base support (support of empty sequence/database size) */
  protected int          sbase;
  /** the minimum length of an item pattern (number of items) */
  protected int          zmin;
  /** the maximum length of an item pattern (number of items) */
  protected int          zmax;
  /** the maximum length of an item pattern (number of items)
   *  that needs to be checked (<code>zmax+1</code> if a
   *  closed/maximal filter is to be used, so that extensions are
   *  being checked, otherwise equal to <code>zmax</code>) */
  protected int          zmaxx;
  /** the search/operation mode */
  protected int          mode;
  /** the current item pattern (item sequence) */
  private   int[]        items;
  /** the number of transactions in which individual items occur */
  private   int[]        cnts;
  /** the support values of individual items */
  private   int[]        supps;
  /** the identifiers of the last considered transaction per item */
  private   int[]        tids;
  /** the number of times an item is used in the current pattern */
  private   int[]        used;
  /** the maximum number of times an item can be used in a pattern */
  private   int          umax;
  /** the current length of the item pattern (number of items) */
  private   int          size;
  /** the stack of database projections / conditional databases
   *  <p>(By reusing the same projections, that is, the contained
   *  occurrence lists and transaction suffixes, the number of created
   *  objects can be can be reduced considerably, which leads to a
   *  significant speedup of the search.)</p> */
  private   OccList[][]  stack;
  /** the item pattern buffer for the closed/maximal check */
  private   int[]        cmbuf;
  /** the closed/maximal filter
   *  (chain of prefix trees or single tree) */
  private   CloMaxFilter filter;
  /** the result set of frequent item patterns (item sequences) */
  protected PatternSet   pats;
  /** the flag whether a mining run has been aborted */
  protected boolean      aborted;

  /*------------------------------------------------------------------*/
  /** Create a miner for item patterns (frequent item sequences).
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public SeqMine ()
  { this.aborted = false; }

  /*------------------------------------------------------------------*/
  /** Check for a closed or maximal item pattern (sequence).
   *  @param  occs the transaction occurrence list for the pattern
   *  @param  smax the largest support of an already tested extension
   *  @return whether the item pattern is closed/maximal
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private final boolean clomax (OccList occs, int smax)
  {                             /* --- check for closed/maximal pat. */
    int xmin = ((this.target & MAXIMAL) != 0) ? this.smin : occs.supp;
    /* xmin: minimum extension support needed for failing the test */
    if (smax >= xmin)           /* if appending some item is frequent */
      return false;             /* or a perfect extension, abort */
    for (int i = 0; i < this.supps.length; i++) {
      this.supps[i] =  0;       /* clear the transaction counters */
      this.tids[i]  = -1;       /* and the last transaction ids */
    }                           /* for conditional support comp. */
    for (int m = 0; m < occs.size; m++) {
      TrActSuffix sfx = occs.sfxs[m];
      for (int k = 0; k < sfx.items.length; k++) {
        int i = sfx.items[k];   /* traverse the transaction suffix */
        if (this.tids[i] < m) { /* if the transaction has not */
          this.tids[i] = m;     /* yet been considered for the item */
          this.supps[i] += sfx.wgt;
        }                       /* set last transaction identifier */
      }                         /* and sum the transaction weight */
    }                           /* (process first item occurrences) */
    for (int i = 0; i < this.supps.length; i++) {
      if ((this.supps[i] < xmin)
      ||  (this.used[i] >= this.umax))
        continue;               /* skip infrequent and used up items */
      System.arraycopy(this.items, 0, this.cmbuf, 0, this.size);
      for (int k = this.size; --k >= 0; ) {
        this.cmbuf[k+1] = this.cmbuf[k];
        this.cmbuf[k]   = i;    /* insert ext. item at next position */
        int supp = 0;           /* initialize the extension support */
        int sadd = occs.supp;   /* and the maximum add. support */
        for (int m = occs.size; --m >= 0; ) {
          TrActSuffix sfx = occs.sfxs[m];
          if (Pattern.subpattern(this.cmbuf, this.size+1,
                                 sfx.items, sfx.items.length)) {
            supp += sfx.wgt;    /* if contained, add to support */
            if (supp >= xmin) return false;
          }                     /* if threshold is reached, abort */
          sadd -= sfx.wgt;      /* reduce remaining add. support */
          if (supp +sadd < xmin) break;
        }                       /* if rem. transactions cannot bring */
      }                         /* the support up to the threshold, */
    }                           /* the loop can be aborted */
    return true;                /* pattern is closed/maximal */
  }  /* clomax() */

  /*------------------------------------------------------------------*/
  /** Recursive part of the search for item patterns (sequences).
   *  @param  occs the pattern occurrences for the current item pattern
   *  @param  exts the pattern occurrence lists for the extension items
   *               (conditional on the current item pattern)
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private final void recurse (OccList occs, OccList[] exts)
  {                             /* --- recursive part of the search */
    if (Thread.currentThread().isInterrupted())
      this.aborted = true;      /* check for thread interruption */
    if (this.aborted) return;   /* check for abortion */
    OccList[] proj = null;      /* projected transaction database */
    if (this.size < this.zmaxx){/* if an extension is possible */
      if (this.stack[this.size] == null)
        this.stack[this.size] = new OccList[exts.length];
      proj = this.stack[this.size];  /* create a new projection array */
      for (int i = 0; i < proj.length; i++) {
        boolean needed = ((exts[i] != null)
                       && (exts[i].supp >= this.smin)
                       && (this.used[i] < this.umax));
        if (proj[i] != null)    /* if an occurrence list exists, */
          proj[i].supp = (needed) ? 0 : -1;  /* only mark occ. list */
        else if (needed)        /* if none exists, but one is needed */
          proj[i] = new OccList(this.cnts[i]);
      }                         /* create a pattern occurrence list */
    }                           /* (with sufficient for recursion) */
    int xmax = 0;               /* init. maximum extension support */
    int beg, end, delta;        /* variables for extension loop */
    if (((this.mode & PREPRUNE) != 0)
    &&   (this.size % 2 != 0)){ /* if to force clo./max. pre-pruning */
      beg = exts.length-1; end = -1; delta = -1; }
    else {                      /* if standard operation or even len. */
      beg = 0; end = exts.length;    delta = +1; }
    for (int i = beg; i != end; i += delta) {
      if ((exts[i] == null)     /* if item is infrequent or used up */
      ||  (exts[i].supp <  this.smin)
      ||  (this.used[i] >= this.umax))
        continue;               /* the extension item can be skipped */
      if (exts[i].supp >= xmax) /* if extension support is larger, */
        xmax = exts[i].supp;    /* update maximum extension support */
      /* The maximum extension support is needed below for the   */
      /* check whether the current pattern is closed or maximal. */
      if (this.size >= this.zmaxx)
        continue;               /* if an extension is not possible */
      if ((this.mode & REDUCE) != 0)
        exts[i].reduce();       /* reduce transaction suffix array */
      for (int k = 0; k < proj.length; k++) {
        if ((proj[k] != null) && (proj[k].supp >= 0))
          proj[k].supp = proj[k].size = 0;
      }                         /* clear occurrence counter & support */
      for (int j = 0; j < exts[i].size; j++) {
        TrActSuffix sfx = exts[i].sfxs[j];
        int[] s = sfx.items;    /* traverse the transaction suffixes */
        for (int k = sfx.off; k < s.length; k++) {
          OccList p = proj[s[k]];  /* traverse items in a suffix */
          if ((p == null) || (p.supp < 0))
            continue;           /* if no pattern occ. list exists */
          int n = p.size;       /* or the item is infrequent, skip it */
          if ((n > 0) && (p.sfxs[n-1].items == s))
            continue;           /* if earlier suffix registered, skip */
          p.supp += sfx.wgt;    /* sum the transaction support */
          //if (k+1 >= s.length)/* if at end of transaction, */
          //  break;            /* abort the suffix traversal */
          /* Empty suffixes can be skipped only if no closed */
          /* or maximal pattern test is executed during the  */
          /* search, as their corresponding transactions are */
          /* needed in the function clomax().                */
          TrActSuffix x = p.sfxs[n];
          if (x == null)        /* create new trans. suffix if nec. */
            p.sfxs[n] = x = new TrActSuffix();
          p.size += 1;          /* count the suffixes/transactions */
          x.items = s;          /* and note the transaction start, */
          x.off   = k+1;        /* the offset to the suffix, */
          x.wgt   = sfx.wgt;    /* and the transaction weight */
        }                       /* (note that only first occurrences */
      }                         /* of the suffix items are recorded) */
      if ((this.mode & CMCHAIN) != 0) {
        this.filter.add(i);     /* add current item to the filter */
        if (((this.mode & PREPRUNE) != 0)
        &&   (this.filter.getSupp() >= exts[i].supp)) {
          this.filter.remove(1);/* is super-pattern with same support */
          continue;             /* exists, neither the pattern itself */
        }                       /* nor any of its super-patterns */
      }                         /* may be closed or maximal, resp. */
      this.items[this.size++] = i;
      this.used[i] += 1;        /* store extension item and */
      recurse(exts[i], proj);   /* increment its use counter, */
      this.used[i] -= 1;        /* find frequent seqs. recursively */
      this.size    -= 1;        /* and remove the extension item */
      if ((this.mode & CMCHAIN) != 0)
        this.filter.remove(1);  /* remove the current item also */
    }                           /* from the closed/maximal filter */

    if ((this.size >= this.zmin)/* if current item pattern qualifies */
    &&  (this.size <= this.zmaxx)) {
      if (this.filter != null)  /* update the closed/maximal filter */
        this.filter.update(this.items, this.size, occs.supp);
      else if (((this.target & (CLOSED|MAXIMAL)) == 0)
      || clomax(occs, xmax))    /* check closed/maximal if needed */
        this.pats.add(new Pattern(this.ibase, this.items, this.size,
                                  occs.supp, this.sbase));
    }                           /* add current item pattern to result */
  }  /* recurse() */

  /*------------------------------------------------------------------*/
  /** Find frequent item patterns (sequences).
   *  @param  tabag  the (sequence) transactions to mine
   *  @param  target the type of frequent item patterns to mine
   *                 (pattern type <code>SEQUENCE</code> and pattern
   *                 subtype <code>FREQUENT</code>, <code>CLOSED</code>
   *                 or <code>MAXIMAL</code>)
   *  @param  smin   the minimum support of an item pattern
   *                 (positive: percentage, negative: absolute value)
   *  @param  zmin   the minimum size of an item pattern
   *                 (number of items)
   *  @param  zmax   the maximum size of an item pattern
   *                 (number of items)
   *  @param  mode   the operation mode (e.g. <code>REDUCE</code>)
   *  @param  umax   the maximum number of times an item
   *                 may be used in a pattern
   *  @return the found set of frequent item patterns
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet mine (TrActBag tabag, int target,
                                double smin, int zmin, int zmax,
                                int umax, int mode)
  {                             /* --- mine frequent item patterns */
    this.aborted = false;       /* clear the abort flag */
    this.pats = null;           /* clear the result variable */
    if ((target & (CLOSED|MAXIMAL)) == 0)
         mode = (mode & ~CMMASK);  /* make operation mode consistent */
    else if ((mode & CMEXTS) != 0)
         mode = (mode & ~CMMASK) | CMEXTS;
    else if ((mode & CMTREE) != 0)
         mode = (mode & ~CMMASK) | CMTREE;
    else mode = (mode & ~CMMASK) | CMCHAIN;
    tabag.pack();               /* ensure packed transactions */
    this.ibase  = tabag.ibase;  /* note the item base */
    this.target = target;       /* the target type */
    this.mode   = mode;         /* and operation/search mode */
    this.zmin   = zmin;         /* note pattern length range */
    this.zmax   = (zmax >= 0) ? zmax : Integer.MAX_VALUE;
    this.umax   = umax;         /* maximum uses of an item */

    int m = this.ibase.getSize();  /* get the number of items */
    if ((this.zmax <  0)        /* check the maximum pattern size */
    || (m          <= 0)        /* (need at least an empty pattern) */
    || (tabag.size <= 0))       /* if there are no items or trans. */
      return this.pats = new PatternSet(this.ibase);
    this.cnts  = new int[m];    /* number of trans. per item */
    this.supps = new int[m];    /* individual item support */
    this.tids  = new int[m];    /* last considered transaction ids */
    for (int i = 0; i < m; i++){/* traverse the items */
      this.supps[i] = this.cnts[i] = 0;
      this.tids[i] = -1;        /* clear support and counters */
    }                           /* and the last transaction ids */
    OccList omts = new OccList(tabag.size);
    omts.supp = 0;              /* create empty pattern occ. list */
    omts.size = tabag.size;     /* and initialize it */
    int tmax = 0;               /* init. maximum transaction length */
    for (int i = 0; i < tabag.size; i++) {
      TrAct t = tabag.get(i);   /* traverse the transactions */
      omts.supp += t.wgt;       /* compute total/base support and */
      if (t.size > tmax)        /* update maximum transaction length */
        tmax = t.size;          /* (limits frequent pattern length) */
      int[] s = t.getAllItems();
      for (int j = 0; j < s.length; j++) {
        int k = s[j];           /* traverse items in transaction */
        if (this.tids[k] >= i) continue;
        this.tids[k] = i;       /* skip already counted transactions */
        this.cnts[k] += 1;      /* set last transaction identifier */
        this.supps[k] += t.wgt; /* and count the transaction */
      }                         /* (count first item occurrences) */
    }
    this.sbase = omts.supp;     /* get the empty pattern support */
    smin = (smin < 0) ? -smin   /* compute absolute minimum support */
         : smin /100.0 *(double)this.sbase *(1-EPSILON);
    this.smin = (int)Math.ceil(smin);
    if (this.smin <= 0)         /* ensure positive minimum support */
      this.smin = 1;            /* (require at least one occurrence) */
    if (omts.supp < this.smin)  /* check empty item pattern support */
      return this.pats = new PatternSet(this.ibase);
    /* create item pattern occurrence lists of single items */
    /* (that is, collect extension items of the empty pattern) */
    OccList[] occs = new OccList[m];
    for (int i = 0; i < m; i++) /* create item occurrence lists */
      if (this.supps[i] >= this.smin)
        occs[i] = new OccList(this.cnts[i]);
    for (int j = 0; j < tabag.size; j++) {
      TrAct t = tabag.get(j);   /* traverse the transactions and */
      int[] s = t.getAllItems();/* create transaction suffixes */
      omts.sfxs[j] = new TrActSuffix(s, 0, t.wgt);
      for (int i = 0; i < s.length; i++) {
        OccList proj = occs[s[i]];  /* traverse items in transaction */
        if (proj == null) continue; /* skip infrequent items */
        int n = proj.size;      /* get current occ. list length */
        if ((n > 0) && (proj.sfxs[n-1].items == s))
          continue;             /* if an earlier suffix is registered */
        proj.supp += t.wgt;     /* sum the suffix weights */
        //if (i+1 >= s.length)  /* if at the end of a transaction, */
        //  break;              /* terminate the suffix loop */
        /* Empty suffixes can be skipped only if no closed or    */
        /* maximal pattern test is executed during the search,   */
        /* as their corresponding transactions are needed in the */
        /* function clomax() for a closed/maximal test.          */
        proj.sfxs[proj.size++] = new TrActSuffix(s, i+1, t.wgt);
      }                         /* note the transaction suffix */
    }                           /* (only first occs. are recorded) */
    this.filter = null;         /* invalidate filter repository */
    if (((this.target & (CLOSED|MAXIMAL)) != 0)
    &&  ((this.mode & CMTREEMASK) != 0))/* create a filter repository */
      this.filter = new CloMaxFilter(this.ibase, this.target, -1);
    else {                      /* if to check via extensions, */
      this.mode &= ~REDUCE;     /* suffixes cannot be reduced */
      this.cmbuf = new int[tmax+1];
    }                           /* create a buffer for ext. checks */
    if (this.filter != null)    /* if to use a closed/maximal filter */
      this.zmaxx = (this.zmax < Integer.MAX_VALUE)
                 ? this.zmax+1 : this.zmax;
    else {                      /* if to use no closed/maximal filter */
      this.pats  = new PatternSet(this.ibase);
      this.zmaxx = this.zmax;   /* set the item support values */
    }                           /* and the pattern size limit */
    this.used  = new int[m];    /* create item usage counters */
    this.stack = new OccList[tmax+1][];
    this.items = new int[tmax]; /* create buffer for pattern */
    this.size  = 0;             /* and initialize the item counter */
    recurse(omts, occs);        /* recursively mine item patterns */
    this.cnts  = this.tids  = this.used = null;
    this.items = this.cmbuf = null;
    this.supps = null;          /* delete the internal buffers */
    this.stack = null;          /* and the projection stack */
    if (this.filter != null)    /* if a closed/maximal filter */
    {                           /* (prefix tree(s)) has been used */
      this.pats = (PatternSet)this.filter.report(
                                  new PatternSet(this.ibase),
                                  this.sbase, this.zmin, this.zmax);
      this.filter = null;       /* report patterns from c/m filter */
      this.pats.reverse();      /* and then delete the c/m filter */
    }
    this.ibase = null;          /* delete the item base */
    return this.pats;           /* return the created pattern set */
  }  /* mine() */

  /*------------------------------------------------------------------*/
  /** Find frequent item sequences.
   *  @param  tabag  the (sequence) transactions to mine
   *  @param  target the type of frequent item sequences to mine
   *                 (<code>FREQUENT</code>, <code>CLOSED</code>, or
   *                 <code>MAXIMAL</code>)
   *  @param  smin   the minimum support of an item sequence
   *                 (positive: percentage, negative: absolute value)
   *  @param  zmin   the minimum size of an item sequence
   *                 (number of items)
   *  @param  zmax   the maximum size of an item sequence
   *                 (number of items)
   *  @param  umax   the maximum number of times an item
   *                 may be used in a pattern
   *  @param  mode   the operation mode (e.g. <code>REDUCE</code>)
   *  @return the found set of frequent item sequences
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet mineSeq (TrActBag tabag, int target,
                                   double smin, int zmin, int zmax,
                                   int umax, int mode)
  {                             /* --- mine frequent item sequences */
    target = (target & SUBTYPEMASK) | SEQUENCE;
    return mine(tabag, target, smin, zmin, zmax, umax, mode);
  }  /* mineSeq() */

  /*------------------------------------------------------------------*/
  /** Initialize mining frequent item patterns (sequences) in a thread.
   *  @param  tabag  the (sequence) transactions to mine
   *  @param  target the type of frequent item patterns to mine
   *                 (pattern type <code>SEQUENCE</code> and pattern
   *                 subtype <code>FREQUENT</code>, <code>CLOSED</code>,
   *                 or <code>MAXIMAL</code>)
   *  @param  smin   the minimum support of an item pattern
   *                 (positive: percentage, negative: absolute value)
   *  @param  zmin   the minimum size of an item pattern
   *                 (number of items)
   *  @param  zmax   the maximum size of an item pattern
   *                 (number of items)
   *  @param  umax   the number of times an item
   *                 may be used in a pattern
   *  @param  mode   the operation mode (e.g. <code>REDUCE</code>)
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void initMining (TrActBag tabag, int target,
                                double smin, int zmin, int zmax,
                                int umax, int mode)
  {                             /* --- mine frequent item patterns */
    this.tabag   = tabag;
    this.itarget = target;
    this.ismin   = smin;
    this.izmin   = zmin;
    this.izmax   = zmax;
    this.iumax   = umax;
    this.imode   = mode;
  }  /* initMining() */

  /*------------------------------------------------------------------*/
  /** Run mining (which must have been initialized with
   *  <code>InitMining</code>).
   *  The result can be retrieved with <code>getResult()</code>.
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void run ()
  {                             /* --- run the mining */
    if (this.tabag == null)     /* if there are no transactions, */
      clear();                  /* merely clear the results */
    mine(this.tabag, this.itarget, this.ismin,
         this.izmin, this.izmax, this.iumax, this.imode);
   }   /* run() */

  /*------------------------------------------------------------------*/
  /** Run mining as a thread (must have been initialized with
   *  <code>InitMining</code>).
   *  <p>The result can be retrieved with <code>getResult()</code>.</p>
   *  @return the created and started thread
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Thread runAsThread ()
  {                             /* --- run the mining as a thread */
    this.thread = new Thread(this);
    this.thread.start();        /* create a new thread and start it */
    return this.thread;         /* return the created thread */
  }  /* runAsThread() */

  /*------------------------------------------------------------------*/
  /** Get the thread that was started last (if any).
   *  @return the thread that was started last
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Thread getThread ()
  { return this.thread; }

  /*------------------------------------------------------------------*/
  /** Abort a mining run.
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void abort ()
  { this.aborted = true; }

  /*------------------------------------------------------------------*/
  /** Get result of a sequence mining run.
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet getResult ()
  { return this.pats; }

  /*------------------------------------------------------------------*/
  /** Clear results of mining run.
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void clear ()
  { this.pats = null; }

  /*------------------------------------------------------------------*/
  /** Help output function.
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static void help()
  {                             /* --- print add. option information */
    System.err.println("\n");   /* terminate the startup message */
    System.out.println("information output characters (option -v#)");
    System.out.println("  i  number of items (pattern size)");
    System.out.println("  a  absolute support");
    System.out.println("  s  relative support as a fraction");
    System.out.println("  S  relative support as a percentage");
    System.out.println("  Q  total transaction weight (database size)");
  }  /* help() */               /* print help information */

  /*------------------------------------------------------------------*/
  /** Main function for command line use.
   *  @param  args the command line arguments as an array of strings
   *  @since  2017.06.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    int     k = 0;              /* number of fixed arguments */
    String  fn_inp  = null;     /* name of input  file */
    String  fn_out  = null;     /* name of output file */
    String  recseps = null;     /* record  separators */
    String  fldseps = null;     /* field   separators */
    String  blanks  = null;     /* blank   characters */
    String  comment = null;     /* comment characters */
    int     target  = 's';      /* target type (item sequences) */
    int     subtype = 's';      /* target subtype (e.g. maximal) */
    double  smin    = 10;       /* minimum support of an item pattern */
    int     zmin    = 1;        /* minimum and maximum pattern size */
    int     zmax    = Integer.MAX_VALUE;
    int     mode    = DEFAULT;  /* operation/search mode */
    int     umax    = Integer.MAX_VALUE; /* max. number of item uses */
    int     reddir  = 0;        /* pattern reduction direction */
    int     reduce  = 0;        /* pattern reduction mode */
    String  isep    = " ";      /* item separator for output */
    String  info    = "";       /* additional value identifiers */
    boolean quiet   = false;    /* whether to suppress messages */
    long    t;                  /* for time measurements */

    /* --- print startup/usage message --- */
    if (args.length > 0) {      /* if arguments are given */
      quiet = (args[0] == "-q");
      if (!quiet) {             /* unless quiet operation requested, */
        System.err.println("SeqMine - " +DESCRIPTION);
        System.err.println("version " +VERSION +"    " +COPYRIGHT);
      } }                       /* print a startup message */
    else {                      /* if no arguments are given */
      System.out.println("usage: SeqMine [options] infile [outfile]");
      System.out.println(DESCRIPTION);
      System.out.println("version " +VERSION +"    " +COPYRIGHT);
      System.out.println("-T#      "
                       + "target pattern type                      "
                       + "(default: " + (char)target + ")");
      System.out.println("         "
                       + "(s: item sequences)");
      System.out.println("-t#      "
                       + "target pattern subtype                   "
                       + "(default: " + (char)subtype + ")");
      System.out.println("         "
                       + "(a/s/f: frequent,"
                       + " c: closed, m: maximal, g: generator)");
      System.out.println("         "
                       + "(note that \"-tg\" is only an abbreviation"
                       + " for \"-ts -R-1\")");
      System.out.println("-m#      "
                       + "minimum number of items per pattern      "
                       + "(default: " +zmin +")");
      System.out.println("-n#      "
                       + "maximum number of items per pattern      "
                       + "(default: no limit)");
      System.out.println("-j#      "
                       + "maximum number of item uses/repetitions  "
                       + "(default: no limit)");
      System.out.println("-s#      "
                       + "minimum support of a pattern             "
                       + "(default: " +smin +"%)");
      System.out.println("         "
                       + "(positive: percentage, "
                       + "negative: absolute number)");
      System.out.println("-y       "
                       + "reduce transaction suffix lists          "
                       + "(default: do not reduce)");
      System.out.println("-e       "
                       + "check extensions for closed/maximal      "
                       + "(default: repository)");
      System.out.println("-1       "
                       + "use only single tree for closed/maximal  "
                       + "(default: tree chain)");
      System.out.println("-2       "
                       + "use a tree chain for closed/maximal      "
                       + "(default: tree chain)");
      System.out.println("-p       "
                       + "force pre-pruning for closed/maximal     "
                       + "(default: do not prune)");
      System.out.println("         "
                       + "(attention: "
                       + "faster, but may lead to incorrect results!)");
      System.out.println("-R#      "
                       + "whether to reduce the found pattern set  "
                       + "(default: " +reddir +")");
      System.out.println("         "
                       + "(positive: maximize,"
                       + " negative: minimize patterns)");
      System.out.println("-i       "
                       + "compare only items in reduction          "
                       + "(default: also support)");
      System.out.println("-k#      "
                       + "item separator for output                "
                       + "(default: \" \")");
      System.out.println("-v#      "
                       + "identifiers of add. output values        "
                       + "(default: none)");
      System.out.println("-r#      "
                       + "record/transaction separators            "
                       + "(default: \"\\n\")");
      System.out.println("-f#      "
                       + "field /item        separators            "
                       + "(default: \" \\t,\")");
      System.out.println("-b#      "
                       + "blank   characters                       "
                       + "(default: \" \\t\\r\")");
      System.out.println("-C#      "
                       + "comment characters                       "
                       + "(default: \"#\")");
      System.out.println("infile   "
                       + "file to read transactions from           "
                       + "[required]");
      System.out.println("outfile  "
                       + "file to write frequent patterns to       "
                       + "[optional]");
      return;                   /* print a usage message */
    }                           /* and abort the program */

    /* --- evaluate arguments --- */
    for (int i = 0; i < args.length; i++) {
      String s = args[i];     /* traverse the arguments */
      if ((s.length() > 0)    /* if the argument is an option */
      && (s.charAt(0) == '-')) {
        if (s.length() < 2) { /* check for an option letter */
          System.err.println("missing option"); return; }
        switch (s.charAt(1)){ /* evaluate the option character */
          case 'q':                                               break;
          case '!': SeqMine.help();                              return;
          case 'T': target  = (int)s.charAt(2);                   break;
          case 't': subtype = (int)s.charAt(2);                   break;
          case 'm': zmin    = Integer.parseInt(s.substring(2));   break;
          case 'n': zmax    = Integer.parseInt(s.substring(2));   break;
          case 'j': umax    = Integer.parseInt(s.substring(2));   break;
          case 's': smin    = Double.parseDouble(s.substring(2)); break;
          case 'y': mode   |= REDUCE;                             break;
          case 'e': mode   |= CMEXTS;                             break;
          case '1': mode   |= CMTREE;                             break;
          case '2': mode   |= CMCHAIN;                            break;
          case 'p': mode   |= PREPRUNE;                           break;
          case 'R': reddir  = Integer.parseInt(s.substring(2));   break;
          case 'i': reduce |= PatternSet.ITEMSONLY;               break;
          case 'v': info    = s.substring(2);                     break;
          case 'r': recseps = s.substring(2);                     break;
          case 'f': fldseps = s.substring(2);                     break;
          case 'b': blanks  = s.substring(2);                     break;
          case 'C': comment = s.substring(2);                     break;
          default : System.err.println("unknown option " +s);    return;
        } }
      else {                    /* if the argument is no option */
        switch (k++) {          /* evaluate non-option (fixed arg.) */
          case  0: fn_inp = s;                                    break;
          case  1: fn_out = s;                                    break;
          default: System.err.println("too many arguments");     return;
        }                       /* (there should be two fixed args: */
      }                         /* a name of an input file and */
    }                           /* a name of an output file) */
    if (k < 1) { System.err.println("too few arguments"); return; }
    if (target == 's') {        /* check and translate target type */
      target = SEQUENCE;        /* frequent item sequences */
      switch (subtype) {        /* check and translate target subtype */
        case 's': case 'a':
        case 'f': target |= FREQUENT;              break;
        case 'c': target |= CLOSED;                break;
        case 'm': target |= MAXIMAL;               break;
        case 'g': target |= FREQUENT; reddir = -1; break;
        default : System.err.println("unknown target pattern subtype "
                                     +(char)subtype); return;
      } }                       /* (get the target subtype code) */
    else { System.err.println("unknown target pattern type "
                              +(char)target); return; }
    if (zmin < 0) {             /* check minimum pattern size */
      System.err.println("invalid minimum size "    +zmin); return; }
    if (zmax < zmin) {          /* check maximum pattern size */
      System.err.println("invalid maximum size "    +zmax); return; }
    if (smin > 100) {           /* check minimum support */
      System.err.println("invalid minimum support " +smin); return; }
    if      (reddir < 0) reduce |= PatternSet.MINSIZE;
    else if (reddir > 1) reduce |= PatternSet.MAXSIZE
                                |  PatternSet.NOFILTER;
    else if (reddir > 0) reduce |= PatternSet.MAXSIZE;
    else                 reduce  = PatternSet.NONE;

    /* --- read transactions --- */
    t = System.currentTimeMillis();
    if (!quiet) System.err.print("reading " +fn_inp +" ... ");
    TableReader reader;         /* print a log message */
    try {                       /* open the transaction file */
      reader = new TableReader(new FileReader(fn_inp));
      reader.setChars(recseps, fldseps, blanks, null, comment); }
    catch (IOException e) {     /* check for an error */
      System.err.println("\n" +e.toString()); return; }
    TrActBag tabag;             /* to read transaction into */
    try {                       /* read transaction file */
      tabag = TrActBag.parse(null, reader);
      reader.close(); }         /* close the file reader */
    catch (IOException e) {     /* check for an error */
      System.err.println("\n" +e.toString()); return; }
    int m = tabag.ibase.getSize();     /* get the number of items */
    int n = tabag.size;         /* and the number of transactions */
    int w = tabag.wgt;          /* and the total transaction weight */
    t = System.currentTimeMillis() -t;
    if (!quiet) {               /* unless quiet operation requested, */
      System.err.print("[" +m +" item(s), " +n);
      if (w != n) System.err.printf("/" +w);
      System.err.println(" transaction(s)] done [" +(t/1000.0) +"s].");
    }                           /* print a log message */

    /* --- reduce transactions --- */
    t = System.currentTimeMillis();
    if (!quiet) System.err.print("reducing transactions ... ");
    double x = (smin < 0) ? -smin :  smin /100.0 *w *(1-EPSILON);
    n = tabag.reduce((int)Math.ceil(x));
    m = tabag.ibase.getSize();  /* reduce the transactions and */
    t = System.currentTimeMillis() -t;
    if (!quiet) {               /* unless quiet operation requested */
      System.err.print("[" +m +" item(s), " +n);
      if (w != n) System.err.printf("/" +w);
      System.err.println(" transaction(s)] "
                        +"done [" +(t/1000.0) +"s].");
    }                           /* print a log message */

    /* --- find frequent patterns --- */
    SeqMine    miner = new SeqMine();
    PatternSet pats  = null;    /* initialize miner and result */
    t = System.currentTimeMillis();
    if (!quiet) System.err.print("mining sequences ... ");
    try {                       /* mine for patterns */
      pats = miner.mine(tabag, target, smin, zmin, zmax, umax, mode); }
    catch (Exception e) {       /* check for an error */
      System.err.println(e.toString()); return; }
    n = pats.getSize();         /* get the number of patterns */
    t = System.currentTimeMillis() -t;
    if (!quiet)                 /* print a log message */
      System.err.println("[" +n +" sequence(s)] "
                        +"done [" +(t/1000.0) +"s].");

    /* --- reduce pattern set --- */
    if (reduce != 0) {          /* if to reduce the pattern set */
      t = System.currentTimeMillis();
      if (!quiet) System.err.print("reducing result ... ");
      n = pats.reduce(reduce);  /* minimize/maximize sizes */
      t = System.currentTimeMillis() -t;
      if (!quiet)               /* unless quiet operation requested */
        System.err.println("[" +n +" sequence(s)] "
                          +"done [" +(t/1000.0) +"s].");
    }                           /* print a log message */

    /* --- write found pattern --- */
    if (fn_out != null) {       /* if an output file name is given */
      t = System.currentTimeMillis();
      if (!quiet) System.err.print("writing " +fn_out +" ... ");
      try {                     /* create writer and write patterns */
        Writer writer = new FileWriter(fn_out);
        pats.write(writer, isep, info);
        writer.close(); }       /* close the output file writer */
      catch (Exception e) {     /* check for an error */
        System.err.println(e.toString()); return; }
      t = System.currentTimeMillis() -t;
      if (!quiet)               /* unless quiet operation requested */
        System.err.println("[" +n +" sequence(s)] "
                          +"done [" +(t/1000.0) +"s].");
    }                           /* print a log message */
  }  /* main() */

}  /* class SeqMine */
