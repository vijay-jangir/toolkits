/*----------------------------------------------------------------------
  File    : FIM.java
  Contents: Java interface to frequent item set mining in C
  Author  : Christian Borgelt
  History : 2014.09.26 file created
            2014.10.03 description of return values added
            2014.10.07 descriptions of functions improved
            2014.10.23 wrapper functions with Java objects added
            2014.10.30 function name differences for rules removed
            2015.02.27 item appearances param. added to rule functions
            2015.03.05 handling of user abort request improved
            2016.07.01 bug in report strings fixed ("s" instead of "a")
            2018.03.21 Jaccard Item set Mining (JIM) added
            2018.03.26 moved wrapper functions to a separate file
----------------------------------------------------------------------*/
package fim;

import java.util.Random;

/*--------------------------------------------------------------------*/
/** Class for Java interface to frequent item set mining in C
 *  @author Christian Borgelt
 *  @since  2014.09.26 */
/*--------------------------------------------------------------------*/
public class FIM {

  /*------------------------------------------------------------------*/
  /* Constants                                                        */
  /*------------------------------------------------------------------*/
  public static final String VERSION    = "1.16 (2018.03.26)";

  /* --- target types --- */
  /** target type: all frequent item sets */
  public static final int SETS          = JNIFIM.SETS;
  /** target type: all frequent item sets */
  public static final int ALL           = JNIFIM.ALL;
  /** target type: all frequent item sets */
  public static final int FREQUENT      = JNIFIM.FREQUENT;
  /** target type: closed (frequent) item sets */
  public static final int CLOSED        = JNIFIM.CLOSED;
  /** target type: maximal (frequent) item sets */
  public static final int MAXIMAL       = JNIFIM.MAXIMAL;
  /** target type: generator (frequent) item sets */
  public static final int GENERATORS    = JNIFIM.GENERATORS;
  /** target type: generator (frequent) item sets */
  public static final int GENERAS       = JNIFIM.GENERAS;
  /** target type: association rules */
  public static final int RULES         = JNIFIM.RULES;

  /* --- item appearance indicators --- */
  /** item may not appear anywhere in a rule */
  public static final int IGNORE        = JNIFIM.IGNORE;
  /** item may not appear anywhere in a rule */
  public static final int NEITHER       = JNIFIM.NEITHER;
  /** item may appear only in a rule body/antecedent */
  public static final int INPUT         = JNIFIM.INPUT;
  /** item may appear only in a rule body/antecedent */
  public static final int BODY          = JNIFIM.BODY;
  /** item may appear only in a rule body/antecedent */
  public static final int ANTE          = JNIFIM.ANTE;
  /** item may appear only in a rule body/antecedent */
  public static final int ANTECEDENT    = JNIFIM.ANTECEDENT;
  /** item may appear only in a rule head/consequent */
  public static final int OUTPUT        = JNIFIM.OUTPUT;
  /** item may appear only in a rule head/consequent */
  public static final int HEAD          = JNIFIM.HEAD;
  /** item may appear only in a rule head/consequent */
  public static final int CONS          = JNIFIM.CONS;
  /** item may appear only in a rule head/consequent */
  public static final int CONSEQUENT    = JNIFIM.CONSEQUENT;
  /** item may appear anywhere in a rule */
  public static final int BOTH          = JNIFIM.BOTH;
  /** item may appear anywhere in a rule */
  public static final int INOUT         = JNIFIM.INOUT;
  /** item may appear anywhere in a rule */
  public static final int CANDA         = JNIFIM.CANDA;

  /* --- evaluation measures --- */
  /** evaluation measure/aggregation mode: none */
  public static final int NONE          = JNIFIM.NONE;
  /** evaluation measure: rule support
   *  (larger is better) */
  public static final int SUPPORT       = JNIFIM.SUPPORT;
  /** evaluation measure: rule support
   *  (larger is better) */
  public static final int SUPP          = JNIFIM.SUPP;
  /** evaluation measure: rule confidence
   *  (larger is better) */
  public static final int CONFIDENCE    = JNIFIM.CONFIDENCE;
  /** evaluation measure: rule confidence
   *  (larger is better) */
  public static final int CONF          = JNIFIM.CONF;
  /** evaluation measure: absolute confidence difference to prior
   *  (larger is better) */
  public static final int CONFDIFF      = JNIFIM.CONFDIFF;
  /** evaluation measure: lift value (confidence divided by prior)
   *  (larger is better) */
  public static final int LIFT          = JNIFIM.LIFT;
  /** evaluation measure: difference of lift value to 1
   *  (larger is better) */
  public static final int LIFTDIFF      = JNIFIM.LIFTDIFF;
  /** evaluation measure: difference of lift quotient to 1
   *  (larger is better) */
  public static final int LIFTQUOT      = JNIFIM.LIFTQUOT;
  /** evaluation measure: conviction
   *  (larger is better) */
  public static final int CONVICTION    = JNIFIM.CONVICTION;
  /** evaluation measure: conviction
   *  (larger is better) */
  public static final int CVCT          = JNIFIM.CVCT;
  /** evaluation measure: difference of conviction to 1
   *  (larger is better) */
  public static final int CVCTDIFF      = JNIFIM.CVCTDIFF;
  /** evaluation measure: difference of conviction quotient to 1
   *  (larger is better) */
  public static final int CVCTQUOT      = JNIFIM.CVCTQUOT;
  /** evaluation measure: conditional probability ratio
   *  (larger is better) */
  public static final int CPROB         = JNIFIM.CPROB;
  /** evaluation measure: conditional probability ratio
   *  (larger is better) */
  public static final int CONDPROB      = JNIFIM.CONDPROB;
  /** evaluation measure: importance
   *  (larger is better) */
  public static final int IMPORTANCE    = JNIFIM.IMPORTANCE;
  /** evaluation measure: importance
   *  (larger is better) */
  public static final int IMPORT        = JNIFIM.IMPORT;
  /** evaluation measure: certainty factor
   *  (larger is better) */
  public static final int CERTAINTY     = JNIFIM.CERTAINTY;
  /** evaluation measure: certainty factor
   *  (larger is better) */
  public static final int CERT          = JNIFIM.CERT;
  /** evaluation measure: normalized chi^2 measure
   *  (larger is better) */
  public static final int CHI2          = JNIFIM.CHI2;
  /** evaluation measure: p-value from chi^2 measure
   *  (smaller is better) */
  public static final int CHI2PVAL      = JNIFIM.CHI2PVAL;
  /** evaluation measure: normalized chi^2 measure (Yates corrected)
   *  (larger is better) */
  public static final int YATES         = JNIFIM.YATES;
  /** evaluation measure: p-value from chi^2 measure (Yates corrected)
   *  (smaller is better) */
  public static final int YATESPVAL     = JNIFIM.YATESPVAL;
  /** evaluation measure: information difference to prior
   *  (larger is better) */
  public static final int INFO          = JNIFIM.INFO;
  /** evaluation measure: p-value from information difference
   *  (smaller is better) */
  public static final int INFOPVAL      = JNIFIM.INFOPVAL;
  /** evaluation measure: Fisher's exact test (table probability)
   *  (smaller is better) */
  public static final int FETPROB       = JNIFIM.FETPROB;
  /** evaluation measure: Fisher's exact test (chi^2 measure)
   *  (smaller is better) */
  public static final int FETCHI2       = JNIFIM.FETCHI2;
  /** evaluation measure: Fisher's exact test (information gain)
   *  (smaller is better) */
  public static final int FETINFO       = JNIFIM.FETINFO;
  /** evaluation measure: Fisher's exact test (support)
   *  (smaller is better) */
  public static final int FETSUPP       = JNIFIM.FETSUPP;
  /** evaluation measure: binary logarithm of support quotient
   *  (larger is better) */
  public static final int LDRATIO       = JNIFIM.LDRATIO;
  /** evaluation measure: item set size times cover similarity
   *  (larger is better) (only for JIM algorithm) */
  public static final int SIZESIM       = JNIFIM.SIZESIM;

  /* --- aggregation modes --- */
  /** aggregation mode: minimum of individual measure values */
  public static final int MIN           = JNIFIM.MIN;
  /** aggregation mode: minimum of individual measure values */
  public static final int MINIMUM       = JNIFIM.MINIMUM;
  /** aggregation mode: maximum of individual measure values */
  public static final int MAX           = JNIFIM.MAX;
  /** aggregation mode: maximum of individual measure values */
  public static final int MAXIMUM       = JNIFIM.MAXIMUM;
  /** aggregation mode: average of individual measure values */
  public static final int AVG           = JNIFIM.AVG;
  /** aggregation mode: average of individual measure values */
  public static final int AVERAGE       = JNIFIM.AVERAGE;

  /* --- algorithm variants --- */
  /** algorithm variant: automatic choice (always applicable) */
  public static final int AUTO          = JNIFIM.AUTO;

  /** Apriori variant: basic algorithm */
  public static final int APRI_BASIC    = JNIFIM.APRI_BASIC;

  /** Eclat variant: transaction id lists intersection (basic) */
  public static final int ECLAT_BASIC   = JNIFIM.ECLAT_BASIC;
  /** Eclat variant: transaction id lists intersection (improved) */
  public static final int ECLAT_LISTS   = JNIFIM.ECLAT_LISTS;
  /** Eclat variant: transaction id lists intersection (improved) */
  public static final int ECLAT_TIDS    = JNIFIM.ECLAT_TIDS;
  /** Eclat variant: transaction id lists as bit vectors */
  public static final int ECLAT_BITS    = JNIFIM.ECLAT_BITS;
  /** Eclat variant: item occurrence table (standard) */
  public static final int ECLAT_TABLE   = JNIFIM.ECLAT_TABLE;
  /** Eclat variant: item occurrence table (simplified) */
  public static final int ECLAT_SIMPLE  = JNIFIM.ECLAT_SIMPLE;
  /** Eclat variant: transaction id range lists intersection */
  public static final int ECLAT_RANGES  = JNIFIM.ECLAT_RANGES;
  /** Eclat variant: occurrence deliver from transaction lists */
  public static final int ECLAT_OCCDLV  = JNIFIM.ECLAT_OCCDLV;
  /** Eclat variant: occurrence deliver from transaction lists */
  public static final int ECLAT_LCM     = JNIFIM.ECLAT_LCM;
  /** Eclat variant: transaction id difference sets (diffsets) */
  public static final int ECLAT_DIFFS   = JNIFIM.ECLAT_DIFFS;

  /** FP-growth variant: simple tree nodes (link and parent) */
  public static final int FPG_SIMPLE    = JNIFIM.FPG_SIMPLE;
  /** FP-growth variant: complex tree nodes (children and sibling) */
  public static final int FPG_COMPLEX   = JNIFIM.FPG_COMPLEX;
  /** FP-growth variant: top-down processing on a single prefix tree */
  public static final int FPG_SINGLE    = JNIFIM.FPG_SINGLE;
  /** FP-growth variant: top-down processing of the prefix trees */
  public static final int FPG_TOPDOWN   = JNIFIM.FPG_TOPDOWN;

  /** SaM variant: basic split and merge algorithm */
  public static final int SAM_BASIC     = JNIFIM.SAM_BASIC;
  /** SaM variant: split and merge with binary search */
  public static final int SAM_BSEARCH   = JNIFIM.SAM_BSEARCH;
  /** SaM variant: split and merge with double source buffering */
  public static final int SAM_DOUBLE    = JNIFIM.SAM_DOUBLE;
  /** SaM variant: split and merge with transaction prefix tree */
  public static final int SAM_TREE      = JNIFIM.SAM_TREE;

  /** RElim variant: basic recursive elimination algorithm */
  public static final int RELIM_BASIC   = JNIFIM.RELIM_BASIC;

  /** JIM variant: basic algorithm */
  public static final int JIM_BASIC     = JNIFIM.JIM_BASIC;

  /** Carpenter variant: item occurrence counter table */
  public static final int CARP_TABLE    = JNIFIM.CARP_TABLE;
  /** Carpenter variant: transaction identifier lists */
  public static final int CARP_LISTS    = JNIFIM.CARP_LISTS;
  /** Carpenter variant: transaction identifier lists */
  public static final int CARP_TIDLIST  = JNIFIM.CARP_TIDLIST;
  /** Carpenter variant: transaction identifier lists */
  public static final int CARP_TIDLISTS = JNIFIM.CARP_TIDLISTS;

  /** IsTa variant: standard prefix tree */
  public static final int ISTA_PREFIX   = JNIFIM.ISTA_PREFIX;
  /** IsTa variant: patricia tree (compact prefix tree) */
  public static final int ISTA_PATRICIA = JNIFIM.ISTA_PATRICIA;

  /* --- mode flags --- */
  /** processing mode: do not use a 16-items machine */
  public static final int NOFIM16       = JNIFIM.NOFIM16;   /* l */
  /** processing mode: do not use perfect extension pruning */
  public static final int NOPERFECT     = JNIFIM.NOPERFECT; /* x */
  /** processing mode: do not sort items w.r.t. conditional support */
  public static final int NOSORT        = JNIFIM.NOSORT;    /* i */
  /** processing mode: do not use head union tail (hut) pruning
   *  (for maximal item sets) */
  public static final int NOHUT         = JNIFIM.NOHUT;     /* u */
  /** processing mode: check extensions for closed/maximal item sets
   *  with a horizontal scheme (default: use a repository) */
  public static final int HORZ          = JNIFIM.HORZ;      /* y */
  /** processing mode: check extensions for closed/maximal item sets
   *  with a vertical scheme (default: use a repository) */
  public static final int VERT          = JNIFIM.VERT;      /* Y */
  /** processing mode: invalidate evaluation below expected support */
  public static final int INVBXS        = JNIFIM.INVBXS;    /* z */
  /** processing mode: use original support definition for rules
   *  (body &amp; head instead of only body) */
  public static final int ORIGSUPP      = JNIFIM.ORIGSUPP;  /* o */

  /** processing mode: do not organize transactions as a prefix tree
   *  (for Apriori algorithm) */
  public static final int NOTREE        = JNIFIM.NOTREE;    /* t/T */
  /** processing mode: a-posteriori pruning of infrequent item sets
   *  (for Apriori algorithm) */
  public static final int POSTPRUNE     = JNIFIM.POSTPRUNE; /* y */
  /** processing mode: filter maximal item sets with repository
   *  (for Carpenter algorithm) */
  public static final int REPOFILT      = JNIFIM.REPOFILT;  /* z */
  /** processing mode: add all (closed) item sets to repository
   *  (for Carpenter algorithm) */
  public static final int ADDALL        = JNIFIM.ADDALL;    /* y */
  /** processing mode: do not collate equal transactions
   *  (for Carpenter algorithm) */
  public static final int NOCOLLATE     = JNIFIM.NOCOLLATE; /* p */
  /** processing mode: do not prune the prefix/patricia tree
   *  (for IsTa algorithm) */
  public static final int NOPRUNE       = JNIFIM.NOPRUNE;   /* p */

  /* --- cover similarity measures for JIM --- */
  /* n = total number of transactions                          */
  /* s = number of transactions with all items in the item set */
  /* r = number of transactions with at least one item in set  */
  /* q = number of transactions with some (but not all) items  */
  /* z = number of transactions with no items in the set       */
  /* x = \sqrt{sz} (geometric mean of s and z)                 */
  /** JIM: no cover similarity */
  public static final int JIM_NONE
                 = JNIFIM.JIM_NONE;
  /** JIM: Russel-Rao S_R = s/n */
  public static final int JIM_RUSSEL_RAO
                 = JNIFIM.JIM_RUSSEL_RAO;
  /** JIM: Kulcynski S_K = s/q */
  public static final int JIM_KULCYNSKI
                 = JNIFIM.JIM_KULCYNSKI;
  /** JIM: Jaccard/Tanimoto S_J = s/r */
  public static final int JIM_JACCARD
                 = JNIFIM.JIM_JACCARD;
  /** JIM: Jaccard/Tanimoto S_J = s/r */
  public static final int JIM_TANIMOTO
                 = JNIFIM.JIM_TANIMOTO;
  /** JIM: Dice S_D = 2s/(r+s) */
  public static final int JIM_DICE
                 = JNIFIM.JIM_DICE;
  /** JIM: Sorensen S_D = 2s/(r+s) */
  public static final int JIM_SORENSEN
                 = JNIFIM.JIM_SORENSEN;
  /** JIM: Czekanowski S_D = 2s/(r+s) */
  public static final int JIM_CZEKANOWSKI
                 = JNIFIM.JIM_CZEKANOWSKI;
  /** JIM: Sokal--Sneath 1 S_S = s/(r+q) */
  public static final int JIM_SOKAL_SNEATH_1
                 = JNIFIM.JIM_SOKAL_SNEATH_1;
  /** JIM: Sokal--Michener S_M = (s+z)/n */
  public static final int JIM_SOKAL_MICHENER
                 = JNIFIM.JIM_SOKAL_MICHENER;
  /** JIM: Hamming S_M = (s+z)/n */
  public static final int JIM_HAMMING
                 = JNIFIM.JIM_HAMMING;
  /** JIM: Faith S_F = (s+z/2)/n */
  public static final int JIM_FAITH
                 = JNIFIM.JIM_FAITH;
  /** JIM: Rogers--Tanimoto S_T = (s+z)/(n+q) */
  public static final int JIM_ROGERS_TANIMOTO
                 = JNIFIM.JIM_ROGERS_TANIMOTO;
  /** JIM: Sokal--Sneath 2 S_N = 2(s+z)/(n+s+z) */
  public static final int JIM_SOKAL_SNEATH_2
                 = JNIFIM.JIM_SOKAL_SNEATH_2;
  /** JIM: Gower--Legendre S_N = 2(s+z)/(n+s+z) */
  public static final int JIM_GOWER_LEGENDRE
                 = JNIFIM.JIM_GOWER_LEGENDRE;
  /** JIM: Sokal--Sneath 3 S_O = (s+z)/q */
  public static final int JIM_SOKAL_SNEATH_3
                 = JNIFIM.JIM_SOKAL_SNEATH_3;
  /** JIM: Baroni--Buser S_B = (x+s)/(x+r) */
  public static final int JIM_BARONI_BUSER
                 = JNIFIM.JIM_BARONI_BUSER;
  /** JIM: generic measure S = (c_0s +c_1z +c_2n +c_3x)
                             / (c_4s +c_5z +c_6n +c_7x) */
  public static final int JIM_GENERIC
                 = JNIFIM.JIM_GENERIC;

  /* --- surrogate data generation methods --- */
  /** surrogate method: identity (keep original data) */
  public static final int IDENT         = JNIFIM.IDENT;
  /** surrogate method: random transaction generation */
  public static final int RANDOM        = JNIFIM.RANDOM;
  /** surrogate method: permutation by pair swaps */
  public static final int SWAP          = JNIFIM.SWAP;
  /** surrogate method: shuffle table-derived data (columns) */
  public static final int SHUFFLE       = JNIFIM.SHUFFLE;

  /* --- pattern spectrum report formats --- */
  /** pattern spectrum report format:
   *  three columns size (integer), support (integer) and
   *  (average) occurrence frequency (double) */
  public static final String COLUMNS    = JNIFIM.COLUMNS;
  /** pattern spectrum report format:
   *  objects of type <code>PatSpecElem</code> */
  public static final String OBJECTS    = JNIFIM.OBJECTS;

  /*------------------------------------------------------------------*/
  /** Java interface to frequent item set mining in C
   *  (very simplified interface, wrapper with Java objects).
   *  @param  tracts transaction set to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code> or <code>GENERATORS</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet fim (TrActBag tracts,
    int target, double supp, int zmin, int zmax, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.fim(t, w, target, supp, zmin, zmax,
                                     "a", border));
  }  /* fim() */

  /*------------------------------------------------------------------*/
  /** Java interface to frequent item set mining in C
   *  (less simplified interface, wrapper with Java objects).
   *  @param  tracts transaction set to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code> or <code>GENERATORS</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                  better, upper bound for measures for which
   *                  smaller is better)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet xfim (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, int agg, double thresh, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.xfim(t, w, target, supp, zmin, zmax,
                                      "ae", eval, agg, thresh, border));
  }  /* xfim() */

  /*------------------------------------------------------------------*/
  /** Java interface to association rule induction in C
   *  (wrapper with Java objects).
   *  @param  tracts transaction set to analyze
   *  @param  supp   minimum support of an association rule<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per association rule
   *  @param  zmax   maximum number of items per association rule
   *  @param  eval   measure for association rule evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                  better, upper bound for measures for which
   *                  smaller is better)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code> or <code>ORIGSUPP</code>)
   *  @return a set of association rules
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet arules (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int mode)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.arules(t, w, supp, conf, zmin, zmax,
                                      "abhe", eval, thresh, mode,
                                      null));
  }  /* arules() */

  /*------------------------------------------------------------------*/
  /** Java interface to association rule induction in C
   *  (wrapper with Java objects).
   *  @param  tracts transaction set to analyze
   *  @param  supp   minimum support of an association rule<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per association rule
   *  @param  zmax   maximum number of items per association rule
   *  @param  eval   measure for association rule evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                  better, upper bound for measures for which
   *                  smaller is better)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code> or <code>ORIGSUPP</code>)
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return a set of association rules
   *  @since  2015.02.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet arules (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int mode, int[][] appear)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.arules(t, w, supp, conf, zmin, zmax,
                                      "abhe", eval, thresh, mode,
                                      appear));
  }  /* arules() */

  /*------------------------------------------------------------------*/
  /** Java interface to Apriori algorithm in C
   *  (frequent item set mining, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code> or <code>GENERATORS</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>APRI_BASIC</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOPERFECT</code>,
   *                  <code>NOTREE</code>, <code>POSTPRUNE</code>,
   *                  <code>INVBXS</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet apriori (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, int agg, double thresh, int prune,
    int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.apriori(t, w, target,
                                         supp, 0, zmin, zmax,
                                         "ae", eval, agg, thresh, prune,
                                         algo, mode, border, null));
  }  /* apriori() */

  /*------------------------------------------------------------------*/
  /** Java interface to Apriori algorithm in C
   *  (association rule induction, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>APRI_BASIC</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOTREE</code>,
   *                  <code>POSTPRUNE</code>, <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet apriori (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.apriori(t, w, RULES,
                                       supp, conf, zmin, zmax,
                                       "abhe", eval, 0, thresh, 0,
                                       algo, mode, border, null));
  }  /* apriori() */

  /*------------------------------------------------------------------*/
  /** Java interface to Apriori algorithm in C
   *  (association rule induction, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>APRI_BASIC</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOTREE</code>,
   *                  <code>POSTPRUNE</code>, <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet apriori (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int algo, int mode,
    int[] border, int[][] appear)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.apriori(t, w, RULES,
                                       supp, conf, zmin, zmax,
                                       "abhe", eval, 0, thresh, 0,
                                       algo, mode, border, appear));
  }  /* apriori() */

  /*------------------------------------------------------------------*/
  /** Java interface to Eclat algorithm in C
   *  (frequent item set mining, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code> or <code>GENERATORS</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>ECLAT_BASIC</code>,
   *                  <code>ECLAT_TIDS</code>, <code>ECLAT_BITS</code>,
   *                  <code>ECLAT_TABLE</code>,
   *                  <code>ECLAT_SIMPLE</code>,
   *                  <code>ECLAT_RANGES</code>,
   *                  <code>ECLAT_OCCDLV</code>,
   *                  <code>ECLAT_DIFFS</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>,
   *                  <code>NOFIM16</code>, <code>NOPERFECT</code>,
   *                  <code>NOSORT</code>, <code>NOHUT</code>,
   *                  <code>HORZ</code>, <code>VERT</code>,
   *                  <code>INVBXS</code>, <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet eclat (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, int agg, double thresh, int prune,
    int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.eclat(t, w, target,
                                       supp, 0, zmin, zmax,
                                       "ae", eval, agg, thresh, prune,
                                       algo, mode, border, null));
  }  /* eclat() */

  /*------------------------------------------------------------------*/
  /** Java interface to Eclat algorithm in C
   *  (association rule induction, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>ECLAT_OCCDLV</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code> or <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet eclat (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.eclat(t, w, RULES,
                                     supp, conf, zmin, zmax,
                                     "abhe", eval, 0, thresh, 0,
                                     algo, mode, border, null));
  }  /* eclat() */

  /*------------------------------------------------------------------*/
  /** Java interface to Eclat algorithm in C
   *  (association rule induction, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>ECLAT_OCCDLV</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code> or <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return a set of (frequent) item sets
   *  @since  2015.02.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet eclat (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int algo, int mode,
    int[] border, int[][] appear)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.eclat(t, w, RULES,
                                     supp, conf, zmin, zmax,
                                     "abhe", eval, 0, thresh, 0,
                                     algo, mode, border, appear));
  }  /* eclat() */

  /*------------------------------------------------------------------*/
  /** Java interface to FP-growth algorithm in C
   *  (frequent item set mining, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code> or <code>GENERATORS</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>FPG_SIMPLE</code>,
   *                  <code>FPG_COMPLEX</code>, <code>FPG_SINGLE</code>,
   *                  <code>FPG_TOPDOWN</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>, <code>NOSORT</code>,
   *                  <code>NOHUT</code>, <code>INVBXS</code>,
   *                  <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet fpgrowth (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, int agg, double thresh, int prune,
    int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.fpgrowth(t, w, target,
                                          supp, 0, zmin, zmax, "ae",
                                          eval, agg, thresh, prune,
                                          algo, mode, border, null));
  }  /* fpgrowth() */

  /*------------------------------------------------------------------*/
  /** Java interface to FP-growth algorithm in C
   *  (association rule induction, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>FPG_SINGLE</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code> or <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet fpgrowth (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.fpgrowth(t, w, RULES,
                                        supp, conf, zmin, zmax,
                                        "abhe", eval, 0, thresh, 0,
                                        algo, mode, border, null));
  }  /* fpgrowth() */

  /*------------------------------------------------------------------*/
  /** Java interface to FP-growth algorithm in C
   *  (association rule induction, wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>FPG_SINGLE</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code> or <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return a set of (frequent) item sets
   *  @since  2015.02.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet fpgrowth (TrActBag tracts,
    double supp, double conf, int zmin, int zmax,
    int eval, double thresh, int algo, int mode,
    int[] border, int[][] appear)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new ARuleSet(tracts.getItemBase(), t.length,
                        JNIFIM.fpgrowth(t, w, RULES,
                                        supp, conf, zmin, zmax,
                                        "abhe", eval, 0, thresh, 0,
                                        algo, mode, border, appear));
  }  /* fpgrowth() */

  /*------------------------------------------------------------------*/
  /** Java interface to SaM algorithm in C
   *  (wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code> or
   *                  <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>SAM_SIMPLE</code>,
   *                  <code>SAM_BSEARCH</code>, <code>SAM_DOUBLE</code>,
   *                  <code>SAM_TREE</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet sam (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, double thresh, int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.sam(t, w, target, supp, zmin, zmax,
                                     "ae", eval, thresh, algo, mode,
                                     border));
  }  /* sam() */

  /*------------------------------------------------------------------*/
  /** Java interface to RElim algorithm in C
   *  (wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code> or
   *                  <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>RELIM_BASIC</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet relim (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, double thresh, int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.relim(t, w, target, supp, zmin, zmax,
                                       "ae", eval, thresh, algo, mode,
                                       border));
  }  /* relim() */

  /*------------------------------------------------------------------*/
  /** Java interface to JIM algorithm in C
   *  (wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code> or
   *                  <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  covsim cover similarity measure
   *                 (<code>JIM_NONE</code>,
   *                  <code>JIM_RUSSEL_RAO</code>,
   *                  <code>JIM_KULCZYNSKI</code>,
   *                  <code>JIM_JACCARD</code>,
   *                  <code>JIM_TANIMOTO</code>, <code>JIM_DICE</code>,
   *                  <code>JIM_SORENSEN</code>,
   *                  <code>JIM_CZEKANOWKSI</code>,
   *                  <code>JIM_SOKAL_SNEATH_1</code>,
   *                  <code>JIM_SOKAL_MICHENER</code>,
   *                  <code>JIM_HAMMING</code>, <code>JIM_FAITH</code>,
   *                  <code>JIM_ROGERS_TANIMOTO</code>,
   *                  <code>JIM_SOKAL_SNEATH_2</code>,
   *                  <code>JIM_GOWER_LEGENDRE</code>,
   *                  <code>JIM_SOKAL_SNEATH_3</code>,
   *                  <code>JIM_BARONI_BUSER</code>,
   *                  <code>JIM_GENERIC</code>)
   *  @param  simps  cover similarity measure parameters (if generic)
   *                 S = (c_0s +c_1z +c_2n +c_3x)
   *                   / (c_4s +c_5z +c_6n +c_7x)
   *  @param  sim    threshold for cover similarity measure
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>SAM_SIMPLE</code>,
   *                  <code>SAM_BSEARCH</code>, <code>SAM_DOUBLE</code>,
   *                  <code>SAM_TREE</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2018.03.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet jim (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, double thresh, int covsim, double[] simps, double sim,
    int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.jim(t, w, target, supp, zmin, zmax,
                                     "aew", eval, thresh, covsim, simps,
                                     sim, algo, mode, border));
  }  /* jim() */

  /*------------------------------------------------------------------*/
  /** Java interface to Carpenter algorithm in C
   *  (wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>CLOSED</code> or <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>CARP_TABLE</code>,
   *                  <code>CARP_TIDLIST</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOPERFECT</code>,
   *                  <code>REPOFILT</code>, <code>MAXONLY</code>,
   *                  <code>NOCOLLATE</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet carpenter (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, double thresh, int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.carpenter(t, w, target,
                                           supp, zmin, zmax, "ae",
                                           eval, thresh, algo, mode,
                                           border));
  }  /* carpenter() */

  /*------------------------------------------------------------------*/
  /** Java interface to IsTa algorithm in C
   *  (wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  target type of the item sets to find
   *                 (<code>CLOSED</code> or <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  eval   measure for item set evaluation
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>ISTA_PREFIX</code>,
   *                  <code>ISTA_PATRICIA</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOPRUNE</code>,
   *                  <code>REPOFILT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet ista (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int eval, double thresh, int algo, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.ista(t, w, target, supp, zmin, zmax,
                                      "ae", eval, thresh, algo, mode,
                                      border));
  }  /* ista() */

  /*------------------------------------------------------------------*/
  /** Java interface to accretion-style Apriori algorithm in C
   *  (wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  stat   test statistic for item set evaluation
   *                 (<code>NONE</code>, <code>CHI2PVAL</code>,
   *                  <code>YATESPVAL</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  siglvl significance level (maximum p-value)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>INVBXS</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet apriacc (TrActBag tracts,
    double supp, int zmin, int zmax,
    int stat, double siglvl, int prune, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.apriacc(t, w, supp, zmin, zmax, "ap",
                                         stat, siglvl, prune, mode,
                                         border));
  }  /* apriacc() */

  /*------------------------------------------------------------------*/
  /** Java interface to Accretion algorithm in C.
   *  @param  tracts transactions to analyze
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  stat   test statistic for item set evaluation
   *                 (<code>NONE</code>, <code>CHI2PVAL</code>,
   *                  <code>YATESPVAL</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  siglvl significance level (maximum p-value)
   *  @param  maxext maximum number of extension items
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>INVBXS</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return a set of (frequent) item sets
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet accretion (TrActBag tracts,
    double supp, int zmin, int zmax,
    int stat, double siglvl, int maxext, int mode, int[] border)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return new PatternSet(tracts.getItemBase(), t.length,
                          JNIFIM.accretion(t, w, supp, zmin, zmax, "ap",
                                           stat, siglvl, maxext, mode,
                                           border));
  }  /* accretion() */

  /*------------------------------------------------------------------*/
  /** Pattern spectrum generation with surrogate data sets
   *  (wrapper with Java objects).
   *  @param  tracts transactions to process
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code> or
   *                  <code>FREQUENT</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  cnt    number of surrogate data sets to generate
   *  @param  surr   surrogate data generation method
   *                 (<code>IDENT</code>, <code>RANDOM</code>,
   *                  <code>SWAP</code> or <code>SHUFFLE</code>)
   *  @param  seed   seed value for random number generator
   *  @param  cpus   number of cpus/threads to use
   *  @param  ctrl   control array (progress indicator, stop flag)
   *  @return an array with objects of type <code>PatSpecElem</code>,
   *          each of which specifies a pattern signature together
   *          with its occurrence frequency
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatSpecElem[] genpsp (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int cnt, int surr, int seed, int cpus, int[] ctrl)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return (PatSpecElem[])JNIFIM.genpsp(t, w, target, supp, zmin, zmax,
                                        "=", cnt, surr, seed,
                                        cpus, ctrl);
  }  /* genpsp() */

  /*------------------------------------------------------------------*/
  /** Estimate a pattern spectrum from data characteristics
   *  (wrapper with Java objects).
   *  @param  tracts transactions to analyze
   *  @param  equiv  equivalent number of surrogate data sets
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code> or
   *                  <code>FREQUENT</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  alpha  probability dispersion factor
   *  @param  smpls  number of samples per item set size
   *  @param  seed   seed value for random number generator
   *  @return an array with objects of type <code>PatSpecElem</code>,
   *          each of which specifies a pattern signature together
   *          with its occurrence frequency
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatSpecElem[] estpsp (TrActBag tracts,
    int target, double supp, int zmin, int zmax,
    int equiv, double alpha, int smpls, int seed)
  {                             /* --- wrapper with Java types */
    int[][] t = tracts.getTrActs();
    int[]   w = tracts.unitWeight() ? null : tracts.getWeights();
    return (PatSpecElem[])JNIFIM.estpsp(t, w, target, supp, zmin, zmax,
                                        "=", equiv, alpha, smpls, seed);
  }  /* estpsp() */

  /*------------------------------------------------------------------*/
  /** Main program for testing.
   *  @param  args the command line arguments
   *  @since  2013.11.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    int         i, k;           /* loop variables */
    int         cnt;            /* number of surrogate data sets */
    int[][]     tracts;         /* transactions */
    Object[]    res;            /* result of coconad call */
    int[]       sizes, supps;   /* sizes and support values */
    double[]    frqs;           /* occurrence frequencies */
    int[][]     pats;           /* found patterns as item id arrays */
    int[]       heads;          /* heads of association rules */
    double[]    confs;          /* association rule confidences */
    PatSpecElem pse;            /* pattern spectrum element */
    Random      rand;           /* random number generator */
    int[][]     app  = { { -1, 1 }, { INPUT, OUTPUT } };
    int[]       ctrl = {0,0};   /* control array (progress indicator) */

    tracts = new int[1000][];   /* create a spike trains array */
    rand   = new Random();      /* and a random number generator */
    for (i = tracts.length; --i >= 0; ) {
      tracts[i] = new int[rand.nextInt(29)+1];
      for (k = tracts[i].length; --k >= 0; )
        tracts[i][k] = rand.nextInt(30);
    }                           /* generate random transactions */
    if (args.length <= 0) cnt = 1;
    else try { cnt = Integer.parseInt(args[0]); }
    catch (NumberFormatException e) { cnt = 0; }
    if      (cnt <= -5)         /* test association rule induction */
      res = JNIFIM.arules(tracts, null, -2, 0.8, 2, -1, "aC",
                          0, 0, NONE, app);
    else if (cnt <= -4)         /* test pattern spectrum estimation */
      res = JNIFIM.estpsp(tracts, null, ALL,    -2, 2, -1, "#",
                          10000, 0.5, 1000, 0);
    else if (cnt <= -3)         /* test pattern spectrum estimation */
      res = JNIFIM.estpsp(tracts, null, ALL,    -2, 2, -1, "=",
                          10000, 0.5, 1000, 0);
    else if (cnt <= -2)         /* test pattern spectrum */
      res = JNIFIM.fim   (tracts, null, CLOSED, -2, 2, -1, "#", null);
    else if (cnt <= -1)         /* test pattern spectrum */
      res = JNIFIM.fim   (tracts, null, CLOSED, -2, 2, -1, "=", null);
    else if (cnt <=  0)         /* test full pattern set */
      res = JNIFIM.fim   (tracts, null, CLOSED, -2, 2, -1, "a", null);
    else                        /* test surrogate generation */
      res = JNIFIM.genpsp(tracts, null, CLOSED, -2, 2, -1, "#",
                          cnt, SWAP, 0, 0, ctrl);
    if (cnt == 0) {             /* if full pattern set */
      pats  = (int[][]) res[0]; /* find frequent item sets */
      supps = (int[])   res[1]; /* and get the result parts */
      for (i = 0; i < pats.length; i++) {
        for (k = 0; k < pats[i].length; k++)
          System.out.print(pats[i][k]+" ");
        System.out.println(" ("+supps[i]+")");
      } }                       /* traverse and print item sets */
    else if  (cnt <= -5) {      /* if association rules */
      heads = (int[])   res[0];
      pats  = (int[][]) res[1];
      supps = (int[])   res[2];
      confs = (double[])res[3];
      for (i = 0; i < heads.length; i++) {
        System.out.print(heads[i]);
        for (k = 0; k < pats[i].length; k++)
          System.out.print(" " +pats[i][k]);
        System.out.println(" ("+supps[i]+","+confs[i]+")");
      } }
    else if ((cnt == -1)        /* if pattern spectrum with objects */
    ||       (cnt == -3)) {     /* (PatSpecElem) */
      for (i = 0; i < res.length; i++) {
        pse = (PatSpecElem)res[i];
        System.out.println(pse.size+" "+pse.supp+" : "+pse.freq);
      } }                       /* traverse and print triplets */
    else {                      /* if only pattern spectrum */
      sizes = (int[])   res[0]; /* generate a pattern spectrum */
      supps = (int[])   res[1]; /* and get its three columns, */
      frqs  = (double[])res[2]; /* then print the triplets */
      for (i = 0; i < sizes.length; i++)
        System.out.println(sizes[i]+" "+supps[i]+" : "+frqs[i]);
    }                           /* print triplets of pattern spectrum */
  }  /* main() */

}  /* class FIM */
