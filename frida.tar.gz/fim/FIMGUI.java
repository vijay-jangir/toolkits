/*----------------------------------------------------------------------
  File    : FIMGUI.java
  Contents: frequent item set mining toolbox
  Author  : Christian Borgelt
  History : 2014.10.18 file created from file ARuleGUI.java
            2014.10.20 options for Eclat and FP-growth added
            2014.10.22 terminal tab for external program output added
            2014.10.23 changed from LGPL license to MIT license
            2015.03.30 workaround for Java bug added (command args.)
            2018.11.14 replaced some deprecated functions
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import dialog.TabbedGUI;
import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.TerminalPanel;
import dialog.AboutPanel;
import dialog.FormatDialog;
import util.Executor;
import util.CmdExecutor;

/*--------------------------------------------------------------------*/
/** Class for a user interface to frequent item set mining programs.
 *  @author Christian Borgelt
 *  @since  2014.10.18 */
/*--------------------------------------------------------------------*/
public class FIMGUI extends TabbedGUI implements ActionListener {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010007L;
  public  static final String VERSION = "1.7 (2018.11.14)";

  /** the index of the Apriori program */
  private static final int APRIORI  = 0;
  /** the index of the Eclat program */
  private static final int ECLAT    = 1;
  /** the index of the FP-growth program */
  private static final int FPGROWTH = 2;

  /** the names of the algorithms/programs */
  private static final String[] algonames = {
    "Apriori", "Eclat", "FP-growth" };
  /** the names of the programs */
  private static final String[] prgnames = {
    "apriori", "eclat", "fpgrowth" };

  /** the names of the target types */
  private static final String[] targnames = {
    "frequent", "closed", "maximal", "generator" };
  /** the names of the target types */
  private static final char[] targcodes = {
    's', 'c', 'm', 'g' };

  /** the names of the item set evaluation measures */
  private static final String[] emnames = {
    "none",                                     /* x */
    "rule confidence",                          /* c */
    "abs. confidence difference to prior",      /* d */
    "lift value (confidence / prior)",          /* l */
    "abs. difference of lift value to 1",       /* a */
    "difference of lift quotient to 1",         /* q */
    "conviction (inv. lift for negated head)",  /* v */
    "abs. difference of conviction to 1",       /* e */
    "diff. of conviction quotient to 1",        /* r */
    "certainty factor (rel. conf. change)",     /* z */
    "normalized chi^2 measure",                 /* n */
    "p-value from chi^2 measure",               /* p */
    "chi^2 measure with Yates' correction",     /* y */
    "p-value from Yates-corrected chi^2",       /* t */
    "information difference to prior",          /* i */
    "p-value from G statistic/info. diff.",     /* g */
    "Fisher's exact test (table probability)",  /* f */
    "Fisher's exact test (chi^2 measure)",      /* h */
    "Fisher's exact test (information gain)",   /* m */
    "Fisher's exact test (support)",            /* s */
  };
  /** the codes of the item set evaluation measures */
  private static final char[] emcodes = {
    'x', 'c', 'd', 'l', 'a', 'q', 'v', 'e', 'r', 'z',
    'n', 'p', 'y', 't', 'i', 'g', 'f', 'h', 'm', 's' };

  /** the names of the evaluation aggregation modes */
  private static final String[] aggnames = {
    "none (use first)",                         /* x */
    "minimum",                                  /* m */
    "maximum",                                  /* n */
    "average",                                  /* a */
  };
  /** the codes of the evaluation aggregation modes */
  private static final char[] aggcodes = {
    'x', 'm', 'n', 'a' };

  /** the names of the pruning modes */
  private static final String[] prnnames = {
    "none", "backward", "weak forward", "strong forward" };

  /** the names of the transaction sorting modes */
  private static final String[] sortnames = {
    "descending w.r.t. transaction size sum",
    "descending w.r.t. frequency",
    "no sorting",
    "ascending w.r.t. frequency",
    "ascending w.r.t. transaction size sum" };

  /** the names of the Eclat variants */
  private static final String[] eclnames = {
    "automatic choice",
    "tid lists intersection (basic)",
    "tid lists intersection (improved)",
    "tid lists represented as bit vectors",
    "item occurrence table (standard)",
    "item occurrence table (simplified)",
    "tid range lists intersection",
    "occurrence deliver (LCM-style)",
    "tid difference sets (dEclat)" };
  /** the codes of the Eclat variants */
  private static final char[] eclcodes = {
    'a', 'e', 'i', 'b', 't', 's', 'r', 'o', 'd' };

  /** the names of the pruning modes */
  private static final String[] extnames = {
    "no", "horizontal", "vertical" };

  /** the names of the FP-growth variants */
  private static final String[] fpgnames = {
    "automatic choice",
    "simple tree nodes (successor/parent)",
    "complex tree nodes (children/siblings)",
    "top-down processing (single tree)",
    "top-down processing (multiple trees)" };
  /** the codes of the FP-growth variants */
  private static final char[] fpgcodes = {
      'c', 's', 'c', 'd', 't' };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /* --- files --- */
  /** the transactions file */
  private JTextField        fn_tra;
  /** the item set output file */
  private JTextField        fn_out;
  /** the item selection file file */
  private JTextField        fn_sel;
  /** the algorithm/program to use */
  private JComboBox<String> algo;
  /** the path to the C programs */
  private File              path;

  /* --- filters --- */
  /** the target type (frequent/closed/maximal item sets) */
  private JComboBox<String> target;
  /** the minimum number of items per item set */
  private JSpinner          mincnt;
  /** the maximum number of items per item set */
  private JSpinner          maxcnt;
  /** the minimum support of a item set */
  private JTextField        minsupp;
  /** the maximum support of a item set */
  private JTextField        maxsupp;
  /** the item set evaluation measure */
  private JComboBox<String> eval;
  /** the evaluation aggregation mode */
  private JComboBox<String> agg;
  /** the threshold for the item set evaluation measure */
  private JTextField        thresh;
  /** whether to invalidate the evaluation below the expected support */
  private JCheckBox         invbxs;

  /* --- output --- */
  /** the record header for the item set output */
  private JTextField        header;
  /** the item separator for the item set output */
  private JTextField        itemsep;
  /** the output format for the item set information */
  private JTextField        outfmt;

  /* --- common options --- */
  /** the evaluation pruning mode */
  private JComboBox<String> prune;
  /** the level for the evaluation pruning */
  private JSpinner          level;
  /** the support border for the item sets */
  private JTextField        border;
  /** the sorting mode for the transactions */
  private JComboBox<String> sort;

  /* --- Apriori options --- */
  /** whether to organize the transactions as a prefix tree */
  private JCheckBox         prefix;
  /** whether to use a-posteriori pruning */
  private JCheckBox         post;
  /** how to filter unused items */
  private JTextField        filter;

  /* --- Eclat/FP-growth options --- */
  /** the Eclat algorithm variant */
  private JComboBox<String> eclat;
  /** the FP-growth algorithm variant */
  private JComboBox<String> fpgrowth;
  /** whether to use perfect extension */
  private JCheckBox         perfext;
  /** the number of items in the k-items machine in Eclat */
  private JSpinner          kitems;
  /** whether to resort the items w.r.t. conditional support in Eclat */
  private JCheckBox         resort;
  /** whether to use head union tail pruning */
  private JCheckBox         hut;
  /** whether to check extensions */
  private JComboBox<String> chkexts;

  /*------------------------------------------------------------------*/
  /** Create a frequent item set mining GUI.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FIMGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a frequent item set mining GUI.
   *  @param  owner the component that is to own this dialog
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FIMGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    DialogPanel tab;            /* current tab of the tabbed pane */

    /* --- create basic GUI --- */
    this.base("Frequent Item Set Mining Tools");
    this.addFormatTab(FormatPanel.TAWGT);

    /* --- Files --- */
    tab = this.addTab("Files");

    tab.addLabel("Transaction file:");
    tab.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FIMGUI.this.getFileName(FIMGUI.this.fn_tra); } } );
    tab.addButton("View", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FIMGUI.this.showTrActs(FIMGUI.this.fn_tra); } } );
    this.fn_tra = tab.addFileInput("data"+File.separator+"tracts.txt");

    tab.addLabel("Item set output file:");
    tab.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FIMGUI.this.getFileName(FIMGUI.this.fn_out); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FIMGUI.this.showPatterns(FIMGUI.this.fn_out); } } );
    this.fn_out = tab.addFileInput("data"+File.separator+"isets.txt");

    tab.addLabel("Item selection file:");
    tab.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FIMGUI.this.getFileName(FIMGUI.this.fn_sel); } } );
    tab.addButton("Edit", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FIMGUI.this.editFile(FIMGUI.this.fn_sel); } } );
    this.fn_sel = tab.addFileInput("");
    tab.addHelp("The item selection file is optional "
               +"and may be missing.\nThis file lists the items "
               +"that are to be included in the mining;\n"
               +"all other items are ignored. If no item selection "
               +"file is given,\nall items in the transaction file "
               +"are considered.\n");
    tab.addFiller(0);

    tab.addLabel("Algorithm/program:");
    this.algo = tab.addComboBox(FIMGUI.algonames);
    this.algo.setSelectedIndex(ECLAT);

    tab.addButton("Locate Programs...", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        JFileChooser c = FIMGUI.this.getFileChooser();
        c.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        c.setDialogTitle("Locate Program...");
        int r = c.showOpenDialog(FIMGUI.this);
        if (r == JFileChooser.APPROVE_OPTION)
          FIMGUI.this.path = c.getSelectedFile();
        c.setFileSelectionMode(JFileChooser.FILES_ONLY);
        c.setDialogTitle("Open File...");
      } } );

    /* --- Filters --- */
    tab = this.addTab("Filters");

    tab.addLabel("Target item set type:");
    this.target = tab.addComboBox(FIMGUI.targnames);
    this.target.setSelectedIndex(0);

    tab.addLabel("Minimum number of items:");
    this.mincnt = tab.addSpinner(1, 1, 999999, 1);
    tab.addLabel("Maximum number of items:");
    this.maxcnt = tab.addSpinner(0, 0, 999999, 1);

    tab.addLabel("Minimum support [#/%]:");
    this.minsupp = tab.addNumberInput("10");
    tab.addLabel("Maximum support [#/%]:");
    this.maxsupp = tab.addNumberInput("100");
    tab.addHelp("A negative support means an absolute number (#);\n"
               +"a positive support a percentage of the "
               +"transactions (%).");

    tab.addLabel("Additional evaluation measure:", DialogPanel.RIGHT);
    this.eval = tab.addComboBox(FIMGUI.emnames);
    tab.addLabel("Threshold [%]:");
    this.thresh = tab.addNumberInput("10");
    tab.addHelp("Most evaluation measures have values "
               +"in the interval [0,1],\nwhich can be expressed "
               +"conveniently as a percentage.");

    tab.addLabel("Invalidate < expectation:");
    this.invbxs = tab.addCheckBox(false);
    tab.addFiller(0);

    /* --- Output --- */
    tab = this.addTab("Output");
    tab.addLabel("Item set header:");
    tab.add(this.header = new JTextField(""), DialogPanel.RIGHT);
    tab.addHelp("String that is printed before each item set.");

    tab.addLabel("Item separator:");
    tab.add(this.itemsep = new JTextField(" "), DialogPanel.RIGHT);
    tab.addHelp("String to separate the items of the item sets "
               +"(default: ' ').");

    tab.addLabel("Information output format:", DialogPanel.FILL);
    this.outfmt = tab.addTextInput(" (%a,%Q,%E)", DialogPanel.FILL);
    tab.addHelp("The information output format is very important for "
               +"the\nparser of the frequent item set viewer to work "
               +"correctly.\nChange at most the number of significant "
               +"digits and/or the\nletter E to lowercase if you "
               +"want to use the viewer.\nLikewise, do not change the "
               +"item set header\nor the item separator in this case.");
    tab.addFiller(50);

    /* --- Common Options --- */
    tab = this.addTab("Options");
    tab.addLabel("Options common to all algorithms", DialogPanel.FILL);

    tab.addLabel("Item sorting:", DialogPanel.RIGHT);
    this.sort = tab.addComboBox(FIMGUI.sortnames);
    this.sort.setSelectedIndex(4);
    tab.addHelp("An item order other than the default "
               +"is usually slower.");

    JPanel pex = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    pex.add(new JLabel("Perfect extension pruning: "));
    pex.add(this.perfext = new JCheckBox("", true));
    tab.add(pex, DialogPanel.FILL);

    tab.addLabel("Evaluation pruning:");
    this.prune = tab.addComboBox(FIMGUI.prnnames);
    this.prune.setSelectedIndex(0);
    tab.addLabel("Pruning level:");
    this.level = tab.addSpinner(1, 1, 999999, 1);
    tab.addHelp("The item (sub)set size at which "
               +"to start forward pruning.");

    tab.addLabel("Support border:", DialogPanel.FILL);
    this.border = tab.addTextInput("", DialogPanel.FILL);
    tab.addHelp("The support border states minimum support values\n"
               +"per item set size (starting at the minimum item "
               +"set size).\nThe individual support values are "
               +"separated by colons ( : ).\nFor larger sizes "
               +"the global minimum support is used.");
    tab.addFiller(0);

    /* --- Apriori Options --- */
    tab = this.addTab("Apriori");
    tab.addLabel("Options specific to Apriori", DialogPanel.RIGHT);
    tab.addFiller(4);

    tab.addLabel("Transaction prefix tree:");
    this.prefix = tab.addCheckBox(true);
    tab.addHelp("Representing the transaction database as a prefix "
               +"tree\nusually speeds up processing.");

    tab.addLabel("Filter unused items:");
    this.filter = tab.addTextInput("0.01");
    tab.addHelp("< 0: fraction of removed items to trigger filtering,\n"
               +"> 0: take execution times ratio into account.");

    tab.addLabel("A-posteriori pruning:");
    this.post = tab.addCheckBox(false);
    tab.addHelp("Remove infrequent item sets from the data structure.");
    tab.addFiller(0);

    /* --- Eclat Options --- */
    tab = this.addTab("Eclat/FPg");
    tab.addLabel("Options specific to Eclat/FP-growth",
                 DialogPanel.RIGHT);

    tab.addLabel("Eclat variant:", DialogPanel.RIGHT);
    this.eclat = tab.addComboBox(FIMGUI.eclnames);
    this.eclat.setSelectedIndex(0);

    tab.addLabel("FP-growth variant:", DialogPanel.RIGHT);
    this.fpgrowth = tab.addComboBox(FIMGUI.fpgnames);
    this.fpgrowth.setSelectedIndex(0);

    tab.addLabel("Items in k-items machine:");
    this.kitems = tab.addSpinner(16, 0, 16, 1);

    tab.addLabel("Resort the items:");
    this.resort = tab.addCheckBox(true);
    tab.addHelp("Adapt the item order based on "
               +"their conditional support.");

    tab.addLabel("Head union tail pruning:");
    this.hut = tab.addCheckBox(true);
    tab.addHelp("Used only for mining maximal (frequent) item sets.");

    tab.addLabel("Check extensions:");
    this.chkexts = tab.addComboBox(FIMGUI.extnames);
    tab.addHelp("Check for closed/maximal item sets with extensions\n"
               +"(only Eclat, improved tid lists variant, "
               +"default: repository).");
    tab.addFiller(0);

    /* --- Terminal --- */
    this.addTerminalTab("Terminal output of external programs");

    /* --- About --- */
    this.addTab("About", new AboutPanel(
       "Frequent Item Set Mining Tools",
       "A simple user interface for frequent item set mining.\n\n"
      +"Version " +FIMGUI.VERSION +"\n"
      +"written by Christian Borgelt\n"
      +"European Centre for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.pack();
    this.selectTab(1);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the path to the frequent item set mining program.
   *  @return the path to the frequent item set mining programs
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getPath ()
  { return this.path; }

  /*------------------------------------------------------------------*/
  /** Set the path to the frequent item set mining programs.
   *  @param  path the path to the frequent item set mining programs
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPath (File path)
  { this.path = path; }

  /*------------------------------------------------------------------*/
  /** Set the transactions file.
   *  @param  file the transactions file to set
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTrActsFile (File file)
  { this.fn_tra.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Set the frequent item sets output file.
   *  @param  file the frequent item sets output file to set
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutputFile (File file)
  { this.fn_out.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Set the item selection file.
   *  @param  file the item selection file to set
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setItemSelFile (File file)
  { this.fn_sel.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Show frequent item patterns.
   *  @param  txt the text field containing the file name
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showPatterns (JTextField txt)
  { this.showPatterns(new File(txt.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a set of frequent item patterns.
   *  @param  file the file to load the frequent item sets from
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showPatterns (File file)
  {                             /* --- show a set of item sets */
    PatternView view = new PatternView(this, PatternView.FILE_ITEMS);
    if (!view.loadPatterns(file)) return;
    view.setVisible(true); view.toFront();
  }  /* showPatterns() */

  /*------------------------------------------------------------------*/
  /** Show a set of transactions.
   *  @param  txt the text field containing the file name
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showTrActs (JTextField txt)
  { this.showTrActs(new File(txt.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a set of transactions.
   *  @param  file the file to load the transactions from
   *  @since  2014.10.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showTrActs (File file)
  {                             /* --- show a set of ass. rules */
    TrActView    view;          /* viewer for the transactions */
    FormatDialog fmtdlg;        /* format dialog of the viewer */

    view = new TrActView(this, TrActView.FILE_ITEMS);
    if (this.format != null) {  /* if there is a format tab */
      fmtdlg = view.getFormatDlg();
      fmtdlg.setMode   (this.format.getMode());
      fmtdlg.setRecSeps(this.format.getRecSeps());
      fmtdlg.setFldSeps(this.format.getFldSeps());
      fmtdlg.setBlanks (this.format.getBlanks());
      fmtdlg.setComment(this.format.getComment());
    }                           /* transfer characters */
    if (!view.loadTrActs(file)) return;
    view.setVisible(true); view.toFront();
  }  /* showTrActs() */

  /*------------------------------------------------------------------*/
  /** Get an executor for the frequent item set mining program.
   *  @return the executor for the frequent item set mining program
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- get the command to execute */
    int      n = 0, k, p;       /* number of arguments, buffers */
    int      algo;              /* index of algorithm/program */
    String[] cmd;               /* command and arguments */
    File     pp;                /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[64];    /* create a command array */
    pp     = this.getPath();    /* and get the program path */
    algo   = this.algo.getSelectedIndex();
    cmd[0] = ((pp != null) ? pp +File.separator : "")
           + FIMGUI.prgnames[algo];
    n = this.format.addFormatArgs(cmd, FormatPanel.TAWGT);
    cmd[n++] = "-t" +FIMGUI.targcodes[this.target.getSelectedIndex()];
    cmd[n++] = "-m" +this.mincnt.getValue();
    k = ((Integer)this.maxcnt.getValue()).intValue();
    if (k > 0) cmd[n++] = "-n" +k;  /* item set size range */
    s = this.minsupp.getText().trim(); /* minimum support */
    if (s.length() > 0) cmd[n++] = "-s" +s;
    s = this.maxsupp.getText().trim(); /* maximum support */
    if (s.length() > 0) cmd[n++] = "-S" +s;
    s = this.border.getText().trim();  /* support border */
    if (s.length() > 0) cmd[n++] = "-F" +s;
    cmd[n++] = "-g";            /* scanable form for items */
    cmd[n++] = "-h"; cmd[n++] = this.header.getText();
    if (cmd[n-1].length() <= 0) cmd[n-1] = "\"\"";
    cmd[n++] = "-k"; cmd[n++] = this.itemsep.getText();
    if (cmd[n-1].length() <= 0) cmd[n-1] = "\"\"";
    cmd[n++] = "-v"; cmd[n++] = this.outfmt.getText();
    if (cmd[n-1].length() <= 0) cmd[n-1] = "\"\"";
    k = this.eval.getSelectedIndex();
    if (k > 0) {                /* item set evaluation measure */
      cmd[n++] = "-e" +FIMGUI.emcodes[k];
      cmd[n++] = "-d" +this.thresh.getText();
    }                           /* threshold for evaluation measure */
    k = this.prune.getSelectedIndex();
    if (k > 0) {                /* if to prune with evaluation */
      s = String.valueOf(((Integer)this.level.getValue()).intValue());
      cmd[n++] = "-p" +((k == 1) ? "0" : ((k <= 2) ? "-"+s : s));
    }                           /* construct pruning option */
    k = this.sort.getSelectedIndex() -2;
    if (k != 2) cmd[n++] = "-q" +k;
    if (!this.perfext.isSelected()) cmd[n++] = "-x";
    if (algo == APRIORI) {      /* if Apriori algorithm */
      cmd[n++] = "-u" +this.filter.getText();
      if (!this.prefix.isSelected()) cmd[n++] = "-T";
      if ( this.post.isSelected())   cmd[n++] = "-y";
    }
    if (algo == ECLAT) {        /* if Eclat algorithm */
      cmd[n++] = "-A" +FIMGUI.eclcodes[this.eclat.getSelectedIndex()];
      k = this.chkexts.getSelectedIndex();
      if (k > 0) cmd[n++] = (k > 1) ? "-y1" : "-y0";
    }
    if (algo == FPGROWTH)       /* if FP-growth algorithm */
      cmd[n++] = "-A" +FIMGUI.fpgcodes[this.fpgrowth.getSelectedIndex()];
    if ((algo == ECLAT) || (algo == FPGROWTH)) {
      if (!this.resort.isSelected())  cmd[n++] = "-i";
      if (!this.hut.isSelected())     cmd[n++] = "-u";
      k = ((Integer)this.kitems.getValue()).intValue();
      if (k > 0) cmd[n++] = "-l" +k;
    }                           /* add eclat/fpgrowth options */
    s = fn_sel.getText();       /* add the file arguments */
    if (s.length() > 0) cmd[n++] = "-R" +s;
    cmd[n++] = fn_tra.getText();
    cmd[n++] = fn_out.getText();
    return new CmdExecutor(TabbedGUI.shrinkCmd(cmd, n), this);
  }  /* createExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    int    i, k;                /* index variables */
    String msg;                 /* buffer for message */
    float  t;                   /* execution time */

    msg = ((CmdExecutor)this.executor).getLastErrorLine();
    i = msg.lastIndexOf("[", msg.indexOf("set(s)]"));
    k = msg.indexOf(']', i);    /* find item sets report */
    t = (System.currentTimeMillis() -this.start) / 1000.0F;
    return "Found " +msg.substring(i+1, k) +".\n"
          +"Total search time: " +t +"s.\n"
          +"(See terminal for more information.)";
  }  /* getResultMessage() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2014.10.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  {                             /* --- load configuration file */
    if (file == null) {         /* if no file name is given */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Load Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileReader reader = new FileReader(file);
      /* --- Format --- */
      this.format.loadConfig(reader);
      /* --- text parameters --- */
      /* --- Files --- */
      this.fn_tra.setText (this.readLine(reader));
      this.fn_out.setText (this.readLine(reader));
      this.fn_sel.setText (this.readLine(reader));
      /* --- Filters --- */
      this.minsupp.setText(this.readLine(reader));
      this.maxsupp.setText(this.readLine(reader));
      this.thresh.setText (this.readLine(reader));
      this.border.setText (this.readLine(reader));
      this.filter.setText (this.readLine(reader));
      /* --- Output --- */
      this.header.setText (this.readLine(reader));
      this.itemsep.setText(this.readLine(reader));
      this.outfmt.setText (this.readLine(reader));
      /* --- flags & indices --- */
      /* --- Filters --- */
      this.target.setSelectedIndex(this.readInt(reader));
      this.mincnt.setValue(Integer.valueOf(this.readInt(reader)));
      this.maxcnt.setValue(Integer.valueOf(this.readInt(reader)));
      this.eval.setSelectedIndex(this.readInt(reader));
      this.agg.setSelectedIndex(this.readInt(reader));
      this.prune.setSelectedIndex(this.readInt(reader));
      this.level.setValue(Integer.valueOf(this.readInt(reader)));
      this.sort.setSelectedIndex(this.readInt(reader));
      this.eclat.setSelectedIndex(this.readInt(reader));
      this.fpgrowth.setSelectedIndex(this.readInt(reader));
      this.kitems.setValue(Integer.valueOf(this.readInt(reader)));
      this.chkexts.setSelectedIndex(this.readInt(reader));
      /* --- Options --- */
      this.invbxs.setSelected (this.readInt(reader) != 0);
      this.perfext.setSelected(this.readInt(reader) != 0);
      this.prefix.setSelected (this.readInt(reader) != 0);
      this.post.setSelected   (this.readInt(reader) != 0);
      this.resort.setSelected (this.readInt(reader) != 0);
      this.hut.setSelected    (this.readInt(reader) != 0);
      reader.close(); }         /* read the configuration values */
    catch (IOException e) {     /* and close the input file */
      JOptionPane.showMessageDialog(this,
        "Error reading configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* check for successful reading */
    this.status.setText("configuration loaded: " +file.getName());
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  {                             /* --- save configuration file */
    if (file == null) {         /* if no file name is given, */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Save Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileWriter writer = new FileWriter(file);
      /* --- Format --- */
      this.format.saveConfig(writer);
      /* --- text parameters --- */
      /* --- Files --- */
      writer.write(this.fn_tra.getText());  writer.write('\n');
      writer.write(this.fn_out.getText());  writer.write('\n');
      writer.write(this.fn_sel.getText());  writer.write('\n');
      /* --- Filters --- */
      writer.write(this.minsupp.getText()); writer.write('\n');
      writer.write(this.maxsupp.getText()); writer.write('\n');
      writer.write(this.thresh.getText());  writer.write('\n');
      writer.write(this.border.getText());  writer.write('\n');
      writer.write(this.filter.getText());  writer.write('\n');
      /* --- Output --- */
      writer.write(this.header.getText());  writer.write('\n');
      writer.write(this.itemsep.getText()); writer.write('\n');
      writer.write(this.outfmt.getText());  writer.write('\n');
      /* --- flags & indices --- */
      /* --- Filters --- */
      writer.write(this.target.getSelectedIndex() +",");
      writer.write(((Integer)this.mincnt.getValue()).intValue() +",");
      writer.write(((Integer)this.maxcnt.getValue()).intValue() +",");
      writer.write(this.eval.getSelectedIndex() +",");
      writer.write(this.agg.getSelectedIndex() +",");
      writer.write(this.prune.getSelectedIndex() +",");
      writer.write(((Integer)this.level.getValue()).intValue() +",");
      writer.write(this.sort.getSelectedIndex() +",");
      writer.write(this.eclat.getSelectedIndex() +",");
      writer.write(this.fpgrowth.getSelectedIndex() +",");
      writer.write(((Integer)this.kitems.getValue()).intValue() +",");
      writer.write(this.chkexts.getSelectedIndex() +",");
      /* --- Options --- */
      writer.write(this.invbxs.isSelected()  ? "1," : "0,");
      writer.write(this.perfext.isSelected() ? "1," : "0,");
      writer.write(this.prefix.isSelected()  ? "1," : "0,");
      writer.write(this.post.isSelected()    ? "1," : "0,");
      writer.write(this.resort.isSelected()  ? "1," : "0,");
      writer.write(this.hut.isSelected()     ? "1," : "0,");
      writer.write('\n');       /* write the configuration values */
      writer.close(); }         /* and close the output file */
    catch (IOException e) {     /* check for successful writing */
      JOptionPane.showMessageDialog(this,
        "Error writing configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show a status message */
    this.status.setText("configuration saved: " +file.getName());
  }  /* saveConfig() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2004.09.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    FIMGUI gui = new FIMGUI();
    if (args.length > 0)        /* load configuration if necessary */
      gui.loadConfig(new File(args[0]));
    gui.setVisible(true);       /* show the user interface */
  }  /* main() */

}  /* class FIMGUI */
