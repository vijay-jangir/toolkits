/*----------------------------------------------------------------------
  File    : ARuleTable.java
  Contents: association rule viewer table
  Author  : Christian Borgelt
  History : 2004.07.06 file created
            2007.03.12 adapted to modified class ARuleSet, javadoc added
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.awt.Dimension;
import javax.swing.table.AbstractTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JFrame;

import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for a tabular representation of a set of association rules.
 *  @author Christian Borgelt
 *  @since  2004.07.06 */
/*--------------------------------------------------------------------*/
public class ARuleTable extends AbstractTableModel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010003L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the set of association rules */
  protected ARuleSet arset;
  /** the names of the table columns */
  protected String[] names;

  /*------------------------------------------------------------------*/
  /** Create an association rule table.
   *  @param  arset the set of association rules
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleTable (ARuleSet arset)
  { this.setRules(arset); }

  /*------------------------------------------------------------------*/
  /** Get the association rule set.
   *  @return the association rule set
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleSet getRules ()
  { return this.arset; }

  /*------------------------------------------------------------------*/
  /** Set the association rule set.
   *  @param  arset the new association rule set
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRules (ARuleSet arset)
  {                             /* --- set a new rule set */
    int n;                      /* number of table columns */

    if (arset == null) arset = new ARuleSet();
    this.arset = arset;         /* note the association rule set */
    n = ((arset.getRuleCount() > 0)
      && (arset.getRule(0).getEval() > -Float.MAX_VALUE)) ? 8 : 7;
    this.names    = new String[n];
    this.names[0] = "consequent";
    this.names[1] = "antecedent";
    this.names[2] = "support";
    this.names[3] = "ante. supp.";
    this.names[4] = "cons. supp.";
    this.names[5] = "confidence";
    this.names[6] = "lift value";
    if (n > 7) this.names[7] = "evaluation";
  }  /* setRules()

  /*------------------------------------------------------------------*/
  /** Sort the set of association rules.
   *  @param  field the identifier of the field to compare first
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sort (int field)
  { if (this.arset != null) this.arset.sort(field); }

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.arset != null) ? this.arset.getRuleCount() : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return the number of columns of the table
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return this.names.length; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column.
   *  @param  i the index of the column
   *  @return the name of the column with index i
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int i)
  { return this.names[i]; }

  /*------------------------------------------------------------------*/
  /** Get the value in a table cell.
   *  @param  row the row    index of the table cell
   *  @param  col the column index of the table cell
   *  @return an object representing the contents of the table cell
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  {                             /* --- get value of table field */
    int           i, n;         /* loop variables */
    double        x;            /* buffer for add. evaluation */
    ARule         rule;         /* rule corresponding to row */
    StringBuilder b;            /* buffer for rule body */

    rule = this.arset.getRule(row);
    switch (col) {              /* evaluate the column */
      case  0: return rule.getHeadName();
      case  1: b = new StringBuilder();
               for (n = rule.getBodySize(), i = 0; i < n; i++) {
                 if (i > 0) b.append(" ");
                 b.append(rule.getBodyName(i));
               } return b.toString();
      case  2: return (100*rule.getRelSupp())
                     +"/" +rule.getAbsSupp();
      case  3: return (100*rule.getRelBodySupp())
                     +"/" +rule.getAbsBodySupp();
      case  4: return (100*rule.getRelHeadSupp())
                     +"/" +rule.getAbsHeadSupp();
      case  5: return String.valueOf(100*rule.getConf());
      case  6: return String.valueOf(rule.getLift());
      default: x = rule.getEval();
               return (x > -Float.MAX_VALUE) ? String.valueOf(x) : "";
    }
  }   /* getValueAt() */

  /*------------------------------------------------------------------*/
  /** Main function for testing some basic functionality.
   *  <p>It is tried to parse the file that is given as the first
   *  command line argument as a set of association rules.</p>
   *  @param  args the command line arguments
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    Dimension  size;            /* table size */
    Scanner    scan;            /* scanner to read from */
    ARuleSet   arset;           /* created association rule set */
    ARuleTable table;           /* table for the rule set */
    JTable     tview;           /* view for the table */
    JFrame     frame;           /* surrounding frame */

    try {                       /* try to read the given file */
      if (args.length <= 0)     /* if no arguments given */
        scan = new Scanner("a <- b c (40/4,50/5,70/7,80,1.42875,0)");
      else                      /* if a file argument is given */
        scan = new Scanner(args[0]);
      arset = ARuleSet.parse(null, scan); }
    catch (IOException e) {     /* parse the association rule set */
      System.err.println(e.getMessage()); return; }
    table = new ARuleTable(arset);
    tview = new JTable(table);
    size  = tview.getPreferredSize();
    if (size.width  > 800) size.width  = 800;
    if (size.height > 600) size.height = 600;
    tview.setPreferredScrollableViewportSize(size);
    frame = new JFrame();     /* create the frame for display */
    frame.getContentPane().add(new JScrollPane(tview));
    frame.setLocation(48, 48);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack(); frame.setVisible(true);
  }  /* main() */

}  /* ARuleTable */
