/*----------------------------------------------------------------------
  File    : Pattern.java
  Contents: item pattern management
            (item sets, partial permutations and sequences)
  Author  : Christian Borgelt
  History : 2013.11.28 file created from ARule.java
            2014.10.03 constructor from item array added
            2015.08.12 sorting and comparison functions added
            2016.04.07 StringBuffer replaced by StringBuilder
            2016.04.13 reduced to storing absolute support values
            2017.06.14 recoding to another item base added
            2017.06.17 constant EMPTY for empty item arrays added
            2017.06.29 functions declared final for speed
            2018.03.21 pattern weight added (e.g. cover similarity)
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Arrays;

import util.IdMap;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for item patterns
 *  (item sets, partial permutations and sequences).
 *  @author Christian Borgelt
 *  @since  2013.11.28 */
/*--------------------------------------------------------------------*/
public class Pattern implements Comparable<Pattern>, Cloneable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00020003L;
  /** the block size for the item array */
  private static final int BLKSIZE = 8;
  /** the empty item array to avoid reallocation */
  private static final int[] EMPTY = {};

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  protected IdMap  ibase;
  /** the items of the item pattern */
  protected int[]  items;
  /** the current number of items */
  protected int    size;
  /** the (absolute) support of the (frequent) item pattern */
  protected int    s_pat;
  /** the (absolute) base support (number of transactions) */
  protected int    s_base;
  /** the evaluation of the (frequent) item pattern */
  protected double eval;
  /** the weight of the (frequent) item pattern
   *  (e.g. cover similarity) */
  protected double wgt;
  /** the value for sorting item patterns */
  protected double sort;
  /** the comparison direction for sorting item patterns */
  protected int    dir;

  /*------------------------------------------------------------------*/
  /** Create an empty item pattern.
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create an empty item pattern.
   *  @param  ibase the underlying item base
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase)
  {                             /* --- create an item pattern */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.items = EMPTY;         /* note the item base and */
    this.size  = 0;             /* initialize the fields */
    this.s_pat = this.s_base = 0;
    this.eval  = this.wgt = 0.0;
  }  /* Pattern() */

  /*------------------------------------------------------------------*/
  /** Create a item pattern from an item array
   *  (the item array is stored, not copied).
   *  @param  ibase  the underlying item base
   *  @param  items  the items in the item pattern
   *  @param  supp   the absolute support of the item pattern
   *  @since  2016.11.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase, int[] items, int supp)
  { this(ibase, items, supp, supp, 0.0); }

  /*------------------------------------------------------------------*/
  /** Create a item pattern from an item array
   *  (the item array is stored, not copied).
   *  @param  ibase  the underlying item base
   *  @param  items  the items in the item pattern
   *  @param  s_pat  the absolute support of the item pattern
   *  @param  s_base the absolute support of the empty pattern
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase, int[] items, int s_pat, int s_base)
  { this(ibase, items, s_pat, s_base, 0.0); }

  /*------------------------------------------------------------------*/
  /** Create an item pattern from an item array
   *  (the item array is stored, not copied).
   *  @param  ibase  the underlying item base
   *  @param  items  the items in the item pattern
   *  @param  s_pat  the absolute support of the item pattern
   *  @param  s_base the absolute support of the empty pattern
   *  @param  eval   the evaluation of the item pattern
   *  @since  2014.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase, int[] items,
                  int s_pat, int s_base, double eval)
  {                             /* --- create an item pattern */
    System.err.println("Pattern.1.len: " + items.length);
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.items  = (items != null) ? items : EMPTY;
    this.size   = items.length; /* note the item base and */
    this.s_pat  = s_pat;        /* initialize the fields */
    this.s_base = s_base;       /* from the given arguments */
    this.eval   = eval;
    this.wgt    = 0.0;
  }  /* Pattern() */

  /*------------------------------------------------------------------*/
  /** Create an item pattern from an item array
   *  (the item array is stored, not copied).
   *  @param  ibase  the underlying item base
   *  @param  items  the items in the item pattern
   *  @param  s_pat  the absolute support of the item pattern
   *  @param  s_base the absolute support of the empty pattern
   *  @param  eval   the evaluation of the item pattern
   *  @param  wgt    the weight of the item pattern
   *                 (e.g. cover similarity)
   *  @since  2018.03.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase, int[] items,
                  int s_pat, int s_base, double eval, double wgt)
  {                             /* --- create an item pattern */
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.items  = (items != null) ? items : EMPTY;
    this.size   = items.length; /* note the item base and */
    this.s_pat  = s_pat;        /* initialize the fields */
    this.s_base = s_base;       /* from the given arguments */
    this.eval   = eval;
    this.wgt    = wgt;
  }  /* Pattern() */

  /*------------------------------------------------------------------*/
  /** Create a item pattern from an item array
   *  (the item array is copied).
   *  @param  ibase  the underlying item base
   *  @param  items  the items in the item pattern
   *  @param  cnt    the number of items in the item pattern
   *  @param  s_pat  the absolute support of the item pattern
   *  @param  s_base the absolute support of the empty pattern
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase, int[] items, int cnt,
                  int s_pat, int s_base)
  { this(ibase, items, cnt, s_pat, s_base, 0); }

  /*------------------------------------------------------------------*/
  /** Create an item pattern from an item array
   *  (the item array is copied).
   *  @param  ibase  the underlying item base
   *  @param  items  the items in the item pattern
   *  @param  cnt    the number of items in the item pattern
   *  @param  s_pat  the absolute support of the item pattern
   *  @param  s_base the absolute support of the empty pattern
   *  @param  eval   the evaluation of the item pattern
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase, int[] items, int cnt,
                  int s_pat, int s_base, double eval)
  {                             /* --- create an item pattern */
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.items  = new int[this.size = cnt];
    System.arraycopy(items, 0, this.items, 0, size);
    this.s_pat  = s_pat;        /* note the item base and */
    this.s_base = s_base;       /* initialize the fields */
    this.eval   = eval;         /* from the given arguments */
  }  /* Pattern() */

  /*------------------------------------------------------------------*/
  /** Create an item pattern from an item array
   *  (the item array is copied).
   *  @param  ibase  the underlying item base
   *  @param  items  the items in the item pattern
   *  @param  cnt    the number of items in the item pattern
   *  @param  s_pat  the absolute support of the item pattern
   *  @param  s_base the absolute support of the empty pattern
   *  @param  eval   the evaluation of the item pattern
   *  @param  wgt    the weight of the item pattern
   *                 (e.g. cover similarity)
   *  @since  2018.03.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Pattern (IdMap ibase, int[] items, int cnt,
                  int s_pat, int s_base, double eval, double wgt)
  {                             /* --- create an item pattern */
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.items  = new int[this.size = cnt];
    System.arraycopy(items, 0, this.items, 0, size);
    this.s_pat  = s_pat;        /* note the item base and */
    this.s_base = s_base;       /* initialize the fields */
    this.eval   = eval;         /* from the given arguments */
    this.wgt    = wgt;
  }  /* Pattern() */

  /*------------------------------------------------------------------*/
  /** Clone this item pattern
   *  (the item base is kept, the item array is copied).
   *  @return a clone of this item pattern
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone ()
  { return this.clone(null, true); }

  /*------------------------------------------------------------------*/
  /** Clone this item pattern
   *  (the item base is kept, the item array is copied).
   *  @param  ibase  the item base to use for the clone
   *  @return a clone of this item pattern
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone (IdMap ibase)
  { return this.clone(ibase, true); }

  /*------------------------------------------------------------------*/
  /** Clone this item pattern (the item base is replaced).
   *  @param  iclone whether to clone the item array
   *  @return a clone of this item pattern
  /*------------------------------------------------------------------*/

  public final Object clone (boolean iclone)
  { return this.clone(null, iclone); }

  /*------------------------------------------------------------------*/
  /** Clone this item pattern (the item base is replaced).
   *  @param  iclone whether to clone the item array
   *  @param  ibase  a possible clone of the item base to use for the
   *                 clone; if <code>null</code>, the item base of the
   *                 pattern to clone is used
   *  @return a clone of this item pattern
  /*------------------------------------------------------------------*/

  public final Object clone (boolean iclone, IdMap ibase)
  { return this.clone(ibase, iclone); }

  /*------------------------------------------------------------------*/
  /** Clone this item pattern
   *  (the item base is kept, the item array is copied).
   *  @param  ibase  the item base to use for the clone
   *  @param  iclone whether to clone the item array
   *  @return a clone of this item pattern
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone (IdMap ibase, boolean iclone)
  {                             /* --- clone an item pattern */
    Pattern pat;                /* created pattern clone */
    if (ibase == null) ibase = this.ibase;
    if (iclone)                 /* if to clone/copy the item array */
      pat = new Pattern(ibase, this.items, this.size,
                        this.s_pat, this.s_base, this.eval, this.wgt);
    else {                      /* if not to copy the item array */
      pat = new Pattern(ibase, this.items,
                        this.s_pat, this.s_base, this.eval, this.wgt);
      pat.size = this.size;     /* call non-copying constructor and */
    }                           /* overwrite with the correct size */
    return pat;                 /* return the created clone */
  }  /* clone() */

  /*------------------------------------------------------------------*/
  /** Add an item (given by its identifier) to the item pattern.
   *  @param  item the identifier of the item to add
   *  @return the index of the new item
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemById (int item)
  {                             /* --- add an item to a pattern */
    int smax = this.items.length;
    if (this.size >= smax) {    /* if the item array is full */
      smax += (smax > BLKSIZE) ? smax >> 1 : BLKSIZE;
      int[] p = new int[smax];  /* create an (enlarged) item array */
      System.arraycopy(this.items, 0, p, 0, this.size);
      this.items = p;           /* copy the existing items */
    }                           /* and set the (new) item array */
    this.items[this.size] = item;
    return this.size++;         /* return the index of the new item */
  }  /* addItemById() */

  /*------------------------------------------------------------------*/
  /** Add an item (given by its name) to the pattern.
   *  @param  item the name of the item to add
   *  @return the index of the new item
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemByName (String item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its object) to the pattern.
   *  @param  item the object of the item to add
   *  @return the index of the new item
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemByObject (Object item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item to the item pattern.
   *  @param  item the item identifier
   *  @return the index of the new item
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (int item)
  { return addItemById(item); }

  /*------------------------------------------------------------------*/
  /** Add an item to the pattern.
   *  @param  item the item name
   *  @return the index of the new item
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (String item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Get an item (i.e., its identifier).
   *  @param  i the index of the item
   *  @return the identifier of the item at index <code>i</code>
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItem (int i)
  { return (i < this.size) ? this.items[i] : -1; }

  /*------------------------------------------------------------------*/
  /** Get an item identifier (as assigned by the underlying item base).
   *  @param  i the index of the item
   *  @return the identifier of the item at index <code>i</code>
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItemId (int i)
  { return (i < this.size) ? this.items[i] : -1; }

  /*------------------------------------------------------------------*/
  /** Get the name of an item.
   *  @param  i the index of the item
   *  @return the name of the item at index <code>i</code>
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getItemName (int i)
  { return (i < this.size)
         ? (String)this.ibase.get(this.items[i]) : ""; }

  /*------------------------------------------------------------------*/
  /** Get the object of an item.
   *  @param  i the index of the item
   *  @return the object of the item at index <code>i</code>
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getItemObject (int i)
  { return (i < this.size) ? this.ibase.get(this.items[i]) : ""; }

  /*------------------------------------------------------------------*/
  /** Get the item array
   *  (length/size fits only after packing with <code>pack()</code>;
   *  should be considered read only).
   *  @return the item array
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getAllItems ()
  { return this.items; }

  /*------------------------------------------------------------------*/
  /** Get the size of the item pattern (number of items).
   *  @return the size of the item pattern
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSize ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the size of the item pattern (number of items).
   *  @return the size of the item pattern
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getCount ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the support of the item pattern.
   *  @return the support of the item pattern
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp ()                   /* a */
  { return this.s_pat; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the item pattern.
   *  @return the (absolute) support of the item pattern
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getAbsSupp ()                /* a */
  { return this.s_pat; }

  /*------------------------------------------------------------------*/
  /** Get the (relative) support of the item pattern.
   *  @return the (relative) support of the item pattern
   *  @since 2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getRelSupp ()             /* s/S */
  { return (this.s_base <= 0) ? 0
         : (double)this.s_pat/(double)this.s_base; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the empty pattern
   *  (i.e. the size of the transaction database).
   *  @return the (absolute) support of the empty pattern
   *  @since 2016.04.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getBaseSupp ()               /* Q */
  { return this.s_base; }

  /*------------------------------------------------------------------*/
  /** Get the value of the additional evaluation measure.
   *  @return the value of the additional evaluation measure
   *  @since 2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getEval ()                /* e/E */
  { return this.eval; }

  /*------------------------------------------------------------------*/
  /** Get the weight of the pattern (e.g. cover similarity).
   *  @return the weight of the pattern (e.g. cover similarity)
   *  @since 2018.03.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getWeight ()              /* w/W */
  { return this.wgt; }

  /*------------------------------------------------------------------*/
  /** Sort the items of an item pattern.
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort ()
  { Arrays.sort(this.items, 0, this.size); }

  /*------------------------------------------------------------------*/
  /** Set sort value and sort direction.
   *  @param  value the value to sort item patterns on
   *  @param  dir   the direction to sort item patterns into
   *  @since  2016.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSort (int value, int dir)
  { this.sort = (double)value; this.dir = dir; }

  /*------------------------------------------------------------------*/
  /** Set sort value and sort direction.
   *  @param  value the value to sort item patterns on
   *  @param  dir   the direction to sort item patterns into
   *  @since  2016.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSort (double value, int dir)
  { this.sort = value; this.dir = dir; }

  /*------------------------------------------------------------------*/
  /** Compare this item pattern to another (given as argument).
   *  @param  pat the item pattern to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as the sort value of this pattern is less than, equal to,
   *          or greater than the sort value of the given pattern
   *  @since 2016.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int compareTo (Pattern pat)
  {                             /* --- compare to another pattern */
    if (this.sort > pat.sort) return +this.dir;
    if (this.sort < pat.sort) return -this.dir;
    return 0;                   /* return sign of sort value diff. */
  }  /* compareTo() */

  /*------------------------------------------------------------------*/
  /** Compare this pattern to another (given as argument)
   *  by comparing its items lexicographically and its support.
   *  @param  pat the pattern to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as this pattern is less than, equal to, or greater than
   *          the pattern given as an argument
   *  @since 2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int allCmpTo (Pattern pat)
  {                             /* --- compare to another pattern */
    int n = (size < pat.size) ? size : pat.size;
    for (int i = 0; i < n; i++){/* traverse the items */
      if (this.items[i] > pat.items[i]) return +1;
      if (this.items[i] < pat.items[i]) return -1;
    }                           /* if items differ, return result */
    if (this.size  > pat.size)  return +1;
    if (this.size  < pat.size)  return -1;
    if (this.s_pat > pat.s_pat) return +1;
    if (this.s_pat < pat.s_pat) return -1;
    return 0;                   /* return sign of "difference" */
  }  /* allCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare this pattern to another (given as argument)
   *  by comparing its items lexicographically.
   *  @param  pat the pattern to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as this pattern is less than, equal to, or greater than
   *          the pattern given as an argument
   *  @since 2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int itemsCmpTo (Pattern pat)
  {                             /* --- compare to another pattern */
    int n = (size < pat.size) ? size : pat.size;
    for (int i = 0; i < n; i++){/* traverse the items */
      if (this.items[i] > pat.items[i]) return +1;
      if (this.items[i] < pat.items[i]) return -1;
    }                           /* if items differ, return result */
    if (this.size > pat.size) return +1;
    if (this.size < pat.size) return -1;
    return 0;                   /* return sign of "difference" */
  }  /* itemsCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare this item pattern to another (given as argument)
   *  w.r.t. the support value.
   *  @param  pat the item pattern to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as the support of this item pattern is less than, equal to,
   *          or greater than the support of the item pattern
   *          given as an argument
   *  @since 2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int suppCmpTo (Pattern pat)
  {                             /* --- compare to another pattern */
    if (this.s_pat > pat.s_pat) return +1;
    if (this.s_pat < pat.s_pat) return -1;
    return 0;                   /* return sign of "difference" */
  }  /* SuppCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare the pattern's items to a given item pattern.
   *  @param items the items of the pattern to compare to
   *  @param cnt   the number of items (if negative, the length
                   of the given item array is used)
   *  @return whether the pattern equals the given item pattern
   *  @since 2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean equals (int[] items, int cnt)
  {                             /* --- compare body to given items */
    if (cnt < 0) cnt = items.length;
    if (this.size != cnt)       /* if the number of items does not */
      return false;             /* match, patterns cannot be equal */
    while (--cnt >= 0)          /* traverse the items */
      if (this.items[cnt] != items[cnt])
        return false;           /* if items do not match, abort */
    return true;                /* return 'no difference' */
  }  /* equals() */

  /*------------------------------------------------------------------*/
  /** Check whether this pattern is equal to another
   *  (given as argument).
   *  @param  pat     the pattern to compare to
   *  @param  chksupp whether to compare the support values
   *  @return <code>true</code> if the two patterns have the same items
   *          (in the same order) and <code>false</code> otherwise
   *  @since 2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean equals (Pattern pat, boolean chksupp)
  {                             /* --- compare to another pattern */
    return equals(pat.items, pat.size)
    &&     (!chksupp || ((this.s_pat  == pat.s_pat)
                     &&  (this.s_base == pat.s_base)));
  }  /* equals() */

  /*------------------------------------------------------------------*/
  /** Check whether this pattern is equal to another
   *  (given as argument).
   *  @param  pat the pattern to compare to
   *  @return <code>true</code> if the two patterns have the same items
   *          (in the same order) and <code>false</code> otherwise
   *  @since 2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean equals (Pattern pat)
  { return equals(pat, true); }

  /*------------------------------------------------------------------*/
  /** Check whether a given array of items, representing an item
   *  pattern, is a subpattern of another item pattern, given as a
   *  second given array of items.
   *  <p>For item permutations and item sequences the function works
   *  directly, but for item sets the items in both passed arrays
   *  <code>itemsA</code> and <code>itemsB</code> need to be sorted
   *  (by item identifier) for this function to work correctly.</p>
   *  @param  itemsA the first array of items
   *  @param  cntA   the number of items to consider in the first array
   *  @param  itemsB the second array of items
   *  @param  cntB  the number of items to consider in the second array
   *  @return <code>true</code> is the first item pattern is a
   *          subpattern of the second item pattern and
   *          <code>false</code> otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static boolean subpattern (int[] itemsA, int cntA,
                                    int[] itemsB, int cntB)
  {                             /* --- check for subpattern rel.ship */
    if (cntA <= 0) return true; /* empty pattern is contained in any */
    if (cntA > cntB) return false;   /* subpattern must be smaller */
    for (int iB = 0; iB <= cntB - cntA; iB++) {
      if (itemsB[iB] == itemsA[0]) { /* if matching first item found */
        int iA = 1;             /* init. the source array index */
        while ((iA < cntA) && (cntB - ++iB >= cntA - iA)) {
          if (itemsB[iB] == itemsA[iA])
            iA += 1;            /* on match, go to next source item */
        }                       /* (always go to next dest. item) */
        return (iA >= cntA);    /* return whether all source items */
      }                         /* could be matched in destination */
    }
    return false;               /* return 'A is not a subpat. of B' */
  }  /* subpattern() */

  /*------------------------------------------------------------------*/
  /** Check whether this item pattern is a subpattern of another
   *  item pattern, given as an array of items.
   *  <p>For item permutations and item sequences the function works
   *  directly, but for item sets the item set needs to be sorted
   *  with <code>sort()</code> and the items in the passed array
   *  <code>items</code> also need to be sorted (by identifier)
   *  for this function to work correctly.</p>
   *  @param  items the array of items to check
   *  @param  cnt   the number of items to consider in the given array;
   *                if negative, the length of the item array is used
   *  @return <code>true</code> if this item pattern is a subpattern of
   *          the given item array <code>items</code> and
   *          <code>false</code>
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isSubOf (int[] items, int cnt)
  {                             /* --- check for subpattern rel.ship */
    return subpattern(this.items, this.size, items,
                      (cnt >= 0) ? cnt : items.length);
  }  /* isSubOf() */

  /*------------------------------------------------------------------*/
  /** Check whether this item pattern is a subpattern
   *  of another item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item patterns, both item sets must have been
   *  sorted with <code>Sort()</code> for this function to work
   *  correctly.</p>
   *  @param  pat the item pattern to compare to
   *  @return <code>true</code> if this item pattern is a subpattern
   *          of the given item pattern <code>pat</code> and
   *          <code>false</code> otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isSubOf (Pattern pat)
  { return subpattern(this.items, this.size, pat.items, pat.size); }

  /*------------------------------------------------------------------*/
  /** Whether this item pattern is contained in another item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets, both item sets must have been sorted
   *  with <code>sort()</code> for this function to work correctly.</p>
   *  @param  pat the item pattern to compare to
   *  @return <code>true</code> if this item pattern is a subpattern of
   *          the given item pattern <code>argPattern</code> and
   *          <code>false</code> otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isContainedIn (Pattern pat)
  { return subpattern(this.items, this.size, pat.items, pat.size); }

  /*------------------------------------------------------------------*/
  /** Whether this item pattern is a contained in a transaction.
   *  <p>For item permutations and sequences the function works
   *  directly, but for sets, both the item set and the transaction
   *  must have been sorted with <code>sort()</code> for this function
   *  to work correctly.</p>
   *  @param  tract the transaction to compare to
   *  @return <code>true</code> if this item pattern is a subpattern of
   *          the given transaction <code>tract</code> and
   *          <code>false</code> otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isContainedIn (TrAct tract)
  {                             /* --- check for subpattern rel.ship */
    return subpattern(this.items, this.size, tract.items, tract.size);
  }  /* isContainedIn() */

  /*------------------------------------------------------------------*/
  /** Whether this item pattern is a superpattern of a given item
   *  pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the item set must have been sorted
   *  with <code>sort()</code> first and also the items in the passed
   *  array <code>items</code> need to be sorted (by identifier)
   *  for this function to work correctly.</p>
   *  @param  items the array of items to check
   *  @param  cnt   the number of items to consider in the given array;
   *                if negative, the length of the item array is used
   *  @return <code>true</code> if this item pattern is a superpattern
   *          of the given item array <code>items</code> and
   *          <code>false</code> otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isSuperOf (int[] items, int cnt)
  {                               /* --- check for superpat. rel.ship */
    return subpattern(items, (cnt >= 0) ? cnt : items.length,
                      this.items, this.size);
  }  /* isSuperOf() */

  /*------------------------------------------------------------------*/
  /** Whether this item pattern is a superpattern of another item
   *  pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets, both item sets must have been sorted
   *  with <code>sort()</code> for this function to work correctly.</p>
   *  @param  pat the item pattern to compare to
   *  @return <code>true</code> is this item pattern is a superpattern
   *          of the given item pattern <code>pat</code> and
   *          <code>false</code> otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isSuperOf (Pattern pat)
  { return subpattern(pat.items, pat.size, this.items, this.size); }

  /*------------------------------------------------------------------*/
  /** Whether this item pattern contains another item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets, both item sets must have been sorted
   *  with <code>sort()</code> for this function to work correctly.</p>
   *  @param  pat the item pattern to compare to
   *  @return <code>true</code> is this item pattern contains the given
   *          item pattern <code>pat</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean contains (Pattern pat)
  { return subpattern(pat.items, pat.size, this.items, this.size); }

  /*------------------------------------------------------------------*/
  /** Whether this item pattern contains a given transaction.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets, both the item set and the transaction
   *  must have been sorted with <code>sort()</code> for this function
   *  to work correctly.</p>
   *  @param  tract the transaction to compare to
   *  @return <code>true</code> is this item pattern contains the given
   *          transaction <code>tract</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean contains (TrAct tract)
  {                               /* --- check for superpat. rel.ship */
    return subpattern(tract.items, tract.size, this.items, this.size);
  }  /* contains() */

  /*------------------------------------------------------------------*/
  /** Get the cover (list of transaction identifiers) of an item pattern
   *  w.r.t. a transaction bag.
   *  @param tabag the transaction bag w.r.t. which to get the cover
   *  @return an array of indices of transactions
   *          in which the item pattern is contained
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getCover (TrActBag tabag)
  { return tabag.getCoverOf(this); }

  /*------------------------------------------------------------------*/
  /** Create the intersection of two item patterns.
   *  <p>The intersection is created in the pattern for which this
   *  function is called, which acts as a buffer to avoid memory
   *  allocation. However, if the item array of this pattern is
   *  too small to hold the intersection, it is enlarged.</p>
   *  @param  A the first  pattern to intersect
   *  @param  B the second pattern to intersect
   *  @return the size of the intersection of the patterns
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final int isect (Pattern A, Pattern B)
  {                             /* --- find intersection size */
    int iA, iB;                 /* loop variables */

    this.size   = 0;            /* clear the intersection size */
    this.s_base = A.s_base;     /* compute the pattern support */
    this.s_pat  = (A.s_pat > B.s_pat) ? A.s_pat : B.s_pat;
    if ((A.size <= 0) || (B.size <= 0))
      return 0;                 /* check for an empty pattern */
    int z = (A.size < B.size) ? A.size : B.size;
    if (z > this.items.length)  /* if the item array is too small, */
      this.items = new int[z];  /* allocate a larger array */
    for (iA = iB = 0; true; ) {
      if      (A.items[iA] < B.items[iB]) {
        if (++iA >= A.size) return this.size; }
      else if (A.items[iA] > B.items[iB]) {
        if (++iB >= B.size) return this.size; }
      else {                    /* count the items in both */
        this.items[this.size++] = A.items[iA];
        if (++iA >= A.size) return this.size;
        if (++iB >= B.size) return this.size;
      }                         /* check whether a pattern exhausted */
    }
  }  /* isect() */

  /*------------------------------------------------------------------*/
  /** Recode a pattern to another item base, replacing the item base.
   *  @param  ibase the item base to recode the pattern to
   *  @param  map   the old identifier to new identifier map;
   *                if <code>null</code>, the map is created by a
   *                call to <code>IdMap.getMapTo()</code>
   *  @since 2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void recode (IdMap ibase, int[] map)
  {                             /* --- recode an item pattern */
    if (map == null)            /* create an id map array if needed */
      map = this.ibase.getMapTo(ibase);
    for (int i = 0; i < this.size; i++)
      this.items[i] = map[this.items[i]];
    this.ibase = ibase;         /* map items and replace item base */
  }  /* recode() */

  /*------------------------------------------------------------------*/
  /** Pack an item pattern, i.e., optimize memory usage.
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void pack ()
  {                             /* --- pack an item pattern */
    if (this.items.length <= this.size)
      return;                   /* shrink the pattern array */
    int[] p = new int[this.size];
    System.arraycopy(this.items, 0, p, 0, this.size);
    this.items = p;             /* set the shrunk array */
  }  /* pack() */

  /*------------------------------------------------------------------*/
  /** Write an item pattern.
   *  @param  writer  the writer to write to
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer) throws IOException
  {                             /* --- write an item pattern */
    writer.write(this.toString(null, null));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write an item pattern.
   *  @param  writer the writer to write to
   *  @param  info   the additional information to write
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String info)
    throws IOException
  {                             /* --- write an item pattern */
    writer.write(this.toString(null, info));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write an item pattern.
   *  @param  writer the writer to write to
   *  @param  isep   the item separator
   *  @param  info   the additional information to write
   *  @since  2017.06.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String isep, String info)
    throws IOException
  {                             /* --- write an item pattern */
    writer.write(this.toString(isep, info));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Create a 'malformed number' I/O exception.
   *  @param  scan the scanner to read from
   *  @return a 'malformed number' I/O exception.
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static IOException badNumEx (Scanner scan)
  { return new IOException("malformed number '" +scan.value +"'"
                           +scan.lno()); }

  /*------------------------------------------------------------------*/
  /** Create a 'malformed number' I/O exception.
   *  @param  scan the scanner to read from
   *  @param  x    the number causing the problem
   *  @return a 'malformed number' I/O exception.
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static IOException badNumEx (Scanner scan, double x)
  { return new IOException("malformed number '" +x +"'" +scan.lno()); }

  /*------------------------------------------------------------------*/
  /** Parse an item pattern.
   *  @param  ibase the underlying item base
   *  @param  scan  the scanner to read from
   *  @return the parsed item pattern
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Pattern parse (IdMap ibase, Scanner scan)
    throws IOException
  {                             /* --- parse an item pattern */
    Pattern pat;                /* created item pattern */
    int     z;                  /* size of the item array */
    double  d;                  /* read buffer */

    pat = new Pattern(ibase);   /* create an item pattern */
    pat.items = new int[z = BLKSIZE];
    while ((scan.nextToken() == Scanner.T_ID)
    ||     (scan.ttype       == Scanner.T_NUM)) {
      if (pat.size >= z) {      /* if the item array is full */
        z += (z > BLKSIZE) ? z >> 1 : BLKSIZE;
        int[] a = new int[z];   /* create a new item array */
        System.arraycopy(pat.items, 0, a, 0, pat.size);
        pat.items = a;          /* copy the array content and */
      }                         /* set the new item array */
      pat.items[pat.size++] = pat.ibase.add(scan.value);
    }                           /* store the antecedent items */
    scan.pushBack();            /* unget last token */

    scan.getChar('(');          /* check for a '(' */
    scan.getNumber();           /* get the item pattern support */
    try { d = Double.parseDouble(scan.value); }
    catch (NumberFormatException e) { throw Pattern.badNumEx(scan); }
    if (scan.nextToken() != '/') {
      scan.pushBack();          /* if no other value follows */
      if (d != Math.floor(d)) throw Pattern.badNumEx(scan, d);
      pat.s_pat = (int)d;       /* read value is absolute support */
      scan.getChar(',');        /* check for a '(' */
      scan.getNumber();         /* get the base support */
      try { pat.s_base = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) { throw Pattern.badNumEx(scan); }}
    else {                      /* if another value follows, */
      scan.getNumber();         /* get the absolute support */
      try { pat.s_pat = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) { throw Pattern.badNumEx(scan); }
      pat.s_base = (int)((double)pat.s_pat /d *100.0 +0.5);
    }                           /* compute and collect base support */

    if (scan.nextToken() != ',') {
      pat.eval = 0.0;           /* if no number follows, clear eval. */
      scan.pushBack(); }        /* invalidate the add. evaluation */
    else {                      /* otherwise consume the number */
      scan.getNumber();         /* get the additional evaluation */
      try { pat.eval = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) { throw Pattern.badNumEx(scan); }
    }

    if (scan.nextToken() != ',') {
      pat.wgt = 0.0;            /* if no number follows, clear eval. */
      scan.pushBack(); }        /* invalidate the add. evaluation */
    else {                      /* otherwise consume the number */
      scan.getNumber();         /* get the additional evaluation */
      try { pat.wgt = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) { throw Pattern.badNumEx(scan); }
    }

    while (scan.nextToken() != ')')
      ;                         /* skip until end of values */
    pat.pack();                 /* pack the parsed item pattern */
    return pat;                 /* and then return it */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse an item pattern.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @return the parsed item pattern
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Pattern parse (IdMap ibase, Reader reader)
    throws IOException
  { return Pattern.parse(ibase, new Scanner(reader)); }

  /*------------------------------------------------------------------*/
  /** Parse an item pattern.
   *  @param  ibase the underlying item base
   *  @param  desc  the string description to parse
   *  @return the parsed item pattern
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Pattern parse (IdMap ibase, String desc)
    throws IOException
  { return Pattern.parse(ibase, new Scanner(desc)); }

  /*------------------------------------------------------------------*/
  /** Parse an item pattern.
   *  @param  ibase the underlying item base
   *  @param  inp   the input stream to read from
   *  @return the parsed item pattern
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Pattern parse (IdMap ibase, InputStream inp)
    throws IOException
  { return Pattern.parse(ibase, new Scanner(inp)); }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @param  isep the separator for the items
   *  @param  info characters specifying
   *               additional information to report
   *  @return the created string description
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString (String isep, String info)
  {                             /* --- create a string representation */
    if (isep == null) isep = " ";
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < this.size; i++) { /* start with the items */
      b.append(this.ibase.get(this.items[i])); b.append(isep); }
    b.append('(');              /* add support values and evaluation */
    b.append(this.s_pat);  b.append(',');
    b.append(this.s_base); b.append(',');
    b.append(this.eval);   b.append(',');
    b.append(this.wgt);         /* add essential information */
    if ((info != null) && (info.length() > 0)) {
      for (int i = 0; i < info.length(); i++) {
        b.append(',');          /* if to add more information */
        switch (info.charAt(i)){/* evaluate the value identifier */
          case 'i': b.append(getSize());         break;
          case 'a': b.append(getSupp());         break;
          case 's': b.append(getRelSupp());      break;
          case 'S': b.append(getRelSupp() *100); break;
          case 'Q': b.append(getBaseSupp());     break;
          case 'e': b.append(getEval());         break;
          case 'E': b.append(getEval() *100);    break;
          case 'w': b.append(getWeight());       break;
          case 'W': b.append(getWeight() *100);  break;
        }                       /* add selected values */
      }                         /* as additional information */
    }
    b.append(')');              /* terminate item pattern infromation */
    return b.toString();        /* return the string representation */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @param  info characters specifying
   *               additional information to report
   *  @return the created string description
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String toString (String info)
  { return toString(null, info); }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return the created string description
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String toString ()
  { return toString(null, null); }

}  /* class Pattern */
