/*----------------------------------------------------------------------
  File    : ARule.java
  Contents: association rule management for visualization
  Author  : Christian Borgelt
  History : 2004.07.06 file created
            2005.02.21 adapted to scanner utility functions
            2006.05.13 class moved to a separate file
            2007.03.12 adapted to class IdMap, javadoc added
            2014.10.02 head support values added
            2016.04.07 StringBuffer replaced by StringBuilder
            2016.04.08 write functions added to complement parse
            2016.04.10 sorting redesigned with public sort value
            2016.04.13 reduced to storing absolute support values
            2017.06.17 constant EMPTY for empty item arrays added
            2017.06.20 cloning and comparison functions added
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.io.PrintWriter;
import java.util.Arrays;

import util.IdMap;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for association rules.
 *  @author Christian Borgelt
 *  @since  2004.07.06 */
/*--------------------------------------------------------------------*/
public class ARule implements Comparable<ARule>, Cloneable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00020001L;
  /** the block size for the item array (rule body) */
  private static final int BLKSIZE = 8;
  /** the empty item array to avoid reallocation */
  private static final int[] EMPTY = {};

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  protected IdMap  ibase;
  /** the antecedent/body of the association rule */
  protected int[]  body;
  /** the number of items in the antecedent/body */
  protected int    size;
  /** the consequent/head of the association rule */
  protected int    head;
  /** the (absolute) support of the item pattern of the association rule */
  protected int    s_pat;
  /** the (absolute) support of the body set of the association rule */
  protected int    s_body;
  /** the (absolute) support of the head item of the association rule */
  protected int    s_head;
  /** the (absolute) base support
   *  (support of the empty pattern, transaction database size) */
  protected int    s_base;
  /** the value of the additional rule evaluation measure */
  protected double eval;
  /** the value for sorting association rules */
  protected double sort;
  /** the comparison direction for sorting association rules */
  protected int    dir;

  /*------------------------------------------------------------------*/
  /** Create an empty association rule.
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARule ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create an empty association rule.
   *  @param  ibase the underlying item base
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARule (IdMap ibase)
  {                             /* --- create an association rule */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.body  = EMPTY;         /* note the item base and */
    this.size  =  0;            /* initialize the fields */
    this.head  = -1;
    this.s_pat = this.s_body = this.s_head = this.s_base = 0;
    this.eval  = 0.0;
  }  /* ARule() */

  /*------------------------------------------------------------------*/
  /** Create an association rule from a head item and a body array.
   *  @param  ibase  the underlying item base
   *  @param  head   the item in the head of the associaton rule
   *  @param  body   the items in the body of the associaton rule
   *  @param  s_pat  the absolute support of the underlying item set
   *  @param  s_body the absolute support of the rule body
   *  @param  s_head the absolute support of the rule head
   *  @param  s_base the absolute support of the empty set
   *  @param  eval   the evaluation of the association rule
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARule (IdMap ibase, int[] body, int head,
                int s_body, int s_pat, int s_head, int s_base,
                double eval)
  {                             /* -- create an association rule */
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.body   = (body != null) ? body : EMPTY;
    this.size   = this.body.length;
    this.head   = head;         /* note the item base and */
    this.s_pat  = s_pat;        /* the rule's body and head */
    this.s_body = s_body;
    this.s_head = s_head;
    this.s_base = s_base;
    this.eval   = eval;         /* note support and other values */
  }  /* ARule() */

  /*------------------------------------------------------------------*/
  /** Create an association rule from a head item and a body array.
   *  @param  ibase  the underlying item base
   *  @param  head   the item in the head of the associaton rule
   *  @param  body   the items in the body of the associaton rule
   *  @param  cnt    the number of items in the rule body
   *  @param  s_pat  the absolute support of the underlying item set
   *  @param  s_body the absolute support of the rule body
   *  @param  s_head the absolute support of the rule head
   *  @param  s_base the absolute support of the empty set
   *  @param  eval   the evaluation of the association rule
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARule (IdMap ibase, int[] body, int cnt, int head,
                int s_body, int s_pat, int s_head, int s_base,
                double eval)
  {                             /* -- create an association rule */
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.body   = new int[this.size = cnt];
    System.arraycopy(body, 0, this.body, 0, cnt);
    this.head   = head;         /* note the item base and */
    this.s_pat  = s_pat;        /* the rule's body and head */
    this.s_body = s_body;
    this.s_head = s_head;
    this.s_base = s_base;
    this.eval   = eval;         /* note support and other values */
  }  /* ARule() */

  /*------------------------------------------------------------------*/
  /** Clone this association rule
   *  (the item base is maintained, the body array is copied).
   *  @return a clone of this association rule
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone ()
  { return clone(null, true); }

  /*------------------------------------------------------------------*/
  /** Clone this association rule (the body array is copied).
   *  @param  ibase the item base to use for the clone
   *  @return a clone of this association rule
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone (IdMap ibase)
  { return clone(null, true); }

  /*------------------------------------------------------------------*/
  /** Clone this association rule.
   *  @param  iclone whether to clone the body item array
   *  @return a clone of this association rule
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone (boolean iclone)
  { return this.clone(iclone, null); }

  /*------------------------------------------------------------------*/
  /** Clone this association rule.
   *  @param  iclone whether to clone the body item array
   *  @param  ibase  the item base to use for the clone;
   *                 if <code>null</code>, keep old item base
   *  @return a clone of this association rule
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone (boolean iclone, IdMap ibase)
  { return this.clone(ibase, iclone); }

  /*------------------------------------------------------------------*/
  /** Clone this association rule.
   *  @param  ibase  the item base to use for the clone;
   *                 if <code>null</code>, keep old item base
   *  @param  iclone whether to clone the body item array
   *  @return a clone of this association rule
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone (IdMap ibase, boolean iclone)
  {                             /* --- clone an association rule */
      ARule rule;               /* created association rule clone */
    if (ibase == null) ibase = this.ibase;
    if (iclone)                 /* if to clone/copy the item array */
      rule = new ARule(ibase, this.body, this.size, this.head,
                       this.s_body, this.s_pat, this.s_head,
                       this.s_base, this.eval);
    else {                      /* if not to copy the item array */
      rule = new ARule(ibase, this.body, this.head,
                       this.s_body, this.s_pat, this.s_head,
                       this.s_base, this.eval);
      rule.size = this.size;    /* call non-copying constructor and */
    }                           /* overwrite with the correct size */
    return rule;                /* return the created clone */
  }  /* clone() */

  /*------------------------------------------------------------------*/
  /** Add an item (given by its identifier)
   *  to the body/antecedent of the association rule.
   *  @param  item the item identifier
   *  @return the index of the new item (in the rule body)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemById (int item)
  {                             /* --- add an item to a transaction */
    int smax = this.body.length;
    if (this.size >= smax) {    /* if the item array is full */
      smax += (smax > BLKSIZE) ? smax >> 1 : BLKSIZE;
      int[] p = new int[smax];  /* create an (enlarged) item array */
      System.arraycopy(this.body, 0, p, 0, this.size);
      this.body = p;            /* copy the existing items */
    }                           /* and set the (new) item array */
    this.body[this.size] = item;
    return this.size++;         /* return the index of the new item */
  }  /* addItemById() */

  /*------------------------------------------------------------------*/
  /** Add an item (given by its name)
   *  to the body/antecedent of the association rule.
   *  @param  item the name of the item to add
   *  @return the index of the new item (in the rule body)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemByName (String item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its object)
   *  to the body/antecedent of the association rule.
   *  @param  item the object of the item to add
   *  @return the index of the new item (in the rule body)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemByObject (Object item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its identifier)
   *  to the body/antecedent of the association rule.
   *  @param  item the identifier of the item to add
   *  @return the index of the new item (in the rule body)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (int item)
  { return this.addItemById(item); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its name)
   *  to the body/antecedent of the association rule.
   *  @param  item the name of the item to add
   *  @return the index of the new item (in the rule body)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (String item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its object)
   *  to the body/antecedent of the association rule.
   *  @param  item the object of the item to add
   *  @return the index of the new item (in the rule body)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (Object item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Get the identifier of an antecedent item.
   *  @param  i the index of the antecedent item
   *  @return the identifier of the antecedent item with index i
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getBody (int i)
  { return (i < this.size) ? this.body[i] : -1; }

  /*------------------------------------------------------------------*/
  /** Get the identifier of an antecedent item.
   *  @param  i the index of the antecedent item
   *  @return the identifier of the antecedent item with index i
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getBodyItem (int i)
  { return (i < this.size) ? this.body[i] : -1; }

  /*------------------------------------------------------------------*/
  /** Get the identifier of the last antecedent item.
   *  @return the identifier of the last antecedent item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getLastBody ()
  { return (this.size > 0) ? this.body[this.size -1] : -1; }

  /*------------------------------------------------------------------*/
  /** Get the identifier of the last antecedent item.
   *  @return the identifier of the last antecedent item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getLastBodyItem (int i)
  { return (this.size > 0) ? this.body[this.size -1] : -1; }

  /*------------------------------------------------------------------*/
  /** Get the name of an antecedent item.
   *  @param  i the index of the antecedent item
   *  @return the name of the antecedent item with index i
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getBodyName (int i)
  { return (i < this.size) ? (String)this.ibase.get(this.body[i]) : "";}

  /*------------------------------------------------------------------*/
  /** Get the name of an antecedent item.
   *  @param  i the index of the antecedent item
   *  @return the name of the antecedent item with index i
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getBodyItemName (int i)
  { return (i < this.size) ? (String)this.ibase.get(this.body[i]) : "";}

  /*------------------------------------------------------------------*/
  /** Get the object of an antecedent item.
   *  @param  i the index of the antecedent item
   *  @return the object of the antecedent item with index i
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getBodyObject (int i)
  { return (i < this.size) ? this.ibase.get(this.body[i]) : null; }

  /*------------------------------------------------------------------*/
  /** Get the object of an antecedent item.
   *  @param  i the index of the antecedent item
   *  @return the name of the antecedent item with index i
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getBodyItemObject (int i)
  { return (i < this.size) ? this.ibase.get(this.body[i]) : null; }

  /*------------------------------------------------------------------*/
  /** Get the item array (length fits only after packing).
   *  @return the array of body items
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getBody ()
  { return this.body; }

  /*------------------------------------------------------------------*/
  /** Get the item array (length fits only after packing).
   *  @return the array of body items
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getAllBodyItems ()
  { return this.body; }

  /*------------------------------------------------------------------*/
  /** Get the size of the rule (total number of items).
   *  @return the size of the rule
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSize ()
  { return this.size +((this.head >= 0) ? 1 : 0); }

  /*------------------------------------------------------------------*/
  /** Get the size of the antecedent (number of items).
   *  @return the size of the antecedent
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getBodySize ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the size of the consequent of the rule (either 0 or 1).
   *  @return the size of the consequent of the rule
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getHeadSize ()
  { return (this.head >= 0) ? 1 : 0; }

  /*------------------------------------------------------------------*/
  /** Get the identifier of the consequent item.
   *  @return the identifier of the consequent item
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getHead ()
  { return this.head; }

  /*------------------------------------------------------------------*/
  /** Get the name of the consequent item.
   *  @return the name of the consequent item
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getHeadName ()
  { return (this.head >= 0) ? (String)this.ibase.get(this.head) : ""; }

  /*------------------------------------------------------------------*/
  /** Get the name of the consequent item.
   *  @return the name of the consequent item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getHeadItemName ()
  { return (this.head >= 0) ? (String)this.ibase.get(this.head) : ""; }

  /*------------------------------------------------------------------*/
  /** Get the object of the consequent item.
   *  @return the object of the consequent item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getHeadObject ()
  { return (this.head >= 0) ? this.ibase.get(this.head) : null; }

  /*------------------------------------------------------------------*/
  /** Get the object of the consequent item.
   *  @return the object of the consequent item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getHeadItemObject ()
  { return (this.head >= 0) ? this.ibase.get(this.head) : null; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the item set
   *  underlying the association rule.
   *  @return the (absolute) support of the item set
   *          underlying the association rule
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp ()                   /* a */
  { return this.s_pat; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the item set
   *  of the association rule.
   *  @return the (absolute) support of the item set
   *          of the association rule
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getAbsSupp ()                /* a */
  { return this.s_pat; }

  /*------------------------------------------------------------------*/
  /** Get the (relative) support of the item set
   *  of the association rule.
   *  @return the (relative) support of the item set
   *          of the association rule
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getRelSupp ()             /* s/S */
  { return (this.s_base <= 0) ? 0
         : (double)this.s_pat/(double)this.s_base; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the body of the association rule.
   *  @return the (absolute) support of the body of the association rule
   *  @since  2008.11.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getBodySupp ()               /* b */
  { return this.s_body; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the body of the association rule.
   *  @return the (absolute) support of the body of the association rule
   *  @since 2008.11.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getAbsBodySupp ()            /* b */
  { return this.s_body; }

  /*------------------------------------------------------------------*/
  /** Get the (relative) support of the body of the association rule.
   *  @return the (relative) support of the body of the association rule
   *  @since  2008.11.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getRelBodySupp ()         /* x/X */
  { return (this.s_base <= 0) ? 0
         : (double)this.s_body/(double)this.s_base; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the head of the association rule.
   *  @return the (absolute) support of the head of the association rule
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getHeadSupp ()               /* h */
  { return this.s_head; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the head of the association rule.
   *  @return the (absolute) support of the head of the association rule
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getAbsHeadSupp ()            /* h */
  { return this.s_head; }

  /*------------------------------------------------------------------*/
  /** Get the (relative) support of the head of the association rule.
   *  @return the (relative) support of the head of the association rule
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getRelHeadSupp ()         /* y/Y */
  { return (this.s_base <= 0) ? 0
         : (double)this.s_head/(double)this.s_base; }

  /*------------------------------------------------------------------*/
  /** Get the (absolute) support of the empty set
   *  (i.e. the size of the transaction database).
   *  @return the (absolute) support of the empty set
   *  @since  2016.04.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getBaseSupp ()               /* Q */
  { return this.s_base; }

  /*------------------------------------------------------------------*/
  /** Get the confidence of the association rule.
   *  @return the confidence of the association rule
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getConf ()                /* c/C */
  { return (this.s_body <= 0) ? 0
         : (double)this.s_pat/(double)this.s_body; }

  /*------------------------------------------------------------------*/
  /** Get the lift value of the association rule.
   *  @return the lift value of the association rule
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getLift ()                /* l/L */
  { double d = (double)this.s_body *(double)this.s_head;
    return (d > 0) ? ((double)this.s_pat *(double)this.s_base) /d : 0; }

  /*------------------------------------------------------------------*/
  /** Get the value of the additional rule evaluation measure.
   *  @return the value of the additional rule evaluation measure
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final double getEval ()                /* e/E */
  { return this.eval; }

  /*--------------------------------------------------------------------*/
  /** Sort the items in the rule body (antecedent).
   *  @since  2017.06.20 (Christian Borgelt) */
  /*--------------------------------------------------------------------*/

  public final void sort ()
  { Arrays.sort(this.body, 0, this.size); }

  /*------------------------------------------------------------------*/
  /** Set sort value and sort direction.
   *  @param  value the value to sort association rules on
   *  @param  dir   the direction to sort association rules into
   *  @since  2016.04.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSort (int value, int dir)
  { this.sort = (double)value; this.dir = dir; }

  /*------------------------------------------------------------------*/
  /** Set sort value and sort direction.
   *  @param  value the value to sort association rules on
   *  @param  dir   the direction to sort association rules into
   *  @since  2016.04.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSort (double value, int dir)
  { this.sort = value; this.dir = dir; }

  /*------------------------------------------------------------------*/
  /** Compare this rule to another (given as argument).
   *  @param  rule the rule to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as the sort value of this rule is less than, equal to,
   *          or greater than the sort value of the given rule
   *  @since  2016.04.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int compareTo (ARule rule)
  {                             /* --- compare to another rule */
    if (this.sort > rule.sort) return +this.dir;
    if (this.sort < rule.sort) return -this.dir;
    return 0;                   /* return sign of sort value diff. */
  }  /* compareTo() */

  /*------------------------------------------------------------------*/
  /** Compare this rule to another (given as argument)
   *  by comparing body items lexicographically.
   *  @param  rule the rule to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as this rule is less than, equal to, or greater than
   *          the rule given as an argument
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int bodyCmpTo (ARule rule)
  {                             /* --- compare to another rule */
    int n = (this.size < rule.size) ? this.size : rule.size;
    for (int i = 0; i < n; i++){/* traverse items in smaller body */
      if (this.body[i] > rule.body[i]) return +1;
      if (this.body[i] < rule.body[i]) return -1;
    }                           /* if items differ, return result */
    if (this.size > rule.size) return +1;
    if (this.size < rule.size) return -1;
    return 0;                   /* return sign of "difference" */
  }  /* bodyCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare this rule to another (given as argument)
   *  by comparing head items lexicographically.
   *  @param  rule the rule to compare to
   *  @return <code>-2</code>, <code>0</code>, or <code>+2</code>
   *          as this rule is less than, equal to, or greater than
   *          the rule given as an argument
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int headCmpTo (ARule rule)
  {                             /* --- compare to another rule */
    if (this.head > rule.head) return +2;
    if (this.head < rule.head) return -2;
    return 0;                   /* return sign of "difference" */
  }  /* headCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare this rule to another (given as argument)
   *  by comparing body and head items lexicographically.
   *  @param  rule the rule to compare to
   *  @return <code>-1</code> or <code>+1</code> if the two rules
   *          differ in their antecedent/body; <code>-2</code> or
   *          <code>+2</code> if the two rules have the same
   *          antecedent/body, but differ in their consequent/head;
   *          and <code>0</code> if the two rules coincide in all items;
   *          the function returns a negative value, <code>0</code>,
   *          or a positive value as this rule is less than, equal to,
   *          or greater than the rule given as an argument
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int itemsCmpTo (ARule rule)
  {                             /* --- compare to another rule */
    int c = this.bodyCmpTo(rule);
    if (c != 0) return c;
    return this.headCmpTo(rule);/* return sign of "difference" */
  }  /* itemsCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare this rule to another (given as argument)
   *  by comparing all head properties: items, support values etc.
   *  @param  rule the rule to compare to
   *  @return <code>-2</code> or <code>+2</code> if the two rules
   *          differ in their consequent/head; <code>-3</code> or
   *          <code>+3</code> if the two rules have the same
   *          consequents/heads, but differ in their support values;
   *          and <code>0</code> if the two rules coincide in all items
   *          and in all support values; the function returns a negative
   *          value, <code>0</code>, or a positive value as this rule is
   *          less than, equal to, or greater than the rule given as an
   *          argument
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int headAllCmpTo (ARule rule)
  {                             /* --- compare to another rule */
    int c = this.headCmpTo(rule);
    if (c != 0) return c;
    if (this.s_pat  > rule.s_pat)  return +3;
    if (this.s_pat  < rule.s_pat)  return -3;
    if (this.s_body > rule.s_body) return +3;
    if (this.s_body < rule.s_body) return -3;
    return 0;                   /* return sign of "difference" */
  }  /* headAllCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare this rule to another (given as argument)
   *  by comparing all body and head properties:
   * items, support values etc.
   *  @param  rule the rule to compare to
   *  @return <code>-1</code> or <code>+1</code> if the two rules
   *          differ in their antecedent/body; <code>-2</code> or
   *          <code>+2</code> if the two rules have the same antecedent,
   *          but differ in their consequent/head; <code>-3</code> or
   *          <code>+3</code> if the two rules coincide in their items,
   *          but differ in their support values; and <code>0</code>
   *          if the two rules coincide in all items and all support
   *          values; the function returns a negative value,
   *          <code>0</code>, or a positive value as this rule is less
   *          than, equal to, or greater than the rule given as an
   *          argument
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int itemsAllCmpTo (ARule rule)
  {                             /* --- compare to another rule */
    int c = this.bodyCmpTo(rule);
    if (c != 0) return c;       /* return sign of "difference" */
    return this.headAllCmpTo(rule);
  }  /* itemsAllCmpTo() */

  /*------------------------------------------------------------------*/
  /** Compare the rule's body to a given item pattern.
   *  @param  items the items of the pattern to compare to
   *  @param  cnt   the number of items; if negative,
   *                the length of the item array is used
   *  @return whether the rule's body equals the given item pattern
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyEquals (int[] items, int cnt)
  {                             /* --- compare body to given items */
    if (cnt < 0) cnt = items.length;
    if (this.size != cnt)       /* if the number of items does not */
      return false;             /* match, the body cannot be equal */
    while (--cnt >= 0)          /* check for matching body items */
      if (this.body[cnt] != items[cnt])
        return false;           /* on mismatch abort with failure */
    return true;                /* return 'no difference' */
  }  /* bodyEquals() */

  /*------------------------------------------------------------------*/
  /** Compare the rule's body to a given item pattern.
   *  @param  items the items of the pattern to compare to
   *  @return whether the rule's body equals the given item pattern
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyEquals (int[] items)
  { return this.bodyEquals(items, items.length); }

  /*------------------------------------------------------------------*/
  /** Compare an association rule to another (given as argument).
   *  @param  rule the association rule to compare to
   *  @return <code>true</code> if the two rules are identical and
   *          <code>false</code> otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean equals (ARule rule)
  { return this.equals(rule, true); }

  /*------------------------------------------------------------------*/
  /** Compare an association rule to another (given as argument).
   *  @param  rule    the association rule to compare to
   *  @param  chksupp whether to compare the support values
   *  @return <code>true</code> if the two rules are identical and
   *          <code>false</code> otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean equals (ARule rule, boolean chksupp)
  {                             /* --- compare body to given items */
    if (this.size != rule.size) /* if the numbers of items differ, */
      return false;             /* the rules cannot be equal */
    for (int i = 0; i < this.size; i++)
      if (this.body[i] != rule.body[i])
        return false;           /* check for matching body items */
    if (this.head != rule.head) /* if the head items differ, */
      return false;             /* the rules are not equal */
    if (chksupp                 /* if to check support values */
    && ((this.s_body != rule.s_body)
    ||  (this.s_pat  != rule.s_pat)
    ||  (this.s_head != rule.s_head)
    ||  (this.s_base != rule.s_base)))
      return false;             /* check for matching support values */
    return true;                /* if all elements match, */
  }  /* equals() */             /* the two rules are equal */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecedent) is a subpattern
   *  of a given item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the rule body and the given item
   *  array need to be sorted for this function to work.</p>
   *  @param  items the items of the pattern to compare to
   *  @param  cnt   the number of items; if negative,
   *                the length of the given item array is used
   *  @return <code>true</code> if this rule's body (antecedent)
   *          is a subpattern of the given item pattern and
   *          <code>false</code> otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyIsSubOf (int[] items, int cnt)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(this.body, this.size, items, cnt);
  }  /* bodyIsSubOf() */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecedent) is a subpattern
   *  of a given item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the rule body and the given item
   *  array need to be sorted for this function to work.</p>
   *  @param  items the items of the pattern to compare to
   *  @return <code>true</code> if this rule's body (antecedent)
   *          is a subpattern of the given item pattern and
   *          <code>false</code> otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyIsSubOf (int[] items)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(this.body, this.size,
                              items, items.length);
  }  /* bodyIsSubOf() */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecedent) is a subpattern
   *  of another rule's body (antecedent).
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets both rule bodies need to be sorted
   *  with <code>sort()</code> for this function to work.</p>
   *  @param  rule the association rule to compare to
   *  @return <code>true</code> if this rule's body (antecedent)
   *          is a subpattern of the body (antecedent) of the given
   *          association rule <code>rule</code> and <code>false</code>
   *          otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyIsSubOf (ARule rule)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(this.body, this.size,
                              rule.body, rule.size);
  }  /* bodyIsSubOf() */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecedent) is contained in
   *  another rule's body (antecedent).
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets both rule bodies need to be sorted
   *  with <code>sort()</code> for this function to work.</p>
   *  @param  rule the association rule to compare to
   *  @return <code>true</code> if this rule's body (antecedent)
   *          is contained in the body (antecedent) of the given
   *          association rule <code>rule</code> and <code>false</code>
   *          otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyIsContainedIn (ARule rule)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(this.body, this.size,
                              rule.body, rule.size);
  }  /* bodyIsContainedIn() */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecedent) is a superpattern
   *  of a given item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the rule body and the given item array
   *  need to be sorted for this function to work.</p>
   *  @param  items the items of the pattern to compare to
   *  @param  cnt   the number of items; if negative,
   *                the length of the given item array is used
   *  @return <code>true</code> if this rule's body (antecedent)
   *          is a superpattern of the given item pattern and
   *          <code>false</code> otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyIsSuperOf (int[] items, int cnt)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(items, cnt, this.body, this.size);
  }  /* bodyIsSuperOf() */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecedent) is a superpattern
   *  of a given item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the rule body and the given item array
   *  need to be sorted for this function to work.</p>
   *  @param  items the items of the pattern to compare to
   *  @return <code>true</code> if this rule's body (antecedent)
   *          is a superpattern of the given item pattern and
   *          <code>false</code> otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyIsSuperOf (int[] items)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(items, items.length,
                              this.body, this.size);
  }  /* bodyIsSuperOf() */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecdent) is a superpattern
   *  of another rule's body (antecedent).
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets both rule bodies need to be sorted
   *  with <code>sort()</code> for this function to work.</p>
   *  @param  rule the association rule to compare to
   *  @return <code>true</code> if this rule's body (antecedent)
   *          is a superpattern of the body (antecedent) of the given
   *          association rule <code>rule</code> and <code>false</code>
   *          otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyIsSuperOf (ARule rule)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(rule.body, rule.size,
                              this.body, this.size);
  }  /* bodyIsSuperOf() */

  /*------------------------------------------------------------------*/
  /** Whether this rule's body (antecdent) contains
   *  another rule's body (antecedent).
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets both rule bodies need to be sorted
   *  with <code>sort()</code> for this function to work.</p>
   *  @param  rule the association rule to compare to
   *  @return <code>true</code> if this rule's body (antecedent)
   *          contains the body (antecedent) of the given association
   *          rule <code>rule</code> and <code>false</code> otherwise
   *  @since  2016.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean bodyContains (ARule rule)
  {                             /* --- compare rule bodies */
    return Pattern.subpattern(rule.body, rule.size,
                              this.body, this.size);
  }  /* bodyContains() */

  /*------------------------------------------------------------------*/
  /** Recode an association rule set to another item base,
   *  replacing the item base.
   *  @param  ibase the item base to recode the association rule set to
   *  @param  map   the old identifier to new identifier map;
   *                if <code>null</code>, the map is created by a
   *                call to <code>IdMap.getMapTo()</code>
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void recode (IdMap ibase, int[] map)
  {                             /* --- recode an association rule set */
    if (map == null)            /* create an id map array if needed */
      map = this.ibase.getMapTo(ibase);
    for (int i = 0; i < this.size; i++)
      this.body[i] = map[this.body[i]];
    if (this.head >= 0)         /* map items in body and head */
      this.head = map[this.head];
    this.ibase = ibase;         /* replace the item base */
  }  /* recode() */

  /*------------------------------------------------------------------*/
  /** Pack an association rule, i.e., optimize memory usage.
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void pack ()
  {                             /* --- pack an association rule */
    if (this.body.length <= this.size) return;
    int[] p = new int[this.size];  /* shrink the item array */
    System.arraycopy(this.body, 0, p, 0, this.size);
    this.body = p;              /* set the shrunk item array */
  }  /* pack() */

  /*------------------------------------------------------------------*/
  /** Write an association rule.
   *  @param  writer the writer to write to
   *  @throws IOException if a write error occurs
   *  @since  2016.04.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer) throws IOException
  {                             /* --- write an association rule */
    writer.write(this.toString(null, null));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write an association rule.
   *  @param  writer the writer to write to
   *  @param  info   the additional information to write
   *  @throws IOException if a write error occurs
   *  @since  2016.04.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String info)
    throws IOException
  {                             /* --- write an association rule */
    writer.write(this.toString(null, info));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write an association rule.
   *  @param  writer the writer to write to
   *  @param  isep   the item separator
   *  @param  info   the additional information to write
   *  @throws IOException if a write error occurs
   *  @since  2016.04.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String isep, String info)
    throws IOException
  {                             /* --- write an association rule */
    writer.write(this.toString(isep, info));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Create a 'malformed number' I/O exception.
   *  @param  scan the scanner to read from
   *  @return a 'malformed number' I/O exception.
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static IOException badNumEx (Scanner scan)
  { return new IOException("malformed number '" +scan.value +"'"
                           +scan.lno()); }

  /*------------------------------------------------------------------*/
  /** Create a 'malformed number' I/O exception.
   *  @param  scan the scanner to read from
   *  @param  x    the number causing the problem
   *  @return a 'malformed number' I/O exception.
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static IOException badNumEx (Scanner scan, double x)
  { return new IOException("malformed number '" +x +"'" +scan.lno()); }

  /*------------------------------------------------------------------*/
  /** Parse an association rule.
   *  @param  ibase the underlying item base
   *  @param  scan  the scanner to read from
   *  @return the parsed association rule
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARule parse (IdMap ibase, Scanner scan)
    throws IOException
  {                             /* --- parse an association rule */
    ARule  rule;                /* created association rule */
    int[]  a;                   /* buffer for reallocation */
    int    z;                   /* size of the antecedent vector */
    double d, s = 0;            /* read buffer, sum of base support */
    int    n = 0;               /* number of base support values */

    rule = new ARule(ibase);    /* create an association rule */
    scan.getID();               /* get the consequent item */
    rule.head = ibase.add(scan.value);
    if (scan.nextToken() != Scanner.T_LFT)
      throw new IOException("'<-' expected " +scan.lno());
    rule.body = new int[z = BLKSIZE];
    while ((scan.nextToken() == Scanner.T_ID)
    ||     (scan.ttype       == Scanner.T_NUM)) {
      if (rule.size >= z) {     /* if the item array is full */
        z += (z > BLKSIZE) ? z >> 1 : BLKSIZE;
        a = new int[z];         /* create a new item array */
        System.arraycopy(rule.body, 0, a, 0, rule.size);
        rule.body = a;          /* copy the array content and */
      }                         /* set the new item array */
      rule.body[rule.size++] = rule.ibase.add(scan.value);
    }                           /* store the antecedent items */
    scan.pushBack();            /* unget last token */

    scan.getChar('(');          /* check for a '(' */
    scan.getNumber();           /* get the body support */
    try { d = Double.parseDouble(scan.value); }
    catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
    if (scan.nextToken() != '/') {
      scan.pushBack();          /* if no other value follows */
      if (d != Math.floor(d)) throw ARule.badNumEx(scan, d);
      rule.s_body = (int)d; }   /* read value is absolute support */
    else {                      /* if another value follows, */
      scan.getNumber();         /* get the absolute support */
      try { rule.s_body = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
      s += (double)rule.s_body /d *100.0; n += 1;
    }                           /* compute and collect base support */

    scan.getChar(',');          /* check for a ',' */
    scan.getNumber();           /* get the item set support */
    try { d = Double.parseDouble(scan.value); }
    catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
    if (scan.nextToken() != '/') {
      scan.pushBack();          /* if no other value follows */
      if (d != Math.floor(d)) throw ARule.badNumEx(scan, d);
      rule.s_pat = (int)d; }    /* read value is absolute support */
    else {                      /* if another value follows, */
      scan.getNumber();         /* get the absolute support */
      try { rule.s_pat = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
      s += (double)rule.s_pat /d *100.0; n += 1;
    }                           /* compute and collect base support */

    scan.getChar(',');          /* check for a ',' */
    scan.getNumber();           /* get the body support */
    try { d = Double.parseDouble(scan.value); }
    catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
    if (scan.nextToken() != '/') {
      scan.pushBack();          /* if no other value follows */
      if (d != Math.floor(d)) throw ARule.badNumEx(scan, d);
      rule.s_head = (int)d; }   /* read value is absolute support */
    else {                      /* if another value follows, */
      scan.getNumber();         /* get the absolute support */
      try { rule.s_head = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
      s += (double)rule.s_head /d *100.0; n += 1;
    }                           /* compute and collect base support */

    if (n > 0) {                /* if base support values collected */
      rule.s_base = (int)Math.floor(s/(double)n +0.5);
      scan.getChar(',');        /* check for a ',' */
      scan.getNumber();         /* get the confidence */
      try { d = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
      scan.getChar(',');        /* check for a ',' */
      scan.getNumber();         /* get the lift value */
      try { d = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) { throw ARule.badNumEx(scan); } }
    else {                      /* if to read the base support */
      scan.getChar(',');        /* check for a ',' */
      scan.getNumber();         /* get the base support */
      try { rule.s_base = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
    }

    if (scan.nextToken() != ',') {
      rule.eval = 0.0;          /* if no number follows, clear eval. */
      scan.pushBack(); }        /* invalidate the add. evaluation */
    else {                      /* otherwise consume the number */
      scan.getNumber();         /* get the additional evaluation */
      try { rule.eval = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) { throw ARule.badNumEx(scan); }
    }

    while (scan.nextToken() != ')')
      ;                         /* skip until end of values */
    rule.pack();                /* pack the parsed association rule */
    return rule;                /* and then return it */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse an association rule.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @return the parsed association rule
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARule parse (IdMap ibase, Reader reader)
    throws IOException
  { return ARule.parse(ibase, new Scanner(reader)); }

  /*------------------------------------------------------------------*/
  /** Parse an association rule.
   *  @param  ibase the underlying item base
   *  @param  desc  the string description to parse
   *  @return the parsed association rule
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARule parse (IdMap ibase, String desc)
    throws IOException
  { return ARule.parse(ibase, new Scanner(desc)); }

  /*------------------------------------------------------------------*/
  /** Parse an association rule.
   *  @param  ibase the underlying item base
   *  @param  in    the input stream to read from
   *  @return the parsed association rule
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARule parse (IdMap ibase, InputStream in)
    throws IOException
  { return ARule.parse(ibase, new Scanner(in)); }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @param  isep the separator for the items
   *  @param  info the additional rule information to write
   *  @return the created string description
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString (String isep, String info)
  {                             /* --- create a string description */
    if (isep == null) isep = " ";
    StringBuilder b = new StringBuilder();
    if (this.head >= 0)         /* start with the consequent */
      b.append(this.ibase.get(this.head));
    b.append(isep);             /* start with the consequent/head */
    b.append("<-");             /* add an implication sign */
    b.append(isep);
    for (int i = 0; i < this.size; i++) {
      b.append(this.ibase.get(this.body[i])); b.append(isep); }
    b.append('(');              /* add the antecedent items */
    b.append(this.s_body); b.append(',');
    b.append(this.s_pat);  b.append(',');
    b.append(this.s_head); b.append(',');
    b.append(this.s_base); b.append(',');
    b.append(this.eval);        /* add essential information */
    if ((info != null) && (info.length() > 0)) {
      for (int i = 0; i < info.length(); i++) {
        b.append(',');          /* if to add more information */
        switch (info.charAt(i)){/* evaluate the value identifier */
          case 'i': b.append(this.getSize());             break;
          case 'a': b.append(this.getAbsSupp());          break;
          case 's': b.append(this.getRelSupp());          break;
          case 'S': b.append(this.getRelSupp() *100);     break;
          case 'b': b.append(this.getAbsBodySupp());      break;
          case 'x': b.append(this.getRelBodySupp());      break;
          case 'X': b.append(this.getRelBodySupp() *100); break;
          case 'h': b.append(this.getAbsHeadSupp());      break;
          case 'y': b.append(this.getRelHeadSupp());      break;
          case 'Y': b.append(this.getRelHeadSupp() *100); break;
          case 'c': b.append(this.getConf());             break;
          case 'C': b.append(this.getConf() *100);        break;
          case 'l': b.append(this.getLift());             break;
          case 'L': b.append(this.getLift() *100);        break;
          case 'Q': b.append(this.getBaseSupp());         break;
        }                       /* add selected values */
      }                         /* as additional information */
    }
    b.append(')');              /* terminate rule information */
    return b.toString();        /* return the string description */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @param  addinfo the additional rule information to write
   *  @return the created string description
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String toString (String addinfo)
  { return this.toString(null, addinfo); }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return the created string description
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String toString ()
  { return this.toString(null, null); }

}  /* class ARule */
