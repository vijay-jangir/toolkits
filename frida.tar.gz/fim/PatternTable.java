/*----------------------------------------------------------------------
  File    : PatternTable.java
  Contents: item pattern viewer table
  Author  : Christian Borgelt
  History : 2013.11.28 file created from file ARuleTable.java
            2016.11.04 merged with ItemSetTable.java
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.FileReader;
import java.awt.Dimension;
import javax.swing.table.AbstractTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JFrame;

import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for a tabular representation of a set of item patterns.
 *  @author Christian Borgelt
 *  @since  2013.11.28 */
/*--------------------------------------------------------------------*/
public class PatternTable extends AbstractTableModel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010002L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the set of item patterns */
  protected PatternSet pats;
  /** the maximum number of items in a pattern */
  protected int        cnt;
  /** the names of the table columns */
  protected String[]   names;

  /*------------------------------------------------------------------*/
  /** Create an item pattern table.
   *  @param  pats the set of item patterns
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternTable (PatternSet pats)
  { this.setPatterns(pats); }

  /*------------------------------------------------------------------*/
  /** Get the item patterns.
   *  @return the item pattern set
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternSet getPatterns ()
  { return this.pats; }

  /*------------------------------------------------------------------*/
  /** Set the item patterns.
   *  @param  pats the new pattern set
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPatterns (PatternSet pats)
  {                             /* --- set the item sets */
    int i, n;                   /* loop variable, number of columns */

    this.pats = pats;           /* note the item patterns and */
    this.cnt  = pats.getMaxSize();  /* their maximum set size */
    n = ((pats.getCount() > 0)
      && (pats.getPattern(0).getEval() > -Float.MAX_VALUE)) ? 3 : 2;
    this.names = new String[this.cnt+n];
    for (i = 0; i < this.cnt; i++) this.names[i] = String.valueOf(i+1);
    this.names[i++] = "size";   /* create the column names */
    this.names[i++] = "support";
    if (n > 2) this.names[i] = "evaluation";
  }  /* setPatterns() */

  /*------------------------------------------------------------------*/
  /** Sort the set of item patterns.
   *  @param  field the identifier of the field to compare first
   *  @since  2014.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sort (int field)
  { if (this.pats != null) this.pats.sort(field); }

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.pats != null) ? this.pats.getCount() : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return the number of columns of the table
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return (this.pats != null) ? this.pats.getMaxSize()+2 : 0; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column.
   *  @param  i the index of the column
   *  @return the name of the column with index i
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int i)
  {                             /* --- get the name of a column */
    int n = this.pats.getMaxSize();
    if     (i < n) return String.valueOf(i+1);
    return (i == n) ? "size" : "support";
  }  /* getColumnName() */

  /*------------------------------------------------------------------*/
  /** Get the value in a table cell.
   *  @param  row the row    index of the table cell
   *  @param  col the column index of the table cell
   *  @return an object representing the contents of the table cell
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  {                             /* --- get value of table field */
    Pattern pat;                /* item pattern corresponding to row */
    double  x;                  /* buffer for add. evaluation */

    pat = this.pats.getPattern(row);
    if (col < this.cnt)         /* if item column */
      return (col < pat.getSize()) ? pat.getItemName(col) : "";
    if (col == this.cnt)        /* if size column */
      return String.valueOf(pat.getSize());
    if (col == this.cnt+1)      /* if support column */
      return (pat.getRelSupp()*100) +"/" +pat.getAbsSupp();
    x = pat.getEval();          /* if evaluation column */
    return (x > -Float.MAX_VALUE) ? String.valueOf(x) : "";
  }  /* getValueAt() */

  /*------------------------------------------------------------------*/
  /** Main function for testing some basic functionality.
   *  <p>It is tried to parse the file that is given as the first
   *  command line argument as a set of patterns.</p>
   *  @param  args the command line arguments
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    Dimension    size;          /* table size */
    Scanner      scan;          /* scanner to read from */
    PatternSet   pats;          /* created pattern set */
    PatternTable table;         /* table for the pattern set */
    JTable       tview;         /* view for the table */
    JFrame       frame;         /* surrounding frame */

    try {                       /* try to read the given file */
      if (args.length <= 0)     /* if no arguments given */
        scan = new Scanner("a b c (1)\na d e f (2)\n"
                          +"b d f (3)\nc d e (4)");
      else                      /* if a file argument is given */
        scan = new Scanner(new FileReader(args[0]));
      pats = PatternSet.parse(null, scan);
      scan.close(); }           /* parse the pattern set */
    catch (IOException e) {     /* catch and report i/o errors */
      System.err.println(e.getMessage()); return; }
    table = new PatternTable(pats);
    tview = new JTable(table);
    size  = tview.getPreferredSize();
    if (size.width  > 800) size.width  = 800;
    if (size.height > 600) size.height = 600;
    tview.setPreferredScrollableViewportSize(size);
    frame = new JFrame();     /* create the frame for display */
    frame.getContentPane().add(new JScrollPane(tview));
    frame.setLocation(48, 48);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack(); frame.setVisible(true);
  }  /* main() */

}  /* PatternTable */
