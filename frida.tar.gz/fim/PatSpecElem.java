/*----------------------------------------------------------------------
  File    : PatSpecElem.java
  Contents: pattern spectrum element for return values
  Author  : Christian Borgelt
  History : 2014.09.26 file created
----------------------------------------------------------------------*/
package fim;

/*--------------------------------------------------------------------*/
/** Class for pattern spectrum elements
 *  @author Christian Borgelt
 *  @since  2014.09.26 */
/*--------------------------------------------------------------------*/
public class PatSpecElem {

  /*------------------------------------------------------------------*/
  /* Instance Variables                                               */
  /*------------------------------------------------------------------*/
  /** size of a frequent item set */
  public int    size;
  /** support of a frequent item set */
  public int    supp;
  /** (average) occurrence frequency of a pattern signature */
  public double freq;

  /*------------------------------------------------------------------*/
  /** Create a pattern spectrum element.
   *  @param  size   size    of a frequent item set
   *  @param  supp   support of a frequent item set
   *  @param  freq   (average) occurrence frequency
   *                 of the pattern signature
   *  @since  2014.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatSpecElem (int size, int supp, double freq)
  { this.size = size; this.supp = supp; this.freq = freq; }

}  /* class PatSpecElem */

