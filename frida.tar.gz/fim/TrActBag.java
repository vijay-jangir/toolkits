/*----------------------------------------------------------------------
  File    : TrActBag.java
  Contents: transaction bag/multiset management for visualization
  Author  : Christian Borgelt
  History : 2007.06.06 file created
            2013.11.29 adapted to new class TrAct.java
            2014.10.02 transaction weight/multiplicity handling added
            2014.10.03 functions unitWeight(), pack() etc. added
            2017.06.20 functions sort(), reduce(), recodeTo() etc. added
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.FileReader;
import java.io.Reader;
import java.util.Arrays;

import util.IdMap;
import util.TableReader;
import util.TableWriter;

/*--------------------------------------------------------------------*/
/** Class for a bag/multiset of transactions.
 *  @author Christian Borgelt
 *  @since  2007.06.06 */
/*--------------------------------------------------------------------*/
public class TrActBag implements Cloneable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** the block size for the transactions array */
  private static final int BLKSIZE = 1024;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  protected IdMap   ibase;
  /** the bag/multiset of transactions */
  protected TrAct[] tracts;
  /** the current number of transactions */
  protected int     size;
  /** the maximal size of a transaction */
  protected int     zmax;
  /** the total weight of all transactions */
  protected int     wgt;
  /** the minimal weight/multiplicity of a transaction */
  protected int     wmin;
  /** the maximal weight/multiplicity of a transaction */
  protected int     wmax;
  /** the support values of the items; is computed on demand */
  protected int[]   supps;

  /*------------------------------------------------------------------*/
  /** Create an empty bag/multiset of transactions.
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrActBag ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create an empty bag/multiset of transactions.
   *  @param  ibase the underlying item base
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrActBag (IdMap ibase)
  {                             /* --- create a transaction bag */
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.tracts = null;         /* note the item base and */
    this.wgt  = this.size = 0;  /* initialize the fields */
    this.zmax = this.wmax = 0;
    this.wmin = Integer.MAX_VALUE;
  }  /* TrActBag() */

  /*------------------------------------------------------------------*/
  /** Clone this bag/multiset of transactions.
   *  <p>The clone is a deep clone, that is, the underlying item base
   *  and all contained transactions are cloned as well.</p>
   *  @return a clone of this bag/multiset of transactions
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone ()
  { return clone(true, true); }

  /*------------------------------------------------------------------*/
  /** Clone this bag/multiset of transactions.
   *  @param  clonebase   whether to clone the underlying item base
   *  @param  clonetracts whether to clone the transactions
   *  @return a clone of this bag/multiset of transactions
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone (boolean clonebase, boolean clonetracts)
  {                             /* --- clone a transaction bag */
    IdMap ibase = (clonebase) ? (IdMap)this.ibase.clone() : this.ibase;
    TrActBag tabag = new TrActBag(ibase);
    clonetracts |= clonebase;   /* create a new transaction bag */
    for (int i = 0; i < this.size; i++)
      tabag.add((!clonetracts) ? this.tracts[i]
              : (TrAct)this.tracts[i].clone(ibase));
    return tabag;               /* add a clone of each transaction */
  }  /* clone() */              /* and return the created clone */

  /*------------------------------------------------------------------*/
  /** Clear this transaction bag, that is, remove all transactions.
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void clear ()
  {                            /* --- clear a transaction bag */
    this.tracts = null;        /* delete all transactions */
    this.wgt  = this.size = 0; /* clear other fields */
    this.zmax = this.wmax = 0;
    this.wmin = Integer.MAX_VALUE;
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the underlying item base.
   *  @return the underlying item base
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final IdMap getItemBase ()
  { return this.ibase; }

  /*------------------------------------------------------------------*/
  /** Get the name of an item.
   *  @return the name of the item with identifier <code>item</code>
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getItemName (int item)
  { return (String)this.ibase.get(item); }

  /*------------------------------------------------------------------*/
  /** Get the size of the transaction bag (number of transactions).
   *  @return the size of the transaction bag
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSize ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the size of the transaction bag (number of transactions).
   *  @return the size of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getCount ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the total weight of all transactions.
   *  @return the size of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getWeight ()
  { return this.wgt; }

  /*------------------------------------------------------------------*/
  /** Get the maximal size of a transaction.
   *  @return the maximal size of a transaction
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMaxSize ()
  { return this.zmax; }

  /*------------------------------------------------------------------*/
  /** Get the minimal weight/multiplicity of a transaction.
   *  @return the maximal size of a transaction
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMinWeight ()
  { return this.wmin; }

  /*------------------------------------------------------------------*/
  /** Get the maximal weight/multiplicity of a transaction.
   *  @return the maximal size of a transaction
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMaxWeight ()
  { return this.wmax; }

  /*------------------------------------------------------------------*/
  /** Check for unit weight/multiplicity of all transactions.
   *  @return whether all transactions have unit weight/multiplicity
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean unitWeight ()
  { return (this.wmin >= 1) && (this.wmax <= 1); }

  /*------------------------------------------------------------------*/
  /** Get a transaction.
   *  @param  i the index of the transaction
   *  @return the transaction with index <code>i</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final TrAct get (int i)
  { return (i < this.size) ? this.tracts[i] : null; }

  /*------------------------------------------------------------------*/
  /** Get a transaction.
   *  @param  i the index of the transaction
   *  @return the transaction with index <code>i</code>
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final TrAct getTrAct (int i)
  { return (i < this.size) ? this.tracts[i] : null; }

  /*------------------------------------------------------------------*/
  /** Get a transaction.
   *  @param  i the index of the transaction
   *  @return the transaction with index <code>i</code>
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getTrActSize (int i)
  { return (i < this.size) ? this.tracts[i].size : 0; }

  /*------------------------------------------------------------------*/
  /** Add a transaction.
   *  @param  tract the transaction to add
   *  @return the index of the transaction in the bag/multiset
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int add (TrAct tract)
  {                             /* --- add a transaction */
    int smax = (this.tracts != null) ? this.tracts.length : 0;
    if (this.size >= smax) {    /* if the transaction array is full */
      smax += (smax > BLKSIZE) ? smax >> 1 : BLKSIZE;
      TrAct[] p = new TrAct[smax];
      if (this.tracts != null)  /* enlarge arary, copy exist. trans. */
        System.arraycopy(this.tracts, 0, p, 0, this.size);
      this.tracts = p;          /* set the (new) trans. array */
    }
    this.tracts[this.size] = tract; /* add the new transaction */
    if (tract.size > this.zmax) /* adapt the maximal size */
      this.zmax = tract.size;
    this.wgt += tract.wgt;      /* adapt the weight range */
    if (tract.wgt < this.wmin) this.wmin = tract.wgt;
    if (tract.wgt > this.wmax) this.wmax = tract.wgt;
    return this.size++;         /* return the transaction identifier */
  }  /* add() */

  /*------------------------------------------------------------------*/
  /** Add a transaction.
   *  @param  tract the transaction to add
   *  @return the index of the transaction in the bag/multiset
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addTrAct (TrAct tract)
  { return this.add(tract); }

  /*------------------------------------------------------------------*/
  /** Add a transaction bag.
   *  @param  tabag the transaction bag to add
   *  @param  clone whether to clone the transactions
   *          of the given transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void addTrActBag (TrActBag tabag, boolean clone)
  {                             /* --- add a transaction bag */
    if (clone) {                /* if to clone the transaction */
      for (int i = 0; i < tabag.size; i++)
        this.add((TrAct)tabag.tracts[i].clone(this.ibase)); }
    else {                      /* if to simply transfer the trans. */
      for (int i = 0; i < tabag.size; i++)
        this.add(       tabag.tracts[i]);
    }                           /* add all transactions */
  }  /* addTrActBag() */

  /*------------------------------------------------------------------*/
  /** Add a transaction bag
   *  (the transactions are transferred, not cloned).
   *  @param  tabag the transaction bag to add
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void addTrActBag (TrActBag tabag)
  { this.addTrActBag(tabag, false); }

  /*------------------------------------------------------------------*/
  /** Sort the transactions lexicographically by item identifiers.
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort()
  { Arrays.sort(this.tracts, 0, this.size); }

  /*------------------------------------------------------------------*/
  /** Reduce the transactions, i.e., combine equal transactions;
   *  optionally remove infrequent items prior to combination.
   *  @param  smin the minimum support of items to keep
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int reduce (int smin)
  {                             /* --- reduce the transactions */
    if (smin > 0) {             /* if to filter items by support */
      getItemSupps();           /* get item support values */
      boolean[] irem = new boolean[this.ibase.getSize()];
      boolean   iany = false;   /* flag array for items to remove */
      for (int i = this.ibase.getSize(); --i >= 0; )
        iany |= irem[i] = (this.supps[i] < smin);
      if (iany) {               /* if to remove any item(s) */
        this.zmax = 0;          /* clear maximum transaction size */
        int[] map = this.ibase.remove(irem);
        for (int i = 0; i < this.size; i++) {
          this.tracts[i].reduce(map);  /* remove infrequent items */
          if (this.tracts[i].size > this.zmax)
            this.zmax = this.tracts[i].size;
        }                       /* update maximum transaction size */
      }
    }  /* if (smin > 0) .. */

    if (this.size < 2)          /* if at most one transaction, */
      return this.size;         /* there is nothing to reduce */
    this.sort();                /* sort the transactions */
    int n = 0;                  /* index of last kept transaction */
    for (int i = 0; ++i < this.size; ) {
      if (this.tracts[i].compareTo(this.tracts[n]) != 0)
        this.tracts[++n] = this.tracts[i];
      else this.tracts[n].wgt += this.tracts[i].wgt;
    }                           /* (keep only 1st of identical trans. */
    n += 1;                     /* get new number of transactions */
    this.wmin = Integer.MAX_VALUE;
    this.wmax = 0;              /* reinit. transaction weight range */
    for (int i = n; --i >= 0; ){/* traverse the transactions */
      if (this.tracts[i].wgt < this.wmin)
        this.wmin = this.tracts[i].wgt;
      if (this.tracts[i].wgt > this.wmax)
        this.wmax = this.tracts[i].wgt;
    }                           /* update the weight range */
    return this.size = n;       /* set reduced number of transactions */
  }  /* reduce() */

  /*------------------------------------------------------------------*/
  /** Reduce the transactions, i.e., combine equal transactions.
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int reduce ()
  { return this.reduce(0); }

  /*------------------------------------------------------------------*/
  /** Get the support value of an item (given by its identifier).
   *  @param  item the item for which to get the support value
   *  @return the support value of the item with identifier
   *          <code>item</code>
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItemSupp (int item)
  { return this.getItemSupps()[item]; }

  /*------------------------------------------------------------------*/
  /** Get the support value of an item (given by its identifier).
   *  @param  item the item for which to get the support value
   *  @return the support value of the item with identifier
   *          <code>item</code>
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItemSuppById (int item)
  { return this.getItemSupps()[item]; }

  /*------------------------------------------------------------------*/
  /** Get the support value of an item (given by its name).
   *  @param  item the name of the item for which to get
   *               the support value
   *  @return the support value of the item with name <code>item</code>
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItemSuppByName (String item)
  { return this.getItemSupps()[this.ibase.get(item)]; }

  /*------------------------------------------------------------------*/
  /** Get the support value of an item (given by its object).
   *  @param  item the object of the item for which to get
   *               the support value
   *  @return the support value of the item with object
   *          <code>item</code>
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItemSuppByObject (Object item)
  { return this.getItemSupps()[this.ibase.get(item)]; }

  /*------------------------------------------------------------------*/
  /** Get the item support values as an array
   *  (to be indexed by item identifiers).
   *  @return an array with the support values of the items
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getItemSupps ()
  {                             /* --- get item support values */
    if (this.supps == null) {   /* if item supports not computed yet */
      int n = this.ibase.getSize();
      this.supps = new int[n];  /* create item support and last */
      int[] last = new int[n];  /* transaction identifier array */
      for (int i = 0; i < n; i++)
        last[i] = -1;           /* clear the last transaction ids */
      for (int i = 0; i < this.size; i++) {
        for (int j = 0; j < this.tracts[i].size; j++) {
          int item = this.tracts[i].getItem(j);
          if (last[item] < i) { /* if trans. not yet cons. for item */
            last[item] = i;     /* set last transaction identifier */
            this.supps[item] += this.tracts[i].wgt;
          }                     /* increment the item support */
        }                       /* (count first item occurrences) */
      }
    }
    return this.supps;          /* return the item support values */
  }  /* getItemSupps() */

  /*------------------------------------------------------------------*/
  /** Get the cover (list of transaction identifiers)
   *  of an item pattern.
   *  @param  pat the item pattern for which to get the cover
   *  @return an array of indices of transactions
   *          in which the item pattern is contained
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getCoverOf (Pattern pat)
  {                             /* --- get the cover of an item pat. */
    int[] c = new int[this.size];
    int n = 0;                  /* create a temporary cover array */
    for (int i = 0; i < this.size; i++)
      if (this.tracts[i].contains(pat))
        c[n++] = i;             /* collect transaction indices */
    int[] cover = new int[n];   /* shrink array to proper size */
    System.arraycopy(c, 0, cover, 0, n);
    return cover;               /* return the created cover array */
  }  /* getCoverOf() */

  /*------------------------------------------------------------------*/
  /** Get the support of the given item pattern in this transaction bag.
   *  @param  pat the item pattern for which to get the support
   *              in this transaction bag
   *  @return the support of the given item pattern
   *          in this transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupport (Pattern pat)
  { return this.getSupport(pat.items, pat.size); }

  /*------------------------------------------------------------------*/
  /** Get the support of the given item pattern in this transaction bag.
   *  @param  items the array of items to of the pattern for which
   *                to get the support in this transaction bag
   *                (may be oversized)
   *  @param  cnt   the number of items in the given array to consider;
   *                if negative, the length of the item array
   *                <code>items</code>is used
   *  @return the support of the given item pattern
   *          in this transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupport(int[] items, int cnt)
  {                             /* --- get an item pattern support */
    if (cnt < 0) cnt = items.length;
    int supp = 0;               /* support of the item pattern */
    for (int i = 0; i < this.size; i++)
      if (this.tracts[i].contains(items, cnt))
        supp += this.tracts[i].wgt;/* sum the transaction weights */
    return supp;                /* and return the counted support */
  }  /* getSupport() */

  /*------------------------------------------------------------------*/
  /** Get the support of the given item pattern in this transaction bag.
   *  @param  items the array of items to of the pattern for which
   *                to get the support in this transaction bag
   *  @return the support of the given item pattern
   *          in this transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupport(int[] items)
  { return this.getSupport(items, items.length); }

  /*------------------------------------------------------------------*/
  /** Get the support values of the given pattern set
   *  in this transaction bag.
   *  @param  patset the item pattern set which to get the support
   *                 values in this transaction bag
   *  @param  supps  the array into which to store the support values
   *                 if <code>null</code>, a new array is created,
   *                 otherwise it must have at least size
   *                 <code>patset.getSize()</code>
   *  @return an array of support values, with as many entries as there
   *          are patterns in the given pattern set, containing the
   *          support values of the item patterns
   *          in this transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getSupport (PatternSet patset, int[] supps)
  {                             /* --- get item pattern set support */
    if (supps == null)          /* create support array if necessary */
      supps = new int[patset.size];
    for (int i = 0; i < patset.size; i++) {
      Pattern pat = patset.pats[i];
      supps[i] = this.getSupport(pat.items, pat.size);
    }                           /* get each pattern for trans. bag */
    return supps;               /* return the pattern support values */
  }  /* getSupport() */

  /*------------------------------------------------------------------*/
  /** Get the support values of the given pattern set
   *  in this transaction bag.
   *  @param  patset the item pattern set which to get the support
   *                 values in this transaction bag
   *  @return an array of support values, with as many entries as there
   *          are patterns in the given pattern set, containing the
   *          support values of the item patterns
   *          in this transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getSupport (PatternSet patset)
  { return this.getSupport(patset, null); }

  /*------------------------------------------------------------------*/
  /** Get the given pattern for this transaction bag.
   *  @param  pat the item pattern which to get for this transaction bag
   *  @return a new pattern with the same items, but with the item base
   *          and the support values of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Pattern getPattern (Pattern pat)
  { return this.getPattern(pat.items, pat.size); }

  /*------------------------------------------------------------------*/
  /** Get the given pattern for this transaction bag.
   *  @param  items the array of items to of the pattern to get
   *                (may be oversized)
   *  @param  cnt   the number of items in the given array to consider;
   *                if negative, the length of the item array
   *                <code>items</code>is used
   *  @return a new pattern with the same items, but with the item base
   *          and the support values of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Pattern getPattern (int[] items, int cnt)
  {                             /* --- get an item pattern */
    if (cnt < 0) cnt = items.length;
    return new Pattern(this.ibase, items, cnt,
                       this.getSupport(items, cnt), this.wgt);
  }  /* getPattern() */

  /*------------------------------------------------------------------*/
  /** Get the given pattern for this transaction bag.
   *  @param  items the array of items to of the pattern to get
   *                (may be oversized)
   *  @return a new pattern with the same items, but with the item base
   *          and the support values of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Pattern getPattern (int[] items)
  { return this.getPattern(items, items.length); }

  /*------------------------------------------------------------------*/
  /** Get the given pattern set for this transaction bag.
   *  @param  patset the item pattern set which to get
   *                 for this transaction bag
   *  @return a new pattern set with the same patterns, but with the
   *          item base and the support values of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet getPatternSet (PatternSet patset)
  {                             /* --- get an item pattern set */
    PatternSet ps = new PatternSet(this.ibase);
    for (int i = 0; i < patset.size; i++) {
      Pattern pat = patset.getPattern(i);
      ps.add(this.getPattern(pat.items, pat.size));
    }                           /* get each pattern for trans. bag */
    return ps;                  /* return the created pattern set */
  }  /* getPatternSet() */

  /*------------------------------------------------------------------*/
  /** Get the given association rule for this transaction bag.
   *  @param  rule the association rule which to get
   *               for this transaction bag
   *  @return a new association rule with the same items, but with the
   *          item base and the support values of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final ARule GetRule (ARule rule)
  {                             /* --- get an association rule */
    this.getItemSupps();        /* get the item support values */
    int s_body = 0;             /* support of the rule body */
    int s_pat  = 0;             /* support of the rule pattern */
    for (int i = 0; i < this.size; i++) {
      int offset = this.tracts[i].getSuffix(rule.body, rule.size);
      if (offset < 0) continue; /* check whether rule body occurs */
      s_body += this.tracts[i].wgt;
      if (this.tracts[i].indexOf(rule.head, offset) >= 0)
        s_pat += this.tracts[i].wgt;
    }                           /* return a new association rule */
    return new ARule(this.ibase, rule.body, rule.size, rule.head,
                     s_body, s_pat,
                     (rule.head < 0) ? 0 : this.supps[rule.head],
                     this.wgt, rule.eval);
  }  /* getRule() */

  /*------------------------------------------------------------------*/
  /** Get the given association rule set for this transaction bag.
   *  @param  ruleset the association rule set which to get
   *                  for this transaction bag
   *  @return a new association rule set with the same rules,
   *          but with the item base and the support values
   *          of the transaction bag
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final ARuleSet getRuleSet (ARuleSet ruleset)
  {                             /* --- get an association rule set */
    ARuleSet rs = new ARuleSet(this.ibase);
    for (int i = 0; i < ruleset.size; i++)
      rs.addRule(ruleset.getRule(i));
    return rs;                  /* return the created rule set */
  }  /* getRuleSet() */

  /*------------------------------------------------------------------*/
  /** Recode a transaction bag to another item base,
   *  replacing the item base.
   *  @param  ibase the item base to recode the transaction bag to
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void recodeTo (IdMap ibase)
  {                             /* --- recode a transaction bag */
    int[] map = this.ibase.getMapTo(ibase);
    for (int i = 0; i < this.size; i++)
      this.tracts[i].recodeTo(ibase, map);
  }  /* recodeTo() */

  /*------------------------------------------------------------------*/
  /** Pack the transactions, i.e., optimize memory usage.
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void pack ()
  {                             /* --- pack the transactions */
    for (int i = 0; i < this.size; i++)
      this.tracts[i].pack();    /* traverse and pack the transactions */
    if ((this.tracts == null) || (this.tracts.length <= this.size))
      return;                   /* shrink the transaction array */
    TrAct[] p = new TrAct[this.size];
    System.arraycopy(this.tracts, 0, p, 0, this.size);
    this.tracts = p;            /* set the shrunk transaction array */
  }  /* pack() */

  /*------------------------------------------------------------------*/
  /** Get all transactions as an array of integer arrays.
   *  @return all transactions as an array of integer arrays.
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[][] getTrActs ()
  {                             /* --- get all transactions */
    this.pack();                /* ensure proper item array lengths */
    int[][] t = new int[this.size][];
    for (int i = 0; i < this.size; i++)
      t[i] = this.tracts[i].items;
    return t;                   /* collect the item arrays and */
  }  /* getTrActs() */          /* return the resulting array */

  /*------------------------------------------------------------------*/
  /** Get all transaction weights as an array of integers.
   *  @return all transaction weights as an array of integers
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getWeights ()
  {                             /* --- get all transaction weights */
    int[] w = new int[this.size];
    for (int i = 0; i < this.size; i++)
      w[i] = this.tracts[i].wgt;/* collect the transaction weights */
    return w;                   /* and return the resulting array */
  }  /* getWeights() */

  /*------------------------------------------------------------------*/
  /** Write a transaction bag/multiset.
   *  @param  writer the table writer to write to
   *  @throws IOException if a write error occurs
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (TableWriter writer) throws IOException
  {                             /* --- write a transaction bag */
    boolean wgt = (this.wmin < 1) || (this.wmax > 1);
    for (int i = 0; i < this.size; i++)
      this.tracts[i].write(writer, wgt);
  }  /* write() */              /* traverse and write transactions */

  /*------------------------------------------------------------------*/
  /** Write a transaction bag/multiset.
   *  @param  writer the table writer to write to
   *  @param  wgt    whether to write transaction weights/multiplicities
   *  @throws IOException if a write error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (TableWriter writer, boolean wgt)
    throws IOException
  {                             /* --- write a transaction bag */
    // wgt = wgt || (this.wmin < 1) || (this.wmax > 1);
    for (int i = 0; i < this.size; i++)
      this.tracts[i].write(writer, wgt);
  }  /* write() */              /* traverse and write transactions */

  /*------------------------------------------------------------------*/
  /** Parse a bag/multiset of transactions.
   *  @param  ibase  the underlying item base
   *  @param  reader the table reader to read from
   *  @param  wgt    whether to read transaction weights/multiplicities
   *  @return the parsed bag/multiset of transactions
   *  @throws IOException if a read error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrActBag parse (IdMap ibase, TableReader reader,
                                boolean wgt)
    throws IOException
  {                             /* --- parse a transaction bag */
    TrActBag tabag = new TrActBag(ibase);
    while (true) {              /* transaction read loop */
      TrAct t = TrAct.parse(tabag.ibase, reader, wgt);
      if (t == null) break;     /* read the next transaction */
      tabag.add(t);             /* and add it to the bag */
    }
    return tabag;               /* return the created bag */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse a bag/multiset of transactions.
   *  @param  ibase  the underlying item base
   *  @param  reader the table reader to read from
   *  @return the parsed bag/multiset of transactions
   *  @throws IOException if a read error occurs
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrActBag parse (IdMap ibase, TableReader reader)
    throws IOException
  { return TrActBag.parse(ibase, reader, false); }

  /*------------------------------------------------------------------*/
  /** Parse a bag/multiset of transactions.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @param  wgt    whether to read transaction weights/multiplicities
   *  @return the parsed bag/multiset of transactions
   *  @throws IOException if a read error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrActBag parse (IdMap ibase, Reader reader, boolean wgt)
    throws IOException
  { return TrActBag.parse(ibase, new TableReader(reader), wgt); }

  /*------------------------------------------------------------------*/
  /** Parse a bag/multiset of transactions.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @return the parsed bag/multiset of transactions
   *  @throws IOException if a read error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrActBag parse (IdMap ibase, Reader reader)
    throws IOException
  { return TrActBag.parse(ibase, new TableReader(reader), false); }

  /*------------------------------------------------------------------*/
  /** Main function for testing some basic functionality.
   *  <p>It is tried to parse the file that is given as the first
   *  command line argument as a bag/multiset of transactions.</p>
   *  @param  args the command line arguments
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    TableReader reader;         /* table reader to read from */
    TableWriter writer;         /* table writer to write to */
    TrActBag    tracts;         /* created transaction bag/multiset */

    try {                       /* try to read the given file */
      if (args.length <= 0)     /* if no arguments given */
        reader = new TableReader("a b c\na d e f\nb d f\nc d e");
      else                      /* if a file argument is given */
        reader = new TableReader(new FileReader(args[0]));
      tracts = TrActBag.parse(null, reader);
      reader.close();           /* parse the transaction bag/multiset */
      writer = new TableWriter(System.out);
      tracts.write(writer);     /* write the transaction bag/multiset */
      writer.close(); }
    catch (IOException e) {     /* catch and report i/o errors */
      System.err.println(e.getMessage()); return; }
  }  /* main() */

}  /* class TrActBag */
