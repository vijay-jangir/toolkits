/*----------------------------------------------------------------------
  File    : JNIFIM.java
  Contents: Java interface to frequent item set mining in C
  Author  : Christian Borgelt
  History : 2014.09.26 file created
            2014.10.03 description of return values added
            2014.10.07 descriptions of functions improved
            2014.10.23 wrapper functions with Java objects added
            2014.10.30 function name differences for rules removed
            2015.02.27 item appearances param. added to rule functions
            2015.03.05 handling of user abort request improved
            2016.07.01 bug in report strings fixed ("s" instead of "a")
            2018.03.21 Jaccard Item set Mining (JIM) added
            2018.03.26 moved wrapper functions to a separate file
----------------------------------------------------------------------*/
package fim;

/*--------------------------------------------------------------------*/
/** Class for Java interface to frequent item set mining in C
 *  @author Christian Borgelt
 *  @since  2014.09.26 */
/*--------------------------------------------------------------------*/
public class JNIFIM {

  /*------------------------------------------------------------------*/
  /* Constants                                                        */
  /*------------------------------------------------------------------*/
  public static final String VERSION    = "1.17 (2018.04.01)";

  /* --- target types --- */
  /** target type: all frequent item sets */
  public static final int SETS          = 0x0000;
  /** target type: all frequent item sets */
  public static final int ALL           = 0x0000;
  /** target type: all frequent item sets */
  public static final int FREQUENT      = 0x0000;
  /** target type: closed (frequent) item sets */
  public static final int CLOSED        = 0x0001;
  /** target type: maximal (frequent) item sets */
  public static final int MAXIMAL       = 0x0002;
  /** target type: generator (frequent) item sets */
  public static final int GENERATORS    = 0x0004;
  /** target type: generator (frequent) item sets */
  public static final int GENERAS       = 0x0004;
  /** target type: association rules */
  public static final int RULES         = 0x0008;

  /* --- item appearance indicators --- */
  /** item may not appear anywhere in a rule */
  public static final int IGNORE        = 0x0000;
  /** item may not appear anywhere in a rule */
  public static final int NEITHER       = 0x0000;
  /** item may appear only in a rule body/antecedent */
  public static final int INPUT         = 0x0001;
  /** item may appear only in a rule body/antecedent */
  public static final int BODY          = 0x0001;
  /** item may appear only in a rule body/antecedent */
  public static final int ANTE          = 0x0001;
  /** item may appear only in a rule body/antecedent */
  public static final int ANTECEDENT    = 0x0001;
  /** item may appear only in a rule head/consequent */
  public static final int OUTPUT        = 0x0002;
  /** item may appear only in a rule head/consequent */
  public static final int HEAD          = 0x0002;
  /** item may appear only in a rule head/consequent */
  public static final int CONS          = 0x0002;
  /** item may appear only in a rule head/consequent */
  public static final int CONSEQUENT    = 0x0002;
  /** item may appear anywhere in a rule */
  public static final int BOTH          = BODY|HEAD;
  /** item may appear anywhere in a rule */
  public static final int INOUT         = BODY|HEAD;
  /** item may appear anywhere in a rule */
  public static final int CANDA         = BODY|HEAD;

  /* --- evaluation measures --- */
  /** evaluation measure/aggregation mode: none */
  public static final int NONE          =  0;
  /** evaluation measure: rule support
   *  (larger is better) */
  public static final int SUPPORT       =  1;
  /** evaluation measure: rule support
   *  (larger is better) */
  public static final int SUPP          =  1;
  /** evaluation measure: rule confidence
   *  (larger is better) */
  public static final int CONFIDENCE    =  2;
  /** evaluation measure: rule confidence
   *  (larger is better) */
  public static final int CONF          =  2;
  /** evaluation measure: absolute confidence difference to prior
   *  (larger is better) */
  public static final int CONFDIFF      =  3;
  /** evaluation measure: lift value (confidence divided by prior)
   *  (larger is better) */
  public static final int LIFT          =  4;
  /** evaluation measure: difference of lift value to 1
   *  (larger is better) */
  public static final int LIFTDIFF      =  5;
  /** evaluation measure: difference of lift quotient to 1
   *  (larger is better) */
  public static final int LIFTQUOT      =  6;
  /** evaluation measure: conviction
   *  (larger is better) */
  public static final int CONVICTION    =  7;
  /** evaluation measure: conviction
   *  (larger is better) */
  public static final int CVCT          =  7;
  /** evaluation measure: difference of conviction to 1
   *  (larger is better) */
  public static final int CVCTDIFF      =  8;
  /** evaluation measure: difference of conviction quotient to 1
   *  (larger is better) */
  public static final int CVCTQUOT      =  9;
  /** evaluation measure: conditional probability ratio
   *  (larger is better) */
  public static final int CPROB         = 10;
  /** evaluation measure: conditional probability ratio
   *  (larger is better) */
  public static final int CONDPROB      = 10;
  /** evaluation measure: importance
   *  (larger is better) */
  public static final int IMPORTANCE    = 11;
  /** evaluation measure: importance
   *  (larger is better) */
  public static final int IMPORT        = 11;
  /** evaluation measure: certainty factor
   *  (larger is better) */
  public static final int CERTAINTY     = 12;
  /** evaluation measure: certainty factor
   *  (larger is better) */
  public static final int CERT          = 12;
  /** evaluation measure: normalized chi^2 measure
   *  (larger is better) */
  public static final int CHI2          = 13;
  /** evaluation measure: p-value from chi^2 measure
   *  (smaller is better) */
  public static final int CHI2PVAL      = 14;
  /** evaluation measure: normalized chi^2 measure (Yates corrected)
   *  (larger is better) */
  public static final int YATES         = 15;
  /** evaluation measure: p-value from chi^2 measure (Yates corrected)
   *  (smaller is better) */
  public static final int YATESPVAL     = 16;
  /** evaluation measure: information difference to prior
   *  (larger is better) */
  public static final int INFO          = 17;
  /** evaluation measure: p-value from information difference
   *  (smaller is better) */
  public static final int INFOPVAL      = 18;
  /** evaluation measure: Fisher's exact test (table probability)
   *  (smaller is better) */
  public static final int FETPROB       = 19;
  /** evaluation measure: Fisher's exact test (chi^2 measure)
   *  (smaller is better) */
  public static final int FETCHI2       = 20;
  /** evaluation measure: Fisher's exact test (information gain)
   *  (smaller is better) */
  public static final int FETINFO       = 21;
  /** evaluation measure: Fisher's exact test (support)
   *  (smaller is better) */
  public static final int FETSUPP       = 22;
  /** evaluation measure: binary logarithm of support quotient
   *  (larger is better) */
  public static final int LDRATIO       = 23;
  /** evaluation measure: item set size times cover similarity
   *  (larger is better) (only for JIM algorithm) */
  public static final int SIZESIM       = 24;

  /* --- aggregation modes --- */
  /** aggregation mode: minimum of individual measure values */
  public static final int MIN           =  1;
  /** aggregation mode: minimum of individual measure values */
  public static final int MINIMUM       =  1;
  /** aggregation mode: maximum of individual measure values */
  public static final int MAX           =  2;
  /** aggregation mode: maximum of individual measure values */
  public static final int MAXIMUM       =  2;
  /** aggregation mode: average of individual measure values */
  public static final int AVG           =  3;
  /** aggregation mode: average of individual measure values */
  public static final int AVERAGE       =  3;

  /* --- algorithm variants --- */
  /** algorithm variant: automatic choice (always applicable) */
  public static final int AUTO          =  0;

  /** Apriori variant: basic algorithm */
  public static final int APRI_BASIC    =  1;

  /** Eclat variant: transaction id lists intersection (basic) */
  public static final int ECLAT_BASIC   =  1;
  /** Eclat variant: transaction id lists intersection (improved) */
  public static final int ECLAT_LISTS   =  2;
  /** Eclat variant: transaction id lists intersection (improved) */
  public static final int ECLAT_TIDS    =  2;
  /** Eclat variant: transaction id lists as bit vectors */
  public static final int ECLAT_BITS    =  3;
  /** Eclat variant: item occurrence table (standard) */
  public static final int ECLAT_TABLE   =  4;
  /** Eclat variant: item occurrence table (simplified) */
  public static final int ECLAT_SIMPLE  =  5;
  /** Eclat variant: transaction id range lists intersection */
  public static final int ECLAT_RANGES  =  6;
  /** Eclat variant: occurrence deliver from transaction lists */
  public static final int ECLAT_OCCDLV  =  7;
  /** Eclat variant: occurrence deliver from transaction lists */
  public static final int ECLAT_LCM     =  7;
  /** Eclat variant: transaction id difference sets (diffsets) */
  public static final int ECLAT_DIFFS   =  8;

  /** FP-growth variant: simple tree nodes (link and parent) */
  public static final int FPG_SIMPLE    =  1;
  /** FP-growth variant: complex tree nodes (children and sibling) */
  public static final int FPG_COMPLEX   =  2;
  /** FP-growth variant: top-down processing on a single prefix tree */
  public static final int FPG_SINGLE    =  3;
  /** FP-growth variant: top-down processing of the prefix trees */
  public static final int FPG_TOPDOWN   =  4;

  /** SaM variant: basic split and merge algorithm */
  public static final int SAM_BASIC     =  1;
  /** SaM variant: split and merge with binary search */
  public static final int SAM_BSEARCH   =  2;
  /** SaM variant: split and merge with double source buffering */
  public static final int SAM_DOUBLE    =  3;
  /** SaM variant: split and merge with transaction prefix tree */
  public static final int SAM_TREE      =  4;

  /** RElim variant: basic recursive elimination algorithm */
  public static final int RELIM_BASIC   =  1;

  /** JIM variant: basic algorithm */
  public static final int JIM_BASIC     =  1;

  /** Carpenter variant: item occurrence counter table */
  public static final int CARP_TABLE    =  1;
  /** Carpenter variant: transaction identifier lists */
  public static final int CARP_LISTS    =  2;
  /** Carpenter variant: transaction identifier lists */
  public static final int CARP_TIDLIST  =  2;
  /** Carpenter variant: transaction identifier lists */
  public static final int CARP_TIDLISTS =  2;

  /** IsTa variant: standard prefix tree */
  public static final int ISTA_PREFIX   =  1;
  /** IsTa variant: patricia tree (compact prefix tree) */
  public static final int ISTA_PATRICIA =  2;

  /* --- mode flags --- */
  /** processing mode: do not use a 16-items machine */
  public static final int NOFIM16       = 0x0001; /* l */
  /** processing mode: do not use perfect extension pruning */
  public static final int NOPERFECT     = 0x0002; /* x */
  /** processing mode: do not sort items w.r.t. conditional support */
  public static final int NOSORT        = 0x0004; /* i */
  /** processing mode: do not use head union tail (hut) pruning
   *  (for maximal item sets) */
  public static final int NOHUT         = 0x0008; /* u */
  /** processing mode: check extensions for closed/maximal item sets
   *  with a horizontal scheme (default: use a repository) */
  public static final int HORZ          = 0x0010; /* y */
  /** processing mode: check extensions for closed/maximal item sets
   *  with a vertical scheme (default: use a repository) */
  public static final int VERT          = 0x0020; /* Y */
  /** processing mode: invalidate evaluation below expected support */
  public static final int INVBXS        = 0x0040; /* z */
  /** processing mode: use original support definition for rules
   *  (body &amp; head instead of only body) */
  public static final int ORIGSUPP      = 0x0080; /* o */

  /** processing mode: do not organize transactions as a prefix tree
   *  (for Apriori algorithm) */
  public static final int NOTREE        = 0x0100; /* t/T */
  /** processing mode: a-posteriori pruning of infrequent item sets
   *  (for Apriori algorithm) */
  public static final int POSTPRUNE     = 0x0200; /* y */
  /** processing mode: filter maximal item sets with repository
   *  (for Carpenter algorithm) */
  public static final int REPOFILT      = 0x1000; /* z */
  /** processing mode: add all (closed) item sets to repository
   *  (for Carpenter algorithm) */
  public static final int ADDALL        = 0x2000; /* y */
  /** processing mode: do not collate equal transactions
   *  (for Carpenter algorithm) */
  public static final int NOCOLLATE     = 0x4000; /* p */
  /** processing mode: do not prune the prefix/patricia tree
   *  (for IsTa algorithm) */
  public static final int NOPRUNE       = 0x8000; /* p */

  /* --- cover similarity measures for JIM --- */
  /* n = total number of transactions                          */
  /* s = number of transactions with all items in the item set */
  /* r = number of transactions with at least one item in set  */
  /* q = number of transactions with some (but not all) items  */
  /* z = number of transactions with no items in the set       */
  /* x = \sqrt{sz} (geometric mean of s and z)                 */
  /** JIM: no cover similarity */
  public static final int JIM_NONE            =  0;
  /** JIM: Russel-Rao S_R = s/n */
  public static final int JIM_RUSSEL_RAO      =  1;
  /** JIM: Kulcynski S_K = s/q */
  public static final int JIM_KULCYNSKI       =  2;
  /** JIM: Jaccard/Tanimoto S_J = s/r */
  public static final int JIM_JACCARD         =  3;
  /** JIM: Jaccard/Tanimoto S_J = s/r */
  public static final int JIM_TANIMOTO        =  3;
  /** JIM: Dice S_D = 2s/(r+s) */
  public static final int JIM_DICE            =  4;
  /** JIM: Sorensen S_D = 2s/(r+s) */
  public static final int JIM_SORENSEN        =  4;
  /** JIM: Czekanowski S_D = 2s/(r+s) */
  public static final int JIM_CZEKANOWSKI     =  4;
  /** JIM: Sokal--Sneath 1 S_S = s/(r+q) */
  public static final int JIM_SOKAL_SNEATH_1  =  5;
  /** JIM: Sokal--Michener S_M = (s+z)/n */
  public static final int JIM_SOKAL_MICHENER  =  6;
  /** JIM: Hamming S_M = (s+z)/n */
  public static final int JIM_HAMMING         =  6;
  /** JIM: Faith S_F = (s+z/2)/n */
  public static final int JIM_FAITH           =  7;
  /** JIM: Rogers--Tanimoto S_T = (s+z)/(n+q) */
  public static final int JIM_ROGERS_TANIMOTO =  8;
  /** JIM: Sokal--Sneath 2 S_N = 2(s+z)/(n+s+z) */
  public static final int JIM_SOKAL_SNEATH_2  =  9;
  /** JIM: Gower--Legendre S_N = 2(s+z)/(n+s+z) */
  public static final int JIM_GOWER_LEGENDRE  =  9;
  /** JIM: Sokal--Sneath 3 S_O = (s+z)/q */
  public static final int JIM_SOKAL_SNEATH_3  = 10;
  /** JIM: Baroni--Buser S_B = (x+s)/(x+r) */
  public static final int JIM_BARONI_BUSER    = 11;
  /** JIM: generic measure S = (c_0s +c_1z +c_2n +c_3x)
                             / (c_4s +c_5z +c_6n +c_7x) */
  public static final int JIM_GENERIC         = 12;

  /* --- surrogate data generation methods --- */
  /** surrogate method: identity (keep original data) */
  public static final int IDENT         = 0;
  /** surrogate method: random transaction generation */
  public static final int RANDOM        = 1;
  /** surrogate method: permutation by pair swaps */
  public static final int SWAP          = 2;
  /** surrogate method: shuffle table-derived data (columns) */
  public static final int SHUFFLE       = 3;

  /* --- pattern spectrum report formats --- */
  /** pattern spectrum report format:
   *  three columns size (integer), support (integer) and
   *  (average) occurrence frequency (double) */
  public static final String COLUMNS    = "#";
  /** pattern spectrum report format:
   *  objects of type <code>PatSpecElem</code> */
  public static final String OBJECTS    = "=";

  /*------------------------------------------------------------------*/
  /** Java interface to frequent item set mining in C
   *  (very simplified interface).
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code> or <code>GENERATORS</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] fim (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to frequent item set mining in C
   *  (less simplified interface).
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code> or <code>GENERATORS</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "e": value of item set evaluation measure
   *                      (double)<br>
   *                 "E": value of item set evaluation measure
   *                      as a percentage (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                  better, upper bound for measures for which
   *                  smaller is better)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] xfim (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int eval, int agg, double thresh, int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to association rule induction in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  supp   minimum support of an association rule<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per association rule
   *  @param  zmax   maximum number of items per association rule
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "b": absolute body set support
   *                      (number of transactions, integer)<br>
   *                 "x": relative body set support as a fraction
   *                      (double)<br>
   *                 "X": relative body set support as a percentage
   *                      (double)<br>
   *                 "h": absolute head item support
   *                      (number of transactions, integer)<br>
   *                 "y": relative head item support as a fraction
   *                      (double)<br>
   *                 "Y": relative head item support as a percentage
   *                      (double)<br>
   *                 "c": rule confidence as a fraction (double)<br>
   *                 "C": rule confidence as a percentage (double)<br>
   *                 "l": lift value of a rule (confidence/prior)
   *                      (double)<br>
   *                 "L": lift value of a rule as a percentage
   *                      (double)<br>
   *                 "e": value of rule evaluation measure (double)<br>
   *                 "E": value of rule evaluation measure (double)
   *                      as a percentage<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for association rule evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code> or <code>ORIGSUPP</code>)
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return if report != "#" and report != "=": an array with k+2
   *          elements, the first of which is an integer array that
   *          contains the head (consequent) items, while the second
   *          contains the body (antecedent) item sets as integer
   *          arrays; the following k array elements contain arrays
   *          that correspond to the values selected with the characters
   *          in report (each value in these arrays corresponds to the
   *          association rule at the same array index in the first
   *          and the second array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] arules (int[][] tracts, int[] wgts,
    double supp, double conf, int zmin, int zmax, String report,
    int eval, double thresh, int mode, int[][] appear);

  /*------------------------------------------------------------------*/
  /** Java interface to Apriori algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code>, <code>GENERATORS</code>
   *                  or <code>RULES</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "b": absolute body set support
   *                      (number of transactions, integer)<br>
   *                 "x": relative body set support as a fraction
   *                      (double)<br>
   *                 "X": relative body set support as a percentage
   *                      (double)<br>
   *                 "h": absolute head item support
   *                      (number of transactions, integer)<br>
   *                 "y": relative head item support as a fraction
   *                      (double)<br>
   *                 "Y": relative head item support as a percentage
   *                      (double)<br>
   *                 "c": rule confidence as a fraction (double)<br>
   *                 "C": rule confidence as a percentage (double)<br>
   *                 "l": lift value of a rule (confidence/prior)
   *                      (double)<br>
   *                 "L": lift value of a rule as a percentage
   *                      (double)<br>
   *                 "e": value of rule evaluation measure (double)<br>
   *                 "E": value of rule evaluation measure (double)
   *                      as a percentage<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code> or <code>APRI_BASIC</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOPERFECT</code>,
   *                  <code>NOTREE</code>, <code>POSTPRUNE</code>,
   *                  <code>INVBXS</code>, <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter is used only if
   *                 target = <code>RULES</code>.
   *                 It may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return if report != "#" and report != "=":<br>
   *          if target = <code>RULES</code>: an array with k+2
   *          elements, the first of which is an integer array that
   *          contains the head (consequent) items, while the second
   *          contains the body (antecedent) item sets as integer
   *          arrays; the following k array elements contain arrays
   *          that correspond to the values selected with the characters
   *          in report (each value in these arrays corresponds to the
   *          association rule at the same array index in the first
   *          and the second array).<br>
   *          if target != <code>RULES</code>: an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] apriori (int[][] tracts, int[] wgts,
    int target, double supp, double conf, int zmin, int zmax,
    String report, int eval, int agg, double thresh, int prune,
    int algo, int mode, int[] border, int[][] appear);

  /*------------------------------------------------------------------*/
  /** Java interface to Eclat algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code>, <code>GENERATORS</code>
   *                  or <code>RULES</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "b": absolute body set support
   *                      (number of transactions, integer)<br>
   *                 "x": relative body set support as a fraction
   *                      (double)<br>
   *                 "X": relative body set support as a percentage
   *                      (double)<br>
   *                 "h": absolute head item support
   *                      (number of transactions, integer)<br>
   *                 "y": relative head item support as a fraction
   *                      (double)<br>
   *                 "Y": relative head item support as a percentage
   *                      (double)<br>
   *                 "c": rule confidence as a fraction (double)<br>
   *                 "C": rule confidence as a percentage (double)<br>
   *                 "l": lift value of a rule (confidence/prior)
   *                      (double)<br>
   *                 "L": lift value of a rule as a percentage
   *                      (double)<br>
   *                 "e": value of rule evaluation measure (double)<br>
   *                 "E": value of rule evaluation measure (double)
   *                      as a percentage<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>ECLAT_BASIC</code>,
   *                  <code>ECLAT_TIDS</code>, <code>ECLAT_BITS</code>,
   *                  <code>ECLAT_TABLE</code>,
   *                  <code>ECLAT_SIMPLE</code>,
   *                  <code>ECLAT_RANGES</code>,
   *                  <code>ECLAT_OCCDLV</code>,
   *                  <code>ECLAT_DIFFS</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>,
   *                  <code>NOFIM16</code>, <code>NOPERFECT</code>,
   *                  <code>NOSORT</code>, <code>NOHUT</code>,
   *                  <code>HORZ</code>, <code>VERT</code>,
   *                  <code>INVBXS</code>, <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter is used only if
   *                 target = <code>RULES</code>.
   *                 It may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return if report != "#" and report != "=":<br>
   *          if target = <code>RULES</code>: an array with k+2
   *          elements, the first of which is an integer array that
   *          contains the head (consequent) items, while the second
   *          contains the body (antecedent) item sets as integer
   *          arrays; the following k array elements contain arrays
   *          that correspond to the values selected with the characters
   *          in report (each value in these arrays corresponds to the
   *          association rule at the same array index in the first
   *          and the second array).<br>
   *          if target != <code>RULES</code>: an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2015.02.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] eclat (int[][] tracts, int[] wgts,
    int target, double conf, double supp, int zmin, int zmax,
    String report, int eval, int agg, double thresh, int prune,
    int algo, int mode, int[] border, int[][] appear);

  /*------------------------------------------------------------------*/
  /** Java interface to FP-growth algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code>,
   *                  <code>MAXIMAL</code>, <code>GENERATORS</code>
   *                  or <code>RULES</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  conf   minimum confidence of an association rule
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "b": absolute body set support
   *                      (number of transactions, integer)<br>
   *                 "x": relative body set support as a fraction
   *                      (double)<br>
   *                 "X": relative body set support as a percentage
   *                      (double)<br>
   *                 "h": absolute head item support
   *                      (number of transactions, integer)<br>
   *                 "y": relative head item support as a fraction
   *                      (double)<br>
   *                 "Y": relative head item support as a percentage
   *                      (double)<br>
   *                 "c": rule confidence as a fraction (double)<br>
   *                 "C": rule confidence as a percentage (double)<br>
   *                 "l": lift value of a rule (confidence/prior)
   *                      (double)<br>
   *                 "L": lift value of a rule as a percentage
   *                      (double)<br>
   *                 "e": value of rule evaluation measure (double)<br>
   *                 "E": value of rule evaluation measure (double)
   *                      as a percentage<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>,
   *                  <code>CONFIDENCE</code>, <code>CONF</code>,
   *                  <code>CONFDIFF</code>, <code>LIFT</code>,
   *                  <code>LIFTDIFF</code>, <code>LIFTQUOT</code>,
   *                  <code>CONVICTION</code>, <code>CVCT</code>,
   *                  <code>CVCTDIFF</code>, <code>CVCTQUOT</code>,
   *                  <code>CPROB</code>, <code>CONDPROB</code>,
   *                  <code>IMPORTANCE</code>, <code>IMPORT</code>,
   *                  <code>CERTAINTY</code>, <code>CERT</code>,
   *                  <code>CHI2</code>, <code>CHI2PVAL</code>,
   *                  <code>YATES</code>, <code>YATESPVAL</code>,
   *                  <code>INFO</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  agg    evaluation measure aggregation mode<br>
   *                 (<code>NONE</code>,
   *                  <code>MIN</code>, <code>MINIMUM</code>,
   *                  <code>MAX</code>, <code>MAXIMUM</code>,
   *                  <code>AVG</code>, <code>AVERAGE</code>)
   *  @param  thresh threshold for evaluation measure
   *                 (lower bound for measures for which larger is
   *                 better, upper bound for measures for which
   *                 smaller is better)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>FPG_SIMPLE</code>,
   *                  <code>FPG_COMPLEX</code>, <code>FPG_SINGLE</code>,
   *                  <code>FPG_TOPDOWN</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>, <code>NOSORT</code>,
   *                  <code>NOHUT</code>, <code>INVBXS</code>,
   *                  <code>ORIGSUPP</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @param  appear map from items to item appearance indicators
   *                 as two integer arrays odf equal size, with
   *                 the first holding the items, the second the
   *                 corresponding item appearance indicators.<br>
   *                 This parameter is used only if
   *                 target = <code>RULES</code>.
   *                 It may be <code>null</code>; and
   *                 then items may appear anywhere in a rule.<br>
   *                 The item appearance indicators must be one of
   *                 <code>IGNORE</code>, <code>NEITHER</code>,
   *                 <code>NONE</code>, <code>BODY</code>,
   *                 <code>INPUT</code>, <code>ANTE</code>,
   *                 <code>ANTECENDENT</code>, <code>HEAD</code>,
   *                 <code>OUTPUT</code>, <code>CONS</code>,
   *                 <code>CONSEQUENT</code>, <code>BOTH</code>,
   *                 <code>INOUT</code>, <code>CANDA</code>.
   *                 The default appearance indicator is set via a
   *                 pseudo-item which has a negative identifier.
   *  @return if report != "#" and report != "=":<br>
   *          if target = <code>RULES</code>: an array with k+2
   *          elements, the first of which is an integer array that
   *          contains the head (consequent) items, while the second
   *          contains the body (antecedent) item sets as integer
   *          arrays; the following k array elements contain arrays
   *          that correspond to the values selected with the characters
   *          in report (each value in these arrays corresponds to the
   *          association rule at the same array index in the first
   *          and the second array).<br>
   *          if target != <code>RULES</code>: an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] fpgrowth (int[][] tracts, int[] wgts,
    int target, double supp, double conf, int zmin, int zmax,
    String report, int eval, int agg, double thresh, int prune,
    int algo, int mode, int[] border, int[][] appear);

  /*------------------------------------------------------------------*/
  /** Java interface to SaM algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code> or
   *                  <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "e": value of item set evaluation measure
   *                      (double)<br>
   *                 "E": value of item set evaluation measure
   *                      as a percentage (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>SAM_SIMPLE</code>,
   *                  <code>SAM_BSEARCH</code>, <code>SAM_DOUBLE</code>,
   *                  <code>SAM_TREE</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] sam (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int eval, double thresh, int algo, int mode, int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to RElim algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code> or
   *                  <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "e": value of item set evaluation measure
   *                      (double)<br>
   *                 "E": value of item set evaluation measure
   *                      as a percentage (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>RELIM_BASIC</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] relim (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int eval, double thresh, int algo, int mode, int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to JIM algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code>,
   *                  <code>FREQUENT</code>, <code>CLOSED</code> or
   *                  <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  covsim cover similarity measure
   *                 (<code>JIM_NONE</code>,
   *                  <code>JIM_RUSSEL_RAO</code>,
   *                  <code>JIM_KULCZYNSKI</code>,
   *                  <code>JIM_JACCARD</code>,
   *                  <code>JIM_TANIMOTO</code>, <code>JIM_DICE</code>,
   *                  <code>JIM_SORENSEN</code>,
   *                  <code>JIM_CZEKANOWKSI</code>,
   *                  <code>JIM_SOKAL_SNEATH_1</code>,
   *                  <code>JIM_SOKAL_MICHENER</code>,
   *                  <code>JIM_HAMMING</code>, <code>JIM_FAITH</code>,
   *                  <code>JIM_ROGERS_TANIMOTO</code>,
   *                  <code>JIM_SOKAL_SNEATH_2</code>,
   *                  <code>JIM_GOWER_LEGENDRE</code>,
   *                  <code>JIM_SOKAL_SNEATH_3</code>,
   *                  <code>JIM_BARONI_BUSER</code>,
   *                  <code>JIM_GENERIC</code>)
   *  @param  simps  cover similarity measure parameters (if generic)
   *                 S = (c_0s +c_1z +c_2n +c_3x)
   *                   / (c_4s +c_5z +c_6n +c_7x)
   *  @param  sim    threshold for cover similarity measure
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "e": value of item set evaluation measure
   *                      (double)<br>
   *                 "E": value of item set evaluation measure
   *                      as a percentage (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation<br>
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>SAM_SIMPLE</code>,
   *                  <code>SAM_BSEARCH</code>, <code>SAM_DOUBLE</code>,
   *                  <code>SAM_TREE</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOFIM16</code>,
   *                  <code>NOPERFECT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2018.03.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] jim (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int eval, double thresh, int covsim, double[] simps, double sim,
    int algo, int mode, int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to Carpenter algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>CLOSED</code> or <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "e": value of item set evaluation measure
   *                      (double)<br>
   *                 "E": value of item set evaluation measure
   *                      as a percentage (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>CARP_TABLE</code>,
   *                  <code>CARP_TIDLIST</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOPERFECT</code>,
   *                  <code>REPOFILT</code>, <code>MAXONLY</code>,
   *                  <code>NOCOLLATE</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] carpenter (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int eval, double thresh, int algo, int mode, int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to IsTa algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>CLOSED</code> or <code>MAXIMAL</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "e": value of item set evaluation measure
   *                      (double)<br>
   *                 "E": value of item set evaluation measure
   *                      as a percentage (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  eval   measure for item set evaluation
   *                 (<code>NONE</code>, <code>LDRATIO</code>)
   *  @param  thresh threshold for evaluation measure
   *  @param  algo   algorithm variant to use<br>
   *                 (<code>AUTO</code>, <code>ISTA_PREFIX</code>,
   *                  <code>ISTA_PATRICIA</code>)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>NOPRUNE</code>,
   *                  <code>REPOFILT</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] ista (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int eval, double thresh, int algo, int mode, int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to accretion-style Apriori algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "p": p-value of item set test as a fraction
   *                      (double)<br>
   *                 "P": p-value of item set test as a percentage
   *                      (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  stat   test statistic for item set evaluation
   *                 (<code>NONE</code>, <code>CHI2PVAL</code>,
   *                  <code>YATESPVAL</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  siglvl significance level (maximum p-value)
   *  @param  prune  minimum size for evaluation filtering<br>
   *                 =    0: backward filtering (no subset check)<br>
   *                 &lt; 0: weak   forward filtering
   *                         (one subset  must qualify)<br>
   *                 &gt; 0: strong forward filtering
   *                         (all subsets must qualify)
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>INVBXS</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] apriacc (int[][] tracts, int[] wgts,
    double supp, int zmin, int zmax, String report,
    int stat, double siglvl, int prune, int mode, int[] border);

  /*------------------------------------------------------------------*/
  /** Java interface to Accretion algorithm in C.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report values to report with an item set<br>
   *                 (multiple values possible except for "#" and "=",
   *                 which have to form a one-character string)<br>
   *                 "a": absolute item set support
   *                      (number of transactions, integer)<br>
   *                 "s": relative item set support
   *                      (fraction of transactions, double)<br>
   *                 "S": relative item set support
   *                      (percentage of transactions, double)<br>
   *                 "p": p-value of item set test as a fraction
   *                      (double)<br>
   *                 "P": p-value of item set test as a percentage
   *                      (double)<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  stat   test statistic for item set evaluation
   *                 (<code>NONE</code>, <code>CHI2PVAL</code>,
   *                  <code>YATESPVAL</code>, <code>INFOPVAL</code>,
   *                  <code>FETPROB</code>, <code>FETCHI2</code>,
   *                  <code>FETINFO</code>, <code>FETSUPP</code>)
   *  @param  siglvl significance level (maximum p-value)
   *  @param  maxext maximum number of extension items
   *  @param  mode   operation mode indicators/flags<br>
   *                 (<code>NONE</code>, <code>INVBXS</code>)
   *  @param  border array of support thresholds per item set size
   *                 (item set size is index of this array);
   *                 may be <code>null</code> if this additional
   *                 filtering is not needed
   *  @return if report != "#" and report != "=": an array with k+1
   *          elements, the first of which is an array that contains
   *          the item sets as integer arrays, while the following k
   *          elements contain arrays that correspond to the values
   *          selected with the characters in report (each value in
   *          these arrays corresponds to the item set at the same
   *          array index in the first array).<br>
   *          if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.10.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] accretion (int[][] tracts, int[] wgts,
    double supp, int zmin, int zmax, String report,
    int stat, double siglvl, int maxext, int mode, int[] border);

  /*------------------------------------------------------------------*/
  /** Pattern spectrum generation with surrogate data sets.
   *  @param  tracts array of transactions to process,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code> or
   *                  <code>FREQUENT</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report format in which to report the pattern spectrum<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  cnt    number of surrogate data sets to generate
   *  @param  surr   surrogate data generation method
   *                 (<code>IDENT</code>, <code>RANDOM</code>,
   *                  <code>SWAP</code> or <code>SHUFFLE</code>)
   *  @param  seed   seed value for random number generator
   *  @param  cpus   number of cpus/threads to use
   *  @param  ctrl   control array (progress indicator, stop flag)
   *  @return if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] genpsp (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int cnt, int surr, int seed, int cpus, int[] ctrl);

  /*------------------------------------------------------------------*/
  /** Estimate a pattern spectrum from data characteristics.
   *  @param  tracts array of transactions to analyze,
   *                 each of which is an array of integers
   *  @param  wgts   weights of the transactions (same array index)<br>
   *                 (may be <code>null</code> if the transactions do
   *                  not carry weights; in this case each transaction
   *                  receives a unit weight)
   *  @param  equiv  equivalent number of surrogate data sets
   *  @param  target type of the item sets to find
   *                 (<code>SETS</code>, <code>ALL</code> or
   *                  <code>FREQUENT</code>)
   *  @param  supp   minimum support of an item set<br>
   *                 (positive: percentage, negative: absolute number)
   *  @param  zmin   minimum number of items per item set
   *  @param  zmax   maximum number of items per item set
   *  @param  report format in which to report the pattern spectrum<br>
   *                 "#": pattern spectrum in column format<br>
   *                 "=": pattern spectrum with <code>PatSpecElem</code>
   *  @param  alpha  probability dispersion factor
   *  @param  smpls  number of samples per item set size
   *  @param  seed   seed value for random number generator
   *  @return if report = "#": an array with three elements; the first
   *          array contains the item set sizes as integers, the second
   *          array contains the support values as integers (that is,
   *          corresponding elements of the first and the second array
   *          form a pattern signature), and the third array contains
   *          the frequency (number of occurrences) of the size/support
   *          pair (at the same array index in the first two arrays)
   *          as a double precision floating point value.<br>
   *          if report = '=': an array with objects of type
   *          <code>PatSpecElem</code>, each of which specifies a
   *          pattern signature together with its occurrence frequency.
   *  @since  2014.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native Object[] estpsp (int[][] tracts, int[] wgts,
    int target, double supp, int zmin, int zmax, String report,
    int equiv, double alpha, int smpls, int seed);

  /*------------------------------------------------------------------*/
  /** Set the abort state (abort computations or clear abort state).
   *  @param  state  abort state to set (0: clear; != 0: signal abort)
   *  @since  2015.03.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static native void abort (int state);

  /*------------------------------------------------------------------*/

  static {                      /* --- load the native library */
    System.loadLibrary("JNIFIM");
  }                             /* java -Djava.library.path=... */

}  /* class JNIFIM */
