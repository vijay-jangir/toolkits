/*----------------------------------------------------------------------
  File    : PatternReceiver.java
  Contents: interface for an item pattern receiver
  Author  : Christian Borgelt
  History : 2017.06.29 file created
----------------------------------------------------------------------*/
package fim;

/*--------------------------------------------------------------------*/
/** Interface for an item pattern receiver
 *  (argument of the function <code>CloMaxTree.report()</code>).
 *  @author Christian Borgelt
 *  @since  2016.10.24 */
/*--------------------------------------------------------------------*/
public interface PatternReceiver {

  /*------------------------------------------------------------------*/
  /** Add an item pattern to the pattern receiver.
   *  @param  items  the items in the item pattern
   *                 (may be an oversized buffer)
   *  @param  cnt    the number of items in the pattern
   *  @param  s_pat  the (absolute) support of the item pattern
   *  @param  s_base the (absolute) base support
   *                 (support of the empty item pattern, database size)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  void receive (int[] items, int cnt, int s_pat, int s_base);

}  /* interface PatternReceiver */
