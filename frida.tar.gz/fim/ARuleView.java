/*----------------------------------------------------------------------
  File    : ARuleView.java
  Contents: association rule visualization program
  Author  : Christian Borgelt
  History : 2004.07.06 file created from file DTView.java
            2006.07.20 user interface creation moved to run method
            2007.03.12 cleaned up and simplified, javadoc added
            2007.06.07 loading and saving simplified
            2014.10.23 changed from LGPL license to MIT license
            2017.06.29 adapted to modified constants of class ARuleSet
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.TableModelEvent;

import dialog.AboutDialog;

/*--------------------------------------------------------------------*/
/** Class for a simple association rule viewer.
 *  @author Christian Borgelt
 *  @since  2004.07.06 */
/*--------------------------------------------------------------------*/
public class ARuleView extends JFrame implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x0001000bL;
  public  static final String VERSION = "1.11 (2014.10.23)";

  /** mode flag: the viewer is a stand-alone program */
  public final static int PROGRAM    = 1;
  /** mode flag: add menu items for loading files */
  public final static int LOAD_ITEMS = 2;
  /** mode flag: add menu items for saving files */
  public final static int SAVE_ITEMS = 4;
  /** mode flag: add menu items for loading and saving files */
  public final static int FILE_ITEMS = LOAD_ITEMS | SAVE_ITEMS;
  /** mode flag: add all menu items */
  public final static int ALL_ITEMS  = FILE_ITEMS;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this association rule viewer */
  private Component    owner   = null;
  /** the mode flags */
  private int          mode    = 0;
  /** the association rule table */
  private ARuleTable   table   = null;
  /** the scroll pane for the viewport */
  private JScrollPane  scroll  = null;
  /** the table view */
  private JTable       view    = null;
  /** the status bar for messages */
  private JTextField   stat    = null;
  /** the file chooser */
  private JFileChooser chooser = null;
  /** the current rule set file */
  private File         curr    = null;
  /** the "About..." dialog box */
  private AboutDialog  about   = null;

  /*------------------------------------------------------------------*/
  /** Create an association rule viewer.
   *  @param  mode the mode flags
   *  @since  2004.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleView (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create an association rule viewer.
   *  @param  owner the component that is to own this viewer
   *  @param  mode  the mode flags
   *  @since  2004.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleView (Component owner, int mode)
  {                             /* --- create an ass. rule viewer */
    this.owner = null;          /* clear the owner and */
    this.mode  = mode;          /* note the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* ARuleView() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2006.07.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    if ((this.mode & PROGRAM) != 0)
      this.mode |= LOAD_ITEMS;  /* check and adapt the mode */

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    if ((this.mode & LOAD_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Load Rule Set...", 'l'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ARuleView.this.loadRules(null); } } );
      item = menu.add(new JMenuItem("Reload Rule Set", 'r'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ARuleView.this.loadRules(ARuleView.this.curr); } } );
      menu.addSeparator();
    }
    if ((this.mode & SAVE_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Save Rule Set", 's'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ARuleView.this.saveRules(ARuleView.this.curr); } } );
      item = menu.add(new JMenuItem("Save Rule Set as...", 'a'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ARuleView.this.saveRules(null); } } );
      menu.addSeparator();
    }
    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ARuleView.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("Sort"));
    menu.setMnemonic('s');
    item = menu.add(new JMenuItem("by Consequent Item", 'q'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.NAMES); } } );
    item = menu.add(new JMenuItem("by Size", 'z'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.SIZE); } } );
    item = menu.add(new JMenuItem("by Antecedent Support", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.BODYSUPP); } } );
    item = menu.add(new JMenuItem("by Consequent Support", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.HEADSUPP); } } );
    item = menu.add(new JMenuItem("by Support", 's'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.SUPP); } } );
    item = menu.add(new JMenuItem("by Confidence", 'c'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.CONF); } } );
    item = menu.add(new JMenuItem("by Lift Value", 'l'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.LIFT); } } );
    item = menu.add(new JMenuItem("by Evaluation", 'e'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ARuleView.this.sortRules(ARuleSet.EVAL); } } );

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (ARuleView.this.about == null)
          ARuleView.this.about = new AboutDialog(ARuleView.this,
             "About ARuleView...", "ARuleView\n"
            +"A Simple Association Rule Viewer\n"
            +"Version " +ARuleView.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        ARuleView.this.about.setVisible(true);
        ARuleView.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    this.view   = new JTable();
    this.scroll = new JScrollPane(this.view);
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(this.scroll, BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    stat = new JTextField("");
    stat.setEditable(false);
    content.add(this.stat,   BorderLayout.SOUTH);

    /* --- show the frame window --- */
    this.setTitle("ARuleView");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser (create if necessary).
   *  @return the file chooser
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure file chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Set the message to display in the status line.
   *  @param  msg the message to display
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.stat.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Sort the association rules.
   *  @param  field the identifier of the field to compare first
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sortRules (int field)
  {                             /* --- sort the association rules */
    if (this.table == null) return;
    this.table.sort(field);     /* sort rules and update viewer */
    this.view.tableChanged(new TableModelEvent(this.table));
  }  /* sortRules() */

  /*------------------------------------------------------------------*/
  /** Set the set of association rules to display.
   *  @param  arset the rule set to display
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRules (ARuleSet arset)
  {                             /* --- set the rule set to display */
    this.view.setModel(this.table = new ARuleTable(arset));
    Dimension size = this.view.getPreferredSize();
    if (size.width  > 400) size.width  = 400;
    if (size.height > 400) size.height = 400;
    this.view.setPreferredScrollableViewportSize(size);
    this.pack();                /* re-layout the window */
  }  /* setRules() */

  /*------------------------------------------------------------------*/
  /** Get the currently displayed set of association rules.
   *  @return the currently displayed set of association rules
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleSet getRules ()
  { return this.table.getRules(); }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void reportError (String msg)
  {                             /* --- report an i/o error */
    this.stat.setText(msg);     /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this,
      msg, "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load a set of association rules.
   *  @param  file the file to load the rule set from
   *  @return whether the file was successfully loaded
   *  @since  2004.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadRules (File file)
  {                             /* --- load an association rule set */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get the selected file */
    try {                       /* create a reader for the file */
      System.err.print("reading " +file +" ... ");
      FileReader reader = new FileReader(file);
      ARuleSet   arset  = ARuleSet.parse(null, reader);
      reader.close();           /* read the rule set from the file */
      this.setRules(arset);     /* and set it for display */
      System.err.print("[" +arset.getRuleCount());
      System.err.println(" rule(s)] done."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.stat.setText(file.getPath());
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadRules() */

  /*------------------------------------------------------------------*/
  /** Save the displayed set of association rules.
   *  @param  file the file to save the rule set to
   *  @return whether the file was successfully saved
   *  @since  2004.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveRules (File file)
  {                             /* --- save the displayed rule set */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get the selected file */
    try {                       /* create a writer for the file */
      System.err.print("writing " +file +" ... ");
      FileWriter writer = new FileWriter(file);
      ARuleSet   arset  = this.getRules();
      arset.write(writer);      /* get the rule set to save and */
      writer.close();           /* write the rules to the file */
      System.err.print("[" +arset.getRuleCount());
      System.err.println(" rule(s)] done."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.curr = file;           /* note the new file name */
    return true;                /* return 'saving successful' */
  }  /* saveRules() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2004.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    ARuleView rv = new ARuleView(PROGRAM|ALL_ITEMS);
    if (args.length > 0) rv.loadRules(new File(args[0]));
    rv.setVisible(true);        /* create and show a rule viewer */
  }  /* main() */

}  /* class ARuleView */
