/*----------------------------------------------------------------------
  File    : PatternSet.java
  Contents: pattern set management for visualization
  Author  : Christian Borgelt
  History : 2013.11.28 file created from ARuleSet.java
            2015.08.12 pattern set reduction moved here
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.FileReader;
import java.io.Writer;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Comparator;

import util.IdMap;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for a set of patterns/item sets.
 *  @author Christian Borgelt
 *  @since  2013.11.28 */
/*--------------------------------------------------------------------*/
public class PatternSet implements Cloneable, PatternReceiver {

  /*------------------------------------------------------------------*/
  /** Interface for a comparator for pattern signatures.
   *  @author Christian Borgelt
   *  @since  2015.08.12 */
  /*------------------------------------------------------------------*/
  public interface PatSigCmp {  /* --- pattern signature comparison */

    /*----------------------------------------------------------------*/
    /** Compare two patterns/item sets.
     *  @param  zA     the size    of the 1st pattern (number of items)
     *  @param  cA     the support of the 1st pattern (coincidences)
     *  @param  zB     the size    of the 2nd pattern (number of items)
     *  @param  cB     the support of the 2nd pattern (coincidences)
     *  @param  border the decision border for pattern filtering
     *  @return a negative integer, zero, or a positive integer,
     *          as the second argument is preferred to the first,
     *          neither is preferred to the other, or the first
     *          argument is preferred to the second, respectively.
     *  @since  2015.08.12 (Christian Borgelt) */
    /*----------------------------------------------------------------*/

    public int compare (int zA, int cA, int zB, int cB, int[] border);

  }  /* interface PatSigCmp */


  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010003L;
  /** the block size for the pattern array */
  private static final int BLKSIZE = 1024;
  /** the empty item pattern array to avoid reallocation */
  private static final Pattern[] EMPTY = {};

  /* --- pattern set sort modes --- */
  /** sort mode: items (in the order in which they appear) */
  public  static final int ITEMS = 0;
  /** sort mode: size / number of items */
  public  static final int SIZE  = 1;
  /** sort mode: support */
  public  static final int SUPP  = 2;
  /** sort mode: evaluation */
  public  static final int EVAL  = 3;

  /* --- pattern set reduction methods --- */
  /** reduction mode: do nothing */
  public static final int NONE      = 0x0000;
  /** reduction mode: remove duplicates/ensure unique patterns */
  public static final int UNIQUE    = 0x0001;
  /** reduction mode: minimize size of item patterns */
  public static final int MINSIZE   = 0x0002;
  /** reduction mode: maximize size of item patterns */
  public static final int MAXSIZE   = 0x0004;
  /** reduction mode: compare only the items (not support) */
  public static final int ITEMSONLY = 0x0008;
  /** reduction mode: do not use a <code>CloMaxFilter</code>,
   *  but rather work directly on the item pattern array */
  public static final int NOFILTER  = 0x0010;
  /** reduction mode: reduce to closed item patterns;
   *  identical to <code>MAXSIZE</code> (since the union of the maximum
   *  size patterns for each support value are the closed patterns) */
  public static final int CLOSED    = MAXSIZE;
  /** reduction mode: reduce to maximal item patterns;
   *  combination of <code>MAXSIZE</code> and <code>ITEMSONLY</code> */
  public static final int MAXIMAL   = MAXSIZE | ITEMSONLY;

  /* --- pattern set signature reduction methods --- */
  /** reduction mode: none (keep all patterns after filtering) */
  public static final int KEEP     = 0x0000;
  /** reduction mode: excess coincidences (zb,cb-ca) */
  public static final int COINS0   = 0x0001;
  /** reduction mode: excess coincidences (zb,cb-ca+1) */
  public static final int COINS1   = 0x0002;
  /** reduction mode: excess items/neurons (za-zb+2,ca) */
  public static final int ITEMS2   = 0x0003;
  /** reduction mode: covered points/spikes za*ca : zb*cb */
  public static final int COVER0   = 0x0004;
  /** reduction mode: covered points/spikes (za-1)*ca : (zb-1)*cb */
  public static final int COVER1   = 0x0005;
  /** reduction mode: combined lenient (z, break rejection tie) */
  public static final int LENIENT0 = 0x0006;
  /** reduction mode: combined lenient (z-1, break rejection tie) */
  public static final int LENIENT1 = 0x0007;
  /** reduction mode: combined strict (z, force decision) */
  public static final int STRICT0  = 0x0008;
  /** reduction mode: combined strict (z-1, force decision) */
  public static final int STRICT1  = 0x0009;

  /* --- pattern selection modes --- */
  /** selection mode: find exact match of given pattern */
  public static final int  EXACT   = 0x00;
  /** selection mode: find superpattern(s) of given pattern
   *  (or exact match) */
  public static final int  SUPER   = 0x01;
  /** selection mode: find subpattern(s) of given pattern
   *  (or exact match) */
  public static final int  SUB     = 0x02;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  protected IdMap     ibase;
  /** the current number of patterns */
  protected int       size;
  /** the maximal size of a pattern */
  protected int       zmax;
  /** the set of patterns/item sets */
  protected Pattern[] pats;
  /** the support values of individual items */
  protected int[]     supps;

  /*------------------------------------------------------------------*/
  /** Create an empty set of item patterns.
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternSet ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create an empty set of item patterns.
   *  @param  ibase the underlying item base
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternSet (IdMap ibase)
  {                             /* --- create an item pattern set */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.size  = this.zmax = 0; /* note the item base and */
    this.pats  = null;          /* initialize the fields */
    this.supps = null;
  }  /* PatternSet() */

  /*------------------------------------------------------------------*/
  /** Create a pattern set from CoCoNAD output.
   *  @param  ibase the underlying item base
   *  @param  ipats the output of the native function
   *                <code>JNICoCo.coconad()</code>
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternSet (IdMap ibase, Object[] ipats)
  {                             /* --- create a pattern set */
    int     i, n;               /* loop variable, number of items */
    int[][] jpats;              /* item sets of the patterns */
    int[]   supps;              /* support values of the patterns */

    jpats = (int[][])ipats[0];  /* get the item patterns */
    supps = (int[])  ipats[1];  /* and their support values */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.pats  = new Pattern[this.size = jpats.length];
    this.zmax  = 0;             /* create a pattern array */
    for (i = 0; i < this.size; i++) {
      this.pats[i] = new Pattern(ibase, jpats[i], supps[i]);
      n = jpats[i].length;      /* create and store a new pattern */
      if (n > this.zmax) this.zmax = n;
    }                           /* update the maximum pattern size */
  }  /* PatternSet() */

  /*------------------------------------------------------------------*/
  /** Create an item pattern set from FIM output.
   *  @param  ibase  the underlying item base
   *  @param  s_base the number of transactions from which the
   *                 (frequent) item patterns where derived
   *  @param  ipats  the output of a native function
   *          <code>JNIFIM.xxx()</code>, called with
   *          <code>report="[a|s]"</code> or
   *          <code>report="[a|s][e|E]"</code>
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternSet (IdMap ibase, int s_base, Object[] ipats)
  {                             /* --- create a set of item patterns */
    int[][]  pats  = (int[][])ipats[0]; /* get the item patterns */
    int[]    supps = (int[])  ipats[1]; /* and their support values */
    double[] evals = (ipats.length > 2) ? (double[])ipats[2] : null;
    double[] wgts  = (ipats.length > 3) ? (double[])ipats[3] : null;
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.pats  = new Pattern[this.size = pats.length];
    this.zmax  = 0;             /* create an array of item patterns */
    for (int i = 0; i < this.size; i++) {  /* traverse the patterns */
      this.pats[i] = new Pattern(ibase, pats[i], supps[i], s_base,
                                 (evals != null) ? evals[i] : 0.0,
                                 (wgts  != null) ? wgts[i]  : 0.0);
      int n = pats[i].length;   /* create and store a new item pat. */
      if (n > this.zmax) this.zmax = n;
    }                           /* update maximum item pattern size */
  }  /* PatternSet() */

  /*------------------------------------------------------------------*/
  /** Clone this item pattern set.
   *  <p>The clone is a deep clone, that is, the underlying item base
   *  and all contained item patterns are cloned as well.</p>
   *  @return a clone of this item pattern set
   *  @since  2017.06.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone ()
  { return clone(true, true); }

  /*------------------------------------------------------------------*/
  /** Clone this item pattern set.
   *  @param  clonebase whether to clone the underlying item base
   *  @param  clonepats whether to clone the item patterns
   *  @return a clone of this item pattern set
   *  @since  2017.06.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone (boolean clonebase, boolean clonepats)
  {                             /* --- clone an item pattern set */
    IdMap ibase = (clonebase) ? (IdMap)this.ibase.clone() : this.ibase;
    PatternSet patset = new PatternSet(ibase);
    clonepats |= clonebase;     /* create a new item pattern set */
    for (int i = 0; i < this.size; i++)
      patset.add((!clonepats) ? this.pats[i]
               : (Pattern)this.pats[i].clone(ibase));
    return patset;              /* add a clone of each item pattern */
  }  /* clone() */              /* and return the created clone */

  /*------------------------------------------------------------------*/
  /** Clear this item pattern set, that is, remove all patterns.
   *  @since  2017.06.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void clear ()
  {                               /* --- clear an item pattern set */
    this.size = this.zmax = 0;    /* clear maximum pattern size */
    this.pats = null;             /* and delete all patterns */
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the underlying item base.
   *  @return the underlying item base
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final IdMap getItemBase ()
  { return this.ibase; }

  /*------------------------------------------------------------------*/
  /** Get the name of an item.
   *  @return the name of the item with identifier <code>i</code>
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getItemName (int item)
  { return (String)this.ibase.get(item); }

  /*------------------------------------------------------------------*/
  /** Get the number of patterns.
   *  @return the number of patterns
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSize ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the number of patterns.
   *  @return the number of patterns
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getCount ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get a pattern.
   *  @param  i the index of the pattern
   *  @return the pattern with index <code>i</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Pattern get (int i)
  { return this.pats[i]; }

  /*------------------------------------------------------------------*/
  /** Get a pattern.
   *  @param  i the index of the pattern
   *  @return the pattern with index <code>i</code>
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Pattern getPattern (int i)
  { return this.pats[i]; }

  /*------------------------------------------------------------------*/
  /** Get all item patterns as an array
   *  (array length fits only after packing with <code>pack()</code>;
   *  should be considered read only).
   *  @return the array of item patterns
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Pattern[] getAllPatterns ()
  { return this.pats; }

  /*------------------------------------------------------------------*/
  /** Get the size of an item patterns.
   *  @param  i the index of the pattern
   *  @return the size of the item pattern with index <code>i</code>
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getPatternSize (int i)
  { return this.pats[i].getSize(); }

  /*------------------------------------------------------------------*/
  /** Get the support of a pattern.
   *  @param  i the index of the pattern
   *  @return the support of the pattern with index <code>i</code>
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupport (int i)
  { return this.pats[i].getSupp(); }

  /*------------------------------------------------------------------*/
  /** Add a pattern/item set.
   *  @param  pat the pattern to add
   *  @return the index of the pattern in the set
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int add (Pattern pat)
  {                             /* --- add a pattern */
    int smax = (this.pats != null) ? this.pats.length : 0;
    if (this.size >= smax) {    /* if the pattern array is full */
      smax += (smax > BLKSIZE) ? smax >> 1 : BLKSIZE;
      Pattern[] p = new Pattern[smax];
      if (this.pats != null)    /* create an (enlarged) pattern array */
        System.arraycopy(this.pats, 0, p, 0, this.size);
      this.pats = p;            /* copy already existing patterns */
    }                           /* and set the (new) pattern array */
    this.pats[this.size] = pat; /* add the new pattern */
    smax = pat.getSize();       /* adapt the maximal pattern size */
    if (smax > this.zmax) this.zmax = smax;
    return this.size++;         /* return the pattern identifier */
  }  /* add() */

  /*------------------------------------------------------------------*/
  /** Add a pattern/item set.
   *  @param  pat the pattern to add
   *  @return the index of the pattern in the set
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addPattern (Pattern pat)
  { return this.add(pat); }

  /*------------------------------------------------------------------*/
  /** Add an item pattern set.
   *  @param  patset the pattern set to add
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void addPatternSet (PatternSet patset)
  { this.addPatternSet(patset, false); }

  /*------------------------------------------------------------------*/
  /** Add an item pattern set.
   *  @param  patset the pattern set to add
   *  @param  clonepats whether to clone the patterns of the given set
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void addPatternSet (PatternSet patset, boolean clonepats)
  {                             /* --- add an item pattern set */
    if (clonepats) {            /* if to clone the patterns */
      for (int i = 0; i < patset.size; i++)
        this.add((Pattern)patset.pats[i].clone(this.ibase)); }
    else                        /* if to simply transfer the patterns */
      for (int i = 0; i < patset.size; i++)
        this.add(patset.pats[i]);
  }  /* addPatternSet() */

  /*------------------------------------------------------------------*/
  /** Receive an item pattern (implements <code>PatternReceiver</code>).
   *  @param  items  the items in the item pattern
   *                 (may be an oversized buffer)
   *  @param  cnt    the number of items in the pattern
   *  @param  s_pat  the (absolute) support of the item pattern
   *  @param  s_base the (absolute) base support
   *                 (support of the empty item pattern, database size)
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void receive (int[] items, int cnt, int s_pat, int s_base)
  { this.add(new Pattern(this.ibase, items, cnt, s_pat, s_base)); }

  /*------------------------------------------------------------------*/
  /** Get the maximal size of a pattern.
   *  @return the maximal size of a pattern
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMaxSize ()
  { return this.zmax; }

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item identifier for which to get
   *               the support value
   *  @return the support value of the item
   *          with identifier <code>item</code>
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp (int item)
  { return getSuppById(item); }

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item identifier
   *               for which to get the support value
   *  @return the support value of the item
   *          with identifier <code>item</code>
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuppById (int item)
  {                             /* --- get item support */
    if ((this.supps == null) || (item >= this.supps.length)) {
      int [] p = new int[this.ibase.getSize()];
      System.arraycopy(this.supps, 0, p, 0, this.supps.length);
      this.supps = p;           /* create a new item support array */
    }                           /* and copy existing array into it */
    return this.supps[item];    /* return the item support */
  }  /* getSuppById() */

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item name for which to get the support value
   *  @return the support value of the item with name <code>item</code>
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuppByName (String item)
  { return getSuppById(this.ibase.get(item)); }

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item object for which to get the support value
   *  @return the support value of the item
   *          with object <code>item</code>
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuppByObject (Object item)
  { return getSuppById(this.ibase.get(item)); }

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param  item the item identifier
   *               for which to set the support value
   *  @param  supp the support value to set for the item
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSupp (int item, int supp)
  { setSuppById(item, supp); }

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param item  the item identifier
   *               for which to set the support value
   *  @param supp  the support value to set for the item
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSuppById (int item, int supp)
  {                             /* --- set item support */
    if ((this.supps == null) || (item >= this.supps.length)) {
      int [] p = new int[this.ibase.getSize()];
      System.arraycopy(this.supps, 0, p, 0, this.supps.length);
      this.supps = p;           /* create a new item support array */
    }                           /* and copy existing array into it */
    this.supps[item] = supp;    /* set the item support value */
  }  /* setSuppById() */

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param  item the item name for which to set the support value
   *  @param  supp the support value to set for the item
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSuppByName (String item, int supp)
  { setSuppById(this.ibase.get(item), supp); }

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param  item the item name for which to set the support value
   *  @param  supp the support value to set for the item
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSuppByObject (String item, int supp)
  { setSuppById(this.ibase.get(item), supp); }

  /*------------------------------------------------------------------*/
  /** Get the support values of all individual items.
   *  @return an array of support values for each item
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getAllSupps ()
  {                             /* --- get item support values */
    if (this.supps == null) {   /* if there is no support array, */
      int [] p = new int[this.ibase.size()];
      System.arraycopy(this.supps, 0, p, 0, this.supps.length);
      this.supps = p;           /* create a new item support array */
    }                           /* and copy existing array into it */
    return this.supps;          /* return the item support array */
  }  /* getAllSupps() */

  /*------------------------------------------------------------------*/
  /** Set the support values of all individual items.
   *  @param supps an array of support values for each item
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setAllSupps (int[] supps)
  {                             /* --- set item support values */
    if ((this.supps == null) || (supps.length > this.supps.length)) {
      int z = this.ibase.size();
      if (supps.length > z) z = supps.length;
      this.supps = new int[z];  /* create a new item support array */
    }
    System.arraycopy(supps, 0, this.supps, 0, supps.length);
  }  /* setAllSupps() */

  /*------------------------------------------------------------------*/
  /** Sort the items in the patterns of an item pattern set.
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sortItems ()
  {                             /* --- sort items in patterns */
    for (int i = 0; i < this.size; i++)
      this.pats[i].sort();      /* sort the items in all patterns */
  }  /* sortItems() */

  /*------------------------------------------------------------------*/
  /** Set the sort parameters for all item patterns.
   *  @param  valid the identifier of the value to sort on
   *  @param  dir   the sort direction
   *                (positive: ascending, negative: descending)
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final void setSort (int valid, int dir)
  {                             /* --- set sort parameters */
    if (dir == 0) {             /* if no direction is given */
      switch (valid) {          /* evaluate the value identifier */
        case SIZE: dir = +1; break;
        case SUPP: dir = -1; break;
        case EVAL: dir = -1; break;
        default  : return;      /* get default sorting direction */
      }                         /* but ignore unknown value ids */
    }
    switch (valid) {            /* evaluate the sort identifier */
      case SIZE:                /* if to sort by item pattern size */
        for (int i = 0; i < this.size; i++)
          this.pats[i].setSort(this.pats[i].getSize(), dir);
        break;
      case SUPP:                /* if to sort by item pattern support */
        for (int i = 0; i < this.size; i++)
          this.pats[i].setSort(this.pats[i].getSupp(), dir);
        break;
      case EVAL:                /* if to sort by item pattern eval. */
        for (int i = 0; i < this.size; i++)
          this.pats[i].setSort(this.pats[i].getEval(), dir);
        break;
      default:                  /* if unknown sort identifier, */
        return;                 /* simply abort the function */
    }
  }  /* setSort() */

  /*------------------------------------------------------------------*/
  /** Sort a set of item patterns.
   *  @since  2014.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort ()
  { this.sort(SIZE, 0); }

  /*------------------------------------------------------------------*/
  /** Sort a set of item patterns.
   *  @param  valid the identifier of the value to compare first
   *  @since  2014.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort (int valid)
  { this.sort(valid, 0); }

  /*------------------------------------------------------------------*/
  /** Sort a set of item patterns.
   *  @param  valid the identifier of the field to compare first
   *  @param  dir   the sort direction
   *                (positive: ascending, negative: descending)
   *  @since  2014.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort (int valid, int dir)
  {                             /* --- sort the item patterns */
    if (this.size <= 0) return; /* if there are no patterns, abort */
    if (valid <= ITEMS) {       /* if to sort the patterns by items */
      for (int i = 0; i < this.size; i++)
        this.pats[i].dir = dir;
      Comparator<Pattern> cmp = new Comparator<Pattern> () {
        public int compare (Pattern p1, Pattern p2)
        { return p1.allCmpTo(p2) *p1.dir; } };
      Arrays.sort(this.pats, 0, this.size, cmp); }
    else {                      /* if to sort by a numeric property */
      setSort(valid, dir);      /* set the sort parameters */
      Arrays.sort(this.pats, 0, this.size);
    }                           /* sort the item patterns */
  }  /* sort() */

  /*------------------------------------------------------------------*/
  /** Reverse the order of the patterns in a pattern set.
   *  @since  2016.06.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void reverse ()
  {                             /* --- reverse item pattern order */
    int l, r;                   /* left and right exchange index */
    for (l = 0, r = this.size-1; l < r; l++, r--) {
      Pattern p = this.pats[l]; /* traverse the patterns */
      this.pats[l] = this.pats[r];
      this.pats[r] = p;         /* iteratively exchange patterns */
    }                           /* from left and right side */
  }  /* reverse() */

  /*------------------------------------------------------------------*/
  /** Check whether two item pattern sets are equal.
   *  It is assumed that both item pattern sets have been sorted
   *  with a call to the function <code>sort()</code> with parameter
   *  <code>ITEMS</code>. If the item pattern set represents item sets
   *  instead of permutations or sequences, it is also assumed that the
   *  items in each pattern have been sorted by a call to the function
   *  <code>sortItems()</code>
   *  @param  patset the pattern set to compare to
   *  @return <code>true</code> if the two item pattern sets contain the
   *          same patterns (in the same order) and <code>false</code>
   *          otherwise
  /*------------------------------------------------------------------*/

  public boolean equals (PatternSet patset)
  {                             /* --- check for equality */
    if (this.size != patset.size)
      return false;             /* check for same number of patterns */
    for (int i = 0; i < this.size; i++)
      if (!this.pats[i].equals(patset.pats[i]))
        return false;           /* check for equal patterns and */
    return true;                /* return if there is a difference */
  }  /* equals() */

  /*------------------------------------------------------------------*/
  /** Reduce an item pattern set.
   *  @param  mode the reduction mode (e.g. <code>MINSIZE</code>)
   *  @return the new number of item patterns
   *  @since  2016.06.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int reduce (int mode)
  {                               /* --- reduce item pattern set */
    if (this.size <= 1)           /* if there is at most one item pat., */
      return this.size;           /* there is nothing to reduce */

    Comparator<Pattern> cmp;      /* comparator for item patterns */
    int m = mode & ~UNIQUE;       /* if to make patterns unique */
    if (((mode & UNIQUE) != 0) && ((m == 0) || (m == ITEMSONLY))) {
      cmp = new Comparator<Pattern> () {
        public int compare (Pattern p1, Pattern p2) {
          return p1.allCmpTo(p2); } };
      Arrays.sort(this.pats, 0, this.size, cmp);
      int i, k;                   /* sort the patterns */
      for (i = k = 0; ++i < this.size; )
        if (!this.pats[i].equals(this.pats[k], m == 0))
          this.pats[++k] = this.pats[i];
      while (--i > k)             /* collect unique patterns and */
        this.pats = null;         /* clear (re)moved pattern entries */
      return this.size = k+1;     /* return the new number of patterns */
    }

    if (((mode & MAXSIZE) != 0) && ((mode & NOFILTER) == 0)
    &&  (this.size > 32)) {       /* if a CloMaxFilter can be used */
      //setSort(SIZE, -1);        /* sort patterns desc. by size */
      //Arrays.sort(this.pats, 0, this.size);
      /* Sorting the patterns by size allows to call the function     */
      /* filter.update() in the loop below with subsets set to false, */
      /* since then the patterns will be added in descending order    */
      /* of size and thus any subsets follow any supersets.           */
      /* However, this appears to be slower.                          */
      /* create a closed/maximal filter tree */
      int target = ((mode & ITEMSONLY) != 0)
                 ? CloMaxTree.MAXIMAL : CloMaxTree.CLOSED;
      int sbase  = this.pats[0].getBaseSupp();
      CloMaxTree filter = new CloMaxTree(this.ibase, target, -1);
      for (int i = 0; i < this.size; i++) {
        if (this.pats[i].getBaseSupp() != sbase)
          sbase = -2;           /* check for same base support */
        filter.update(this.pats[i].items, 0,
                      this.pats[i].size, this.pats[i].s_pat);
      }                         /* update filter with each pattern */
      clear();                  /* delete all patterns */
      filter.report(this, sbase);
      reverse();                /* get the reduced pattern set and */
      return this.size;         /* return the new number of patterns */
    }

    if ((mode & ITEMSONLY) != 0)/* if only to compare items, */
      cmp = new Comparator<Pattern> () {
        public int compare (Pattern p1, Pattern p2) {
          return 0; } };        /* get a dummy comparator */
    else {                      /* if to compare items and support */
      cmp = new Comparator<Pattern> () {
        public int compare (Pattern p1, Pattern p2) {
          return p1.suppCmpTo(p2); } };
      Arrays.sort(this.pats, 0, this.size, cmp);
    }                           /* sort the item patterns by support */

    int beg, end;               /* range of current section */
    if ((mode & MAXSIZE) != 0){ /* if to maximize item patterns */
      setSort(SIZE, -1);        /* sort the patterns by size */
      for (beg = 0; beg < this.size; beg = end) {
        for (end = beg+1; end < this.size; end++)
          if (cmp.compare(this.pats[end], this.pats[beg]) != 0)
            break;              /* if item patterns differ, abort */
        if (end -beg >= 2) {    /* if there are at least two patterns */
          Arrays.sort(this.pats, beg, end);
          for (int i = beg+1; i < end; i++)
            for (int k = beg; k < i; k++)
              if ((this.pats[k] != null)
              &&  (this.pats[i].isSubOf(this.pats[k]))) {
                this.pats[i] = null; break; }
        }                       /* (if a pattern is a subpattern */
      } }                       /*  of another, keep only larger) */
    else if ((mode & MINSIZE) != 0) { /* if to minimize item patterns */
      setSort(SIZE, +1);        /* sort the patterns by size */
      for (beg = 0; beg < this.size; beg = end) {
        for (end = beg+1; end < this.size; end++)
          if (cmp.compare(this.pats[end], this.pats[beg]) != 0)
            break;              /* if item patterns differ, abort */
        if (end -beg >= 2) {    /* if there are at least two patterns */
          Arrays.sort(this.pats, beg, end);
          for (int i = beg + 1; i < end; i++)
            for (int k = beg; k < i; k++)
              if ((this.pats[k] != null)
              &&  (this.pats[k].isSubOf(this.pats[i]))) {
                this.pats[i] = null; break; }
        }                       /* (if a pattern is a subpattern */
      }                         /*  of another, keep only smaller) */
    }
    int n = 0;                  /* traverse the item patterns */
    for (int i = 0; i < this.size; i++)
      if (this.pats[i] != null) /* if a pattern has not been deleted, */
        this.pats[n++] = this.pats[i];/* move it to next free element */
    for (int i = n; i < this.size; i++)
      this.pats[i] = null;      /* clear emptied elements */
    return this.size = n;       /* set the new number of patterns */
  }  /* reduce() */

  /*------------------------------------------------------------------*/
  /** Reduce a set of item patterns (by pattern signatures).
   *  @param  method  the pattern set reduction method (one of
   *                  <code>KEEP</code>, <code>COINS0</code>,
   *                  <code>COINS1</code>, <code>ITEMS2</code>,
   *                  <code>COVER0</code>, <code>COVER1</code>,
   *                  <code>LENIENT0</code>, <code>LENIENT1</code>,
   *                  <code>STRICT0</code>, <code>STRICT1</code>)
   *  @param  border  the decision border for rejecting patterns
   *  @param  addis   whether to add pattern intersections
   *  @return the new number of patterns
   *  @since  2015.08.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int reduce (int method, int[] border, boolean addis)
  {                             /* --- reduce a pattern set */
    int       iA, iB, n, r;     /* loop variables */
    Pattern   A, B, P, Q;       /* to traverse the patterns */
    int       zA, cA, zB, cB;   /* size and support of patterns */
    int       zP, cP, zQ, cQ;   /* size and support of patterns */
    PatSigCmp patcmp;           /* pattern signature comparison func. */
    boolean[] keep;             /* flags which patterns to keep */

    /* --- get pattern comparison function --- */
    switch (method) {           /* evaluate pattern set reduction */
      case COINS0:              /* excess coincidences 1 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            return (cB-cA < border[zB]) ? +1 : -1;
          } }; break;
      case COINS1:              /* excess coincidences 2 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            return (cB-cA+1 < border[zB]) ? +1 : -1;
          } }; break;
      case ITEMS2:              /* excess items/neurons */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            return (cA < border[zB-zB+2]) ? -1 : +1;
          } }; break;
      case COVER0:              /* covered spikes 1 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            return (zA*cA >= zB*cB) ? +1 : -1;
          } }; break;
      case COVER1:              /* covered spikes 2 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            return ((zA-1)*cA >= (zB-1)*cB) ? +1 : -1;
          } }; break;
      case LENIENT0:            /* lenient combination 1 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            boolean xA = (cA < border[zA-zB+2]);
            boolean xB = (cB-cA+1 < border[zB]);
            if ( xA && !xB) return -1;
            if (!xA &&  xB) return +1;
            if (!xA && !xB) return  0;
            return (zA*cA >= zB*cB) ? +1 : -1;
          } }; break;
      case LENIENT1:            /* lenient combination 2 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            boolean xA = (cA < border[zA-zB+2]);
            boolean xB = (cB-cA+1 < border[zB]);
            if ( xA && !xB) return -1;
            if (!xA &&  xB) return +1;
            if (!xA && !xB) return  0;
            return ((zA-1)*cA >= (zB-1)*cB) ? +1 : -1;
          } }; break;
      case STRICT0:             /* strict combination 1 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            boolean xA = (cA < border[zA-zB+2]);
            boolean xB = (cB-cA+1 < border[zB]);
            if ( xA && !xB) return -1;
            if (!xA &&  xB) return +1;
            return (zA*cA >= zB*cB) ? +1 : -1;
          } }; break;
      case STRICT1:             /* strict combination 2 */
        patcmp = new PatSigCmp () {
          public int compare (int zA,int cA,int zB,int cB,int[] border)
          { if (cA >= cB) return +1;
            boolean xA = (cA < border[zA-zB+2]);
            boolean xB = (cB-cA+1 < border[zB]);
            if ( xA && !xB) return -1;
            if (!xA &&  xB) return +1;
            return ((zA-1)*cA >= (zB-1)*cB) ? +1 : -1;
          } }; break;
      default: return this.size;/* default: keep everything */
    }

    /* --- pattern set reduction --- */
    if ((border == null) || (border.length <= this.zmax)) {
      int[] t = new int[this.zmax+1];
      if (border != null) System.arraycopy(border,0,t,0,border.length);
      border = t;               /* if the border is too short, */
    }                           /* enlarge to max. pattern size */
    keep = new boolean[this.size]; /* default: keep all patterns */
    for (n = 0; n < this.size; n++) keep[n] = true;
    P = new Pattern(this.ibase, new int[this.zmax], 0);
                                /* create a buffer for intersections */
    for (iA = 0; iA < this.size; iA++) {
      A = this.pats[iA]; zA = A.getSize(); cA = A.getSupp();
      for (iB = 0; iB < iA; iB++) {    /* traverse pattern pairs */
        if (!keep[iA] && !keep[iB])
          continue;             /* if both to be discarded, skip */
        B  = this.pats[iB]; zB = B.getSize(); cB = B.getSupp();
        zP = P.isect(A, B);     /* intersect the two patterns */
        if (zP < zB) {          /* if a proper intersection exist */
          cP = P.getSupp();     /* get estimate of isect. support */
          if (!addis || (cP < border[zP]))
            continue;           /* if to ignore or fails border, skip */
          for (n = this.size; --n >= 0; ) {
            Q = this.pats[n]; zQ = Q.getSize(); cQ = Q.getSupp();
            if (zQ <= zP) break;/* if no possible superpattern, abort */
            if (P.isSubOf(Q)    /* is superpattern of intersection */
            &&  patcmp.compare(zQ, cQ, zP, cP, border) < 0)
              keep[n] = false;  /* filter patterns with intersection */
          } }                   /* working backwards */
        else {                  /* if pattern B is a subpattern of A */
          r = patcmp.compare(zA, cA, zB, cB, border);
          if (r > 0) keep[iB] = false;
          if (r < 0) keep[iA] = false;
        }                       /* compare the two patterns and */
      }                         /* unmark the disfavored one */
    }

    /* --- remove disfavored patterns --- */
    for (r = n = 0; r < this.size; r++)
      if (keep[r]) this.pats[n++] = this.pats[r];
    return this.size = n;       /* return new number of patterns */
  }  /* reduce() */

  /*------------------------------------------------------------------*/
  /** Filter an item pattern set by size.
   *  @param  zmin the minimum size of the patterns to keep
   *  @param  zmax the maximum size of the patterns to keep
   *  @return the new number of item patterns
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int filter (int zmin, int zmax)
  {                             /* --- filter patterns by size */
    int i, k;                   /* loop variables */
    for (i = k = 0; i < this.size; i++) { /* traverse the patterns */
      if ((this.pats[i].getSize() >= zmin)
      &&  (this.pats[i].getSize() <= zmax))
        this.pats[++k] = this.pats[i];
      while (--i > k)           /* collect patterns in size range */
        this.pats[i] = null;    /* and clear the emptied entries */
    }
    return this.size = k+1;     /* return the new number of patterns */
  }  /* filter() */

  /*------------------------------------------------------------------*/
  /** Select patterns that are subpatterns, superpatterns or an exact
   *  match of the given pattern (in terms of the contained items).
   *  @param pat  the pattern with which to select patterns
   *  @param mode the mode with which to select patterns; either
   *              <code>EXACT</code>, <code>SUPERPAT</code>, or
   *              <code>SUBPAT</code>.
   *  @return a pattern set with the qualifying patterns (uncloned)
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet select (Pattern pat, int mode)
  {                             /* --- get a pattern selection */
      return select(pat.getAllItems(), pat.getSize(), mode);
  }  /* select() */

  /*------------------------------------------------------------------*/
  /** Select patterns that are subpatterns, superpatterns or an exact
   *  match of the given pattern (in terms of the contained items).
   *  @param  items the items of the pattern to compare to
   *  @param  cnt   the number of items; if negative,
   *                the length of the given item array is used
   *  @param  mode  the mode with which to select patterns; either
   *              <code>EXACT</code>, <code>SUPERPAT</code>, or
   *              <code>SUBPAT</code>.
   *  @return a pattern set with the qualifying patterns (uncloned)
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet select (int[] items, int cnt, int mode)
  {                             /* --- get a pattern selection */
    PatternSet sel = new PatternSet(this.ibase);
    if (mode == SUB) {          /* if to select all subpatterns */
      for (int i = 0; i < this.size; i++) {
        if (this.pats[i].isSubOf(items, cnt))
          sel.add(this.pats[i]);
      } }                       /* find and collect subpatterns */
    else if (mode == SUPER) {   /* if to select all superpatterns */
      for (int i = 0; i < this.size; i++) {
        if (this.pats[i].isSuperOf(items, cnt))
          sel.add(this.pats[i]);
      } }                       /* find and collect superpatterns */
    else {                      /* if to select only exact matches */
      for (int i = 0; i < this.size; i++) {
        if (this.pats[i].equals(items, cnt))
          sel.add(this.pats[i]);
      }                         /* find and collect exact matches */
    }
    return sel;                 /* return the selected patterns */
  }  /* select() */

  /*------------------------------------------------------------------*/
  /** Get a list of all items that occur in at leat one pattern.
   *  @return an array with the identifiers of items that occur
   *          in at least one pattern, sorted by item identifier
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getItems ()
  {                             /* --- get list of occurring items */
    int[] occs = new int[this.ibase.size()];
    for (int i = 0; i < this.size; i++) /* mark occurring items */
      for (int k = this.pats[i].size; --k >= 0; )
        occs[this.pats[i].items[k]] = 1;
    int n = 0;                  /* number of occurring items */
    for (int i = 0; i < occs.length; i++)
      n += occs[i];             /* sum the flag values/count items */
    int[] items = new int[n];   /* create the result array */
    for (int i = occs.length; --i >= 0; )
      if (occs[i] != 0) items[--n] = i;
    return items;               /* collect and return occurring items */
  }  /* getItems() */

  /*------------------------------------------------------------------*/
  /** Recode a pattern set to another item base,
   *  replacing the item base.
   *  @param  ibase the item base to recode the pattern set to
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void recode (IdMap ibase)
  {                             /* --- recode a item pattern set */
    int[] map = this.ibase.getMapTo(ibase);
    for (int i = 0; i < this.size; i++)
      this.pats[i].recode(ibase, map);
  }  /* recode() */             /* recode each item pattern */

  /*------------------------------------------------------------------*/
  /** Pack the patterns, i.e., optimize memory usage.
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void pack ()
  {                             /* --- pack the item patterns */
    for (int i = 0; i < this.size; i++)
      this.pats[i].pack();      /* traverse and pack the patterns */
    if ((this.pats == null) || (this.pats.length <= this.size))
      return;                   /* shrink the item pattern array */
    Pattern[] p = new Pattern[this.size];
    System.arraycopy(this.pats, 0, p, 0, this.size);
    this.pats = p;              /* set the shrunk transaction array */
  }  /* pack() */

  /*------------------------------------------------------------------*/
  /** Write a set of item patterns.
   *  @param  writer the writer to write to
   *  @throws IOException if a write error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer) throws IOException
  {                             /* --- write a pattern set */
    for (int i = 0; i < this.size; i++)
      this.pats[i].write(writer, null, null);
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write a set of item patterns.
   *  @param  writer  the writer to write to
   *  @param  addinfo the additional information to write
   *  @throws IOException if a write error occurs
   *  @since  2017.06.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String addinfo)
    throws IOException
  {                             /* --- write a pattern set */
    for (int i = 0; i < this.size; i++)
      this.pats[i].write(writer, null, addinfo);
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write a set of item patterns.
   *  @param  writer  the writer to write to
   *  @param  isep    the item separator
   *  @param  addinfo the additional information to write
   *  @throws IOException if a write error occurs
   *  @since  2017.06.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String isep, String addinfo)
    throws IOException
  {                             /* --- write a pattern set */
    for (int i = 0; i < this.size; i++)
      this.pats[i].write(writer, isep, addinfo);
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Parse a set of item patterns.
   *  @param  ibase the underlying item base
   *  @param  scan  the scanner to read from
   *  @return the parsed set of patterns
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet parse (IdMap ibase, Scanner scan)
    throws IOException
  {                             /* --- parse a pattern set */
    PatternSet patset = new PatternSet(ibase);
    while (scan.nextToken() != Scanner.T_EOF) {
      scan.pushBack();          /* while not at end of input */
      patset.add(Pattern.parse(patset.ibase, scan));
    }                           /* parse the patterns/item sets */
    return patset;              /* return the created set */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse a set of item patterns.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @return the parsed set of patterns
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet parse (IdMap ibase, Reader reader)
    throws IOException
  { return PatternSet.parse(ibase, new Scanner(reader)); }

  /*------------------------------------------------------------------*/
  /** Parse a set of item patterns.
   *  @param  ibase the underlying item base
   *  @param  desc  the string description to parse
   *  @return the parsed set of patterns
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet parse (IdMap ibase, String desc)
    throws IOException
  { return PatternSet.parse(ibase, new Scanner(desc)); }

  /*------------------------------------------------------------------*/
  /** Parse a set of item patterns.
   *  @param  ibase the underlying item base
   *  @param  inp   the input stream to read from
   *  @return the parsed set of patterns
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static PatternSet parse (IdMap ibase, InputStream inp)
    throws IOException
  { return PatternSet.parse(ibase, new Scanner(inp)); }

  /*------------------------------------------------------------------*/
  /** Main function for testing some basic functionality.
   *  <p>It is tried to parse the file that is given as the first
   *  command line argument as a set of patterns.</p>
   *  @param  args the command line arguments
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    Scanner    scan;            /* table reader to read from */
    PatternSet pats;            /* created pattern set */

    try {                       /* try to read the given file */
      if (args.length <= 0)     /* if no arguments given */
        scan = new Scanner("a b c (10/1,0)\na d e f (10/2,0)\n"
                          +"b d f (10/3,0)\nc d e (10/4,0)");
      else                      /* if a file argument is given */
        scan = new Scanner(new FileReader(args[0]));
      pats = PatternSet.parse(null, scan);
      scan.close();             /* parse and print the pattern set */
      pats.write(new PrintWriter(System.out)); }
    catch (IOException e) {     /* catch and report i/o errors */
      System.err.println(e.getMessage()); return; }
  }  /* main() */

}  /* class PatternSet */
