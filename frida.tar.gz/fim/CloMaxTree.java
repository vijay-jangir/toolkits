/*----------------------------------------------------------------------
  File    : CloMaxTree.java
  Contents: Filter repository for closed and maximal sequences
            (also works for item sets, but is suboptimal for these)
  Author  : Christian Borgelt
  History : 2017.06.22 file created
            2017.06.29 functions declared final for speed
            2017.06.30 pruning for closed and maximal patterns improved
----------------------------------------------------------------------*/
package fim;

import util.IdMap;

/*--------------------------------------------------------------------*/
/** Class for a prefix tree node.
 *  @author Christian Borgelt
 *  @since  2016.10.24
/*--------------------------------------------------------------------*/
class CloMaxNode {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the support of the represented item pattern */
  protected int        supp;
  /** the associated item (last item in represented pattern) */
  protected int        item;
  /** the height of the subtree rooted at this node, which is
   *  measured as the number of nodes (including this node)
   *  on the path to the deepest leaf in this subtree. */
  protected int        height;
  /** the successor node in the sibling list ("right sibling") */
  protected CloMaxNode sibling;
  /** the list of child nodes ("first child")
   *  (linked together by the <code>sibling</code> field) */
  protected CloMaxNode children;

  /*------------------------------------------------------------------*/
  /** Create a new prefix tree node.
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public CloMaxNode()
  { }

  /*------------------------------------------------------------------*/
  /** Check whether a super-pattern with at least a given support
   *  exists in the subtree rooted at this node.
   *  @param  items the item pattern to check
   *  @param  cnt   the number of items in the pattern
   *  @param  supp  the support of the item pattern to check
   *  @return whether a super-pattern with at least
   *          the given support exists
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean hasSuper (int[] items, int cnt, int supp)
  { return this.hasSuper(items, 0, cnt, supp); }

  /*------------------------------------------------------------------*/
  /** Check whether a super-pattern with at least a given support
   *  exists in the subtree rooted at this node.
   *  @param  items  the item pattern to check
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern
   *  @param  supp   the support of the item pattern to check
   *  @return whether a super-pattern with at least
   *          the given support exists
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean hasSuper (int[] items, int offset, int cnt,
                                 int supp)
  {                             /* --- check for a super-pattern */
    CloMaxNode child;           /* traverse the child node list */
    for (child = this.children; child != null; child = child.sibling) {
      if (child.supp < supp)    /* if a child node has insufficient */
        continue;               /* support, it can be skipped */
      if (child.item == items[offset]) {
        if (offset+1 >= cnt)    /* if the last item was matched, */
          return true;          /* abort the search with success */
        if ((child.height >= cnt -offset)
        &&   child.hasSuper(items, offset+1, cnt, supp))
          return true; }        /* recursively check children */
      else {                    /* if at a node with different item */
        if ((child.height >= cnt -offset +1)
        &&   child.hasSuper(items, offset,   cnt, supp))
          return true;          /* recursively check children */
      }                         /* (not skipping the item) */
    }
    return false;               /* return 'no super-pattern exists' */
  }  /* hasSuper() */

  /*------------------------------------------------------------------*/
  /** Show a prefix node/subtree (for debugging purposes).
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show ()
  { this.show(0, null); }

  /*------------------------------------------------------------------*/
  /** Show a prefix node/subtree (for debugging purposes).
   *  @param  indent the indentation level
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show (int indent)
  { this.show(indent, null); }

  /*------------------------------------------------------------------*/
  /** Show a prefix node/subtree (for debugging purposes).
   *  @param  ibase  the underlying item base as a name provider
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show (IdMap ibase)
  { this.show(0, ibase); }

  /*------------------------------------------------------------------*/
  /** Show a prefix node/subtree (for debugging purposes).
   *  @param  indent the indentation level
   *  @param  ibase  the underlying item base as a name provider
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show (int indent, IdMap ibase)
  {                             /* --- show a prefix node/subtree */
    for (int i = 0; i < indent; i++)
      System.out.print("   ");  /* indent the output line */
    if ((item >= 0) && (ibase != null))
      System.out.print((String)ibase.get(item) + "/");
    System.out.println(this.item +":" +this.supp +":" +this.height);
    CloMaxNode child;           /* print the node information */
    for (child = this.children; child != null; child = child.sibling)
      child.show(indent+1, ibase); /* recursively show the subtrees */
  }  /* Show() */

}  /* class CloMaxNode */


/*--------------------------------------------------------------------*/
/** Class for a prefix tree to filter for closed and maximal item
 *  sequences (also works for item sets, but is suboptimal for these).
 *  @author Christian Borgelt
 *  @since  2016.10.24 */
/*--------------------------------------------------------------------*/
public class CloMaxTree {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** target pattern subtype mask; to extract the target pattern
   *  subtype, that is, <code>CLOSED</code> or <code>MAXIMAL</code> */
  public static final int SUBTYPEMASK = 0x00ff;
  /** target pattern type mask; to extract the main target pattern type,
   *  that is, <code>SEQUENCE</code> */
  public static final int TYPEMASK    = ~SUBTYPEMASK;
  /** target pattern type: item sets (item order is ignored) */
  public static final int ITEMSET     = 0x0000;
  /** target pattern type: paths represent (general) sequences
   *  (with and without repetition) */
  public static final int SEQUENCE    = 0x0200;
  /** target pattern subtype: simple frequent item patterns */
  public static final int FREQUENT    = 0x0000;
  /** target pattern subtype: closed frequent item patterns;
   *  to be combined with or <code>SEQUENCE</code> */
  public static final int CLOSED      = 0x0001;
  /** target pattern subtype: maximal frequent item patterns;
   *  to be combined with <code>SEQUENCE</code> */
  public static final int MAXIMAL     = 0x0002;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  protected IdMap           ibase;
  /** the target type of the filtering; <code>SEQUENCE</code> as
   *  the main target pattern type and either <code>FREQUENT</code>,
   *  <code>CLOSED</code> or <code>MAXIMAL</code> as the target
   *  pattern subtype */
  protected int             target;
  /** the direction of the item order */
  protected int             dir;
  /** the associated item (for a prefix tree chain) */
  protected int             item;
  /** the root node of the prefix tree */
  protected CloMaxNode      root;
  /** the (last) positions of the items in an item pattern
   *  (<code>-1</code> if an item does not occur) */
  protected int[]           last;
  /** the item buffer for collecting/reporting the patterns */
  protected int[]           items;
  /** the minimum length of a pattern (number of items) */
  protected int             zmin;
  /** the maximum length of a pattern (number of items) */
  protected int             zmax;
  /** the base support (support of empty item pattern/database size) */
  protected int             s_base;
  /** the pattern receiver for collecting the result patterns */
  protected PatternReceiver patrec;

  /*------------------------------------------------------------------*/
  /** Create an empty prefix tree for closed/maximal filtering.
   *  @param  ibase  the underlying item base
   *  @param  target the target pattern type of the prefix tree
   *                 (main target pattern type <code>SEQUENCE</code>
   *                 and target pattern subtype <code>CLOSED</code>
   *                 or <code>MAXIMAL</code>)
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public CloMaxTree (IdMap ibase, int target)
  { this(ibase, target, -1); }

  /*------------------------------------------------------------------*/
  /** Create an empty prefix tree for closed/maximal filtering.
   *  @param  ibase  the underlying item base
   *  @param  target the target pattern type of the prefix tree
   *                 (main target pattern type <code>SEQUENCE</code>
   *                 and target pattern subtype <code>CLOSED</code>
   *                 or <code>MAXIMAL</code>)
   *  @param  dir    the direction of the item order
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public CloMaxTree (IdMap ibase, int target, int dir)
  {                             /* --- create a c/m prefix tree */
    this.ibase  = (ibase != null) ? ibase : new IdMap();
    this.target = target;       /* initialize the tree's fields and */
    this.dir    = dir;          /* create root node and initialize it */
    this.root   = new CloMaxNode();
    this.root.item    = this.item = -1;
    this.root.supp    = this.root.height = 0;
    this.root.sibling = this.root.children = null;
    this.last = new int[ibase.getSize()];
    for (int i = this.ibase.getSize(); --i >= 0; )
      this.last[i] = -1;        /* initialize (last) item positions */
  }  /* CloMaxTree() */

  /*------------------------------------------------------------------*/
  /** Clear a prefix tree for closed/maximal filtering.
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void clear ()
  {                             /* --- clear a c/m prefix tree */
    this.root.item = this.item = -1; /* reinitialize the root node */
    this.root.supp = this.root.height = 0;
    this.root.sibling = this.root.children = null;
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Add a new item pattern to this prefix tree.
   *  @param  items the item pattern to add
   *  @param  cnt   the number of items in the pattern to add
   *  @param  supp  the support of the item pattern to add
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void add (int[] items, int cnt, int supp)
  { this.add(items, 0, cnt, supp); }

  /*------------------------------------------------------------------*/
  /** Add a new item pattern to a prefix tree.
   *  @param  items  the item pattern to add
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern to add
   *                 (counted from 0, not from <code>offset</code>)
   *  @param  supp   the support of the pattern to add
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void add (int[] items, int offset, int cnt, int supp)
  {                             /* --- add a pattern to the tree */
    CloMaxNode node = this.root;/* start at the root node */
    CloMaxNode parent;          /* parent of the current child */
    CloMaxNode pred;            /* predecessor of the current child */
    int i = offset-1;           /* index of the current item */
    do {                        /* traverse the items of the pattern */
      if (supp > node.supp)     /* adapt the node support */
        node.supp = supp;       /* (root represents empty pattern) */
      if (node.height < cnt -i) /* adapt the subtree height */
        node.height = cnt -i;   /* (may get increased by this seq.) */
      if (++i >= cnt) return;   /* if all items are processed, abort */
      parent = node;            /* note current node as parent and */
      pred   = null;            /* invalidate the predecessor node */
      node   = node.children;   /* get the list of child nodes */
      if (this.dir < 0) {       /* if descending item order */
        while ((node != null) && (node.item > items[i])) {
          pred = node;          /* try to find the current item */
          node = node.sibling;  /* (always remember predecessor) */
        } }
      else {                    /* if ascending item order */
        while ((node != null) && (node.item < items[i])) {
          pred = node;          /* try to find the current item */
          node = node.sibling;  /* (always remember predecessor) */
        }
      }                         /* while current item was found */
    } while ((node != null) && (node.item == items[i]));

    node = new CloMaxNode();
    node.supp   = supp;         /* and initialize its fields */
    node.item   = items[i];
    node.height = cnt -i;
    if (pred == null) {         /* if to insert before first child */
      node.sibling = parent.children;
      parent.children = node; } /* add node as the first child */
    else {                      /* if to insert somewhere else */
      node.sibling = pred.sibling;
      pred.sibling = node;      /* add the new node as the successor */
    }                           /* of the noted predecessor sibling */

    while (++i < cnt) {         /* traverse the remaining items */
      node = node.children = new CloMaxNode();
      node.supp    = supp;
      node.item    = items[i];
      node.height  = cnt -i;
      node.sibling = null;      /* initialize the prefix tree node */
    }
    node.children = null;       /* last created node is a leaf */
  }  /* add() */

  /*------------------------------------------------------------------*/
  /** Get the maximal support of any item pattern in the prefix tree.
   *  @return the maximal support of any item pattern in the prefix tree
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMaxSupp ()
  { return this.root.supp; }

  /*------------------------------------------------------------------*/
  /** Get the maximal support of any item pattern in the prefix tree.
   *  @return the maximal support of any item pattern in the prefix tree
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp ()
  { return this.root.supp; }

  /*------------------------------------------------------------------*/
  /** Get the support of a given item pattern.
   *  @param  items the item pattern for which to get the support
   *  @param  cnt   the number of items in the pattern
   *  @return the support of the item pattern
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp (int[] items, int cnt)
  { return this.getSupp(items, 0, cnt); }

  /*------------------------------------------------------------------*/
  /** Get the support of a given item pattern.
   *  @param  items  the item pattern for which to get the support
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern
   *                 (counted from 0, not from <code>offset</code>)
   *  @return the support of the item pattern
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp (int[] items, int offset, int cnt)
  {                             /* --- get support of a pattern */
    CloMaxNode node = this.root;/* start at the root node */
    for (int i = offset; i < cnt; i++) { /* traverse the item pattern */
      if (cnt -i > node.height) /* check whether subtree is high */
        return -1;              /* enough, otherwise abort */
      node = node.children;     /* try to find node with curr. item */
      if (this.dir < 0)         /* if descending item order */
        while ((node != null) && (node.item > items[i]))
          node = node.sibling;  /* try to find the next item */
      else                      /* if ascending item order */
        while ((node != null) && (node.item < items[i]))
          node = node.sibling;  /* try to find the next item */
      if ((node == null) || (node.item != items[i]))
        return -1;              /* if item does not exist, */
    }                           /* abort the search with failure */
    return node.supp;           /* return support of the item seq. */
  }  /* getSupp() */

  /*------------------------------------------------------------------*/
  /** Check whether a super-pattern with at least a given support
   *  exists in this prefix tree.
   *  @param  items the item pattern to check
   *  @param  cnt   the number of items in the pattern
   *  @param  supp  the support of the item pattern to check
   *  @return whether a super-pattern with at least
   *          the given support exists
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean hasSuper (int[] items, int cnt, int supp)
  { return this.root.hasSuper(items, 0, cnt, supp); }

  /*------------------------------------------------------------------*/
  /** Check whether a super-pattern with at least a given support
   *  exists in this prefix tree.
   *  @param  items  the item pattern to check
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern
   *                 (counted from 0, not from <code>offset</code>)
   *  @param  supp   the support of the item pattern to check
   *  @return whether a super-pattern with at least
   *          the given support exists
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean hasSuper (int[] items, int offset, int cnt,
                                 int supp)
  { return this.root.hasSuper(items, offset, cnt, supp); }

  /*------------------------------------------------------------------*/
  /** Clone the subtree rooted at a given node
   *  (that is, clone the node itself and its descendants).
   *  @param  src the root node of the source subtree
   *  @return the root node of the created subtree clone
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final CloMaxNode clone (CloMaxNode src)
  {                             /* --- clone a subtree */
    CloMaxNode dst = new CloMaxNode();
    dst.supp     = src.supp;    /* clone the root of the subtree */
    dst.item     = src.item;
    dst.height   = src.height;
    dst.children = null;
    CloMaxNode node = src.children;
    if (node != null) {         /* if there are child nodes, */
      CloMaxNode clone = this.clone(node);
      dst.children = clone;     /* store first child in root node */
      for (node = node.sibling; node != null; node = node.sibling) {
        clone.sibling = this.clone(node);
        clone = clone.sibling;  /* clone each sibling node */
      }
      clone.sibling = null;     /* terminate the sibling list */
    }
    return dst;                 /* return root node of created clone */
  }  /* clone() */

  /*------------------------------------------------------------------*/
  /** Merge a subtree rooted at a given node to the subtree rooted
   *  at this node (by cloning the nodes of the source tree).
   *  <p>This function is for positive/ascending item direction.
   *  For negative/descending item direction, use
   *  <code>mergeNeg()</code>.</p>
   *  @param  dst the root node of the destination subtree to merge
   *  @param  src the root node of the source subtree to merge
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void mergePos (CloMaxNode dst, CloMaxNode src)
  {                             /* --- merge a subtree to another */
    CloMaxNode e = null;        /* end of output child node list */
    CloMaxNode s = src.children;
    CloMaxNode d = dst.children;
    while ((s != null) && (d != null)) {
      CloMaxNode t;             /* while child lists are not empty */
      if (d.item < s.item) {    /* if an item is only in destination */
        t = d;                  /* simply transfer its subtree */
        d = d.sibling; }        /* go to the next dest. child node */
      else if (d.item > s.item){/* if an item is only in source */
        t = this.clone(s);      /* copy its subtree to destination */
        s = s.sibling; }        /* go to the next child node */
      else {                    /* if the item is in both lists */
        this.mergePos(d, s);    /* recursively merge the subtrees */
        t = d;                  /* transfer result to the dest. */
        d = d.sibling; s = s.sibling;
      }                         /* go to the next child nodes */
      if (e == null) e = d.children = t;
      else           e = e.sibling  = t;
    }                           /* append the node to transfer */
    for ( ; s != null; s = s.sibling) {
      if (e == null) e = dst.children = this.clone(s);
      else           e = e.sibling    = this.clone(s);
    }                           /* append remaining sibling nodes */
    if (e == null) dst.children = d;  /* append remaining nodes and */
    else           e.sibling    = d;  /* update height and support */
    if (dst.height < src.height) dst.height = src.height;
    if (dst.supp   < src.supp)   dst.supp   = src.supp;
  }  /* mergePos() */

  /*------------------------------------------------------------------*/
  /** Merge a subtree rooted at a given node to the subtree rooted
   *  at this node (by cloning the nodes of the source tree).
   *  <p>This function is for negative/descending item direction.
   *  For postive/ascending item direction, use
   *  <code>mergePos()</code>.</p>
   *  @param  dst the root node of the destination subtree to merge
   *  @param  src the root node of the subtree to merge to this subtree
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void mergeNeg (CloMaxNode dst, CloMaxNode src)
  {                             /* --- merge a subtree to another */
    CloMaxNode e = null;        /* end of output child node list */
    CloMaxNode s = src.children;
    CloMaxNode d = dst.children;
    while ((s != null) && (d != null)) {
      CloMaxNode t;             /* while child lists are not empty */
      if (d.item > s.item) {    /* if an item is only in destination */
        t = d;                  /* simply transfer its subtree */
        d = d.sibling; }        /* go to the next dest. child node */
      else if (d.item < s.item){/* if an item is only in source */
        t = this.clone(s);      /* copy its subtree to destination */
        s = s.sibling; }        /* go to the next child node */
      else {                    /* if the item is in both lists, */
        this.mergeNeg(d, s);    /* recursively merge the subtrees */
        t = d;                  /* transfer result to the dest. */
        d = d.sibling; s = s.sibling;
      }                         /* go to the next child nodes */
      if (e == null) e = dst.children = t;
      else           e = e.sibling    = t;
    }                           /* append the node to transfer */
    for ( ; s != null; s = s.sibling) {
      if (e == null) e = dst.children = this.clone(s);
      else           e = e.sibling    = this.clone(s);
    }                           /* append remaining sibling nodes */
    if (e == null) dst.children = d; /* append remaining nodes and */
    else           e.sibling    = d; /* update height and support */
    if (dst.height < src.height) dst.height = src.height;
    if (dst.supp   < src.supp)   dst.supp   = src.supp;
  }  /* mergeNeg() */

  /*------------------------------------------------------------------*/
  /** Project a prefix tree to a given item.
   *  @param  src the node of the source tree from which to project
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final void project (CloMaxNode src)
  {                             /* --- project a c/m prefix tree */
    CloMaxNode node;            /* traverse the child node list */
    for (node = src.children; node != null; node = node.sibling) {
      if (node.item != this.item)  /* if node item is different, */
        this.project(node);     /* project corresponding subtree */
      else if (this.dir < 0)    /* if node item is projection item */
           this.mergeNeg(this.root, node);
      else this.mergePos(this.root, node);
    }                           /* (respect item direction) */
  }  /* project() */

  /*------------------------------------------------------------------*/
  /** Project a prefix tree to a given item.
   *  <p>The result is a prefix tree that represents all suffixes in
   *  the source tree that start with the given item. The support
   *  values associated with these suffixes are the maxima over all
   *  corresponding suffixes in the source prefix tree.</p>
   *  @param  item the item to project the prefix tree to
   *  @param  dst  the destination prefix tree
   *               in which to store the projection
   *  @return the given destination prefix tree, or a new prefix tree if
   *          <code>dst</code> is <code>null</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final CloMaxTree project (int item, CloMaxTree dst)
  {                             /* --- project a c/m prefix tree */
    if (dst == null)            /* create a new prefix tree if nec. */
      dst = new CloMaxTree(this.ibase, this.target, this.dir);
    dst.item = item;            /* note the projection item and */
    dst.root.supp = 0;          /* clear maximum item set support */
    dst.project(this.root);     /* project this tree to the item */
    return dst;                 /* return the destination prefix tree */
  }  /* project() */

  /*------------------------------------------------------------------*/
  /** For a given item pattern, prune all sub-patterns that are
   *  represented by paths of the prefix tree rooted at the given
   *  node and have at most the support of the given item pattern.
   *  @param  root   the root node of the subtree to prune
   *  @param  items  the item pattern to prune with
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern
   *  @param  supp   the support of the item pattern to prune with
   *  @return the maximum support of a child node (of <code>root</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final int pruneClo (CloMaxNode root, int[] items,
                                int offset, int cnt, int supp)
  {                             /* --- prune a c/m prefix tree */
    CloMaxNode e = null;        /* end of the output child list */
    int smax = -1;              /* maximum support of a child node */
    int hmax =  0;              /* maximum height  of a child node */
    for (CloMaxNode node = root.children; node != null; ) {
      int s = 1;                /* default: keep the current node */
      if (this.last[node.item] >= offset) {
        int o;                  /* if node may represent a sub-seq. */
        for (o = offset; o < cnt; o++)
          if (items[o] == node.item)
            break;              /* find item in pattern suffix */
        /* Note that the above loop must find the item, since */
        /* items[this.last[node.item]] == node.item, but it   */
        /* may also occur another time before that position.  */
        s = this.pruneClo(node, items, o+1, cnt, supp);
        if (node.supp > supp) s = node.supp;
        else if (s >= 0)      node.supp = s;
      }                         /* set support to maximum of children */
      if (s < 0)                /* if to delete the current node, */
        node = node.sibling;    /* simply go to the sibling */
      else {                    /* if to keep the current node */
        if (hmax < node.height) hmax = node.height;
        if (smax < node.supp)   smax = node.supp;
        if (e == null) e = root.children = node;
        else           e = e.sibling     = node;
        node = node.sibling;    /* append node to output list */
      }                         /* and go to the next child node */
    }                           /* afterward terminate output list */
    if (e == null) root.children = null;
    else           e.sibling     = null;
    root.height = hmax+1;       /* store the new root node height */
    return smax;                /* return maximum support of a child */
  }  /* pruneClo() */

  /*------------------------------------------------------------------*/
  /** For a given item pattern, prune all sub-patterns that are
   *  represented by paths of the prefix tree rooted at the given node.
   *  @param  root   the root node of the subtree to prune
   *  @param  items  the item pattern to prune with
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern
   *  @return the maximum support of a child node (of <code>root</code>)
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final int pruneMax (CloMaxNode root, int[] items,
                                int offset, int cnt)
  {                             /* --- prune a c/m prefix tree */
    CloMaxNode e = null;        /* end of the output child list */
    int smax = -1;              /* maximum support of a child node */
    int hmax =  0;              /* maximum height  of a child node */
    for (CloMaxNode node = root.children; node != null; ) {
      int s = 1;                /* default: keep the current node */
      if (this.last[node.item] >= offset) {
        int o;                  /* if node may represent a sub-seq. */
        for (o = offset; o < cnt; o++)
          if (items[o] == node.item)
            break;              /* find item in pattern suffix */
        /* Note that the above loop must find the item, since */
        /* items[this.last[node.item]] == node.item, but it   */
        /* may also occur another time before that position.  */
        s = this.pruneMax(node, items, o+1, cnt);
        if (s >= 0) node.supp = s;
      }                         /* update the node support */
      if (s < 0)                /* if to delete the current node */
        node = node.sibling;    /* simply go to the sibling */
      else {                    /* if to keep the current node */
        if (hmax < node.height) hmax = node.height;
        if (smax < node.supp)   smax = node.supp;
        if (e == null) e = root.children = node;
        else           e = e.sibling     = node;
        node = node.sibling;    /* append node to output list */
      }                         /* and go to the next child node */
    }                           /* afterward terminate output list */
    if (e == null) root.children = null;
    else           e.sibling     = null;
    root.height = hmax+1;       /* store the new root node height */
    return smax;                /* return maximum support of a child */
  }  /* pruneMax() */

  /*------------------------------------------------------------------*/
  /** For a given item pattern, prune all sub- or super-patterns
   *  (depending on the target type of this tree) that are represented
   *  by paths of this prefix tree.
   *  @param  items the item pattern to prune with
   *  @param  cnt   the number of items in the pattern
   *  @param  supp  the support of the item pattern to prune with
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void prune (int[] items, int cnt, int supp)
  { this.prune(items, 0, cnt, supp); }

  /*------------------------------------------------------------------*/
  /** For a given item pattern, prune all sub- or super-patterns
   *  (depending on the target type of this tree) that are represented
   *  by paths of this prefix tree.
   *  @param  items  the item pattern to prune with
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern
   *                 (counted from 0, not from <code>offset</code>)
   *  @param  supp   the support of the pattern to prune with
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void prune (int[] items, int offset, int cnt, int supp)
  {                             /* --- prune a c/m prefix tree */
    for (int i = offset; i < cnt; i++)
      this.last[items[i]] = i;  /* set the (last) item positions */
    if ((this.target & MAXIMAL) != 0)
      this.pruneMax(this.root, items, offset, cnt);
    else                        /* recursively prune the tree */
      this.pruneClo(this.root, items, offset, cnt, supp);
    for (int i = offset; i < cnt; i++)
      this.last[items[i]] = -1; /* clear the (last) item positions */
  }  /* prune() */

  /*------------------------------------------------------------------*/
  /** Update the prefix tree with a new item pattern.
   *  @param  pat the item pattern to update with
   *  @return <code>true</code> if the prefix tree was modified and
   *          <code>false</code> otherwise
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (Pattern pat)
  { return this.update(pat.items, 0, pat.size, pat.s_pat, true); }

  /*------------------------------------------------------------------*/
  /** Update the prefix tree with a new item pattern.
   *  @param  pat   the item pattern to update with
   *  @param  prune whether to prune sub- or super-patterns (depending
   *                on the target type) from the prefix tree
   *  @return <code>true</code> if the prefix tree was modified and
   *          <code>false</code> otherwise
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (Pattern pat, boolean prune)
  { return this.update(pat.items, 0, pat.size, pat.s_pat, prune); }

  /*------------------------------------------------------------------*/
  /** Update the prefix tree with a new item pattern.
   *  @param  items the item pattern to update with
   *  @param  cnt   the number of items in the pattern
   *                (counted from 0, not from <code>offset</code>)
   *  @param  supp  the support of the pattern to update with
   *  @return <code>true</code> if the prefix tree was modified and
   *          <code>false</code> otherwise
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (int[] items, int cnt, int supp)
  { return this.update(items, 0, cnt, supp, true); }

  /*------------------------------------------------------------------*/
  /** Update the prefix tree with a new item pattern.
   *  @param  items the item pattern to update with
   *  @param  cnt   the number of items in the pattern
   *                (counted from 0, not from <code>offset</code>)
   *  @param  supp  the support of the pattern to update with
   *  @param  prune whether to prune sub- or super-patterns (depending
   *                on the target type) from the prefix tree
   *  @return <code>true</code> if the prefix tree was modified and
   *          <code>false</code> otherwise
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (int[] items, int cnt, int supp,
                               boolean prune)
  { return this.update(items, 0, cnt, supp, prune); }

  /*------------------------------------------------------------------*/
  /** Update the prefix tree with a new pattern.
   *  @param  items   the item pattern to update with
   *  @param  offset  the offset to the first item to consider
   *  @param  cnt     the number of items in the pattern
   *                  (counted from 0, not from <code>offset</code>)
   *  @param  supp    the support of the pattern to update with
   *  @return <code>true</code> if the prefix tree was modified and
   *          <code>false</code> otherwise
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (int[] items, int offset, int cnt,
                               int supp)
  { return this.update(items, offset, cnt, supp, true); }

  /*------------------------------------------------------------------*/
  /** Update the prefix tree with a new pattern.
   *  @param  items  the item pattern to update with
   *  @param  offset the offset to the first item to consider
   *  @param  cnt    the number of items in the pattern
   *                 (counted from 0, not from <code>offset</code>)
   *  @param  supp   the support of the pattern to update with
   *  @param  prune  whether to prune sub- or super-patterns (depending
   *                 on the target type) from the prefix tree
   *  @return <code>true</code> if the prefix tree was modified and
   *          <code>false</code> otherwise
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (int[] items, int offset, int cnt,
                               int supp, boolean prune)
  {                             /* --- update a c/m prefix tree */
    int s = ((this.target & MAXIMAL) != 0) ? 1 : supp;
    if (this.hasSuper(items, offset, cnt, s))
      return false;             /* if super-pattern contained, abort */
    if (prune)                  /* if requested, prune the tree */
      this.prune(items, offset, cnt, supp);
    this.add(items, offset, cnt, supp);
    return true;                /* add the new item pattern */
  }  /* update() */

  /*------------------------------------------------------------------*/
  /** Recursively collect closed item patterns from the tree.
   *  @param  node the current node of the prefix tree
   *  @param  size the current size of the item pattern (depth in tree)
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final void collectClo (CloMaxNode node, int size)
  {                             /* --- collect closed patterns */
    int smax = -1;              /* maximum extension support */
    CloMaxNode child;           /* traverse the child nodes */
    for (child = node.children; child != null; child = child.sibling){
      if (smax < child.supp) smax = child.supp;
      this.items[size] = child.item;   /* add node's item to pattern */
      if (size < this.zmax) this.collectClo(child, size+1);
    }                           /* collect item patterns recursively */
    if ((smax < node.supp) && (size >= this.zmin)) {
      this.patrec.receive(this.items, size, node.supp,
                          (this.s_base >= 0) ? this.s_base : node.supp);
    }                           /* add current pattern to result set */
  }  /* collectClo() */

  /*------------------------------------------------------------------*/
  /** Recursively collect maximal item patterns from the tree.
   *  @param  node the current node of the prefix tree
   *  @param  size the current size of the item pattern (depth in tree)
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final void collectMax (CloMaxNode node, int size)
  {                             /* --- collect maximal patterns */
    CloMaxNode child;           /* traverse the child nodes */
    for (child = node.children; child != null; child = child.sibling){
      this.items[size] = child.item;   /* add node's item to pattern */
      if (size < zmax) this.collectMax(child, size+1);
    }                           /* collect item patterns recursively */
    if ((node.children == null) && (size >= this.zmin)) {
      this.patrec.receive(this.items, size, node.supp,
                          (this.s_base >= 0) ? this.s_base : node.supp);
    }                           /* add current pattern to result set */
  }  /* collectMax() */

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet report ()
  { return (PatternSet)this.report(null, -1, 0, Integer.MAX_VALUE); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code>, the root node
   *                 is used, if <code>-2</code>, the item pattern
   *                 support is used
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet report (int s_base)
  { return (PatternSet)this.report(null, s_base, 0, Integer.MAX_VALUE);}

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code>, the root node
   *                 is used, if <code>-2</code>, the item pattern
   *                 support is used
   *  @param  zmin   the minimum size of an item pattern
   *                 (number of items)
   *  @param  zmax   the maximum size of an item pattern
   *                 (number of items)
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet report (int s_base, int zmin, int zmax)
  { return (PatternSet)this.report(null, s_base, zmin, zmax); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  patrec the receiver for collecting the item patterns
   *  @return the argument <code>patset</code>, or a new pattern set
   *          if this argument is <code>null</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternReceiver report (PatternReceiver patrec)
  { return this.report(patrec, -1, 0, Integer.MAX_VALUE); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  patrec the receiver for collecting the item patterns
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code> the root node support
   *                 is used, if <code>-2</code>, the item pattern
   *                 support is used
   *  @return the argument <code>patset</code>, or a new pattern set
   *          if this argument is <code>null</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternReceiver report (PatternReceiver patrec,
                                       int s_base)
  { return this.report(patrec, s_base, 0, Integer.MAX_VALUE); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  patrec the receiver for collecting the item patterns
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code> the root node support
   *                 is used, if <code>-2</code>, the item pattern
   *                 support is used
   *  @param  zmin   the minimum size of an item pattern
   *                 (number of items)
   *  @param  zmax   the maximum size of an item pattern
   *                 (number of items)
   *  @return the argument <code>patset</code>, or a new pattern set
   *          if this argument is <code>null</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternReceiver report (PatternReceiver patrec,
                                       int s_base, int zmin, int zmax)
  {                             /* --- report c/m item patterns */
    if (patrec == null)         /* create a pattern set if needed */
      patrec = new PatternSet(this.ibase);
    this.patrec = patrec;       /* note receiver and create buffer */
    this.items  = new int[this.root.height];
    this.s_base = (s_base == -1) ? this.root.supp : s_base;
    this.zmin   = zmin;         /* note the pattern size range */
    this.zmax   = (zmax >= 0) ? zmax : Integer.MAX_VALUE;
    if      ((this.target & MAXIMAL) != 0)
      this.collectMax(this.root, 0);
    else if ((this.target & CLOSED)  != 0)
      this.collectClo(this.root, 0);
    this.items  = null;         /* clear the internal buffers */
    this.patrec = null;         /* (allow memory to be clean up) */
    return patrec;              /* return the pattern receiver */
  }  /* report() */

  /*------------------------------------------------------------------*/
  /** Show a closed/maximal filter prefix tree (for debugging purposes).
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show ()
  { this.show(0); }

  /*------------------------------------------------------------------*/
  /** Show a closed/maximal filter prefix tree (for debugging purposes).
   *  @param  indent the indentation level
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void show (int indent)
  {                             /* --- show a prefix tree */
    for (int i = 0; i < indent; i++)
      System.out.print("   ");  /* indent the output line */
    System.out.print("item: "); /* start with associated item */
    if (this.item >= 0)         /* print the item name */
      System.out.print((String)this.ibase.get(this.item) + "/");
    System.out.println(this.item);
    this.root.show(indent, this.ibase);
  }  /* show() */               /* show the nodes recursively */

}  /* class CloMaxTree */
