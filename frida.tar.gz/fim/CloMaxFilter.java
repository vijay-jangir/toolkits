/*----------------------------------------------------------------------
  File    : CloMaxFilter.java
  Contents: Filter repository for closed and maximal sequences
            (also works for item sets, but is suboptimal for these)
  Author  : Christian Borgelt
  History : 2017.06.22 file created
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package fim;

import util.IdMap;

/*--------------------------------------------------------------------*/
/** Class for filter repository for closed and maximal item patterns.
 *  The repository takes the form of a chain of <code>CloMaxTree</code>.
 *  @author Christian Borgelt
 *  @since  2016.10.24
/*--------------------------------------------------------------------*/
public class CloMaxFilter {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** the block size for the prefix tree array */
  private static final int BLKSIZE     = 32;
  /** target pattern type mask; to extract the main target pattern type,
   *  that is, <code>SEQUENCE</code> */
  public  static final int TYPEMASK    = CloMaxTree.TYPEMASK;
  /** target pattern subtype mask; to extract the target pattern
   *  subtype, that is, <code>CLOSED</code> or <code>MAXIMAL</code> */
  public  static final int SUBTYPEMASK = CloMaxTree.SUBTYPEMASK;
  /** target pattern type: item sets (item order is ignored) */
  public  static final int ITEMSET     = CloMaxTree.ITEMSET;
  /** target pattern type: paths represent (general) sequences
   *  (with and without repetition) */
  public  static final int SEQUENCE    = CloMaxTree.SEQUENCE;
  /** target pattern subtype: simple frequent item patterns */
  public  static final int FREQUENT    = CloMaxTree.FREQUENT;
  /** target pattern subtype: closed frequent item patterns;
   *  to be combined with <code>SEQUENCE</code> */
  public  static final int CLOSED      = CloMaxTree.CLOSED;
  /** target pattern subtype: maximal frequent item patterns;
   *  to be combined with <code>SEQUENCE</code> */
  public  static final int MAXIMAL     = CloMaxTree.MAXIMAL;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  public IdMap        ibase;
  /** the target type of the filtering; <code>SEQUENCE</code> as
   *  the main target pattern type and either <code>FREQUENT</code>,
   *  <code>CLOSED</code> or <code>MAXIMAL</code> as the target
   *  pattern subtype */
  public int          target;
  /** the direction of the item order */
  public int          dir;
  /** the current number of prefix trees */
  public int          size;
  /** the chain of (conditional) prefix trees */
  public CloMaxTree[] trees;

  /*------------------------------------------------------------------*/
  /** Create a closed/maximal filter
   *  (in the form of a prefix tree chain/hierarchy).
   *  @param  ibase  the underlying item base
   *  @param  target the target pattern type of the prefix tree
   *                 (main target pattern type <code>SEQUENCE</code>
   *                 and target pattern subtype <code>CLOSED</code>
   *                 or <code>MAXIMAL</code>
   *  @param  dir    the direction of the item order
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public CloMaxFilter (IdMap ibase, int target, int dir)
  {                             /* --- create a closed/max. filter */
    this.ibase    = (ibase != null) ? ibase : new IdMap();
    this.target   = target;     /* initialize the filter's fields */
    this.dir      = dir;        /* create a prefix tree array */
    this.trees    = new CloMaxTree[BLKSIZE];
    this.trees[0] = new CloMaxTree(ibase, target, dir);
    this.size     = 1;          /* create and init. a root tree */
  }  /* CloMaxFilter() */

  /*------------------------------------------------------------------*/
  /** Create a closed/maximal filter
   *  (in the form of a prefix tree chain/hierarchy).
   *  @param  ibase  the underlying item base
   *  @param  target the target pattern type of the prefix tree
   *                 (main target pattern type <code>SEQUENCE</code>
   *                 and target pattern subtype <code>CLOSED</code>
   *                 or <code>MAXIMAL</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public CloMaxFilter (IdMap ibase, int target)
  { this(ibase, target, -1); }

  /*------------------------------------------------------------------*/
  /** Clear the closed/maximal filter.
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void clear ()
  {                             /* --- clear the c/m filter */
    for (int i = 1; i < this.trees.length; i++)
      this.trees[i] = null;     /* delete all projection trees */
    this.trees[0].clear();      /* clear the root tree */
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the support of the current prefix.
   *  @return the support of the current prefix
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp ()
  { return this.trees[(this.size > 0) ? this.size-1 : 0].getMaxSupp(); }

  /*------------------------------------------------------------------*/
  /** Retrieve one of the prefix trees of the prefix tree chain.
   *  @param  index the index of the prefix tree to retrieve
   *  @return the prefix tree with index <code>index</code>
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final CloMaxTree getTree (int index)
  { return this.trees[index]; }

  /*------------------------------------------------------------------*/
  /** Retrieve one of the prefix trees of the prefix tree chain.
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final CloMaxTree getTree ()
  { return this.trees[0]; }

  /*------------------------------------------------------------------*/
  /** Add an item to the current prefix
   *  (involves projecting the last prefix tree to the item).
   *  @param  item the item to add to the current prefix
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void add (int item)
  {                             /* --- add an item to the prefix */
    if (this.size >= this.trees.length) {
      int z = this.size + ((this.size > BLKSIZE)
                          ? this.size >> 1 : BLKSIZE);
      CloMaxTree[] t = new CloMaxTree[z];
      System.arraycopy(this.trees, 0, t, 0, this.size);
      this.trees = t;           /* enlarge the prefix tree array */
    }                           /* and copy the existing trees */
    this.trees[this.size] =     /* project the last prefix tree and */
      this.trees[this.size-1].project(item, this.trees[this.size]);
    this.size += 1;             /* increment the prefix tree counter */
  }  /* add() */

  /*------------------------------------------------------------------*/
  /** Add an item to the current prefix
   *  (involves projecting the last prefix tree to the item).
   *  @param  item the item to add to the current prefix
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void addItem (int item)
  { this.add(item); }

  /*------------------------------------------------------------------*/
  /** Remove items from the current prefix.
   *  @param  cnt the number of items to remove from the current prefix
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void remove (int cnt)
  {                             /* --- remove items from the prefix */
    int z = (cnt < this.size) ? this.size -cnt : 1;
    while (this.size > z)       /* clear trees down to new number */
      this.trees[--this.size].clear();
  }  /* remove() */

  /*------------------------------------------------------------------*/
  /** Remove an item from the current prefix.
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void remove ()
  { this.remove(1); }

  /*------------------------------------------------------------------*/
  /** Remove an item from the current prefix.
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void removeItem ()
  { this.remove(1); }

  /*------------------------------------------------------------------*/
  /** Update a closed/maximal filter with a new item pattern
   *  (that is, remove all item patterns that are subpatterns of this
   *  pattern [for maximal pattern filtering] or subpatterns with the
   *  same support [for closed pattern filtering] and add the pattern
   *  to the filter unless it is subsumed [is a subpattern or a
   *  subpattern with the same support, respectively] by an item
   *  pattern in the filter).
   *  @param  items the item pattern to add
   *  @param  cnt   the number of items in the pattern to add
   *  @param  supp  the support of the item pattern to add
   *  @param  prune whether to prune sub- or super-patterns (depending
   *                on the target type) from the prefix tree
   *  @return whether the given pattern was added to the filter
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (int[] items, int cnt, int supp,
                               boolean prune)
  {                             /* --- update filter with a pattern */
    for (int i = (this.size < cnt+1) ? this.size : cnt+1; --i >= 0; )
      if (!this.trees[i].update(items, i, cnt, supp, prune))
        return false;           /* update each prefix tree */
    return true;                /* return that trees were updated */
  }  /* update() */

  /*------------------------------------------------------------------*/
  /** Update a closed/maximal filter with a new item pattern
   *  (that is, remove all item patterns that are subpatterns of this
   *  pattern [for maximal pattern filtering] or subpatterns with the
   *  same support [for closed pattern filtering] and add the pattern
   *  to the filter unless it is subsumed [is a subpattern or a
   *  subpattern with the same support, respectively] by an item
   *  pattern in the filter).
   *  @param  items   the item pattern to add
   *  @param  cnt     the number of items in the pattern to add
   *  @param  supp    the support of the item pattern to add
   *  @return whether the given pattern was added to the filter
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean update (int[] items, int cnt, int supp)
  { return this.update(items, cnt, supp, true); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code>, the root node
   *                 supportis used, if <code>-2</code>, the item
   *                 pattern support is used
   *  @param  zmin   the minimum size of an item pattern
   *                 (number of items)
   *  @param  zmax   the maximum size of an item pattern
   *                 (number of items)
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet report (int s_base, int zmin, int zmax)
  { return this.trees[0].report(s_base, zmin, zmax); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code>, the root node
   *                 supportis used, if <code>-2</code>, the item
   *                 pattern support is used
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet report (int s_base)
  { return this.trees[0].report(s_base, 0, Integer.MAX_VALUE); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternSet report ()
  { return this.trees[0].report(-1, 0, Integer.MAX_VALUE); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  patrec the receiver for collecting the item patterns
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternReceiver report (PatternReceiver patrec)
  { return this.trees[0].report(patrec, -1, 0, Integer.MAX_VALUE); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  patrec the receiver for collecting the item patterns
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code>, the root node
   *                 support is used, if <code>-2</code>, the item
   *                 pattern support is used
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternReceiver report (PatternReceiver patrec,
                                       int s_base)
  { return this.trees[0].report(patrec, s_base, 0, Integer.MAX_VALUE); }

  /*------------------------------------------------------------------*/
  /** Report closed or maximal item patterns
   *  (type is determined by the parameters passed to the constructor).
   *  @param  patrec the receiver for collecting the item patterns
   *  @param  s_base the base support (support of the empty item
   *                 pattern); if <code>-1</code>, the root node
   *                 support is used, if <code>-2</code>, the item
   *                 pattern support is used
   *  @param  zmin   the minimum size of an item pattern
   *                 (number of items)
   *  @param  zmax   the maximum size of an item pattern
   *                 (number of items)
   *  @return the set of closed or maximal item patterns
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final PatternReceiver report (PatternReceiver patrec,
                                       int s_base, int zmin, int zmax)
  { return this.trees[0].report(patrec, s_base, zmin, zmax); }

}  /* class CloMaxFilter */
