/*----------------------------------------------------------------------
  File    : ARuleSet.java
  Contents: association rule management for visualization
  Author  : Christian Borgelt
  History : 2004.07.06 file created
            2004.12.09 adapted to changed additional evaluation output
            2005.01.24 incomplete adaptation completed
            2005.02.21 adapted to scanner utility functions
            2007.03.12 adapted to class IdMap, javadoc added
            2010.01.25 access to comparators modified in sort()
            2013.11.28 two more parse() functions added
            2013.10.23 constructor from JNIFIM.xxx() output added
            2016.04.10 sorting redesigned with rule sort value
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.FileReader;
import java.io.Writer;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.Arrays;

import util.IdMap;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for a set of association rules.
 *  @author Christian Borgelt
 *  @since  2004.07.06 */
/*--------------------------------------------------------------------*/
public class ARuleSet implements Cloneable, PatternReceiver {

  /*------------------------------------------------------------------*/
  /* constants                                                        */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010003L;
  /** the block size for the rule array */
  private static final int BLKSIZE = 1024;

  /* --- association rule set sort modes --- */
  /** sort mode: items (in the order in which they appear) */
  public  static final int ITEMS    = 0;
  /** sort mode: size / number of items */
  public  static final int SIZE     = 1;
  /** sort mode: size / number of items in antecedent/body*/
  public  static final int BODYSIZE = 2;
  /** sort mode: confidence */
  public  static final int CONF     = 3;
  /** sort mode: item pattern support (body and head) */
  public  static final int SUPP     = 4;
  /** sort mode: antecedent/body support */
  public  static final int BODYSUPP = 5;
  /** sort mode: consequent/head support */
  public  static final int HEADSUPP = 6;
  /** sort mode: lift value */
  public  static final int LIFT     = 7;
  /** sort mode: evaluation */
  public  static final int EVAL     = 8;
  /** sort mode: consequent/head item of the rule */
  public  static final int HEAD     = 9;
  /** sort mode: names of the consequent items */
  public  static final int NAMES    = 10;

  /* --- association rule set reduction modes --- */
  /** reduction mode: do nothing */
  public  static final int NONE        = PatternSet.NONE;
  /** reduction mode: remove duplicates/ensure unique rules */
  public  static final int UNIQUE      = PatternSet.UNIQUE;
  /** reduction mode: minimize the size of the antecedent/rule body */
  public  static final int MINSIZE     = PatternSet.MINSIZE;
  /** reduction mode: maximize the size of the antecedent/rule body */
  public  static final int MAXSIZE     = PatternSet.MAXSIZE;
  /** reduction mode: compare only the head items (not support etc.) */
  public  static final int ITEMSONLY   = PatternSet.ITEMSONLY;
  /** reduction mode: do not use a <code>CloMaxFilter</code>,
   * but rather work directly on the item pattern array */
  public  static final int NOFILTER    = PatternSet.NOFILTER;

  /* --- association rule set filter modes --- */
  /** filter mode: do nothing (keep all association rules, sort only) */
  public  static final int SORTONLY    = 0x00;
  /** filter mode: keep only rules in which the head item
   *  is not also the last item in the body */
  public  static final int HEADNOTLAST = 0x01;
  /** filter mode: keep only rules in which the head item
   *  is not contained in the body */
  public  static final int HEADNOTBODY = 0x04;

  /* --- association rule set selection modes --- */
  /** selection mode: find exact match of given rule */
  public  static final int EXACT       = 0x00;
  /** selection mode: find subrule of given rule (or exact match) */
  public  static final int SUB         = 0x01;
  /** selection mode: find superrule of given rule (or exact match) */
  public  static final int SUPER       = 0x02;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  protected IdMap   ibase;
  /** the set of association rules */
  protected ARule[] rules;
  /** the current number of rules */
  protected int     size;
  /** the maximal number of items in a rule body */
  protected int     body;
  /** the maximal number of items in a rule head */
  protected int     head;
  /** the maximal number of items in a rule (body and head) */
  protected int     zmax;
  /** the support values of individual items */
  protected int[]   supps;
  /** the current rule index for the rule set reduction */
  protected int     curr;

  /*------------------------------------------------------------------*/
  /** Create an empty set of association rules.
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleSet ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create an empty set of association rules.
   *  @param  ibase the underlying item base
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleSet (IdMap ibase)
  {                             /* --- create an association rule set */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.size  = this.zmax = this.body = this.head = 0;
    this.supps = null;
  }  /* ARuleSet() */

  /*------------------------------------------------------------------*/
  /** Create a set of association rules from FIM output.
   *  @param  ibase  the underlying item base
   *  @param  s_base the number of transactions from which the
   *                 (frequent) item sets where derived
   *  @param  rules  the output of a native function
   *          <code>JNIFIM.xxx()</code>, called with
   *          <code>report = "bsh"</code> or
   *          <code>report = "bsh[e|E]"</code>
   *  @since  2014.10.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ARuleSet (IdMap ibase, int s_base, Object[] rules)
  {                             /* --- create an association rule set */
    int[]    heads  = (int[])  rules[0]; /* get the head items, */
    int[][]  bodies = (int[][])rules[1]; /* the body item sets, */
    int[]    s_body = (int[])  rules[2]; /* the body supports, */
    int[]    s_set  = (int[])  rules[3]; /* the rule supports, */
    int[]    s_head = (int[])  rules[4]; /* and the head supports */
    double[] evals  = (rules.length > 5) ? (double[])rules[5] : null;
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.rules = new ARule[this.size = heads.length];
    this.zmax  = this.body = this.head = 0;
    for (int i = 0; i < this.size; i++) {  /* traverse the rules */
      this.rules[i] = new ARule(ibase, bodies[i], heads[i],
                                s_body[i], s_set[i], s_head[i], s_base,
                                (evals != null) ? evals[i] : 0.0);
      int b = bodies[i].length; /* create and store a new rule */
      int h = (heads[i] >= 0) ? 1 : 0;
      if (b   > this.body) this.body = b;
      if (h   > this.head) this.head = h;
      if (b+h > this.zmax) this.zmax = b+h;
    }                           /* update the maximum sizes */
    this.supps = null;
  }  /* ARuleSet() */

  /*------------------------------------------------------------------*/
  /** Clone this set of association rules.
   *  <p>The clone is a deep clone, that is, the underlying item base
   *  and all contained association rules are cloned as well.</p>
   *  @return a clone of this set of association rules
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone ()
  { return this.clone(true, true); }

  /*------------------------------------------------------------------*/
  /** Clone this set of association rules.
   *  @param  clonebase  whether to clone the underlying item base
   *  @param  clonerules whether to clone the association rules
   *  @return a clone of this set of association rules
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone (boolean clonebase, boolean clonerules)
  {                             /* --- clone a set of assoc. rules */
    IdMap ibase = (clonebase) ? (IdMap)this.ibase.clone() : this.ibase;
    ARuleSet ruleset = new ARuleSet(ibase);
    clonerules |= clonebase;    /* create a new association rule set */
    for (int i = 0; i < this.size; i++)
      ruleset.add((!clonerules) ? this.rules[i]
                : (ARule)this.rules[i].clone(ibase));
    return ruleset;             /* add a clone of each assoc. rule */
  }  /* clone() */              /* and return the created clone */

  /*------------------------------------------------------------------*/
  /** Clear this association rule set, that is, remove all rules.
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void clear ()
  {                             /* --- clear an associtaion rule set */
    this.rules = null;          /* delete all rules and */
    this.size = 0;              /* clear all other fields */
    this.zmax = this.body = this.head = 0;
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the underlying item base.
   *  @return the underlying item base
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final IdMap getItemBase ()
  { return this.ibase; }

  /*------------------------------------------------------------------*/
  /** Get the number of association rules (size of rule set).
   *  @return the number of association rules
   *  @since  2016.04.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSize ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the number of association rules (size of rule set).
   *  @return the number of association rules
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getRuleCount ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the maximal size of a rule.
   *  @return the maximal size of a rule
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMaxSize ()
  { return this.zmax; }

  /*------------------------------------------------------------------*/
  /** Get the maximal size of a rule body/antecedent.
   *  @return the maximal size of a rule body/antecedent
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMaxBodySize ()
  { return this.body; }

  /*------------------------------------------------------------------*/
  /** Get the maximal size of a rule head/consequent.
   *  @return the maximal size of a rule body/consequent
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getMaxHeadSize ()
  { return this.head; }

  /*------------------------------------------------------------------*/
  /** Get the name of an item.
   *  @param  item the identifier of the item for which to get the name
   *  @return the name of the item with identifier <code>item</code>
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getItemName (int item)
  {                             /* --- get an item name */
    return (String)this.ibase.get(item);
  }  /* getItemName() */

  /*------------------------------------------------------------------*/
  /** Get an association rule
   *  @param  i the index of the association rule
   *  @return the association rule with index i
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final ARule get (int i)
  { return (i < this.size) ? this.rules[i] : null; }

  /*------------------------------------------------------------------*/
  /** Get an association rule
   *  @param  i the index of the association rule
   *  @return the association rule with index i
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final ARule getRule (int i)
  { return (i < this.size) ? this.rules[i] : null; }

  /*------------------------------------------------------------------*/
  /** Get all association rules as an array
   *  (array length fits only after packing with <code>pack()</code>;
   *   should be considered read only).
   *  @return the array of association rules
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final ARule[] getAllRules()
  { return this.rules; }

  /*------------------------------------------------------------------*/
  /** Get the size of an association rule.
   *  @param  i the index of the association rule
   *  @return the size of the association rule with index <code>i</code>
  /*------------------------------------------------------------------*/

  public final int getRuleSize (int i)
  { return (i < this.size) ? this.rules[i].getSize() : 0; }

  /*------------------------------------------------------------------*/
  /** Add an association rule.
   *  @param  rule the association rule to add
   *  @return the index of the association rule in the set
   *  @since  2017.06.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int add (ARule rule)
  {                             /* --- add an association rule */
    int smax = (this.rules != null) ? this.rules.length : 0;
    if (this.size >= smax) {    /* if the rule array is full */
      smax += (smax > BLKSIZE) ? smax >> 1 : BLKSIZE;
      ARule[] p = new ARule[smax];  /* create a new rule array */
      if (this.rules != null)   /* copy already existing rules */
        System.arraycopy(this.rules, 0, p, 0, this.size);
      this.rules = p;           /* set the (new) rules array */
    }
    this.rules[this.size] = rule;
    int b = rule.size;          /* add the new rule to the set */
    int h = (rule.head >= 0) ? 1 : 0;
    if (b   > this.body) this.body = b;
    if (h   > this.head) this.head = h;
    if (b+h > this.zmax) this.zmax = b+h;
    return this.size++;         /* adapt the maximal sizes and */
  }  /* add() */                /* return the rule identifier */

  /*------------------------------------------------------------------*/
  /** Add an association rule.
   *  @param  rule the association rule to add
   *  @return the index of the association rule in the set
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addRule (ARule rule)
  { return this.add(rule); }

  /*------------------------------------------------------------------*/
  /** Add an association rule set
   *  (the rules are not cloned/copied, but merely transferred).
   *  @param  ruleset the association rule set to add
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void addRuleSet (ARuleSet ruleset)
  { this.addRuleSet(ruleset, false); }

  /*------------------------------------------------------------------*/
  /** Add an association rule set.
   *  @param  ruleset    the association rule set to add
   *  @param  clonerules whether to clone the rules of the given set
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void addRuleSet (ARuleSet ruleset, boolean clonerules)
  {                             /* --- add an association rule set */
    if (clonerules)             /* if to clone the association rules */
      for (int i = 0; i < ruleset.size; i++)
        this.add((ARule)ruleset.rules[i].clone(this.ibase));
    else                        /* if to simply transfer the rules */
      for (int i = 0; i < ruleset.size; i++)
        this.add(ruleset.rules[i]);
  }  /* addRuleSet() */

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item identifier for which to get
   *               the support value
   *  @return the support value of the item
   *          with identifier <code>item</code>
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSupp (int item)
  { return getSuppById(item); }

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item identifier
   *               for which to get the support value
   *  @return the support value of the item
   *          with identifier <code>item</code>
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuppById (int item)
  {                             /* --- get item support */
    if ((this.supps == null) || (item >= this.supps.length)) {
      int [] p = new int[this.ibase.getSize()];
      System.arraycopy(this.supps, 0, p, 0, this.supps.length);
      this.supps = p;           /* create a new item support array */
    }                           /* and copy existing array into it */
    return this.supps[item];    /* return the item support */
  }  /* getSuppById() */

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item name for which to get the support value
   *  @return the support value of the item with name <code>item</code>
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuppByName (String item)
  { return getSuppById(this.ibase.get(item)); }

  /*------------------------------------------------------------------*/
  /** Get the support of an individual item.
   *  @param  item the item object for which to get the support value
   *  @return the support value of the item
   *          with object <code>item</code>
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuppByObject (Object item)
  { return getSuppById(this.ibase.get(item)); }

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param  item the item identifier
   *               for which to set the support value
   *  @param  supp the support value to set for the item
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSupp (int item, int supp)
  { setSuppById(item, supp); }

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param item  the item identifier
   *               for which to set the support value
   *  @param supp  the support value to set for the item
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSuppById (int item, int supp)
  {                             /* --- set item support */
    if ((this.supps == null) || (item >= this.supps.length)) {
      int [] p = new int[this.ibase.getSize()];
      System.arraycopy(this.supps, 0, p, 0, this.supps.length);
      this.supps = p;           /* create a new item support array */
    }                           /* and copy existing array into it */
    this.supps[item] = supp;    /* set the item support value */
  }  /* setSuppById() */

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param  item the item name for which to set the support value
   *  @param  supp the support value to set for the item
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSuppByName (String item, int supp)
  { setSuppById(this.ibase.get(item), supp); }

  /*------------------------------------------------------------------*/
  /** Set the support of an individual item.
   *  @param  item the item name for which to set the support value
   *  @param  supp the support value to set for the item
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setSuppByObject (String item, int supp)
  { setSuppById(this.ibase.get(item), supp); }

  /*------------------------------------------------------------------*/
  /** Get the support values of all individual items.
   *  @return an array of support values for each item
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getAllSupps ()
  {                             /* --- get item support values */
    if (this.supps == null) {   /* if there is no support array, */
      int [] p = new int[this.ibase.size()];
      System.arraycopy(this.supps, 0, p, 0, this.supps.length);
      this.supps = p;           /* create a new item support array */
    }                           /* and copy existing array into it */
    return this.supps;          /* return the item support array */
  }  /* getAllSupps() */

  /*------------------------------------------------------------------*/
  /** Set the support values of all individual items.
   *  @param supps an array of support values for each item
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setAllSupps (int[] supps)
  {                             /* --- set item support values */
    if ((this.supps == null) || (supps.length > this.supps.length)) {
      int z = this.ibase.size();
      if (supps.length > z) z = supps.length;
      this.supps = new int[z];  /* create a new item support array */
    }
    System.arraycopy(supps, 0, this.supps, 0, supps.length);
  }  /* setAllSupps() */

  /*------------------------------------------------------------------*/
  /** Sort the items in each association rule's body.
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sortItems()
  { this.sortBodyItems(); }

  /*------------------------------------------------------------------*/
  /** Sort the items in each association rule's body.
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sortBodyItems()
  {                             /* --- sort items in rule bodies */
    for (int i = 0; i < this.size; i++)
      this.rules[i].sort();     /* sort the items in each body */
  }  /* sortBodyItems() */

  /*------------------------------------------------------------------*/
  /** Set the sort parameters for all item patterns.
   *  @param  valid the identifier of the value to sort on
   *  @param  dir   the sort direction
   *                (positive: ascending, negative: descending)
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final void setSort (int valid, int dir)
  {                             /* --- set sort parameters */
    if (dir == 0) {             /* if no direction is given */
      switch (valid) {          /* evaluate the value identifier */
        case SIZE:     dir = +1; break;
        case BODYSIZE: dir = +1; break;
        case CONF:     dir = -1; break;
        case SUPP:     dir = -1; break;
        case BODYSUPP: dir = -1; break;
        case HEADSUPP: dir = -1; break;
        case LIFT:     dir = -1; break;
        case EVAL:     dir = -1; break;
        default  :     return;  /* get default sorting direction */
      }                         /* but ignore unknown value ids */
    }
    switch (valid) {            /* evaluate the sort identifier */
      case SIZE:                /* if to sort by item pattern size */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getSize(),     dir);
        break;
      case BODYSIZE:            /* if to sort by item pattern size */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getBodySize(), dir);
        break;
      case CONF:                /* if to sort by rule confidence */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getConf(),     dir);
        break;
      case SUPP:                /* if to sort by rule support */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getSupp(),     dir);
        break;
      case BODYSUPP:            /* if to sort by rule body support */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getBodySupp(), dir);
        break;
      case HEADSUPP:            /* if to sort by rule head support */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getHeadSupp(), dir);
        break;
      case LIFT:                /* if to sort by rule lift */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getLift(),     dir);
        break;
      case EVAL:                /* if to sort by rule evaluation */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getEval(),     dir);
        break;
      case HEAD:                /* if to sort by rule evaluation */
        for (int i = 0; i < this.size; i++)
          this.rules[i].setSort(this.rules[i].getHead(),     dir);
        break;
      default:                  /* if unknown sort identifier, */
        return;                 /* simply abort the function */
    }
  }  /* setSort() */

  /*------------------------------------------------------------------*/
  /** Sort the set of association rules (by their size).
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort ()
  { this.sort(SIZE, 0); }

  /*------------------------------------------------------------------*/
  /** Sort the set of association rules.
   *  @param  valid the identifier of the value to compare first
   *  @since  2005.07.06/2016.04.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort (int valid)
  { this.sort(valid, 0); }

  /*------------------------------------------------------------------*/
  /** Sort the set of association rules.
   *  @param  valid the identifier of the value to compare first
   *  @param  dir   the sort direction
   *                (positive: ascending, negative: descending)
   *  @since  2016.04.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort (int valid, int dir)
  {                             /* --- sort the rule set */
    if (this.size <= 0) return; /* if there are no rules, abort */
    if (valid <= ITEMS) {       /* compare all items (body and head) */
      dir = (dir < 0) ? -1 : +1;
      for (int i = 0; i < this.size; i++)
        this.rules[i].dir = dir;
      Comparator<ARule> cmp = new Comparator<ARule> () {
        public int compare (ARule r1, ARule r2)
        { return r1.itemsCmpTo(r2) *r1.dir; } };
      Arrays.sort(this.rules, 0, this.size, cmp); }
    else if (valid == HEAD) {   /* compare head/consequent items */
      dir = (dir < 0) ? -1 : +1;
      for (int i = 0; i < this.size; i++)
        this.rules[i].dir = dir;
      Comparator<ARule> cmp = new Comparator<ARule> () {
        public int compare (ARule r1, ARule r2)
        { return r1.headCmpTo(r2) *r1.dir; } };
      Arrays.sort(this.rules, 0, this.size, cmp); }
    else if (valid == NAMES) { /* if to compare by consequent names */
      dir = (dir < 0) ? -1 : +1;
      for (int i = 0; i < this.size; i++)
        this.rules[i].dir = dir;
      Comparator<ARule> cmp = new Comparator<ARule> () {
        public int compare (ARule r1, ARule r2) {
          if (r1.head < 0) return (r2.head < 0) ? 0 : -r1.dir;
          if (r2.head < 0) return +r1.dir;
          return r1.getHeadName().compareTo(r2.getHeadName()) *r1.dir;
        } };                    /* create a comparator object */
      Arrays.sort(this.rules, 0, this.size, cmp); }
    else {
      this.setSort(valid, dir); /* set the sort parameters */
      Arrays.sort(this.rules, 0, this.size);
    }                           /* sort the association rules */
  }  /* sort() */

  /*------------------------------------------------------------------*/
  /** Reverse the order of the association rules in a rule set.
   *  @since  2016.06.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void reverse ()
  {                             /* --- reverse association rule order */
    int l, r;                   /* left and right exchange index */
    for (l = 0, r = this.size-1; l < r; l++, r--) {
      ARule x = this.rules[l];  /* traverse the association rules */
      this.rules[l] = this.rules[r];
      this.rules[r] = x;        /* iteratively exchange rules */
    }                           /* from left and right side */
  }  /* reverse() */

  /*------------------------------------------------------------------*/
  /** Check whether two association rule sets are equal.
   *  <p> It is assumed that both association rule sets have been sorted
   *  with a call to the function <code>sort()</code> with parameter
   *  <code>ITEMS</code>. If the rule bodies represents item sets
   *  instead of permutations or sequences, it is also assumed that
   *  the items have been sorted by a call to the function
   *  <code>sortItems()</code>.</p>
   *  @param  ruleset the rule set to compare to
   *  @return <code>true</code> if the two rule sets contain the same
   *          rule (in the same order) and <code>false</code> otherwise
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean equals (ARuleSet ruleset)
  {                             /* --- check for equality */
    if (this.size != ruleset.size)
      return false;             /* check for the same number of rules */
    for (int i = 0; i < this.size; i++)
      if (!this.rules[i].equals(ruleset.rules[i]))
        return false;           /* check for equal rules and */
    return true;                /* return if there is a difference */
  }  /* equals() */

  /*------------------------------------------------------------------*/
  /** Filter a set of association rules.
   *  @param  mode the filter mode (e.g. <code>HEADNOTLAST</code>)
   *  @return the new number of association rules
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int filter (int mode)
  {                             /* --- filter association rules */
    if (mode == 0) return this.size;
    int i, j, k;                /* loop variables */
    for (i = k = 0; i < this.size; i++) {
      int   size = this.rules[i].size;
      int   head = this.rules[i].head;
      int   last = this.rules[i].getLastBody();
      int[] body = this.rules[i].body;
      if (((mode & HEADNOTLAST) != 0) && (head == last))
        continue;               /* if head item is last in body */
      if ((mode & HEADNOTBODY) != 0) {
        for (j = size; --j >= 0; )
          if (head == body[j]) break;
        if (j >= 0) continue;   /* if the head item was found */
      }                         /* among the body items, skip rule */
      this.rules[k++] = this.rules[i];
    }                           /* keep only qualifying rules */
    while (--i >= k)            /* clear moved elements */
      this.rules[i] = null;     /* (remove junk entries) */
    return this.size = k;       /* return the new number of rules */
  }  /* filter() */

  /*------------------------------------------------------------------*/
  /** Filter an association rule set by antecedent/body size.
   *  @param  zmin the minimum body size of the rules to keep
   *  @param  zmax the maximum body size of the rules to keep
   *  @return the new number of association rules
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int filter (int zmin, int zmax)
  {                             /* --- filter rules by body size */
    int i, k;                   /* loop variables */
    for (i = k = 0; i < this.size; i++) {
      if ((this.rules[i].size >= zmin)
      &&  (this.rules[i].size <= zmax))
        this.rules[k++] = this.rules[i];
    }                           /* keep only qualifying rules */
    while (--i >= k)            /* clear moved elements */
      this.rules[i] = null;     /* (remove junk entries) */
    return this.size = k;       /* return the new number of rules */
  }  /* filter() */

  /*------------------------------------------------------------------*/
  /** Receive an item pattern (implements <code>PatternReceiver</code>).
   *  <p>This function is needed internally to implement the function
   *  <code>reduce()</code>. It performs no operation if called from
   *  the outside of this class. On the other hand, it cannot be
   *  declared private, because it implements an interface.</p>
   *  @param  items  the items in the item pattern
   *                 (may be an oversized buffer)
   *  @param  size   the number of items in the pattern
   *  @param  s_pat  the (absolute) support of the item pattern
   *  @param  s_base the (absolute) base support
   *                 (support of the empty item pattern, database size)
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void receive (int[] items, int size, int s_pat, int s_base)
  {                             /* --- receive an item pattern */
    if (this.curr < 0)          /* if there is no current rule index, */
      return;                   /* this is an external call, so abort */
    while (!this.rules[--this.curr].bodyEquals(items, size))
      this.rules[this.curr] = null;  /* delete rules that */
  }  /* receive() */                 /* do not math the pattern */

  /*------------------------------------------------------------------*/
  /** Reduce a set of association rules.
   *  @param  mode the reduction mode (e.g. <code>MINSIZE</code>)
   *  @return the new number of association rules
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int reduce (int mode)
  {                             /* --- reduce association rules */
    if (this.size <= 1)         /* if there is at most one rule, */
      return this.size;         /* there is nothing to reduce */

    Comparator<ARule> cmp;      /* comparator for association rules */
    int m = mode & ~UNIQUE;     /* if to make patterns unique */
    if (((mode & UNIQUE) != 0) && ((m == 0) || (m == ITEMSONLY))) {
      cmp = new Comparator<ARule> () {
              public int compare (ARule r1, ARule r2)
              { return r1.itemsAllCmpTo(r2); } };
      Arrays.sort(this.rules, 0, this.size, cmp);
      int i, k;                 /* traverse the rules */
      for (i = k = 0; ++i < this.size; )
        if (!this.rules[i].equals(this.rules[k], m == 0))
          this.rules[++k] = this.rules[i];
      while (--i > k)         /* keep only rules without duplicates */
        this.rules[i] = null; /* and clear (re)moved pattern entries */
      return this.size = k+1; /* return the new number of rules */
    }

    cmp = ((mode & ITEMSONLY) != 0)
        ? new Comparator<ARule> () {
            public int compare (ARule r1, ARule r2)
            { return r1.headCmpTo(r2); } }
        : new Comparator<ARule> () {
            public int compare (ARule r1, ARule r2)
            { return r1.headAllCmpTo(r2); } };
    Arrays.sort(this.rules, 0, this.size, cmp);

    if (((mode & MINSIZE) == 0) && ((mode & MAXSIZE) == 0))
      return this.size;         /* check whether to reduce rules */

    CloMaxTree filter = null;   /* filter for faster reduction */
    Comparator<ARule> bodycmp = null;
    if (((mode & MAXSIZE) != 0) && ((mode & NOFILTER) == 0)
    && (this.size > 32)) {      /* if a CloMaxFilter can be used */
      filter  = new CloMaxTree(this.ibase, CloMaxTree.MAXIMAL, -1);
      bodycmp = new Comparator<ARule> () {
                  public int compare (ARule r1, ARule r2)
                  { return r1.bodyCmpTo(r2); } };
    }                           /* create closed/maximal filter tree */

    if ((mode & MAXSIZE) != 0) {
      this.setSort(BODYSIZE,-1);/* if to maximize rule bodies */
      int beg, end;             /* range of current section */
      for (beg = 0; beg < this.size; beg = end) {
        for (end = beg+1; end < this.size; end++)
          if (cmp.compare(this.rules[end], this.rules[beg]) != 0)
            break;              /* if the rules differ, abort loop */
        if ((end-beg > 32) && (filter != null)) {
          Arrays.sort(this.rules, beg, end-beg, bodycmp);
          filter.clear();       /* clear the closed/maximal filter */
          for (int i = beg; i < end; i++)
            filter.update(this.rules[i].body, 0,
                          this.rules[i].size, this.rules[i].s_body);
          this.curr = end;      /* enter rule bodies into filter and */
          filter.report(this,0);/* reduce this set of item patterns */
          Arrays.fill(this.rules, beg, this.curr, null); }
        else if (end-beg >= 2){ /* if there are at least two rules */
          Arrays.sort(this.rules, beg, end-beg);
          for (int i = beg+1; i < end; i++) {
            for (int k = beg; k < i; k++) {
              if ((this.rules[k] != null)
              &&  (this.rules[k].bodyContains(this.rules[i]))) {
                this.rules[i] = null; break; }
            }                   /* (if a rule body is a superset */
          }                     /*  of another rule body, keep only */
        }                       /*  the rule with the smaller body) */
      } }
    else if ((mode & MINSIZE) != 0) {
      this.setSort(BODYSIZE,+1);/* if to minimize rule bodies */
      int beg, end;             /* range of current section */
      for (beg = 0; beg < this.size; beg = end) {
        for (end = beg+1; end < this.size; end++)
          if (cmp.compare(this.rules[end], this.rules[beg]) != 0)
            break;              /* if the rules differ, abort loop */
        if (end-beg >= 2) {     /* if there are at least two sets */
          Arrays.sort(this.rules, beg, end-beg);
          for (int i = beg + 1; i < end; i++) {
            for (int k = beg; k < i; k++) {
              if ((this.rules[k] != null)
              && (this.rules[k].bodyIsContainedIn(this.rules[i]))) {
                this.rules[i] = null; break; }
            }                   /* (if a rule body is a superset */
          }                     /*  of another rule body, keep only */
       }                        /*  the rule with the smaller body) */
     }
   }
   this.curr = -1;              /* make receive() functionless again */

   int i, k;                    /* initialize the rule counter */
   for (i = k = 0; i < this.size; i++)
     if (this.rules[i] != null) /* collect non-deleted rules */
       this.rules[k++] = this.rules[i];
    while (--i >= k)            /* clear moved elements */
      this.rules[i] = null;     /* (remove junk entries) */
    return this.size = k;       /* return the new number of rules */
  }  /* reduce() */

  /*------------------------------------------------------------------*/
  /** Select rules that are subrules, superrules (w.r.t. the rule body)
   *  or an exact match of the given rule (in terms of the contained
   *  items, including the head).
   *  @param  rule the rule with which to select rules
   *  @param  mode the mode with which to select rules; either
   *               <code>EXACT</code>, <code>SUB</code>, or
   *               <code>SUPER</code>.
   *  @return an association rule set with the qualifying rules
   *          (uncloned)
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final ARuleSet select (ARule rule, int mode)
  { return this.select(rule.body, rule.size, rule.head, mode); }

  /*------------------------------------------------------------------*/
  /** Select rules that are subrules, superrules (w.r.t. the rule body)
   *  or an exact match of the given rule (in terms of the contained
   *  items, including the head).
   *  @param  body the items of the rule body to compare to
   *  @param  size the number of items in the body
   *  @param  head the head item of the rule
   *  @param  mode the mode with which to select rules
   *               <code>EXACT</code>, <code>SUB</code>, or
   *               <code>SUPER</code>.
   *  @return an association rule set with the qualifying rules
   *          (uncloned)
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final ARuleSet select (int[] body, int size, int head,int mode)
  {                             /* --- get a pattern selection */
    ARuleSet sel = new ARuleSet(this.ibase);
    if (mode == SUB) {          /* is to select all subrules */
      for (int i = 0; i < this.size; i++) {
        if ((this.rules[i].head == head)
        && this.rules[i].bodyIsSubOf(body, size))
          sel.add(this.rules[i]);
      } }                       /* collect subrules */
    else if (mode == SUPER) {   /* if to select all superrules */
      for (int i = 0; i < this.size; i++) {
        if ((this.rules[i].head == head)
        && this.rules[i].bodyIsSuperOf(body, size))
          sel.add(this.rules[i]);
      } }                       /* collect subrules */
    else {                      /* if only exact match */
      for (int i = 0; i < this.size; i++) {
        if ((this.rules[i].head == head)
        && this.rules[i].bodyEquals(body, size))
          sel.add(this.rules[i]);
      }                         /* collect exact matches */
    }
    return sel;                 /* return the selected rules */
  }  /* select() */

  /*------------------------------------------------------------------*/
  /** Get a list of all items that occur
   *  in at least one association rule (in body or head).
   *  @return an array with the identifiers of items that occur in at
   *          least one association rule, sorted by item identifier
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getItems ()
  {                             /* --- get list of occurring items */
    int[] occs = new int[this.ibase.size()];
    for (int i = 0; i < this.size; i++) {
      for (int k = this.rules[i].size; --k >= 0; )
        occs[this.rules[i].body[k]] = 1;
      int head = this.rules[i].head;
      if (head >= 0) occs[head] = 1;
    }                           /* mark occurring items */
    int n = 0;                  /* number of occurring items */
    for (int i = 0; i < occs.length; i++)
      n += occs[i];             /* sum the flag values/count items */
    int[] items = new int[n];   /* create the result array */
    for (int i = occs.length; --i >= 0; )
      if (occs[i] != 0) items[--n] = i;
    return items;               /* return the result array */
  }  /* getItems() */

  /*------------------------------------------------------------------*/
  /** Recode an association rule set to another item base,
   *  replacing the item base.
   *  @param  ibase the item base to recode the association rule set to
   *  @since  2016.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void recode (IdMap ibase)
  {                             /* --- recode an association rule set */
    int[] map = this.ibase.getMapTo(ibase);
    for (int i = 0; i < this.size; i++)
      this.rules[i].recode(ibase, map);
  }  /* recode() */

  /*------------------------------------------------------------------*/
  /** Pack the association rules, i.e., optimize memory usage.
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void pack ()
  {                             /* --- pack the association rules */
    for (int i = 0; i < this.size; i++)
      this.rules[i].pack();     /* traverse and pack the rules */
    if ((this.rules == null) || (this.rules.length <= this.size))
      return;                   /* shrink the association rule array */
    ARule[] p = new ARule[this.size];
    System.arraycopy(this.rules, 0, p, 0, this.size);
    this.rules = p;             /* set the shrunk transaction array */
  }  /* pack() */

  /*------------------------------------------------------------------*/
  /** Write a set of association rules.
   *  @param  writer the writer to write to
   *  @throws IOException if a write error occurs
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void write (Writer writer) throws IOException
  {                             /* --- write a set of ass. rules */
    for (int i = 0; i < this.size; i++) {
      writer.write(this.rules[i].toString());
      writer.write('\n');       /* traverse and print the rules */
    }
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write a set of association rules.
   *  @param  out the output stream to write to
   *  @throws IOException if a write error occurs
   *  @since  2016.04.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void write (OutputStream out) throws IOException
  { this.write(new PrintWriter(out)); }

  /*------------------------------------------------------------------*/
  /** Parse a set of association rules.
   *  @param  ibase the underlying item base
   *  @param  scan the scanner to read from
   *  @return the parsed set of association rules
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet parse (IdMap ibase, Scanner scan)
    throws IOException
  {                             /* --- parse an association rule set */
    ARuleSet rules = new ARuleSet(ibase);
    while (scan.nextToken() != Scanner.T_EOF) {
      scan.pushBack();          /* while not at end of input */
      rules.addRule(ARule.parse(rules.ibase, scan));
    }                           /* parse the association rules */
    return rules;               /* and return the created set */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse a set of association rules.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @return the parsed set of association rules
   *  @throws IOException if a read error occurs
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet parse (IdMap ibase, Reader reader)
    throws IOException
  { return ARuleSet.parse(ibase, new Scanner(reader)); }

  /*------------------------------------------------------------------*/
  /** Parse a set of association rules.
   *  @param  ibase the underlying item base
   *  @param  desc  the string description to parse
   *  @return the parsed set of association rules
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet parse (IdMap ibase, String desc)
    throws IOException
  { return ARuleSet.parse(ibase, new Scanner(desc)); }

  /*------------------------------------------------------------------*/
  /** Parse a set of association rules.
   *  @param  ibase  the underlying item base
   *  @param  inp    the input stream to read from
   *  @return the parsed set of association rules
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ARuleSet parse (IdMap ibase, InputStream inp)
    throws IOException
  { return ARuleSet.parse(ibase, new Scanner(inp)); }

  /*------------------------------------------------------------------*/
  /** Main function for testing some basic functionality.
   *  <p>It is tried to parse the file that is given as the first
   *  command line argument as a set of association rules.</p>
   *  @param  args the command line arguments
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    Scanner     scan;           /* scanner to read from */
    ARuleSet    rules;          /* created association rule set */
    PrintWriter writer;         /* writer for test output */

    try {                       /* try to read the given file */
      if (args.length <= 0)     /* if no arguments given */
        scan = new Scanner("a <- b c (40/4,50/5,70/7,80,1.42875,0)");
      else                      /* if a file argument is given */
        scan = new Scanner(new FileReader(args[0]));
      rules = ARuleSet.parse(null, scan);
      scan.close();             /* parse the rule set */
      writer = new PrintWriter(System.out);
      rules.write(writer);      /* print the rule set and */
      writer.flush(); }         /* flush writer to actually print */
    catch (IOException e) {     /* catch and report i/o errors */
      System.err.println(e.getMessage()); return; }
  }  /* main() */

}  /* class ARuleSet */
