/*----------------------------------------------------------------------
  File    : TrAct.java
  Contents: transaction management for visualization
  Author  : Christian Borgelt
  History : 2013.11.29 file created from Pattern.java
            2014.10.02 transaction weight/multiplicity handling added
            2014.10.03 function getAllItems() etc. added
            2016.04.07 StringBuffer replaced by StringBuilder
            2016.04.11 bug in write function fixed (double deref.)
            2016.06.19 constant "EMPTY", function toString(isep) added
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Arrays;

import util.IdMap;
import util.TableReader;
import util.TableWriter;

/*--------------------------------------------------------------------*/
/** Class for transactions.
 *  @author Christian Borgelt
 *  @since  2013.11.29 */
/*--------------------------------------------------------------------*/
public class TrAct implements Comparable<TrAct>, Cloneable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010002L;
  /** the block size for the item array */
  private static final int BLKSIZE = 32;
  /** the empty item array to avoid reallocation */
  private static final int[] EMPTY = {};

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying item base */
  protected IdMap ibase;
  /** the items of the transaction */
  protected int[] items;
  /** the current number of items */
  protected int   size;
  /** the weight/multiplicity of the transaction
   *  (number of occurrences) */
  protected int   wgt;

  /*------------------------------------------------------------------*/
  /** Create an empty transaction.
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrAct ()
  { this(null, 1); }

  /*------------------------------------------------------------------*/
  /** Create an empty transaction.
   *  @param  ibase the underlying item base
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrAct (IdMap ibase)
  { this(ibase, 1); }

  /*------------------------------------------------------------------*/
  /** Create an empty transaction.
   *  @param  ibase the underlying item base
   *  @param  wgt   the weight/multiplicity of the transaction
   *                (number of occurrences)
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrAct (IdMap ibase, int wgt)
  {                             /* --- create a transaction */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.size  = 0;             /* note the item base and */
    this.items = EMPTY;         /* initialize the fields */
    this.wgt   = wgt;
  }  /* TrAct() */

  /*------------------------------------------------------------------*/
  /** Create a transaction from an item array
   *  (the given item array is stored, not copied).
   *  @param  ibase the underlying item base
   *  @param  items the array of item identifiers
   *  @param  wgt   the weight/multiplicity of the transaction
   *                (number of occurrences)
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrAct (IdMap ibase, int[] items, int wgt)
  {                             /* --- create a transaction */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.size  = 0;             /* note the item base and */
    this.items = items;         /* initialize the fields */
    this.wgt   = wgt;
  }  /* TrAct() */

  /*------------------------------------------------------------------*/
  /** Create a transaction from an item array
   *  (the given item array is copied).
   *  @param  ibase the underlying item base
   *  @param  items the array of item identifiers
   *  @param  cnt   the number of items
   *                (may be smaller than <code>items.length</code>)
   *  @param  wgt   the weight/multiplicity of the transaction
   *                (number of occurrences)
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrAct (IdMap ibase, int[] items, int cnt, int wgt)
  {                             /* --- create a transaction */
    this.ibase = (ibase != null) ? ibase : new IdMap();
    this.items = new int[this.size = cnt];
    System.arraycopy(items, 0, this.items, 0, cnt);
    this.wgt   = wgt;           /* copy the given items */
  }  /* TrAct() */

  /*------------------------------------------------------------------*/
  /** Clone this transaction
   *  (the item base is maintained, the item array is copied).
   *  @return a clone of this transaction
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone ()
  { return this.clone(null, true); }

  /*------------------------------------------------------------------*/
  /** Clone this transaction (the item array is copied).
   *  @param  ibase the item base to use for the clone
   *  @return a clone of this transaction
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone (IdMap ibase)
  { return this.clone(ibase, true); }

  /*------------------------------------------------------------------*/
  /** Clone this transaction
   *  (the item base is maintained).
   *  @param  iclone whether to clone the item array
   *  @return a clone of this transaction
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone (boolean iclone)
  { return this.clone(null, iclone); }

  /*------------------------------------------------------------------*/
  /** Clone this transaction
   *  (the item base is maintained).
   *  @param  iclone whether to clone the item array
   *  @param  ibase the item base to use for the clone
   *  @return a clone of this transaction
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone (boolean iclone, IdMap ibase)
  { return this.clone(ibase, iclone); }

  /*------------------------------------------------------------------*/
  /** Clone this transaction
   *  (the item base is maintained).
   *  @param  ibase the item base to use for the clone
   *  @param  iclone whether to clone the item array
   *  @return a clone of this transaction
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone (IdMap ibase, boolean iclone)
  {                             /* --- clone a transaction */
    TrAct tract;                /* created transaction clone */
    if (ibase == null) ibase = this.ibase;
    if (iclone)                 /* if to clone/copy the item array */
      tract = new TrAct(ibase, this.items, this.size, this.wgt);
    else {                      /* if not to copy the item array */
      tract = new TrAct(ibase, this.items, this.wgt);
      tract.size = this.size;   /* call non-copying constructor and */
    }                           /* overwrite with the correct size */
    return tract;               /* return the created clone */
  }  /* clone() */

  /*------------------------------------------------------------------*/
  /** Add an item to the transaction.
   *  @param  item the item identifier
   *  @return the index of the new item
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemById (int item)
  {                             /* --- add an item to a transaction */
    int smax = this.items.length;
    if (this.size >= smax) {    /* if the item array is full */
      smax += (smax > BLKSIZE) ? smax >> 1 : BLKSIZE;
      int[] p = new int[smax];  /* create an (enlarged) item array */
      System.arraycopy(this.items, 0, p, 0, this.size);
      this.items = p;           /* copy the existing items */
    }                           /* and set the (new) item array */
    this.items[this.size] = item;
    return this.size++;         /* return the index of the new item */
  }  /* addItemById() */

  /*------------------------------------------------------------------*/
  /** Add an item (given by its name) to the transaction.
   *  @param  item the name of the item to add
   *  @return the index of the new item
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemByName (String item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its object) to the transaction.
   *  @param  item the object of the item to add
   *  @return the index of the new item
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItemByObject (Object item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its identifier) to the transaction.
   *  @param  item the identifier of the item to add
   *  @return the index of the new item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (int item)
  { return this.addItemById(item); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its name) to the transaction.
   *  @param  item the name of the item to add
   *  @return the index of the new item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (String item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Add an item (given by its object) to the transaction.
   *  @param  item the object of the item to add
   *  @return the index of the new item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int addItem (Object item)
  { return this.addItemById(this.ibase.add(item)); }

  /*------------------------------------------------------------------*/
  /** Get an item (i.e., its identifier).
   *  @param  i the index of the item
   *  @return the identifier of the item
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItem (int i)
  { return (i < this.items.length) ? this.items[i] : -1; }

  /*------------------------------------------------------------------*/
  /** Get an item (i.e., its identifier).
   *  @param  i the index of the item
   *  @return the identifier of the item
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getItemId (int i)
  { return (i < this.items.length) ? this.items[i] : -1; }

  /*------------------------------------------------------------------*/
  /** Get the name of an item.
   *  @param  i the index of the item
   *  @return the name of the item
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String getItemName (int i)
  { return (i < this.items.length)
         ? this.ibase.get(this.items[i]).toString() : ""; }

  /*------------------------------------------------------------------*/
  /** Get the object of an item.
   *  @param  i the index of the item
   *  @return the name of the item
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getItemObject (int i)
  { return (i < this.items.length)
         ? this.ibase.get(this.items[i]) : ""; }

  /*------------------------------------------------------------------*/
  /** Get the item array
   *  (length fits only after packing with <code>pack()</code>;
   *  should be considered readonly).
   *  @return the item array (which is possibly oversized)
   *  @since  2014.10.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] getAllItems ()
  { return this.items; }

  /*------------------------------------------------------------------*/
  /** Get the size of the transaction (number of items).
   *  @return the size of the transaction
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSize ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the size of the transaction (number of items).
   *  @return the size of the transaction
   *  @since  2017.06.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getCount ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the weight/multiplicity of the transaction
   *  (number of occurrences).
   *  @return the weight/multiplicity of the transaction
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getWeight ()
  { return this.wgt; }

  /*------------------------------------------------------------------*/
  /** Set the weight/multiplicity of the transaction
   *  (number of occurrences).
   *  @param  wgt the weight/multiplicity of the transaction
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int setWeight (int wgt)
  { return this.wgt = wgt; }

  /*------------------------------------------------------------------*/
  /** Compare this transaction to another (given as argument).
   *  @param  tract the other transaction to compare to
   *  @return <code>-1</code>, <code>0</code>, or <code>+1</code>
   *          as this transaction is less than, equal to, or greater
   *          than the given transaction (argument)
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int compareTo (TrAct tract)
  {                             /* --- compare to another transaction */
    int n = (this.size < tract.size) ? this.size : tract.size;
    for (int i = 0; i < n; i++){/* traverse items up to smaller size */
      if (this.items[i] > tract.items[i]) return +1;
      if (this.items[i] < tract.items[i]) return -1;
    }                           /* if items differ, return result */
    if (this.size > tract.size) return +1;
    if (this.size < tract.size) return -1;
    return 0;                   /* return sign of length difference */
  }  /* compareTo() */

  /*------------------------------------------------------------------*/
  /** Reduce the items of a transaction (remove infrequent items).
   *  @param  map the old to new item identifier map:
   *          a negative value means that the item is to be removed,
   *          a non-negative value states the new item identifier
   *  @return the new number of items
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int reduce (int[] map)
  {                             /* --- reduce a transaction */
    int n = 0;                  /* initialize the new size */
    for (int i = 0; i < this.size; i++) {
      int k = map[this.items[i]];      /* if non-negative, */
      if (k >= 0) this.items[n++] = k; /* set the new identifier; */
    }                                  /* otherwise drop the item */
    return this.size = n;       /* set the new number of items */
  }  /* reduce() */

  /*------------------------------------------------------------------*/
  /** Sort the items in a transaction (by item identifier).
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void sort ()
  { Arrays.sort(this.items, 0, this.size); }

  /*------------------------------------------------------------------*/
  /** Check whether a given item pattern is contained
   *  in this transaction.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the transaction needs to be sorted
   *  with <code>sort()</code> first and the items in the passed array
   *  <code>items</code> also need to be sorted (by identifier)
   *  for this function to work.</p>
   *  @param  items the array of items to check
   *  @param  cnt   the number of items in the given array to consider;
   *                if negative, the length of the item array
   *                <code>items</code>is used
   *  @return <code>true</code> is this transaction contains the given
   *          items in <code>items</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean contains (int[] items, int cnt)
  {                             /* --- check for superpat. rel.ship */
    return Pattern.subpattern(items, (cnt >= 0) ? cnt : items.length,
                              this.items, this.size);
  }  /* contains() */

  /*------------------------------------------------------------------*/
  /** Check whether a given item pattern is contained
   *  in this transaction.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the transaction needs to be sorted
   *  with <code>sort()</code> first and the items in the passed array
   *  <code>items</code> also need to be sorted (by identifier)
   *  for this function to work.</p>
   *  @param  items the array of items to check
   *  @return <code>true</code> is this transaction contains the given
   *          items in <code>items</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean contains (int[] items)
  {                             /* --- check for superpat. rel.ship */
    return Pattern.subpattern(items, items.length,
                              this.items, this.size);
  }  /* contains() */

  /*------------------------------------------------------------------*/
  /** Check whether a given item pattern is contained
   *  in this transaction.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets both the transaction and the item set
   *  need to be sorted with <code>sort()</code> for this function to
   *  work.</p>
   *  @param  pat the item pattern to check whether it is contained
   *  @return <code>true</code> if this transaction contains the given
   *          item pattern <code>pat</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean contains (Pattern pat)
  {                               /* --- check for superpat. rel.ship */
    return Pattern.subpattern(pat.items, pat.size,
                              this.items, this.size);
  }  /* Contains() */

  /*------------------------------------------------------------------*/
  /** Check whether a given other transaction is contained
   *  in this transaction.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets both transactions need to be sorted
   *  with <code>sort()</code> for this function to work.</p>
   *  @param  tract the other transaction to check
   *                whether it is contained
   *  @return <code>true</code> is this transaction contains the given
   *          transaction <code>tract</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean contains (TrAct tract)
  {                             /* --- check for superpat. rel.ship */
    return Pattern.subpattern(tract.items, tract.size,
                              this.items, this.size);
  }  /* contains() */

  /*------------------------------------------------------------------*/
  /** Whether this transaction is contained in a given item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the transaction needs to be sorted
   *  with <code>sort()</code> and the items in the passed array
   *  <code>items</code> also need to be sorted (by identifier).</p>
   *  @param  items the array of items to check
   *  @param  cnt   the number of items in the given array to consider;
   *                if negative, the length of the item array is used
   *  @return <code>true</code> if this transaction is contained in the
   *          given items <code>items</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isContainedIn (int[] items, int cnt)
  {                             /* --- check for subpat. relationship */
    return Pattern.subpattern(this.items, this.size, items,
                              (cnt >= 0) ? cnt : items.length);
  }  /* isContainedIn() */

  /*------------------------------------------------------------------*/
  /** Whether this transaction is contained in a given item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets the transaction needs to be sorted
   *  with <code>sort()</code> and the items in the passed array
   *  <code>items</code> also need to be sorted (by identifier).</p>
   *  @param  items the array of items to check
   *  @return <code>true</code> if this transaction is contained in the
   *          given items <code>items</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isContainedIn (int[] items)
  {                             /* --- check for subpat. relationship */
    return Pattern.subpattern(this.items, this.size,
                              items, items.length);
  }  /* isContainedIn() */

  /*------------------------------------------------------------------*/
  /** Whether this transaction is contained in a given item pattern.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets, both the transaction and the item
   *  set need to be sorted with <code>sort()</code> for this function
   *  to work.</p>
   *  @param  pat the item pattern to check
   *  @return <code>true</code> if this transaction is contained in the
   *          given item pattern <code>pat</code> and <code>false</code>
   *          otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isContainedIn (Pattern pat)
  {                             /* --- check for subpat. relationship */
    return Pattern.subpattern(this.items, this.size,
                              pat.items, pat.size);
  }  /* isContainedIn() */

  /*------------------------------------------------------------------*/
  /** Whether this transaction is contained
   *  in a given other transaction.
   *  <p>For item permutations and sequences the function works
   *  directly, but for item sets, both transactions must have been
   *  sorted with <code>sort()</code> for this function to work.</p>
   *  @param  tract the other transaction to check
   *  @return <code>true</code> if this transaction is contained
   *          in the given other transaction <code>tract</code>
   *          and <code>false</code> otherwise
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isContainedIn (TrAct tract)
  {                             /* --- check for subpat. relationship */
    return Pattern.subpattern(this.items, this.size,
                              tract.items, tract.size);
  }  /* isContainedIn() */

  /*------------------------------------------------------------------*/
  /** Get the offset to the start of the suffix
   *  after the first occurrence of an item pattern.
   *  @param  items the array of items to check
   *  @param  cnt   the number of items in the given array to consider;
   *                if negative, the length of the item array
   *                <code>items</code>is used
   *  @return the offset to the start of the suffix after the first
   *          occurrence of the given item pattern, or <code>-1</code>
   *          if the item pattern does not occur
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuffix (int[] items, int cnt)
  {                             /* --- get last item position */
    if (cnt < 0) cnt = items.length;
    if (this.size <= 0)         /* if the transaction is empty, */
      return (cnt <= 0) ? 0:-1; /* check for an empty item pattern */
    int i, k = 0;               /* index of next item to match */
    for (i = 0; i < cnt; i++)   /* traverse the items */
      if ((this.items[k] == items[i]) && (++k >= this.size)) {
        i += 1; break; }        /* if item was matched, skip it */
    return (i >= cnt) ? k : -1; /* return the offset to the suffix */
  }  /* getSuffix() */

  /*------------------------------------------------------------------*/
  /** Get the offset to the start of the suffix
   *  after the first occurrence of an item pattern.
   *  @param  items the array of items to check
   *  @return the offset to the start of the suffix after the first
   *          occurrence of the given item pattern, or <code>-1</code>
   *          if the item pattern does not occur
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSuffix (int[] items)
  { return this.getSuffix(items, items.length); }

  /*------------------------------------------------------------------*/
  /** Find the index of the (first) occurrence of an item.
   *  @param  item   the identifier of the item to find
   *  @param  offset the offset at which to start the search
   *  @return the index of the (first) occurrence of an item,
   *          or <code>-1</code> if the item does not occur
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int indexOf (int item, int offset)
  {                             /* --- find index of an item */
    for (int i = offset; i < this.size; i++)
      if (this.items[i] == item) return i;
    return -1;                  /* try to find the given item */
  }  /* indexOf() */

  /*------------------------------------------------------------------*/
  /** Find the index of the (first) occurrence of an item.
   *  @param  item   the identifier of the item to find
   *  @return the index of the (first) occurrence of an item,
   *          or <code>-1</code> if the item does not occur
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int indexOf (int item)
  { return this.indexOf(item, 0); }

  /*------------------------------------------------------------------*/
  /** Recode a transaction to another item base,
   *  replacing the item base.
   *  @param  ibase the item base to recode the transaction to
   *  @param  map   the old identifier to new identifier map;
   *                if <code>null</code>, the map is created by a call
   *                to <code>IdMap.getMapTo()</code>
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void recodeTo (IdMap ibase, int[] map)
  {                             /* --- recode a transaction */
    if (map == null)            /* if no id map is given, create one */
      map = this.ibase.getMapTo(ibase);
    for (int i = 0; i < this.size; i++)
      this.items[i] = map[this.items[i]];
    this.ibase = ibase;         /* map items, replace item base */
  }  /* recodeTo() */

  /*------------------------------------------------------------------*/
  /** Recode a transaction to another item base,
   *  replacing the item base.
   *  @param  ibase the item base to recode the transaction to
   *  @since  2017.06.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void recodeTo (IdMap ibase)
  { this.recodeTo(ibase, null); }

  /*------------------------------------------------------------------*/
  /** Pack a transaction, i.e., optimize memory usage.
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void pack ()
  {                             /* --- pack a transaction */
    if (this.items.length <= this.size) return;
    int[] p = new int[this.size];  /* shrink the item array array */
    System.arraycopy(this.items, 0, p, 0, this.size);
    this.items = p;             /* set the shrunk item array */
  }  /* pack() */

  /*------------------------------------------------------------------*/
  /** Write a transaction.
   *  @param  writer  the writer to write to
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer) throws IOException
  {                             /* --- write a transaction */
    writer.write(this.toString(null, false));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write a transaction.
   *  @param  writer the writer to write to
   *  @param  isep   the item separator
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String isep)
    throws IOException
  {                             /* --- write a transaction */
    writer.write(this.toString(isep, false));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write a transaction.
   *  @param  writer the writer to write to
   *  @param  wgt    whether to write a transaction weight
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, boolean wgt)
    throws IOException
  {                             /* --- write a transaction */
    writer.write(this.toString(null, wgt));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write a transaction.
   *  @param  writer  the writer to write to
   *  @param  isep    the item separator
   *  @param  wgt    whether to write a transaction weight
   *  @since  2017.06.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (Writer writer, String isep, boolean wgt)
    throws IOException
  {                             /* --- write a transaction */
    writer.write(this.toString(isep, wgt));
    writer.write('\n');
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Write a transaction with a table writer.
   *  @param  writer the table writer to write to
   *  @throws IOException if a write error occurs
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (TableWriter writer) throws IOException
  { this.write(writer, false); }

  /*------------------------------------------------------------------*/
  /** Write a transaction with a table writer.
   *  @param  writer the table writer to write to
   *  @param  wgt    whether to write the transaction weight
   *  @throws IOException if a write error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (TableWriter writer, boolean wgt)
    throws IOException
  {                             /* --- write a transaction */
    if (wgt) {                  /* if to write weight/multiplicity */
      for (int i = 0; i < this.size; i++)
        writer.write(this.getItemName(i));
      writer.write(String.valueOf(this.wgt), true); }
    else if (this.size <= 0)    /* if there are no items, */
      writer.write("", true);   /* write at least the record end */
    else {                      /* if to write only items */
      for (int i = 0; i < this.size; i++)
        writer.write(this.getItemName(i), i >= this.size-1);
    }                           /* write the list of items */
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Create a 'missing item' I/O exception.
   *  @param  scan the scanner to read from
   *  @return a 'missing item' I/O exception.
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static IOException misItemEx (TableReader reader)
  { return new IOException("missing item " +reader.rno()); }

  /*------------------------------------------------------------------*/
  /** Create a 'malformed number' I/O exception.
   *  @param  scan the scanner to read from
   *  @return a 'malformed number' I/O exception.
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static IOException badNumEx (TableReader reader)
  { return new IOException("malformed number "+reader.rno()); }

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @param  wgt    whether to read a transaction weight/multiplicity
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, TableReader reader,
                             boolean wgt)
    throws IOException
  {                             /* --- parse a transaction */
    TrAct tract = new TrAct(ibase); /* create a transaction */
    do {                        /* read the column names */
      if (reader.nextField() < 0)   /* if at the end of the input, */
        return null;            /* there is no transaction to read */
      /* Note that nextField() can return a negative value only   */
      /* on the first call, since a value of 0 (field separator)  */
      /* cannot be followed immediately by a negative value and   */
      /* a positive value (record separator) terminates the loop. */
      if (wgt && (reader.delim != 0)) {
        try { tract.wgt = Integer.parseInt(reader.field); }
        catch (NumberFormatException e) {throw TrAct.badNumEx(reader);}
        break;                  /* if to read a weight/multiplicity, */
      }                         /* read and check an integer number */
      if (reader.field != null) /* add the read item */
        tract.addItem(reader.field);
    } while (reader.delim == 0);/* while in the same record */
    tract.pack();               /* pack the parsed transaction */
    return tract;               /* and then return it */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, TableReader reader)
    throws IOException
  { return TrAct.parse(ibase, reader, false); }

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @param  wgt    whether to read a transaction weight/multiplicity
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, Reader reader, boolean wgt)
    throws IOException
  { return TrAct.parse(ibase, new TableReader(reader), wgt); }

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase  the underlying item base
   *  @param  reader the reader to read from
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, Reader reader)
    throws IOException
  { return TrAct.parse(ibase, new TableReader(reader)); }

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase the underlying item base
   *  @param  desc  the string description to parse
   *  @param  wgt   whether to read a transaction weight/multiplicity
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, String desc, boolean wgt)
    throws IOException
  { return TrAct.parse(ibase, new TableReader(desc), wgt); }

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase the underlying item base
   *  @param  desc  the string description to parse
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, String desc)
    throws IOException
  { return TrAct.parse(ibase, new TableReader(desc)); }

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase the underlying item base
   *  @param  inp   the input stream to read from
   *  @param  wgt   whether to read a transaction weight/multiplicity
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2014.10.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, InputStream inp, boolean wgt)
    throws IOException
  { return TrAct.parse(ibase, new TableReader(inp), wgt); }

  /*------------------------------------------------------------------*/
  /** Parse a transaction.
   *  @param  ibase the underlying item base
   *  @param  inp   the input stream to read from
   *  @return the parsed transaction
   *  @throws IOException if a read error occurs
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TrAct parse (IdMap ibase, InputStream inp)
    throws IOException
  { return TrAct.parse(ibase, new TableReader(inp)); }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @param  isep the item separator
   *  @param  wgt  whether to write a transaction weight
   *  @return the created string description
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString (String isep, boolean wgt)
  {                             /* --- create a string representation */
    if (isep == null) isep = " ";
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < this.size-1; i++) {
      b.append(this.ibase.get(this.items[i]));
      b.append(isep);           /* start with the items */
    }
    if (this.size > 0)          /* print last item (if any) */
      b.append(this.ibase.get(this.items[this.size-1]));
    if (wgt) {                  /* if to add a transaction weight */
      b.append(isep); b.append(this.wgt); }
    return b.toString();        /* return the string representation */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @param  isep the item separator
   *  @return the created string description
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String toString (String isep)
  { return toString(isep, false); }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @param  wgt whether to write a transaction weight
   *  @return the created string description
   *  @since  2017.06.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String toString (boolean wgt)
  { return toString(null, wgt); }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return the created string description
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String toString ()
  { return toString(null, false); }

}  /* class TrAct */
