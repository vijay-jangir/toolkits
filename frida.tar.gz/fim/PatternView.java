/*----------------------------------------------------------------------
  File    : PatternView.java
  Contents: patterns visualization program
  Author  : Christian Borgelt
  History : 2013.11.28 file created from ARuleView.java
            2014.10.23 changed from LGPL license to MIT license
            2016.11.04 merged with ItemSetView.java
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.TableModelEvent;

import util.TableReader;
import util.TableWriter;
import dialog.FormatPanel;
import dialog.FormatDialog;
import dialog.AboutDialog;

/*--------------------------------------------------------------------*/
/** Class for an item pattern viewer.
 *  @author Christian Borgelt
 *  @since  2013.11.28 */
/*--------------------------------------------------------------------*/
public class PatternView extends JFrame implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010003L;
  public  static final String VERSION = "1.3 (2016.11.04)";

  /** mode flag: the viewer is a stand-alone program */
  public final static int PROGRAM    = 1;
  /** mode flag: add menu items for loading trees */
  public final static int LOAD_ITEMS = 2;
  /** mode flag: add menu items for saving trees */
  public final static int SAVE_ITEMS = 4;
  /** mode flag: add menu items for loading and saving trees */
  public final static int FILE_ITEMS = LOAD_ITEMS | SAVE_ITEMS;
  /** mode flag: add all menu items */
  public final static int ALL_ITEMS  = FILE_ITEMS;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this patterns viewer */
  private Component    owner   = null;
  /** the mode flags */
  private int          mode    = 0;
  /** the patterns table */
  private PatternTable table   = null;
  /** the scroll pane for the viewport */
  private JScrollPane  scroll  = null;
  /** the table view */
  private JTable       view    = null;
  /** the status bar for messages */
  private JTextField   stat    = null;
  /** the file chooser */
  private JFileChooser chooser = null;
  /** the current patterns file */
  private File         curr    = null;
  /** the data format dialog box */
  private FormatDialog format  = null;
  /** the "About..." dialog box */
  private AboutDialog  about   = null;

  /*------------------------------------------------------------------*/
  /** Create an item pattern viewer.
   *  @param  mode the mode flags
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternView (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create an item pattern viewer.
   *  @param  owner the component that is to own this viewer
   *  @param  mode  the mode flags
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternView (Component owner, int mode)
  {                             /* --- create an item pattern viewer */
    this.owner = null;          /* clear the owner and */
    this.mode  = mode;          /* note the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* PatternView() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    if ((this.mode & PROGRAM) != 0)
      this.mode |= LOAD_ITEMS;  /* check and adapt the mode */

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    if ((this.mode & LOAD_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Load Patterns...", 'l'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          PatternView.this.loadPatterns(null); } } );
      item = menu.add(new JMenuItem("Reload Patterns", 'r'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          PatternView.this.loadPatterns(PatternView.this.curr); } } );
      menu.addSeparator();
    }
    if ((this.mode & SAVE_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Save Patterns", 's'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          PatternView.this.savePatterns(PatternView.this.curr); } } );
      item = menu.add(new JMenuItem("Save Patterns as...", 'a'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          PatternView.this.savePatterns(null); } } );
      menu.addSeparator();
    }
    if ((this.mode & FILE_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Data Format...", 'f'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          PatternView.this.getFormatDlg().setVisible(true);
          PatternView.this.format.toFront();
        } } );
      menu.addSeparator();
    }

    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          PatternView.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("Sort"));
    menu.setMnemonic('s');
    item = menu.add(new JMenuItem("by Size", 'z'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        PatternView.this.sortPatterns(PatternSet.SIZE); } } );
    item = menu.add(new JMenuItem("by Support", 's'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        PatternView.this.sortPatterns(PatternSet.SUPP); } } );
    item = menu.add(new JMenuItem("by Evaluation", 'e'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        PatternView.this.sortPatterns(PatternSet.EVAL); } } );

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (PatternView.this.about == null)
          PatternView.this.about = new AboutDialog(PatternView.this,
             "About PatternView...", "PatternView\n"
            +"A Simple Item Pattern Set Viewer\n"
            +"Version " +PatternView.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        PatternView.this.about.setVisible(true);
        PatternView.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    this.view   = new JTable();
    this.scroll = new JScrollPane(this.view);
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(this.scroll, BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    stat = new JTextField("");
    stat.setEditable(false);
    content.add(this.stat,   BorderLayout.SOUTH);

    /* --- show the frame window --- */
    this.setTitle("PatternView");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser (create if necessary).
   *  @return the file chooser
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure file chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Get the data format dialog (create if necessary).
   *  @return the data format dialog
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatDialog getFormatDlg()
  {                             /* --- get the data format dialog */
    if (this.format == null)    /* if it does not exist, create it */
      this.format = new FormatDialog(this, "Set Data Format...", 0);
    return this.format;         /* return the data format dialog */
  }  /* getFormatDlg() */

  /*------------------------------------------------------------------*/
  /** Set the message to display in the status line.
   *  @param  msg the message to display
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.stat.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Set the item patterns to display.
   *  @param  pats the item pattern set to display
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPatterns (PatternSet pats)
  {                             /* --- set patterns to display */
    this.view.setModel(this.table = new PatternTable(pats));
    Dimension size = this.view.getPreferredSize();
    if (size.width  > 400) size.width  = 400;
    if (size.height > 400) size.height = 400;
    this.view.getColumnModel().getColumn(
      this.view.getColumnCount()-1).setPreferredWidth(160);
    this.view.setPreferredScrollableViewportSize(size);
    this.pack();                /* re-layout the window */
  }  /* setPatterns() */

  /*------------------------------------------------------------------*/
  /** Get the currently displayed set of item patterns.
   *  @return the currently displayed set of item patterns
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PatternSet getPatterns ()
  { return this.table.getPatterns(); }

  /*------------------------------------------------------------------*/
  /** Sort the item patterns.
   *  @param  field the identifier of the field to compare first
   *  @since  2014.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sortPatterns (int field)
  {                             /* --- sort the item patterns */
    if (this.table == null) return;
    this.table.sort(field);     /* sort item sets and update viewer */
    this.view.tableChanged(new TableModelEvent(this.table));
  }  /* sortPatterns() */

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void reportError (String msg)
  {                             /* --- report an i/o error */
    this.stat.setText(msg);     /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this,
      msg, "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load a set of patterns.
   *  @param  file the file to load the patterns from
   *  @return whether the file was successfully loaded
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadPatterns (File file)
  {                             /* --- load a set of patterns */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a reader for the file */
      long t = System.currentTimeMillis();
      System.err.print("reading " +file +" ... ");
      FileReader reader = new FileReader(file);
      PatternSet pats   = PatternSet.parse(null, reader);
      reader.close();           /* read the patterns and */
      this.setPatterns(pats);   /* set them for display */
      t = System.currentTimeMillis() -t;
      System.err.print("[" +pats.getCount());
      System.err.print(" pattern(s)] done");
      System.err.println(" [" +(t/(float)1000.0) +"s]."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.stat.setText(file.getPath());
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadPatterns() */

  /*------------------------------------------------------------------*/
  /** Save the displayed set of patterns.
   *  @param  file the file to save the patterns to
   *  @return whether the file was successfully saved
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean savePatterns (File file)
  {                             /* --- save displayed patterns */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a writer for the file */
      System.err.print("writing " +file +" ... ");
      FileWriter writer = new FileWriter(file);
      PatternSet pats   = this.table.getPatterns();
      pats.write(writer);       /* save the patterns */
      writer.close();           /* then close the file */
      System.err.print("[" +pats.getCount());
      System.err.println("pattern(s)] done."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.curr = file;           /* note the new file name */
    return true;                /* return 'saving successful' */
  }  /* savePatterns() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2013.11.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    PatternView pv = new PatternView(PROGRAM|ALL_ITEMS);
    if (args.length > 0) pv.loadPatterns(new File(args[0]));
    pv.setVisible(true);        /* create and show pattern viewer */
  }  /* main() */

}  /* class PatternView */
