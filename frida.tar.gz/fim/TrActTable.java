/*----------------------------------------------------------------------
  File    : TrActTable.java
  Contents: transaction viewer table
  Author  : Christian Borgelt
  History : 2007.06.06 file created
----------------------------------------------------------------------*/
package fim;

import java.io.IOException;
import java.io.FileReader;
import java.awt.Dimension;
import javax.swing.table.AbstractTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JFrame;

import util.TableReader;

/*--------------------------------------------------------------------*/
/** Class for a tabular representation of a set of transactions.
 *  @author Christian Borgelt
 *  @since  2007.06.06 */
/*--------------------------------------------------------------------*/
public class TrActTable extends AbstractTableModel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the set of transactions */
  protected TrActBag taset;

  /*------------------------------------------------------------------*/
  /** Create a transaction table.
   *  @param  taset the set of transactions
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrActTable (TrActBag taset)
  {                             /* --- create a transaction table */
    if (taset == null) taset = new TrActBag();
    this.taset = taset;         /* note the transaction set */
  }  /* TrActTable() */

  /*------------------------------------------------------------------*/
  /** Get the transactions.
   *  @return the transaction set
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TrActBag getTrActs ()
  { return this.taset; }

  /*------------------------------------------------------------------*/
  /** Set the transactions.
   *  @param  taset the new transaction set
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTrActs (TrActBag taset)
  { this.taset = taset; }

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.taset != null) ? this.taset.getSize() : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return the number of columns of the table
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  {                             /* --- get number of table columns */
    if (this.taset == null) return 0;
    int n = this.taset.getMaxSize();
    return (!this.taset.unitWeight()) ? n+1 : n;
  }  /* getColumnCount() */

  /*------------------------------------------------------------------*/
  /** Get the name of a column.
   *  @param  i the index of the column
   *  @return the name of the column with index i
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int i)
  {                             /* --- get name of table column */
    return ((this.taset == null) || (i < this.taset.getMaxSize()))
         ? String.valueOf(i+1) : "weight";
  }  /* getColumnName() */

  /*------------------------------------------------------------------*/
  /** Get the value in a table cell.
   *  @param  row the row    index of the table cell
   *  @param  col the column index of the table cell
   *  @return an object representing the contents of the table cell
   *  @since  2007.06.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  {                             /* --- get value of table field */
    TrAct t = this.taset.getTrAct(row);
    if (col >= this.taset.getMaxSize()) return t.getWeight();
    return (col < t.getSize()) ? t.getItemName(col) : null;
  }  /* getValueAt() */

  /*------------------------------------------------------------------*/
  /** Main function for testing some basic functionality.
   *  <p>It is tried to parse the file that is given as the first
   *  command line argument as a set of transactions.</p>
   *  @param  args the command line arguments
   *  @since  2005.07.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    Dimension   size;           /* table size */
    TableReader reader;         /* table reader to read from */
    TrActBag    taset;          /* created transaction set */
    TrActTable  table;          /* table for the transaction set */
    JTable      tview;          /* view for the table */
    JFrame      frame;          /* surrounding frame */

    try {                       /* try to read the given file */
      if (args.length <= 0)     /* if no arguments given */
        reader = new TableReader("a b c\na d e f\nb d f\nc d e");
      else                      /* if a file argument is given */
        reader = new TableReader(new FileReader(args[0]));
      taset = TrActBag.parse(null, reader);
      reader.close(); }         /* parse the transaction set */
    catch (IOException e) {     /* catch and report i/o errors */
      System.err.println(e.getMessage()); return; }
    table = new TrActTable(taset);
    tview = new JTable(table);
    size  = tview.getPreferredSize();
    if (size.width  > 800) size.width  = 800;
    if (size.height > 600) size.height = 600;
    tview.setPreferredScrollableViewportSize(size);
    frame = new JFrame();     /* create the frame for display */
    frame.getContentPane().add(new JScrollPane(tview));
    frame.setLocation(48, 48);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack(); frame.setVisible(true);
  }  /* main() */

}  /* TrActTable */
