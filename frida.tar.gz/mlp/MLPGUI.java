/*----------------------------------------------------------------------
  File    : MLPGUI.java
  Contents: graphical user interface for multilayer perceptron programs
  Author  : Christian Borgelt
  History : 2007.05.30 file created
            2007.05.05 parameter tabs designed
            2007.06.05 training command creation added
            2007.07.07 adapted to new class TabPanel
            2013.04.22 adapted to type argument of JComboBox
            2014.10.20 trimming of spaces from number arguments added
            2014.10.23 terminal added, changed from LGPL to MIT license
            2018.11.14 replaced some deprecated functions
----------------------------------------------------------------------*/
package mlp;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JSpinner;

import util.Executable;
import util.Executor;
import util.ObjExecutor;
import util.CmdExecutor;
import dialog.TabbedGUI;
import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.DomainsPanel;
import dialog.AboutPanel;

/*--------------------------------------------------------------------*/
/** Class for a user interface to the multilayer perceptron programs.
 *  @author Christian Borgelt
 *  @since  2007.05.30 */
/*--------------------------------------------------------------------*/
public class MLPGUI extends TabbedGUI implements ItemListener{

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00020001L;
  public  static final String VERSION = "2.1 (2018.11.14)";

  /** tab index: domain determination */
  private static final int DOMAINS   = 1;
  /** tab index: neuron parameters */
  private static final int NEURONS   = 2;
  /** tab index: pattern parameters */
  private static final int PATTERNS  = 3;
  /** tab index: training parameters 1 */
  private static final int PARAMS_1  = 4;
  /** tab index: training parameters 2 */
  private static final int PARAMS_2  = 5;
  /** tab index: multilayer perceptron training */
  private static final int TRAINING  = 6;
  /** tab index: multilayer perceptron execution */
  private static final int EXECUTION = 7;
  /** tab index: multilayer perceptron sensitivity analysis */
  private static final int SENSITY   = 8;

  /** the names of the update methods */
  private static final String[] metnames = {
    "standard backpropagation",
    "manhattan training",
    "super self-adaptive backpropagation",
    "resilient backpropagation",
    "quick backpropagation",
    "adaptive subgradient descent (AdaGrad)",
    "root mean squared gradient (RMSProp)",
    "RMSProp with 2nd order term (AdaDelta)",
    "adaptive moment estimation (Adam)",
    "Adam with bias correction",
    "Adam with Nesterov acceleration (NAdam)",
    "NAdam with bias correction",
    "Adam with l_inf estimation",
    "Adam with l_inf and bias correction",
    "Adam with variance maximum (AMSGrad)" };
  /** the codes of the update methods */
  private static final String[] metcodes = {
    "standard", "manhattan", "supersab", "rprop", "quick",
    "adagrad", "rmsprop", "adadelta", "adam", "adambc",
    "nadam", "nadambc", "adamax", "adamaxbc", "amsgrad" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /* --- neurons --- */
  /** number of units in first hidden layer */
  private JSpinner          hidden1;
  /** number of units in second hidden layer */
  private JSpinner          hidden2;
  /** number of units in third hidden layer */
  private JSpinner          hidden3;
  /** the seed value for (pseudo-)random numbers */
  private JTextField        seed;

  /* --- patterns --- */
  /** the maximum number of update epochs */
  private JSpinner          epochs;
  /** the number of patterns between two updates */
  private JSpinner          update;
  /** whether to shuffle the training patterns */
  private JCheckBox         shuffle;
  /** whether to normalize the input ranges */
  private JCheckBox         norm;
  /** the expansion factor for output ranges */
  private JTextField        expand;

  /* --- training parameters 1 --- */
  /** the learning rate */
  private JTextField        lrate;
  /** the flat spot elimination */
  private JTextField        flat;
  /** the weight decay factor */
  private JTextField        decay;
  /** the range for weight jogging */
  private JTextField        jog;
  /** the initial weight range */
  private JTextField        range;
  /** the error for termination */
  private JTextField        term;

  /* --- training parameters 2 --- */
  /** the parameter update method */
  private JComboBox<String> method;
  /** the momentum coefficient */
  private JTextField        moment;
  /** the minimal change/learning rate */
  private JTextField        minchg;
  /** the maximal change/learning rate */
  private JTextField        maxchg;
  /** the growth factor */
  private JTextField        growth;
  /** the shrink factor */
  private JTextField        shrink;
  /** the decay factor for the gradient mean */
  private JTextField        dmean;
  /** the decay factor for the gradient variance */
  private JTextField        dvar;
  /** the epsilon value */
  private JTextField        epsilon;

  /** the labels that can be disabled in the tab */
  private JLabel[]          labels;
  /** the help texts that can be disabled in the tab */
  private JTextArea[]       helps;

  /* --- training --- */
  /** the name of the domains file */
  private JTextField        fn_dom;
  /** the name of the target attribute */
  private JTextField        target;
  /** the name of the table/pattern file */
  private JTextField        fn_tab;
  /** the name of the multilayer perceptron file */
  private JTextField        fn_mlp;

  /* --- execution --- */
  /** the name of the multilayer perceptron file */
  private JTextField        fn_exec;
  /** the name of the table input file */
  private JTextField        fn_in;
  /** the name of the prediction field */
  private JTextField        pred;
  /** the name of the confidence field */
  private JTextField        conf;
  /** whether to write the field names to the first record */
  private JCheckBox         write;
  /** the name of the table output file */
  private JTextField        fn_out;

  /* --- sensitivity analysis --- */
  /** the name of the multilayer perceptron file */
  private JTextField        fn_sens;
  /** the name of the table/pattern file */
  private JTextField        fn_tse;
  /** whether to sum sensitivity over output units */
  private JCheckBox         sumout;
  /** whether to sum sensitivity over input units */
  private JCheckBox         sumin;
  /** whether to normalize the sensitivity */
  private JCheckBox         snorm;
  /** the name of the sensitivity values file */
  private JTextField        fn_val;

  /*------------------------------------------------------------------*/
  /** Create a multilayer perceptron graphical user interface.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2007.05.30 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public MLPGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a multilayer perceptron graphical user interface.
   *  @param  owner the component that is to own this dialog
   *  @since  2007.05.30 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public MLPGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Update the parameter context after a method selection.
   *  @since  2007.06.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void itemStateChanged (ItemEvent e)
  {                             /* --- process a method selection */
    int m, g, r, d;             /* flags for the different groups */

    switch (this.method.getSelectedIndex()) {
      case  0:                  /* vanilla */
        m = +1; g =  0; r =  0; d = -1; break;
      case  1:                  /* manhattan */
        m =  0; g =  0; r =  0; d = -1; break;
      case  2:                  /* supersab */
        m =  0; g = +1; r = +1; d = -1; break;
      case  3:                  /* rprop */
        m =  0; g = +1; r = +1; d = -1; break;
      case  4:                  /* quick */
        m =  0; g =  0; r = +1; d = -1; break;
      case  5:                  /* adagrad */
        m = +1; g = -1; r = -1; d = +1; break;
      case  6:                  /* rmsprop */
        m = +1; g = -1; r = -1; d = +1; break;
      case  7:                  /* adam */
        m =  0; g = -1; r = -1; d = +2; break;
      case  8:                  /* adamcorr */
        m =  0; g = -1; r = -1; d = +2; break;
      case  9:                  /* adamax */
        m =  0; g = -1; r = -1; d = +2; break;
      case 10:                  /* adamcmax */
        m =  0; g = -1; r = -1; d = +2; break;
      default:                  /* default */
        m =  0; g =  0; r =  0; d = -1; break;
    }

    this.moment.setVisible(m >= 0); /* momentum term */
    this.moment.setEnabled(m >  0);
    this.labels[0].setVisible(m >= 0);
    this.labels[0].setEnabled(m >  0);
    this.helps[0].setVisible(m >= 0);
    this.helps[0].setEnabled(m >  0);

    this.growth.setVisible(g >= 0); /* growth factor */
    this.growth.setEnabled(g >  0);
    this.labels[1].setVisible(g >= 0);
    this.labels[1].setEnabled(g >  0);

    this.shrink.setVisible(g >= 0); /* shrink factor */
    this.shrink.setEnabled(g >  0);
    this.labels[2].setVisible(g >= 0);
    this.labels[2].setEnabled(g >  0);
    this.helps[1].setVisible(g >= 0);
    this.helps[1].setEnabled(g >  0);

    this.minchg.setVisible(r >= 0); /* minimum change/learning rate */
    this.minchg.setEnabled(r >  0);
    this.labels[3].setVisible(r >= 0);
    this.labels[3].setEnabled(r >  0);

    this.maxchg.setVisible(r >= 0); /* maximum change/learning rate */
    this.maxchg.setEnabled(r >  0);
    this.labels[4].setVisible(r >= 0);
    this.labels[4].setEnabled(r >  0);
    this.helps[2].setVisible(r >= 0);
    this.helps[2].setEnabled(r >  0);

    this.dmean.setVisible(d >= 0);  /* gradient mean decay */
    this.dmean.setEnabled(d >  1);
    this.labels[5].setVisible(d >= 0);
    this.labels[5].setEnabled(d >  1);

    this.dvar.setVisible(d >= 0);   /* gradient variance decay */
    this.dvar.setEnabled(d >  0);
    this.labels[6].setVisible(d >= 0);
    this.labels[6].setEnabled(d >  0);
    this.helps[3].setVisible(d >= 0);
    this.helps[3].setEnabled(d >  0);

    this.epsilon.setVisible(d >= 0); /* minimum denominator */
    this.epsilon.setEnabled(d >  0);
    this.labels[7].setVisible(d >= 0);
    this.labels[7].setEnabled(d >  0);
    this.helps[4].setVisible(d >= 0);
    this.helps[4].setEnabled(d >  0);
  }  /* itemStateChanged() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.05.30 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    DialogPanel tab;            /* current tab of the tabbed pane */

    /* --- basic tabs --- */
    this.base("Multilayer Perceptron Tools");
    this.addFormatTab (FormatPanel.HEADER
                     | FormatPanel.WEIGHT
                     | FormatPanel.NONULLS);
    this.addDomainsTab(DomainsPanel.LOCATE);
    this.labels = new JLabel[8];
    this.helps  = new JTextArea[5];

    /* --- Neurons --- */
    tab = this.addTab("Neurons");

    tab.addLabel("Hidden neurons (layer 1):");
    this.hidden1 = tab.addSpinner(2, 0, 999999, 1);
    tab.addLabel("Hidden neurons (layer 2):");
    this.hidden2 = tab.addSpinner(0, 0, 999999, 1);
    tab.addLabel("Hidden neurons (layer 3):");
    this.hidden3 = tab.addSpinner(0, 0, 999999, 1);
    tab.addHelp("A multilayer perceptron consists of an input layer,\n"
               +"an output layer, and optional hidden layers.\n\n"
               +"The number of input and output neurons is determined\n"
               +"from the data types of the input attributes and the "
               +"target\nas they are specified in the domains file.\n\n"
               +"The numbers of hidden neurons must be specified "
               +"above.\nIf the number of hidden neurons is zero "
               +"for a layer,\nthe corresponding layer is not added "
               +"to the network.");
    tab.addFiller(0);

    tab.addLabel("Seed for random numbers:");
    this.seed = tab.addNumberInput("");
    tab.addHelp("If no value is given, "
               +"the current time is used as a seed.");

    /* --- Patterns --- */
    tab = this.addTab("Patterns");

    tab.addLabel("Max. number of epochs:");
    this.epochs = tab.addSpinner(1000, 0, 999999, 1);
    tab.addLabel("Patterns between updates:");
    this.update = tab.addSpinner(0, 0, 999999, 1);
    tab.addHelp("If the number of patterns to be processed between "
               +"weight\nupdates is zero, weights are updated once "
               +"per traversal\nof the training data. A value of 1 "
               +"means online training.");

    tab.addLabel("Shuffle between epochs:");
    this.shuffle = tab.addCheckBox(true);
    tab.addHelp("If the number of patterns to be processed between "
               +"weight\nupdates is less than the number of available "
               +"patterns,\nshuffling is recommended to avoid order "
               +"effects.");

    tab.addLabel("Normalize input ranges:");
    this.norm = tab.addCheckBox(true);
    tab.addHelp("If this box is checked, all input attributes "
               +"are normalized\nto mean 0 and variance 1 "
               +"in order to avoid scaling effects.");

    tab.addLabel("Output expansion factor:");
    this.expand = tab.addNumberInput("1");
    tab.addHelp("Due to the limiting behavior of the logistic "
               +"function,\nit can be useful to expand the range "
               +"of output values.");
    tab.addFiller(0);

    /* --- Parameters 1 --- */
    tab = this.addTab("Parameters 1");

    tab.addLabel("Learning rate:");
    this.lrate = tab.addNumberInput("0.2");
    tab.addHelp("For update methods that adapt the weight change "
               +"or the\nlearning rate, this is the initial change "
               +"or learning rate.");

    tab.addLabel("Flat spot elimination:");
    this.flat = tab.addNumberInput("");
    tab.addHelp("An offset added to the derivative "
               +"to avoid slow training.");

    tab.addLabel("Weight decay factor:");
    this.decay = tab.addNumberInput("");
    tab.addHelp("Weight decay can improve the stability "
               +"of training results.");

    tab.addLabel("Weight jogging range:       ");
    this.jog = tab.addNumberInput("");
    tab.addHelp("(Small) random values are added to the weights.");

    tab.addLabel("Initial weight range:");
    this.range = tab.addNumberInput("1");
    tab.addHelp("The initial connection weights "
               +"are generated randomly.");

    tab.addLabel("Error for termination:");
    this.term = tab.addNumberInput("0");
    tab.addHelp("If the sum of squared errors on the training data "
               +"does not\nexceed this value, the network training "
               +"is terminated.");
    tab.addFiller(0);

    /* --- Parameters 2 --- */
    tab = this.addTab("Parameters 2");

    tab.addLabel("Weight update method:", DialogPanel.RIGHT);
    this.method = tab.addComboBox(MLPGUI.metnames);
    this.method.addItemListener(this);
    tab.addFiller(2);

    this.labels[0] = tab.addLabel("Momentum coefficient:");
    this.moment    = tab.addNumberInput("");
    this.helps[0] =
    tab.addHelp("A momentum term speeds up standard backpropagation.");

    this.labels[1] = tab.addLabel("Growth factor:");
    this.growth    = tab.addNumberInput("1.2");
    this.labels[2] = tab.addLabel("Shrink factor:");
    this.shrink    = tab.addNumberInput("0.7");
    this.helps[1]  =
    tab.addHelp("Growth and shrink factors are used in super "
               +"self-adaptive\nbackpropagation (learning rate "
               +"adaptation) and resilient\nbackpropagation "
               +"(weight change adaptation).");

    this.labels[3] = tab.addLabel("Min. change/learning rate:");
    this.minchg    = tab.addNumberInput("0");
    this.labels[4] = tab.addLabel("Max. change/learning rate:");
    this.maxchg    = tab.addNumberInput("2");
    this.helps[2]  =
    tab.addHelp("These values constrain either the learning rate "
               +"(super\nself-adaptive backpropagation) or the "
               +"weight change\n(resilient backpropagation and "
               +"quick backpropagation).");

    this.labels[5] = tab.addLabel("Gradient mean decay:");
    this.dmean     = tab.addNumberInput("0.9");
    this.labels[6] = tab.addLabel("Gradient variance decay:");
    this.dvar      = tab.addNumberInput("0.999");
    this.helps[3]  =
    tab.addHelp("Decay factors are used to estimate mean and "
               +"variance\n(that is, first and second moment) "
               +"of the gradient\n"
               +"for the adaptive gradient methods.");
    this.labels[7] = tab.addLabel("Minimal denominator:");
    this.epsilon   = tab.addNumberInput("1e-8");
    this.helps[4]  =
    tab.addHelp("The minimal denominator prevents "
               +"a division by zero.");
    tab.addFiller(0);

    /* --- Training --- */
    tab = this.addTab("Training");

    tab.addLabel("Domains file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_dom); } } );
    tab.addButton("Edit", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.editDomains(MLPGUI.this.fn_dom); } } );
    this.fn_dom = tab.addFileInput("noname.dom");
    tab.addHelp("The domains file may also be a network file "
               +"containing the\ndescription of an already trained "
               +"network. In this case the\ntraining of this network "
               +"is continued (no reinitialization).");

    tab.addLabel("Target attribute:");
    this.target = tab.addTextInput("");
    tab.addHelp("If no target attribute is specified, the one listed "
               +"last in the\ndomains file is used. The type of the "
               +"target attribute and\nthus the network type is "
               +"determined from the domains file.");

    tab.addLabel("Training data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_tab); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.showTable(MLPGUI.this.fn_tab); } } );
    this.fn_tab = tab.addFileInput("noname.tab");

    tab.addLabel("Output network file:    ");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_mlp); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.editFile(MLPGUI.this.fn_mlp); } } );
    this.fn_mlp = tab.addFileInput("noname.mlp");
    tab.addFiller(0);

    /* --- multilayer perceptron execution --- */
    tab = this.addTab("Execution");

    tab.addLabel("Network file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_exec); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.editFile(MLPGUI.this.fn_exec); } } );
    this.fn_exec = tab.addFileInput("noname.mlp");

    tab.addLabel("Input data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_in); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.showTable(MLPGUI.this.fn_in); } } );
    this.fn_in = tab.addFileInput("noname.tab");

    tab.addLabel("Prediction field name:");
    this.pred = tab.addTextInput("mlp");
    tab.addLabel("Confidence field name:");
    this.conf = tab.addTextInput("");
    tab.addHelp("The confidence indicates how reliable "
               +"the prediction is.\nIt is derived from the "
               +"activations of the output neurons.");

    tab.addLabel("Write field names:");
    this.write = tab.addCheckBox(true);

    tab.addLabel("Output data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_out); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.showTable(MLPGUI.this.fn_out); } } );
    this.fn_out = tab.addFileInput("noname.out");
    tab.addFiller(0);

    /* --- multilayer perceptron sensitivity analysis --- */
    tab = this.addTab("Sensitivity");

    tab.addLabel("Network file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_sens); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.editFile(MLPGUI.this.fn_sens); } } );
    this.fn_sens = tab.addFileInput("noname.mlp");

    tab.addLabel("Input data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_tse); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.showTable(MLPGUI.this.fn_tse); } } );
    this.fn_tse = tab.addFileInput("noname.tab");

    tab.addLabel("Sum over outputs:");
    this.sumout = tab.addCheckBox(false);
    tab.addLabel("Sum over inputs:");
    this.sumin =  tab.addCheckBox(false);
    tab.addHelp("If these boxes are unchecked, the sensitivity "
               +"is determined\nby taking the maximum over the "
               +"output or input neurons.");

    tab.addLabel("Normalize sensitivity:");
    this.snorm = tab.addCheckBox(true);
    tab.addHelp("If this box is checked, the sensitivity is "
               +"normalized\nby dividing by the number of training "
               +"patterns.");

    tab.addLabel("Sensitivity output file: ");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.getFileName(MLPGUI.this.fn_val); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        MLPGUI.this.showTable(MLPGUI.this.fn_val); } } );
    this.fn_val = tab.addFileInput("noname.sns");
    tab.addFiller(0);

    /* --- Terminal --- */
    this.addTerminalTab("Terminal output of external programs");

    /* --- About --- */
    this.addTab("About", new AboutPanel(
       "Multilayer Perceptron Tools",
       "A simple user interface for the MLP programs.\n\n"
      +"Version " +MLPGUI.VERSION +"\n"
      +"written by Christian Borgelt\n"
      +"European Center for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.method.setSelectedIndex(1);
    this.method.setSelectedIndex(0);
    this.pack();
    this.selectTab(TRAINING);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  {                             /* --- set the domains file */
    this.domains.setDomainsFile(file);
    this.fn_dom.setText(file.getPath());
  }  /* setDomainsFile() */

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  {                             /* --- set the data file */
    this.domains.setDataFile(file);
    this.fn_tab.setText(file.getPath());
  }  /* setDataFile() */

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  {                             /* --- set the test file */
    String path = file.getPath();
    this.fn_in.setText(path);
    this.fn_tse.setText(path);
  }  /* setTestFile() */

  /*------------------------------------------------------------------*/
  /** Create a command to train a multilayer perceptron.
   *  @return the command to train a multilayer perceptron
   *  @since  2007.06.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createTrainingCmd ()
  {                             /* --- train multilayer perceptron */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s, p, e;           /* buffer for arguments */
    Integer  k;                 /* number of hidden units */

    cmd    = new String[40];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"mlpt";
    n = this.format.addFormatArgs(cmd);
    s = this.target.getText();  /* target field name */
    if (s.length() > 0) cmd[n++] = "-o" +s;
    p = "";                     /* numbers of hidden units */
    k = (Integer)this.hidden1.getValue();
    if (k.intValue() > 0) p = (p.length() > 0) ? p +":" +s : s;
    k = (Integer)this.hidden2.getValue();
    if (k.intValue() > 0) p = (p.length() > 0) ? p +":" +s : s;
    k = (Integer)this.hidden3.getValue();
    if (k.intValue() > 0) p = (p.length() > 0) ? p +":" +s : s;
    if (p.length() > 0) cmd[n++] = "-c" +p;
    s = this.seed.getText().trim(); /* seed value for random numbers */
    if (s.length() > 0) cmd[n++] = "-S" +s;
    if (!this.norm.isSelected())
      cmd[n++] = "-q";          /* normalization of input ranges */
    s = this.expand.getText().trim(); /* expansion factor for outputs */
    if (s.length() > 0) cmd[n++] = "-x" +s;
    cmd[n++] = "-e" +this.epochs.getValue();   /* number of epochs */
    cmd[n++] = "-k" +(Integer)this.update.getValue();
                                /* patterns between weight updates */
    if (!this.shuffle.isSelected())
      cmd[n++] = "-s";          /* pattern shuffling between epochs */
    s = this.lrate.getText().trim();   /* (initial) learning rate */
    if (s.length() > 0) cmd[n++] = "-t" +s;
    s = this.flat.getText().trim();    /* flat spot elimination */
    if (s.length() > 0) cmd[n++] = "-i" +s;
    s = this.range.getText().trim();   /* initial weight range */
    if (s.length() > 0) cmd[n++] = "-w" +s;
    s = this.decay.getText().trim();   /* weight decay factor */
    if (s.length() > 0) cmd[n++] = "-y" +s;
    s = this.jog.getText().trim();     /* weight jogging range */
    if (s.length() > 0) cmd[n++] = "-j" +s;
    s = this.term.getText().trim();    /* error for termination */
    if (s.length() > 0) cmd[n++] = "-T" +s;
    s = MLPGUI.metcodes[this.method.getSelectedIndex()];
    cmd[n++] = "-a" +s;         /* weight update method */
    s = this.moment.getText().trim();  /* momentum coefficient */
    if (s.length() > 0) cmd[n++] = "-m" +s;
    s = this.minchg.getText().trim();  /* min. change / learning rate */
    if (s.length() <= 0) this.minchg.setText(s = "0");
    p = this.maxchg.getText().trim();  /* max. change / learning rate */
    if (p.length() <= 0) this.maxchg.setText(p = "2");
    cmd[n++] = "-z" +s +":" +p;
    s = this.growth.getText().trim();  /* growth factor */
    if (s.length() <= 0) this.growth.setText(s = "1.2");
    p = this.shrink.getText().trim();  /* shrink factor */
    if (p.length() <= 0) this.shrink.setText(p = "0.7");
    cmd[n++] = "-g" +s +":" +p;
    s = this.dmean.getText().trim();   /* gradient mean decay */
    if (s.length() <= 0) this.growth.setText(s = "0.9");
    p = this.dvar.getText().trim();    /* gradient variance decay */
    if (p.length() <= 0) this.shrink.setText(p = "0.999");
    e = this.epsilon.getText().trim(); /* minimal denominator */
    if (p.length() <= 0) this.shrink.setText(p = "1e-8");
    cmd[n++] = "-p" +s +":" +p +":" +e;
    cmd[n++] = this.fn_dom.getText();
    cmd[n++] = this.fn_tab.getText();
    cmd[n++] = this.fn_mlp.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createTrainingCmd() */  /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a command to execute a multilayer perceptron.
   *  @return the command to execute a multilayer perceptron
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createExecutionCmd ()
  {                             /* --- execute multilayer perceptron */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[16];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"mlpx";
    n = this.format.addFormatArgs(cmd);
    s = this.pred.getText();    /* prediction field name */
    if (s.length() <= 0) this.pred.setText(s = "mlp");
    cmd[n++] = "-p" +s;
    s = this.conf.getText();    /* confidence field name */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    if (!this.write.isSelected())
      cmd[n++] = "-w";          /* do not write field names */
    cmd[n++] = this.fn_exec.getText();
    cmd[n++] = this.fn_in.getText();
    cmd[n++] = this.fn_out.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createExecutionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a command to execute a multilayer perceptron.
   *  @return the command to execute a multilayer perceptron
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createSensitivityCmd ()
  {                             /* --- sensitivity analysis */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */

    cmd    = new String[16];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"mlps";
    n = this.format.addFormatArgs(cmd);
    if (this.sumout.isSelected()) cmd[n++] = "-s";
    if (this.sumin.isSelected())  cmd[n++] = "-i";
    if (!this.snorm.isSelected()) cmd[n++] = "-n";
    cmd[n++] = this.fn_sens.getText();
    cmd[n++] = this.fn_tse.getText();
    cmd[n++] = this.fn_val.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createSensitivityCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Get the executor for a dialog tab.
   *  @param  i the index of the dialog tab
   *  @return the executor for the <code>i</code>-th dialog tab
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- get the executor for a tab */
    String[]   cmd;             /* command for external program */
    Executable obj;             /* executable object */

    if (this.domains.useExternal()) {
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS  : cmd = this.createDomainsCmd();     break;
        case NEURONS  : case PATTERNS:
        case PARAMS_1 : case PARAMS_2:
        case TRAINING : cmd = this.createTrainingCmd();    break;
        case EXECUTION: cmd = this.createExecutionCmd();   break;
        case SENSITY  : cmd = this.createSensitivityCmd(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new CmdExecutor(cmd, this); }
    else {                      /* if to use internal programs */
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS: obj = this.createDomainsObj(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new ObjExecutor(obj, this);
    }                           /* create and return the executor */
  }  /* createExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    int    i, k;                /* index variables */
    String txt, msg;            /* buffers for text and message */

    if (this.index == DOMAINS)  /* if domains determination */
      return this.getDomainsMsg();
    if ((this.index >= NEURONS) /* if network training */
    &&  (this.index <= TRAINING)) {
      txt = ((CmdExecutor)this.executor).getErrorData();
      i   = txt.indexOf("[", txt.lastIndexOf("creating network ... ["));
      k   = txt.indexOf(",", i);
      msg = txt.substring(i+1, k);
      i   = txt.indexOf("]", k);
      msg = msg +" and" +txt.substring(k+1, i);
      i   = txt.lastIndexOf("[");
      k   = txt.indexOf("]", i);
      return "Trained multilayer perceptron\nhas "
          + msg +"\n" +txt.substring(i, k+1) +".";
    }                           /* extract network description */
    if (this.index == EXECUTION) {  /* if network execution */
      msg = ((CmdExecutor)this.executor).getLastErrorLine();
      return "Multilayer perceptron execution leads to\n" +msg +".";
    }                           /* extract error information */
    if (this.index == SENSITY){ /* if sensitivity analysis */
      txt = ((CmdExecutor)this.executor).getLastErrorLine();
      i   = txt.lastIndexOf("[", txt.indexOf("attribute(s)]"));
      k   = txt.indexOf("]", i);   /* extract attribute report */
      msg = txt.substring(i+1, k);
      return "Sensitivity information for\n" +msg +" written.";
    }                           /* extract error information */
    return null;                /* otherwise there is no message */
  }  /* getResultMsg() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  {                             /* --- load configuration file */
    if (file == null) {         /* if no file name is given */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Load Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileReader reader = new FileReader(file);
      /* --- Format & Domains --- */
      this.format.loadConfig(reader);
      this.domains.loadConfig(reader);
      /* --- text parameters --- */
      /* --- Neurons --- */
      this.seed.setText   (this.readLine(reader));
      /* --- Patterns --- */
      this.expand.setText (this.readLine(reader));
      /* --- Parameters 1 --- */
      this.lrate.setText  (this.readLine(reader));
      this.flat.setText   (this.readLine(reader));
      this.decay.setText  (this.readLine(reader));
      this.jog.setText    (this.readLine(reader));
      this.range.setText  (this.readLine(reader));
      this.term.setText   (this.readLine(reader));
      /* --- Parameters 2 --- */
      this.moment.setText (this.readLine(reader));
      this.growth.setText (this.readLine(reader));
      this.shrink.setText (this.readLine(reader));
      this.minchg.setText (this.readLine(reader));
      this.maxchg.setText (this.readLine(reader));
      /* --- Training --- */
      this.fn_dom.setText (this.readLine(reader));
      this.fn_tab.setText (this.readLine(reader));
      this.fn_mlp.setText (this.readLine(reader));
      this.target.setText (this.readLine(reader));
      /* --- Execution --- */
      this.fn_exec.setText(this.readLine(reader));
      this.fn_in.setText  (this.readLine(reader));
      this.fn_out.setText (this.readLine(reader));
      this.pred.setText   (this.readLine(reader));
      this.conf.setText   (this.readLine(reader));
      /* --- Sensitivity --- */
      this.fn_sens.setText(this.readLine(reader));
      this.fn_tse.setText (this.readLine(reader));
      this.fn_val.setText (this.readLine(reader));
      /* --- Neurons --- */
      this.hidden1.setValue(Integer.valueOf(this.readInt(reader)));
      this.hidden2.setValue(Integer.valueOf(this.readInt(reader)));
      this.hidden3.setValue(Integer.valueOf(this.readInt(reader)));
      /* --- Patterns --- */
      this.epochs.setValue (Integer.valueOf(this.readInt(reader)));
      this.update.setValue (Integer.valueOf(this.readInt(reader)));
      this.shuffle.setSelected    (this.readInt(reader) != 0);
      this.norm.setSelected       (this.readInt(reader) != 0);
      /* --- Parameters 1 --- */
      /* --- Parameters 2 --- */
      this.method.setSelectedIndex(this.readInt(reader));
      /* --- Training --- */
      /* --- Execution --- */
      this.write.setSelected      (this.readInt(reader) != 0);
      /* --- Sensitivity --- */
      this.sumout.setSelected     (this.readInt(reader) != 0);
      this.sumin.setSelected      (this.readInt(reader) != 0);
      this.snorm.setSelected      (this.readInt(reader) != 0);
      reader.close(); }         /* read the configuration values */
    catch (IOException e) {     /* and close the input file */
      JOptionPane.showMessageDialog(this,
        "Error reading configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* check for successful reading */
    this.status.setText("configuration loaded: " +file.getName());
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  {                             /* --- save configuration file */
    if (file == null) {         /* if no file name is given, */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Save Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileWriter writer = new FileWriter(file);
      /* --- Format & Domains --- */
      this.format.saveConfig(writer);
      this.domains.saveConfig(writer);
      /* --- text parameters --- */
      /* --- Neurons --- */
      writer.write(this.seed.getText());    writer.write('\n');
      /* --- Patterns --- */
      writer.write(this.expand.getText());  writer.write('\n');
      /* --- Parameters 1 --- */
      writer.write(this.lrate.getText());   writer.write('\n');
      writer.write(this.flat.getText());    writer.write('\n');
      writer.write(this.decay.getText());   writer.write('\n');
      writer.write(this.jog.getText());     writer.write('\n');
      writer.write(this.range.getText());   writer.write('\n');
      writer.write(this.term.getText());    writer.write('\n');
      /* --- Parameters 2 --- */
      writer.write(this.moment.getText());  writer.write('\n');
      writer.write(this.growth.getText());  writer.write('\n');
      writer.write(this.shrink.getText());  writer.write('\n');
      writer.write(this.minchg.getText());  writer.write('\n');
      writer.write(this.maxchg.getText());  writer.write('\n');
      /* --- Training --- */
      writer.write(this.fn_dom.getText());  writer.write('\n');
      writer.write(this.fn_tab.getText());  writer.write('\n');
      writer.write(this.fn_mlp.getText());  writer.write('\n');
      writer.write(this.target.getText());  writer.write('\n');
      /* --- Execution --- */
      writer.write(this.fn_exec.getText()); writer.write('\n');
      writer.write(this.fn_in.getText());   writer.write('\n');
      writer.write(this.fn_out.getText());  writer.write('\n');
      writer.write(this.pred.getText());    writer.write('\n');
      writer.write(this.conf.getText());    writer.write('\n');
      /* --- Sensitivity --- */
      writer.write(this.fn_sens.getText()); writer.write('\n');
      writer.write(this.fn_tse.getText());  writer.write('\n');
      writer.write(this.fn_val.getText());  writer.write('\n');
      /* --- flags & indices --- */
      /* --- Neurons --- */
      writer.write(((Integer)this.hidden1.getValue()).intValue() +",");
      writer.write(((Integer)this.hidden2.getValue()).intValue() +",");
      writer.write(((Integer)this.hidden3.getValue()).intValue() +",");
      /* --- Patterns --- */
      writer.write(((Integer)this.epochs.getValue()).intValue() +",");
      writer.write(((Integer)this.update.getValue()).intValue() +",");
      writer.write(this.shuffle.isSelected() ? "1," : "0,");
      writer.write(this.norm.isSelected()    ? "1," : "0,");
      /* --- Parameters 1 --- */
      /* --- Parameters 2 --- */
      writer.write(this.method.getSelectedIndex()   +",");
      /* --- Training --- */
      /* --- Execution --- */
      writer.write(this.write.isSelected()   ? "1," : "0,");
      /* --- Sensitivity --- */
      writer.write(this.sumout.isSelected()  ? "1," : "0,");
      writer.write(this.sumin.isSelected()   ? "1," : "0,");
      writer.write(this.snorm.isSelected()   ? "1," : "0,");
      writer.write('\n');       /* write the configuration values */
      writer.close(); }         /* and close the output file */
    catch (IOException e) {     /* check for successful writing */
      JOptionPane.showMessageDialog(this,
        "Error writing configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show a status message */
    this.status.setText("configuration saved: " +file.getName());
  }  /* saveConfig() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    MLPGUI gui = new MLPGUI();  /* create an MLP user interface */
    if (args.length > 0)        /* load configuration if necessary */
      gui.loadConfig(new File(args[0]));
    gui.setVisible(true);       /* show the user interface */
  }  /* main() */

}  /* class MLPGUI */
