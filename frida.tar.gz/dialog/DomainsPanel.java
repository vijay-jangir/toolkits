/*----------------------------------------------------------------------
  File    : DomainsPanel.java
  Contents: domains determination panel for graphical user interfaces
  Author  : Christian Borgelt
  History : 2007.02.11 file created
            2007.03.12 cleaned up and simplified
            2007.05.09 command and finder creation moved here
            2007.05.17 optional use of external programs added
            2007.07.07 made a subclass of class DialogPanel
            2007.07.24 functions to get and set the files added
            2007.07.27 functions to get and set the operations added
            2013.08.06 bug in function createFinder() fixed (getMode)
----------------------------------------------------------------------*/
package dialog;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.JCheckBox;

import table.DomainsFinder;

/*--------------------------------------------------------------------*/
/** Class for a domains determination panel
 *  for graphical user interfaces.
 *  @author Christian Borgelt
 *  @since  2007.02.11 */
/*--------------------------------------------------------------------*/
public class DomainsPanel extends DialogPanel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010002L;
  /** mode: external programs checkbox */
  public static final int EXTERNAL = 1;
  /** mode: locate programs button */
  public static final int LOCATE   = 2;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the associated data format panel */
  protected FormatPanel format   = null;
  /** the path to the C programs */
  protected File        path     = null;
  /** the name of the table file */
  protected JTextField  fn_tab   = null;
  /** whether to determine types automatically */
  protected JCheckBox   autotype = null;
  /** whether to sort the values of nominal attributes */
  protected JCheckBox   sortvals = null;
  /** the name of the domains file */
  protected JTextField  fn_dom   = null;
  /** the path to the C programs */
  protected JCheckBox   extern   = null;

  /*------------------------------------------------------------------*/
  /** Create a domains determination panel.
   *  @param  mode the mode (additional input selector)
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsPanel (int mode)
  { this(mode, null); }

  /*------------------------------------------------------------------*/
  /** Create a domains determination panel.
   *  @param  format the corresponding format panel
   *  @since  2007.02.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsPanel (FormatPanel format)
  { this(0, format); }

  /*------------------------------------------------------------------*/
  /** Create a domains determination panel.
   *  @param  mode   the mode (additional input selector)
   *  @param  format the associated data format panel
   *  @since  2007.02.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsPanel (int mode, FormatPanel format)
  {                             /* --- create a domains det. panel */
    this.format = format;       /* note the data format panel */
    this.path   = null;         /* clear the path to the C programs */
    this.addLabel("Data file:");
    this.addButton("Select", MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsPanel.this.getFileName(DomainsPanel.this.fn_tab); } } );
    this.addButton("View", RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsPanel.this.showTable(DomainsPanel.this.fn_tab,
                                    DomainsPanel.this.format); } } );
    this.fn_tab = this.addFileInput("noname.tab");
    this.addLabel("Determine types:");
    this.autotype = this.addCheckBox("", true);
    this.addLabel("Sort nominal values:");
    this.sortvals = this.addCheckBox("", true);
    this.addLabel("Domains file:");
    this.addButton("Select", MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsPanel.this.getFileName(DomainsPanel.this.fn_dom); } } );
    this.addButton("Edit", RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsPanel.this.editDomains(DomainsPanel.this.fn_dom); } } );
    this.add(this.fn_dom = new JTextField("noname.dom"), RIGHT);
    this.addHelp(
       "The domains file states the scale types of the attributes.\n"
      +"An automatic type determination may fail, for instance,\n"
      +"because of numerically coded nominal attributes.\n"
      +"In such a case the domains file must be edited.");
    this.addFiller(0);
    if ((mode & EXTERNAL) != 0) {
      this.addLabel("Use external programs:");
      this.add(this.extern = new JCheckBox("", true), RIGHT);
    }
    if ((mode & LOCATE) != 0) {
      this.addFiller(0);
      this.addButton("Locate Programs...", RIGHT).addActionListener(
        new ActionListener () {
        public void actionPerformed (ActionEvent e) {
          JFileChooser c = DomainsPanel.this.getFileChooser();
          c.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
          c.setDialogTitle("Locate Program...");
          c.setCurrentDirectory(DomainsPanel.this.path);
          int r = c.showOpenDialog(DomainsPanel.this);
          if (r == JFileChooser.APPROVE_OPTION)
            DomainsPanel.this.path = c.getSelectedFile();
          c.setFileSelectionMode(JFileChooser.FILES_ONLY);
          c.setDialogTitle("Open File...");
        } } );
    }
  }  /* DomainsPanel() */

  /*------------------------------------------------------------------*/
  /** Get the associated data format panel.
   *  @return the associated data format panel
   *  @since  2014.04.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel getFormat ()
  { return this.format; }

  /*------------------------------------------------------------------*/
  /** Set the associated data format panel.
   *  @param  format the associated data format panel
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFormat (FormatPanel format)
  { this.format = format; }

  /*------------------------------------------------------------------*/
  /** Get the data file.
   *  @return the data file
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getDataFile ()
  { return new File(this.fn_tab.getText()); }

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  { this.fn_tab.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Get the domains file.
   *  @return the domains file
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getDomainsFile ()
  { return new File(this.fn_dom.getText()); }

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  { this.fn_dom.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Get the additional operations.
   *  @return the additional operations
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getOps ()
  {                             /* --- get the additional operations */
    int ops = 0;                /* init. the operation flags */
    if (this.autotype.isSelected()) ops |= DomainsFinder.AUTOTYPE;
    if (this.sortvals.isSelected()) ops |= DomainsFinder.SORTVALS;
    return ops;                 /* set and return operation flags */
  }  /* getOps() */

  /*------------------------------------------------------------------*/
  /** Set the additional operations.
   *  @param  ops the additional operations
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOps (int ops)
  {                             /* --- set the additional operations */
    this.autotype.setSelected((ops & DomainsFinder.AUTOTYPE) != 0);
    this.sortvals.setSelected((ops & DomainsFinder.SORTVALS) != 0);
  }  /* setOps() */

  /*------------------------------------------------------------------*/
  /** Create a command to determine attribute domains.
   *  @return the command to determine attribute domains
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String[] createCmd ()
  {                             /* --- create domains command */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     prgpath;           /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd     = new String[16];   /* create a command array */
    prgpath = this.getPath();   /* and get the program path */
    cmd[0]  = ((prgpath != null) ? prgpath +File.separator : "") +"dom";
    n = this.format.addFormatArgs(cmd, FormatPanel.ALL);
    s = (this.autotype.isSelected() ? "a" : "")
      + (this.sortvals.isSelected() ? "s" : "");
    if (s.length() > 0) cmd[n++] = "-" +s;
    cmd[n++] = this.fn_tab.getText();
    cmd[n++] = this.fn_dom.getText();
    return DomainsPanel.shrinkCmd(cmd, n);
  }  /* createCmd() */          /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a domain finder.
   *  @return a domain finder for the current settings
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsFinder createFinder ()
  {                             /* --- create a domain finder */
    DomainsFinder finder = new DomainsFinder();
    finder.setInput (this.fn_tab.getText());
    finder.setOutput(this.fn_dom.getText());
    finder.setOps   (this.getOps());
    if (this.format != null) {  /* set input, output, and operations */
      finder.setMode (this.format.getTableMode());
      finder.setChars(this.format.getRecSeps(),
                      this.format.getFldSeps(),
                      this.format.getBlanks(),
                      this.format.getNullChars(),
                      this.format.getComment());
    }                           /* set the data format and */
    return finder;              /* return the created domain finder */
  }  /* createFinder() */

  /*------------------------------------------------------------------*/
  /** Get flag for external program usage.
   *  @return whether to use external programs
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean useExternal ()
  { return (this.extern != null) ? this.extern.isSelected() : true; }

  /*------------------------------------------------------------------*/
  /** Get flag for external program usage.
   *  @param  extern whether to use external programs
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setExternal (boolean extern)
  { if (this.extern != null) this.extern.setSelected(extern); }

  /*------------------------------------------------------------------*/
  /** Get the path to the C programs.
   *  @return the path to the C programs
   *  @since  2007.02.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getPath ()
  { return this.path; }

  /*------------------------------------------------------------------*/
  /** Set the path to the C programs.
   *  @param  path the path to the C programs
   *  @since  2007.02.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPath (File path)
  { this.path = path; }

  /*------------------------------------------------------------------*/
  /** Shrink a command to a given length.
   *  @param  cmd the command to shrink
   *  @param  n   the number of arguments
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected static String[] shrinkCmd (String[] cmd, int n)
  {                             /* --- shrink command to used args */
    if (cmd.length == n)        /* if all arguments are used, */
      return cmd;               /* return the command */
    String[] tmp = new String[n];
    System.arraycopy(cmd, 0, tmp, 0, n);
    return tmp;                 /* shrink command and return it */
  }  /* shrinkCmd() */

  /*------------------------------------------------------------------*/
  /** Load domain arguments from a configuration file.
   *  @param  reader  file reader to read from
   *  @since  2013.11.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void loadConfig (FileReader reader) throws IOException
  {                             /* --- save to configuration file */
    this.fn_tab.setText(this.readLine(reader));
    this.fn_dom.setText(this.readLine(reader));
    this.autotype.setSelected(this.readInt(reader) != 0);
    this.sortvals.setSelected(this.readInt(reader) != 0);
    this.readLine(reader);
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save domain arguments to a configuration file.
   *  @param  writer  file writer to write to
   *  @since  2013.11.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void saveConfig (FileWriter writer) throws IOException
  {                             /* --- save to configuration file */
    writer.write(this.fn_tab.getText()); writer.write('\n');
    writer.write(this.fn_dom.getText()); writer.write('\n');
    writer.write(this.autotype.isSelected() ? "1," : "0,");
    writer.write(this.sortvals.isSelected() ? "1," : "0,");
    writer.write('\n');         /* write the configuration values */
  }  /* saveConfig() */

}  /* class DomainsPanel() */
