/*----------------------------------------------------------------------
  File    : FormatDialog.java
  Contents: convenience class for an data format dialog box
  Author  : Christian Borgelt
  History : 2007.02.09 file created
            2007.02.11 handling of owners corrected
            2007.02.24 function FormatDialog.store added
            2007.03.12 mode for input fields added
            2007.05.08 function createReader() added
            2007.05.15 constructor now stores initial settings
            2007.05.20 function createWriter() added
            2007.06.07 direct creation of reader/writer from file
            2007.07.24 FormatDialog now encloses a FormatPanel
----------------------------------------------------------------------*/
package dialog;

import java.io.IOException;
import java.io.File;
import java.io.Reader;
import java.io.FileReader;
import java.io.Writer;
import java.io.FileWriter;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BorderFactory;

import util.TableReader;
import util.TableWriter;

/*--------------------------------------------------------------------*/
/** Convenience class for a data format dialog box.
 *  @author Christian Borgelt
 *  @since  2007.02.09 */
/*--------------------------------------------------------------------*/
public class FormatDialog extends JDialog {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010000L;
  /** mode: show check box for field names in first record */
  public static final int HEADER  = FormatPanel.HEADER;
  /** mode: show check box for tuple weight */
  public static final int WEIGHT  = FormatPanel.WEIGHT;
  /** mode: show null value characters input */
  public static final int NULLCHS = FormatPanel.NULLCHS;
  /** mode: show message about null values */
  public static final int NONULLS = FormatPanel.NONULLS;
  /** mode: show check box for transaction weight */
  public static final int TAWGT   = FormatPanel.TAWGT;
  /** mode: show combo box for train record contents */
  public static final int TRAIN   = FormatPanel.TRAIN;
  /** mode: show all optional fields */
  public static final int ALL     = FormatPanel.ALL;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the data format panel */
  private FormatPanel panel = null;
  /** the buffer for the read mode */
  private int         mode  = 0;
  /** the 'ok' button */
  private JButton     ok    = null;
  /** the buffer for the input texts */
  private String[]    bufs  = null;

  /*------------------------------------------------------------------*/
  /** Create a data format dialog.
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatDialog ()
  { this(null, "Set Data Format...",
         FormatPanel.HEADER|FormatPanel.NULLCHS); }

  /*------------------------------------------------------------------*/
  /** Create a data format dialog.
   *  @param  owner the component that is to own the dialog box
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatDialog (Frame owner)
  { this(owner, "Set Data Format...",
         FormatPanel.HEADER|FormatPanel.NULLCHS); }

  /*------------------------------------------------------------------*/
  /** Create a data format dialog.
   *  @param  owner the component that is to own the dialog box
   *  @param  title the title of the dialog box
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatDialog (Frame owner, String title)
  { this(owner, title, FormatPanel.HEADER|FormatPanel.NULLCHS); }

  /*------------------------------------------------------------------*/
  /** Create a data format dialog.
   *  @param  owner the component that is to own the dialog box
   *  @param  title the title of the dialog box
   *  @param  mode  the mode (additional input selector)
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatDialog (Frame owner, String title, int mode)
  {                             /* --- create a data format dialog */
    super(owner);               /* initialize this dialog */
    JPanel  bbar;               /* panel for the button bar */
    JButton button;             /* button for ok and cancel */

    this.setTitle(title);       /* set title and location */
    if (owner != null) this.setLocationRelativeTo(owner);
    else               this.setLocation(48, 48);
    this.panel = new FormatPanel(mode);
    this.getContentPane().add(this.panel, BorderLayout.CENTER);
    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(this.ok = button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FormatDialog.this.store();
        FormatDialog.this.setVisible(false); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FormatDialog.this.restore();
        FormatDialog.this.setVisible(false); } } );
    this.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.setModal(true);
    this.pack();
    this.store();
  }  /* FormatDialog() */

  /*------------------------------------------------------------------*/
  /** Store settings from inputs.
   *  @since  2007.02.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void store ()
  {                             /* --- store settings from inputs */
    if (this.bufs == null)      /* create buffers for the inputs */
      this.bufs = new String[5];
    this.mode    = this.panel.getMode();
    this.bufs[0] = this.panel.getRecSeps();
    this.bufs[1] = this.panel.getFldSeps();
    this.bufs[2] = this.panel.getBlanks();
    this.bufs[3] = this.panel.getNullChars();
    this.bufs[4] = this.panel.getComment();
  }  /* store() */              /* get and decode characters */

  /*------------------------------------------------------------------*/
  /** Restore settings from buffer.
   *  @since  2007.02.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void restore ()
  {                             /* --- restore settings from buffer */
    if (this.bufs == null)      /* create buffers for the inputs */
      this.bufs = new String[5];
    this.panel.setMode(this.mode);
    this.panel.setRecSeps(this.bufs[0]);
    this.panel.setFldSeps(this.bufs[1]);
    this.panel.setBlanks(this.bufs[2]);
    this.panel.setNullChars(this.bufs[3]);
    this.panel.setComment(this.bufs[4]);
  }  /* restore() */

  /*------------------------------------------------------------------*/
  /** Add an action listener for pressing the 'ok' button.
   *  @param  listener the listener to add
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addActionListener (ActionListener listener)
  { this.ok.addActionListener(listener); }

  /*------------------------------------------------------------------*/
  /** Get the data format panel.
   *  @return the data format panel
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel getPanel ()
  { return this.panel; }

  /*------------------------------------------------------------------*/
  /** Get the record separators.
   *  @return the record separators
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getRecSeps ()
  { return this.panel.getRecSeps(); }

  /*------------------------------------------------------------------*/
  /** Set the record separators.
   *  @param  s the record separators
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRecSeps (String s)
  { this.panel.setRecSeps(s); }

  /*------------------------------------------------------------------*/
  /** Get the field separators.
   *  @return the field separators
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getFldSeps ()
  { return this.panel.getFldSeps(); }

  /*------------------------------------------------------------------*/
  /** Set the field separators.
   *  @param  s the field separators
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFldSeps (String s)
  { this.panel.setFldSeps(s); }

  /*------------------------------------------------------------------*/
  /** Get the blank characters.
   *  @return the blank characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getBlanks ()
  { return this.panel.getBlanks(); }

  /*------------------------------------------------------------------*/
  /** Set the blank characters.
   *  @param  s the blank characters
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setBlanks (String s)
  { this.panel.setBlanks(s); }

  /*------------------------------------------------------------------*/
  /** Get the null value characters.
   *  @return the null value characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getNullChars ()
  { return this.panel.getNullChars(); }

  /*------------------------------------------------------------------*/
  /** Set the null value characters.
   *  @param  s the null value characters
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNullChars (String s)
  { this.panel.setNullChars(s); }

  /*------------------------------------------------------------------*/
  /** Get the comment characters.
   *  @return the comment characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getComment ()
  { return this.panel.getComment(); }

  /*------------------------------------------------------------------*/
  /** Set the comment characters.
   *  @param  s the comment characters
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setComment (String s)
  { this.panel.setComment(s); }

  /*------------------------------------------------------------------*/
  /** Get the read/write mode for tables.
   *  <p>In the returned value the flags <code>Table.NOHEADER</code>
   *  and/or <code>Table.WEIGHT</code> may be set, depending
   *  on the selection in the dialog panel.</p>
   *  @return the read/write mode with <code>Table</code> flags
   *  @since  2011.08.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getTableMode ()
  { return this.panel.getTableMode(); }

  /*------------------------------------------------------------------*/
  /** Get the record contents mode for trains.
   *  @return the record contents mode
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getTrainMode ()
  { return this.panel.getTrainMode(); }

  /*------------------------------------------------------------------*/
  /** Get the read/write mode.
   *  <p>In the returned value the flags <code>FormatPanel.HEADER</code>
   *  and/or <code>FormatPanel.WEIGHT</code> (or
   *  <code>FormatPanel.TAWGT</code>) may be set, depending on the
   *  selection in the dialog box.</p>
   *  @return the read mode
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getMode ()
  { return this.panel.getMode(); }

  /*------------------------------------------------------------------*/
  /** Set the read/write mode.
   *  @param  mode the read mode to set
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMode (int mode)
  { this.panel.setMode(mode); }

  /*------------------------------------------------------------------*/
  /** Create a table reader configured for the current format.
   *  @param  file the file to create the reader for
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader createReader (File file) throws IOException
  { return this.panel.createReader(new FileReader(file)); }

  /*------------------------------------------------------------------*/
  /** Create a table reader configured for the current format.
   *  @param  reader the reader to create the reader from
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader createReader (Reader reader)
  { return this.panel.createReader(reader); }

  /*------------------------------------------------------------------*/
  /** Create a table writer configured for the current format.
   *  @param  file the file to create the table writer for
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableWriter createWriter (File file) throws IOException
  { return this.panel.createWriter(new FileWriter(file)); }

  /*------------------------------------------------------------------*/
  /** Create a table writer configured for the current format.
   *  @param  writer the writer to create the table writer from
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableWriter createWriter (Writer writer)
  { return this.panel.createWriter(writer); }

  /*------------------------------------------------------------------*/
  /** Add format arguments to a command array.
   *  @param  cmd the command array to add to
   *  @return the number of arguments (assumed to be 1 before)
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addFormatArgs (String[] cmd)
  { return this.panel.addFormatArgs(cmd,
      FormatPanel.HEADER|FormatPanel.WEIGHT|FormatPanel.NULLCHS); }

  /*------------------------------------------------------------------*/
  /** Add format arguments to a command array.
   *  @param  cmd  the command array to add to
   *  @param  mode the mode (whether to add null value characters etc.)
   *  @return the number of arguments (assumed to be 1 before)
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addFormatArgs (String[] cmd, int mode)
  { return this.panel.addFormatArgs(cmd, mode); }

}  /* class FormatDialog */
