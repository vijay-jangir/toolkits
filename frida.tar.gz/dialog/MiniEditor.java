/*----------------------------------------------------------------------
  File    : MiniEditor.java
  Contents: very small and simple file editor
  Author  : Christian Borgelt
  History : 2004.05.27 file created
            2007.02.11 changed to a JDialog window
            2007.02.12 other constructors added
            2007.03.12 file reading modified, empty files allowed
            2007.06.07 changed to JFrame, JMenu, and JEditorPane
            2014.10.23 changed from LGPL license to MIT license
----------------------------------------------------------------------*/
package dialog;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/*--------------------------------------------------------------------*/
/** Class for a very small and simple text editor.
 *  @author Christian Borgelt
 *  @since  2004.05.27 */
/*--------------------------------------------------------------------*/
public class MiniEditor extends JFrame implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010003L;
  public  static final String VERSION = "1.3 (2014.10.23)";

  /** mode flag: the viewer is a stand-alone program */
  public final static int PROGRAM = 1;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this text editor */
  private Component    owner   = null;
  /** the mode flags */
  private int          mode    = 0;
  /** the editable text area */
  private JEditorPane  text    = null;
  /** the status bar for messages */
  private JTextField   stat    = null;
  /** the file chooser */
  private JFileChooser chooser = null;
  /** the "About..." dialog box */
  private AboutDialog  about   = null;
  /** the current text file */
  private File         curr    = null;

  /*------------------------------------------------------------------*/
  /** Create a simple text editor.
   *  @param  mode the mode flags
   *  @since  2004.05.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public MiniEditor (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create a simple text editor.
   *  @param  owner the frame that is to own the editor
   *  @param  mode  the mode flags
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public MiniEditor (Component owner, int mode)
  {                             /* --- create a simple text editor */
    this.owner = owner;         /* note the owner */
    this.mode  = mode;          /* and the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* MiniEditor() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    item = menu.add(new JMenuItem("Load Text...", 'l'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        MiniEditor.this.loadText(null); } } );
    item = menu.add(new JMenuItem("Reload Text", 'r'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        MiniEditor.this.loadText(MiniEditor.this.curr); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Save Text", 's'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        MiniEditor.this.saveText(MiniEditor.this.curr); } } );
    item = menu.add(new JMenuItem("Save Text as...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        MiniEditor.this.saveText(null); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          MiniEditor.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (MiniEditor.this.about == null)
          MiniEditor.this.about = new AboutDialog(MiniEditor.this,
             "About MiniEditor...", "MiniEditor\n"
            +"A simple Text Editor\n"
            +"Version " +MiniEditor.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        MiniEditor.this.about.setVisible(true);
        MiniEditor.this.about.toFront();
      } } );

    /* --- create and set text area --- */
    this.text = new JEditorPane("text/plain", "");
    this.text.setFont(new Font("Monospaced", Font.PLAIN, 12));
    this.text.setPreferredSize(new Dimension(528, 400));
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(new JScrollPane(this.text), BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    this.stat = new JTextField();
    this.stat.setEditable(false);
    content.add(this.stat, BorderLayout.SOUTH);

    /* --- configure and show the frame window --- */
    this.setTitle("MiniEditor");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* MiniEditor() */

  /*------------------------------------------------------------------*/
  /** Get the attribute selector dialog box (create if necessary).
   *  @return the attribute selector dialog box
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure the chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Set the message to display in the status line.
   *  @param  msg the message to display in the status line
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.stat.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Set the text to edit.
   *  @param  text the text to edit
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setText (String text)
  { this.text.setText(text); }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void reportError (String msg)
  {                             /* --- report an i/o error */
    this.stat.setText(msg);     /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this,
      msg, "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load text from a file.
   *  @param  file the file to load
   *  @return whether the file was successfully read
   *  @since  2004.05.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadText (File file)
  {                             /* --- load the text to edit */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create an input stream */
      System.err.print("reading " +file +" ... ");
      FileInputStream stream = new FileInputStream(file);
      this.text.read(stream, null);
      stream.close();           /* read the text from the file */
      System.err.println("done."); }
    catch (FileNotFoundException e) {
      System.err.println("new file."); }
    catch (IOException e) {     /* catch and report i/o errors */
      this.reportError(e.getMessage()); return false; }
    this.stat.setText(file.getName());
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* read() */

  /*------------------------------------------------------------------*/
  /** Save text to a file.
   *  @return whether the file was successfully written
   *  @since  2004.05.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveText (File file)
  {                             /* --- write the edited file */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a writer for the file */
      System.err.print("writing " +file +" ... ");
      FileWriter writer = new FileWriter(file);
      writer.write(this.text.getText());
      writer.close();           /* write the edited text */
      System.err.println("done."); }
    catch (IOException e) {     /* catch and report i/o errors */
      this.reportError(e.getMessage()); return false; }
    this.stat.setText(file.getName());
    this.curr = file;           /* note the new file name */
    return true;                /* return 'writing successful' */
  }  /* saveText() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    MiniEditor ed = new MiniEditor(PROGRAM);
    if (args.length > 0) ed.loadText(new File(args[0]));
    ed.setVisible(true);        /* create and show an editor */
  }  /* main() */

}  /* MiniEditor */
