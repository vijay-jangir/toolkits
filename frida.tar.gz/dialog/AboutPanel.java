/*----------------------------------------------------------------------
  File    : AboutPanel.java
  Contents: about panel for graphical user interfaces
  Author  : Christian Borgelt
  History : 2007.02.11 file created
            2007.07.07 made a subclass of class DialogPanel
            2014.10.23 changed from LGPL license to MIT license
----------------------------------------------------------------------*/
package dialog;

import javax.swing.JTextArea;

/*--------------------------------------------------------------------*/
/** Class for an about panel for graphical user interfaces.
 *  @author Christian Borgelt
 *  @since  2007.02.11 */
/*--------------------------------------------------------------------*/
public class AboutPanel extends DialogPanel {

  private static final long serialVersionUID = 0x00010001L;

  /*------------------------------------------------------------------*/
  /** Create an about panel.
   *  @param  title  the title of the about panel
   *  @param  text   the text  of the about panel
   *  @since  2007.02.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public AboutPanel (String title, String text)
  {                             /* --- create an about panel */
    JTextArea txa = new JTextArea(title);
    this.add(txa, RIGHT);
    txa.setBackground(this.getBackground());
    txa.setFont(BOLD);
    txa.setEditable(false);
    this.addHelp(text +"\n\n"
      +"This program is free software;\n"
      +"you can redistribute it and/or modify it under the terms\n"
      +"of the MIT license (or more precisely, the Expat license,\n"
      +"see the web pages http://www.opensource.org/licenses/MIT\n"
      +"or http://en.wikipedia.org/wiki/MIT_license for details).");

    // LGPL license abandoned on November 23, 2014
    //this.addHelp(text +"\n\n"
    //  +"This program is free software;\n"
    //  +"you can redistribute it and/or modify it under the terms\n"
    //  +"of the GNU Lesser (Library) General Public License v2.1\n"
    //  +"as published by the Free Software Foundation.\n\n"
    //  +"This program is distributed in the hope\n"
    //  +"that it will be useful, but WITHOUT ANY WARRANTY;\n"
    //  +"without even the implied warranty of MERCHANTABILITY\n"
    //  +"or FITNESS FOR A PARTICULAR PURPOSE. See the\n"
    //  +"GNU Lesser (Library) General Public License for more details.");
    this.addFiller(0);
  }  /* AboutPanel() */

}  /* class AboutPanel */
