/*----------------------------------------------------------------------
  File    : FormatPanel.java
  Contents: data format panel for graphical user interfaces
  Author  : Christian Borgelt
  History : 2007.02.11 file created
            2007.02.16 function addFormatArgs added
            2007.03.12 names option added, cleaned up and simplified
            2007.05.08 function createReader() added
            2007.05.17 functions to get the characters added
            2007.05.18 format arguments fixed (null value characters)
            2007.05.20 function createWriter() added
            2007.05.21 classes FormatPanel and FormatDialog unified
            2007.05.30 message about null values made optional
            2007.06.07 direct creation of reader/writer from file
            2007.07.07 made a subclass of class DialogPanel
            2011.08.01 mode TAWGT for transaction data added
            2013.08.06 bug in function setMode() fixed (HEADER)
            2013.11.29 combo box for train record format added
----------------------------------------------------------------------*/
package dialog;

import java.io.IOException;
import java.io.File;
import java.io.Reader;
import java.io.FileReader;
import java.io.Writer;
import java.io.FileWriter;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import table.Table;
import util.ASCIICoder;
import util.TableReader;
import util.TableWriter;

/*--------------------------------------------------------------------*/
/** Class for a data format panel for graphical user interfaces.
 *  @author Christian Borgelt
 *  @since  2007.02.11 */
/*--------------------------------------------------------------------*/
public class FormatPanel extends DialogPanel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010001L;
  /** mode: show check box for field names in first record */
  public static final int HEADER  = 0x01;
  /** mode: show check box for tuple weight */
  public static final int WEIGHT  = 0x02;
  /** mode: show null value characters input */
  public static final int NULLCHS = 0x04;
  /** mode: show message about null values */
  public static final int NONULLS = 0x08;
  /** mode: show check box for transaction weight */
  public static final int TAWGT   = 0x10;
  /** mode: show combo box for train record contents */
  public static final int TRAIN   = 0x20;
  /** mode: show all optional fields */
  public static final int ALL     = 0x07;
  /** the names of the record formats */
  private static final String[] fmtnames = {
    "train: item and times",
    "train: only times",
    "pair: item and time",
    "pair: time and item" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the record separators */
  protected JTextField recseps = null;
  /** the field separators */
  protected JTextField fldseps = null;
  /** the blank characters */
  protected JTextField blanks  = null;
  /** the null value characters */
  protected JTextField nullchs = null;
  /** the comment characters */
  protected JTextField comment = null;
  /** whether the first record contains column names */
  protected JCheckBox  header  = null;
  /** whether the last column contains tuple weights */
  protected JCheckBox  weight  = null;
  /** whether the last column contains transaction weights */
  protected JCheckBox  tawgt   = null;
  /** the format of each input record */
  protected JComboBox<String> recfmt = null;

  /*------------------------------------------------------------------*/
  /** Create a data format panel.
   *  @since  2007.02.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel ()
  { this(ALL); }

  /*------------------------------------------------------------------*/
  /** Create a data format panel.
   *  @param  mode the mode (additional input selector)
   *  @since  2007.02.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel (int mode)
  {                             /* --- create a data format panel */
    this.addLabel("Record separators:");
    this.add(this.recseps = new JTextField("\\n"), RIGHT);
    this.recseps.setFont(BOLD);
    this.addLabel("Field separators:");
    this.add(this.fldseps = new JTextField(" ,\\t"), RIGHT);
    this.fldseps.setFont(BOLD);
    this.addLabel("Blank characters:");
    this.add(this.blanks = new JTextField(" \\t\\r"), RIGHT);
    this.blanks.setFont(BOLD);
    this.addHelp("Blank characters may be used to pad fields "
                +"to a specific width;\nthey are discarded "
                +"when the data file is read.");
    if ((mode & NULLCHS) != 0) {
      this.addLabel("Null value characters:");
      this.add(this.nullchs = new JTextField("?*"), RIGHT);
      this.nullchs.setFont(BOLD);
      this.addHelp(
         "Fields containing only null value characters are\n"
        +"assumed to be null (unknown/missing values).");
    }
    this.addLabel("Comment characters:");
    this.add(this.comment = new JTextField("#"), RIGHT);
    this.comment.setFont(BOLD);
    this.addHelp(
      "Records starting with a comment character are ignored.");
    if ((mode & HEADER) != 0) {
      this.addLabel("Field names in first record:");
      this.add(this.header = new JCheckBox("", true), RIGHT);
      this.addHelp("Otherwise default field names will be generated.");
    }
    if ((mode & WEIGHT) != 0) {
      this.addLabel("Tuple weight in last field:");
      this.add(this.weight = new JCheckBox("", false), RIGHT);
      this.addHelp("Tuple weights can be arbitrary real numbers.\n");
    }
    if ((mode & TAWGT) != 0) {
      this.addLabel("Transaction weights:");
      this.add(this.tawgt = new JCheckBox("", false), RIGHT);
      this.addHelp("Whether the last field of each record "
                  +"contains a weight\n"
                  +"(number of occurrences or multiplicity: "
                  +"must be an integer).");
    }
    if ((mode & TRAIN) != 0) {
      this.addLabel("Records contain:");
      this.recfmt = this.addComboBox(FormatPanel.fmtnames);
      this.recfmt.setSelectedIndex(2);
      this.addHelp("If the input file contains one train per record, "
                  +"but no items,\ndefault item names are generated "
                  +"as the record numbers,\nstarting with 1. That is, "
                  +"the first train is associated with item 1,\n"
                  +"the second train with item 2 etc.");
    }
    if (((mode & NULLCHS) == 0) && ((mode & NONULLS) != 0)) {
      this.addFiller(16);
      this.addHelp("Note that null values are not allowed in the "
                  +"input file.\nA record with a null value causes "
                  +"a read error.");
    }
    this.addFiller(0);
  }  /* FormatPanel() */

  /*------------------------------------------------------------------*/
  /** Get the record separators.
   *  @return the record separators
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getRecSeps ()
  { return ASCIICoder.decode(this.recseps.getText()); }

  /*------------------------------------------------------------------*/
  /** Set the record separators.
   *  @param  s the record separators
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRecSeps (String s)
  { this.recseps.setText(ASCIICoder.encode(s)); }

  /*------------------------------------------------------------------*/
  /** Get the field separators.
   *  @return the field separators
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getFldSeps ()
  { return ASCIICoder.decode(this.fldseps.getText()); }

  /*------------------------------------------------------------------*/
  /** Set the field separators.
   *  @param  s the field separators
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFldSeps (String s)
  { this.fldseps.setText(ASCIICoder.encode(s)); }

  /*------------------------------------------------------------------*/
  /** Get the blank characters.
   *  @return the blank characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getBlanks ()
  { return ASCIICoder.decode(this.blanks.getText()); }

  /*------------------------------------------------------------------*/
  /** Set the blank characters.
   *  @param  s the blank characters
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setBlanks (String s)
  { this.blanks.setText(ASCIICoder.encode(s)); }

  /*------------------------------------------------------------------*/
  /** Get the null value characters.
   *  @return the null value characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getNullChars ()
  { return (this.nullchs != null)
         ? ASCIICoder.decode(this.nullchs.getText()) : ""; }

  /*------------------------------------------------------------------*/
  /** Set the null value characters.
   *  @param  s the null value characters
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNullChars (String s)
  { if (this.nullchs != null)
      this.nullchs.setText(ASCIICoder.encode(s)); }

  /*------------------------------------------------------------------*/
  /** Get the comment characters.
   *  @return the comment characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getComment ()
  { return ASCIICoder.decode(this.comment.getText()); }

  /*------------------------------------------------------------------*/
  /** Set the comment characters.
   *  @param  s the comment characters
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setComment (String s)
  { this.comment.setText(ASCIICoder.encode(s)); }

  /*------------------------------------------------------------------*/
  /** Get the read/write mode.
   *  <p>In the returned value the flags <code>HEADER</code> and/or
   *  <code>WEIGHT</code> (or <code>TAWGT</code>) may be set, depending
   *  on the selection in the dialog panel.</p>
   *  @return the read/write mode
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getMode ()
  {                             /* --- get the read/write mode */
    int m = 0;                  /* read/write mode */
    if ((this.header != null) && this.header.isSelected())
      m |= HEADER;              /* evaluate the header flag */
    if ((this.weight != null) && this.weight.isSelected())
      m |= WEIGHT;              /* evaluate the tuple weight flag */
    if ((this.tawgt  != null) && this.tawgt.isSelected())
      m |= TAWGT;               /* evaluate the tuple weight flag */
    return m;                   /* return the read/write mode */
  }  /* getMode() */

  /*------------------------------------------------------------------*/
  /** Set the read mode.
   *  @param  mode the read mode to set
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMode (int mode)
  {                             /* --- set the read/write mode */
    if (this.header != null)    /* set the header flag */
      this.header.setSelected((mode & HEADER) != 0);
    if (this.weight != null)    /* set the tuple weight flag */
      this.weight.setSelected((mode & WEIGHT) != 0);
    if (this.tawgt  != null)    /* set the transaction weight flag */
      this.tawgt.setSelected( (mode & TAWGT)  != 0);
  }  /* setMode() */

  /*------------------------------------------------------------------*/
  /** Get the read/write mode for tables.
   *  <p>In the returned value the flags <code>Table.HEADER</code>
   *  and/or <code>Table.WEIGHT</code> may be set, depending
   *  on the selection in the dialog panel.</p>
   *  @return the read/write mode with <code>Table</code> flags
   *  @since  2011.08.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getTableMode ()
  {                             /* --- get the read/write mode */
    int m = 0;                  /* read/write mode */
    if ((this.header != null) && !this.header.isSelected())
      m |= Table.NOHEADER;      /* evaluate the header flag */
    if ((this.weight != null) && this.weight.isSelected())
      m |= Table.WEIGHT;        /* evaluate the tuple weight flag */
    return m;                   /* return the read/write mode */
  }  /* getTableMode() */

  /*------------------------------------------------------------------*/
  /** Get the record contents mode for trains.
   *  @return the record contents mode
   *  @since  2013.11.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getTrainMode ()
  { return this.recfmt.getSelectedIndex(); }

  /*------------------------------------------------------------------*/
  /** Copy settings from another data format panel.
   *  @param  fmt the data format panel to copy from
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void copyFrom (FormatPanel fmt)
  {                             /* --- copy from a format panel */
    this.setMode     (fmt.getMode());
    this.setRecSeps  (fmt.getRecSeps());
    this.setFldSeps  (fmt.getFldSeps());
    this.setBlanks   (fmt.getBlanks());
    this.setComment  (fmt.getComment());
    this.setNullChars(fmt.getNullChars());
  }  /* copyFrom() */

  /*------------------------------------------------------------------*/
  /** Copy settings to another data format panel.
   *  @param  fmt the data format panel to copy to
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void copyTo (FormatPanel fmt)
  { fmt.copyFrom(this); }

  /*------------------------------------------------------------------*/
  /** Create a table reader configured for the current format.
   *  @param  file the file to create the reader for
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader createReader (File file) throws IOException
  { return this.createReader(new FileReader(file)); }

  /*------------------------------------------------------------------*/
  /** Create a table reader configured for the current format.
   *  @param  reader the reader to create the reader from
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader createReader (Reader reader)
  {                             /* --- configure a table reader */
    TableReader trdr = new TableReader(reader);
    trdr.setChars(this.getRecSeps(), this.getFldSeps(),
                  this.getBlanks(),  this.getNullChars(),
                  this.getComment());
    return trdr;                /* create and configure a reader */
  }  /* createReader() */

  /*------------------------------------------------------------------*/
  /** Create a table writer configured for the current format.
   *  @param  file the file to create the table writer for
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableWriter createWriter (File file) throws IOException
  { return this.createWriter(new FileWriter(file)); }

  /*------------------------------------------------------------------*/
  /** Create a table writer configured for the current format.
   *  @param  writer the writer to create the table writer from
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableWriter createWriter (Writer writer)
  {                             /* --- configure a table writer */
    String      s;              /* buffer for separator characters */
    TableWriter tw;             /* created table writer */

    tw = new TableWriter(writer);
    s  = this.getRecSeps();     /* record separators */
    if (s.length() > 0) tw.setRecSep(s.charAt(0));
    s  = this.getFldSeps();     /* field separators */
    if (s.length() > 0) tw.setFldSep(s.charAt(0));
    s  = this.getBlanks();      /* blank characters */
    tw.setBlank   ((s.length() > 0) ? s.charAt(0) : -1);
    s  = this.getNullChars();   /* null value characters */
    tw.setNullChar((s.length() > 0) ? s.charAt(0) : -1);
    return tw;                  /* create and configure a writer */
  }  /* createWriter() */

  /*------------------------------------------------------------------*/
  /** Add format arguments to a command array.
   *  @param  cmd the command array to add to
   *  @return the number of arguments (assumed to be 1 before)
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addFormatArgs (String[] cmd)
  { return this.addFormatArgs(cmd, HEADER|WEIGHT); }

  /*------------------------------------------------------------------*/
  /** Add format arguments to a command array.
   *  @param  cmd  the command array to add to
   *  @param  mode the mode (whether to add null value characters etc.)
   *  @return the number of arguments (assumed to be 1 before)
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addFormatArgs (String[] cmd, int mode)
  {                             /* --- add format arguments */
    int    n = 1;               /* number of arguments */
    String s;                   /* buffer for argument/option */

    s = this.recseps.getText(); /* record separators */
    if (s.length() > 0) cmd[n++] = "-r" +s;
    s = this.fldseps.getText(); /* field separators */
    if (s.length() > 0) cmd[n++] = "-f" +s;
    s = this.blanks.getText();  /* blank characters */
    if (s.length() > 0) cmd[n++] = "-b" +s;
    s = this.comment.getText(); /* comment characters */
    if (s.length() > 0) cmd[n++] = "-C" +s;
    if ((mode & NULLCHS) != 0) {
      s = (this.nullchs != null) ? this.nullchs.getText() : "";
      cmd[n++] = "-u" +s; if (s.length() <= 0) cmd[n++] = "";
    }                           /* null value characters */
    if (((mode & HEADER) != 0) && (this.header != null)
    &&  !this.header.isSelected())
      cmd[n++] = "-d";          /* format flags: header */
    if (((mode & WEIGHT) != 0) && (this.weight != null)
    &&  this.weight.isSelected())
      cmd[n++] = "-n";          /* format flags: tuple weight */
    if (((mode & TAWGT)  != 0) && (this.weight != null)
    &&  this.weight.isSelected())
      cmd[n++] = "-w";          /* format flags: transaction weight */
    return n;                   /* return the number of arguments */
  }  /* addFormatArgs() */

  /*------------------------------------------------------------------*/
  /** Load format arguments from a configuration file.
   *  @param  reader  file reader to read from
   *  @since  2013.11.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void loadConfig (FileReader reader) throws IOException
  {                             /* --- save to configuration file */
    this.recseps.setText(this.readLine(reader));
    this.fldseps.setText(this.readLine(reader));
    this.blanks.setText (this.readLine(reader));
    if (this.nullchs != null)
      this.nullchs.setText(this.readLine(reader));
    this.comment.setText(this.readLine(reader));
    if (this.header  != null)
      this.header.setSelected(this.readInt(reader) != 0);
    if (this.weight  != null)
      this.weight.setSelected(this.readInt(reader) != 0);
    if (this.tawgt   != null)
      this.tawgt.setSelected (this.readInt(reader) != 0);
    if (this.recfmt  != null)
      this.recfmt.setSelectedIndex(this.readInt(reader));
    this.readLine(reader);
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save format arguments to a configuration file.
   *  @param  writer  file writer to write to
   *  @since  2013.11.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void saveConfig (FileWriter writer) throws IOException
  {                             /* --- save to configuration file */
    writer.write(this.recseps.getText());   writer.write('\n');
    writer.write(this.fldseps.getText());   writer.write('\n');
    writer.write(this.blanks.getText());    writer.write('\n');
    if (this.nullchs != null) {
      writer.write(this.nullchs.getText()); writer.write('\n'); }
    writer.write(this.comment.getText());   writer.write('\n');
    if (this.header  != null)
      writer.write(this.header.isSelected() ? "1," : "0,");
    if (this.weight  != null)
      writer.write(this.weight.isSelected() ? "1," : "0,");
    if (this.tawgt   != null)
      writer.write(this.tawgt.isSelected()  ? "1," : "0,");
    if (this.recfmt  != null)
      writer.write(this.recfmt.getSelectedIndex() +",");
    writer.write('\n');         /* write the configuration values */
  }  /* saveConfig() */

}  /* class FormatPanel() */
