/*----------------------------------------------------------------------
  File    : TerminalPanel.java
  Contents: terminal panel for graphical user interfaces
  Author  : Christian Borgelt
  History : 2014.10.22 file created
            2014.10.27 setText() and append() with text comp. methods
----------------------------------------------------------------------*/
package dialog;

import java.awt.Font;
import java.awt.Color;
import java.io.OutputStream;
import java.io.IOException;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.text.BadLocationException;

/*--------------------------------------------------------------------*/
/** Class for a terminal panel for graphical user interfaces.
 *  @author Christian Borgelt
 *  @since  2014.10.22 */
/*--------------------------------------------------------------------*/
public class TerminalPanel extends DialogPanel {

  private static final long serialVersionUID = 0x00010001L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the editor pane for the terminal text */
  protected JTextArea term = null;
  /** the maximum number of lines to display */
  protected int       max  = 0;

  /*------------------------------------------------------------------*/
  /** Create a terminal panel.
   *  @param  title  the title of the terminal panel
   *  @since  2014.10.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TerminalPanel (String title)
  { this(title, 160); }

  /*------------------------------------------------------------------*/
  /** Create a terminal panel.
   *  @param  title  the title of the terminal panel
   *  @since  2014.10.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TerminalPanel (String title, int maxlines)
  {                             /* --- create a terminal panel */
    this.max  = maxlines;
    this.term = new JTextArea();
    this.term.setBackground(Color.WHITE);
    this.term.setFont(SMALL);
    this.term.setEditable(false);
    this.addHelp(title);
    this.add(new JScrollPane(this.term), FILL);
  }  /* TerminalPanel() */

  /*------------------------------------------------------------------*/
  /** Get the text of the terminal panel.
   *  @return the text displayed in the terminal panel
   *  @since  2014.10.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getText ()
  { return this.term.getText(); }

  /*------------------------------------------------------------------*/
  /** Set text of the terminal panel.
   *  @param  text  the text to display in the terminal panel
   *  @since  2014.10.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setText (String text)
  { this.term.setText(text); this.purge(); }

  /*------------------------------------------------------------------*/
  /** Append text to the terminal panel.
   *  @param  text  the text to append to the text displayed
   *  @since  2014.10.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void append (String text)
  { this.term.append(text); this.purge(); }

  /*------------------------------------------------------------------*/
  /** Purge excess text from the terminal panel.
   *  @since  2014.10.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void purge ()
  {                             /* --- add text to the terminal */
    int n = this.term.getLineCount() -this.max;
    if (n <= 0) return;         /* if no excess lines, abort */
    try { n = this.term.getLineStartOffset(n+1);
          this.term.replaceRange("", 0, n); }
    catch (BadLocationException e) {} /* delete excess lines */
  }  /* append() */

}  /* class TerminalPanel */
