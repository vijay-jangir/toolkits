/*----------------------------------------------------------------------
  File    : TemplateGUI.java
  Contents: template for tabbed graphical user interface
  Author  : Christian Borgelt
  History : 2007.02.12 file created
            2007.05.08 adapted to new executor classes
            2007.07.07 adapted to new class TabPanel
----------------------------------------------------------------------*/
package dialog;

import java.io.File;
import java.awt.Component;

import util.Executable;
import util.Executor;
import util.ObjExecutor;
import util.CmdExecutor;
import table.DomainsFinder;

/*--------------------------------------------------------------------*/
/** Class for a user interface to external programs.
 *  @author Christian Borgelt
 *  @since  2004.05.25 */
/*--------------------------------------------------------------------*/
public class TemplateGUI extends TabbedGUI {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010000L;
  /** tab index: domain determination */
  private static final int DOMAINS = 1;
  /** tab index: test tab */
  private static final int TEST    = 2;

  /*------------------------------------------------------------------*/
  /** Create a template graphical user interface.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TemplateGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a template graphical user interface.
   *  @param  owner the component that is to own this dialog
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TemplateGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    DialogPanel tab;            /* current tab of the tabbed pane */

    /* --- basic tabs --- */
    this.base("Template Tools");
    this.addFormatTab (FormatPanel.ALL);
    this.addDomainsTab(DomainsPanel.EXTERNAL
                     | DomainsPanel.LOCATE);

    /* --- specific tabs --- */
    tab = this.addTab("Dummy");
    tab.addLabel("Input field:             ");
    tab.addTextInput("");
    tab.addFiller(0);

    /* --- about --- */
    this.addTab("About", new AboutPanel(
       "Template Tools",
       "A simple user interface for external programs.\n\n"
      +"Version 1.3, 2007.07.07\n"
      +"written by Christian Borgelt\n"
      +"European Center for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.pack();
    this.selectTab(TEST);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the executor for a dialog tab.
   *  @param  i the index of the dialog tab
   *  @return the executor for the <code>i</code>-th dialog tab
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- get the executor for a tab */
    String[]   cmd;             /* command for external program */
    Executable obj;             /* executable object */

    if (this.domains.useExternal()) {
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS: cmd = this.createDomainsCmd(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new CmdExecutor(cmd, this); }
    else {                      /* if to use internal programs */
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS: obj = this.createDomainsObj(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new ObjExecutor(obj, this);
    }                           /* create and return the executor */
  }  /* getExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    int           i, k;         /* index variables */
    String        msg;          /* buffer for message */
    DomainsFinder df;           /* domain finder */

    if (this.index == DOMAINS){ /* if domain determination */
      if (this.executor instanceof CmdExecutor) {
        msg = ((CmdExecutor)this.executor).getErrorData();
        i   = msg.lastIndexOf("[", msg.indexOf("attribute(s)]"));
        k   = msg.indexOf("]", i); /* extract attribute report */
        msg = msg.substring(i+1, k); }
      else {                    /* if no external command used */
        df  = (DomainsFinder)((ObjExecutor)this.executor).getObject();
        msg = df.getTable().getColumnCount() +" attribute(s)";
      }                         /* get the number of attributes */
      return "Domain descriptions of\n" +msg +" written.";
    }                           /* build the result message */
    return null;                /* otherwise there is no message */
  }  /* getResultMsg() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2006.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  { }

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2006.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  { }

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  { new TemplateGUI().setVisible(true); }

}  /* class TemplateGUI */
