/*----------------------------------------------------------------------
  File    : DomainsDialog.java
  Contents: convenience class for a domains determination dialog box
  Author  : Christian Borgelt
  History : 2007.07.27 file created from file FormatDialog.java
            2014.04.02 bug connected with duplicate FormatPanel fixed
----------------------------------------------------------------------*/
package dialog;

import java.io.File;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BorderFactory;

import table.DomainsFinder;

/*--------------------------------------------------------------------*/
/** Convenience class for a domains determination dialog box.
 *  @author Christian Borgelt
 *  @since  2007.07.27 */
/*--------------------------------------------------------------------*/
public class DomainsDialog extends JDialog {

  private static final long serialVersionUID = 0x00010002L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the domains determination panel */
  private DomainsPanel panel = null;

  /*------------------------------------------------------------------*/
  /** Create a domains determination dialog.
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsDialog ()
  { this(null, "Determine Domains...", 0); }

  /*------------------------------------------------------------------*/
  /** Create a domains determination dialog.
   *  @param  owner the component that is to own the dialog box
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsDialog (Frame owner)
  { this(owner, "Determine Domains...", 0); }

  /*------------------------------------------------------------------*/
  /** Create a domains determination dialog.
   *  @param  owner the component that is to own the dialog box
   *  @param  title the title of the dialog box
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsDialog (Frame owner, String title)
  { this(owner, title, 0); }

  /*------------------------------------------------------------------*/
  /** Create a domains determination dialog.
   *  @param  owner the component that is to own the dialog box
   *  @param  title the title of the dialog box
   *  @param  mode  the mode (additional input selector)
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsDialog (Frame owner, String title, int mode)
  {                             /* --- create a data format dialog */
    super(owner);               /* initialize this dialog */
    JPanel  bbar;               /* panel for the button bar */
    JButton button;             /* button for ok and cancel */

    this.setTitle(title);       /* set title and location */
    if (owner != null) this.setLocationRelativeTo(owner);
    else               this.setLocation(48, 48);
    this.panel = new DomainsPanel(mode);
    this.getContentPane().add(this.panel, BorderLayout.CENTER);
    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Execute"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsDialog.this.findDomains();
        DomainsDialog.this.setVisible(false); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsDialog.this.setVisible(false); } } );
    this.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.pack();
  }  /* DomainsDialog() */

  /*------------------------------------------------------------------*/
  /** Get the domains determination panel.
   *  @return the domains determination panel
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsPanel getPanel ()
  { return this.panel; }

  /*------------------------------------------------------------------*/
  /** Get the associated data format panel.
   *  @return the associated data format panel
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel getFormat ()
  { return this.panel.getFormat(); }

  /*------------------------------------------------------------------*/
  /** Set the associated data format panel.
   *  @param  format the associated data format panel
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFormat (FormatPanel format)
  { this.panel.setFormat(format); }

  /*------------------------------------------------------------------*/
  /** Get the data file.
   *  @return the data file
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getDataFile ()
  { return this.panel.getDataFile(); }

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  { this.panel.setDataFile(file); }

  /*------------------------------------------------------------------*/
  /** Get the domains file.
   *  @return the domains file
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getDomainsFile ()
  { return this.panel.getDomainsFile(); }

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  { this.panel.setDomainsFile(file); }

  /*------------------------------------------------------------------*/
  /** Get the additional operations.
   *  @return the additional operations
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getOps ()
  { return this.panel.getOps(); }

  /*------------------------------------------------------------------*/
  /** Set the additional operations.
   *  @param  ops the additional operations
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOps (int ops)
  { this.panel.setOps(ops); }

  /*------------------------------------------------------------------*/
  /** Create a command to determine attribute domains.
   *  @return the command to determine attribute domains
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String[] createCmd ()
  { return this.panel.createCmd(); }

  /*------------------------------------------------------------------*/
  /** Create a domain finder.
   *  @return a domain finder
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsFinder createFinder ()
  { return this.panel.createFinder(); }

  /*------------------------------------------------------------------*/
  /** Find attribute domains.
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void findDomains ()
  {                             /* --- find attribute domains */
    try {                       /* create a domain finder */
      DomainsFinder finder = this.panel.createFinder();
      finder.exec();            /* execute the domain finder */
      JOptionPane.showMessageDialog(this,
        "Domain descriptions of\n" +finder.getTable().getColumnCount()
       +" attribute(s) written."); }
    catch (Exception e) {       /* catch and report errors */
      JOptionPane.showMessageDialog(this,
        "Execution failed:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }
  }  /* findDomains() */

}  /* class DomainsDialog */
