/*----------------------------------------------------------------------
  File    : AboutDialog.java
  Contents: convenience class for an "About..." dialog box
  Author  : Christian Borgelt
  History : 2007.02.09 file created
            2007.02.11 handling of owners corrected
----------------------------------------------------------------------*/
package dialog;

import java.awt.Frame;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JTextArea;
import javax.swing.JButton;

/*--------------------------------------------------------------------*/
/** Convenience class for an "About..." dialog box.
 *  @author Christian Borgelt
 *  @since  2007.02.09 */
/*--------------------------------------------------------------------*/
public class AboutDialog extends JDialog {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /** Create an "About..." dialog box.
   *  @param  msg the message to display in the box
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public AboutDialog (String title, String msg)
  { this(null, title, msg, 0); }

  /*------------------------------------------------------------------*/
  /** Create an "About..." dialog box.
   *  @param  owner the component that is to own the dialog box
   *  @param  msg   the message to display in the box
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public AboutDialog (Frame owner, String title, String msg)
  { this(owner, title, msg, 0); }

  /*------------------------------------------------------------------*/
  /** Create an "About..." dialog box.
   *  @param  owner the component that is to own the dialog box
   *  @param  msg   the message to display in the dialog box
   *  @param  id    the identifier of the logo to use
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public AboutDialog (Frame owner, String title, String msg, int id)
  {                             /* --- create an "About..." dialog */
    super(owner);               /* initialize the dialog */
    Container pane = this.getContentPane();
    LogoPanel logo = new LogoPanel();
    JButton   btn  = new JButton("Ok");
    JPanel    rest = new JPanel(new BorderLayout(2, 5));
    JTextArea text = new JTextArea(msg);

    this.setTitle(title);       /* set title and location */
    if (owner == null) this.setLocation(48, 48);
    else               this.setLocationRelativeTo(owner);
    text.setFont(DialogPanel.BOLD);
    text.setEditable(false);
    btn.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        AboutDialog.this.setVisible(false); } } );
    rest.add(logo, BorderLayout.NORTH);
    rest.add(btn,  BorderLayout.SOUTH);
    pane.setLayout(new FlowLayout());
    pane.add(text);
    pane.add(rest);
    text.setBackground(pane.getBackground());
    this.setModal(true);
    this.setResizable(false);
    this.pack();
  }  /* AboutDialog() */

}  /* class AboutDialog */
