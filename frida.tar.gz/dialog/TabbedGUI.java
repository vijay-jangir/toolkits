/*----------------------------------------------------------------------
  File    : TabbedGUI.java
  Contents: graphical user interface with tabs
  Author  : Christian Borgelt
  History : 2007.02.12 file created
            2007.02.16 command generation improved
            2007.03.12 format and domains panel removed from baseGUI
            2007.05.08 adapted to new executor classes
            2007.07.07 convenience functions for adding components added
            2007.07.24 domain editor functions added
            2007.07.26 convenience functions for tabs added
            2007.07.27 function getDomainsMsg() added
            2012.12.10 waiting for executor abort added to "Close"
            2014.10.21 tab layout changed to WRAP_TAB_LAYOUT
            2014.10.22 terminal tab and log instance variable added
            2016.04.07 StringBuffer replaced by StringBuilder
            2016.05.02 newly required serialVersionUID added
----------------------------------------------------------------------*/
package dialog;

import java.lang.Thread;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.awt.Component;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.BorderFactory;

import util.Executable;
import util.Executor;
import util.ObjExecutor;
import util.CmdExecutor;
import table.DomainsFinder;

/*--------------------------------------------------------------------*/
/** Abstract class for graphical user interfaces with tabbed panes.
 *  @author Christian Borgelt
 *  @since  2007.02.12 */
/*--------------------------------------------------------------------*/
public abstract class TabbedGUI extends JFrame
                                implements Runnable, ActionListener {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this dialog box */
  protected Component     owner    = null;
  /** whether started as an independent program */
  protected boolean       isprog   = false;
  /** the pane for the dialog tabs */
  protected JTabbedPane   pane     = null;
  /** the data format tab */
  protected FormatPanel   format   = null;
  /** the domains determination tab */
  protected DomainsPanel  domains  = null;
  /** the terminal output tab */
  protected TerminalPanel terminal = null;
  /** the status line (for messages) */
  protected JTextField    status   = null;
  /** the execution button */
  protected JButton       exec     = null;
  /** the executor for an object or an external program */
  protected Executor      executor = null;
  /** the index of the executed tab */
  protected int           index    = 0;
  /** the start time for the execution */
  protected long          start    = 0;
  /** the stream to write progress messages to */
  protected PrintStream   log      = System.err;
  /** the buffer for reading a configuration file */
  private StringBuilder   buf      = null;

  /*------------------------------------------------------------------*/
  /** Convenience function for the constructors of child classes.
   *  @param  owner  the owner of this dialog box
   *  @param  isprog whether started as a separate program
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void init (Component owner, boolean isprog)
  {                             /* --- create user interface */
    this.owner  = owner;        /* note the owner and */
    this.isprog = isprog;       /* the program flag */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* init() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract void run ();

  /*------------------------------------------------------------------*/
  /** Create the basic graphical user interface.
   *  @param  title the title of the dialog box
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void base (String title)
  {                             /* --- create the basic GUI */
    JPanel  bbar;               /* panel for the button bar */
    JButton button;             /* button for execute etc. */
    JPanel  bottom;             /* panel for the bottom */

    /* --- frame --- */
    this.setTitle(title);       /* configure the frame */
    this.setDefaultCloseOperation(this.isprog
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);

    /* --- main pane --- */
    this.pane = new JTabbedPane(JTabbedPane.LEFT,
                                JTabbedPane.WRAP_TAB_LAYOUT);
    this.getContentPane().add(this.pane, BorderLayout.CENTER);

    /* --- buttons --- */
    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    bbar.add(this.exec = new JButton("Run"));
    this.exec.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        TabbedGUI.this.start(); } } );
    bbar.add(button = new JButton("Load"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        TabbedGUI.this.loadConfig(null); } } );
    bbar.add(button = new JButton("Save"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        TabbedGUI.this.saveConfig(null); } } );
    bbar.add(button = new JButton("Close"));
    if (this.isprog) {          /* if stand-alone program */
      button.addActionListener(new ActionListener () {
        public void actionPerformed (ActionEvent e) {
          if (TabbedGUI.this.executor != null) {
            TabbedGUI.this.executor.abort();
            while (TabbedGUI.this.executor != null)
              try { Thread.sleep(50); }
              catch (InterruptedException x) { };
          }                     /* wait until the executor stopped, */
          System.exit(0); } } ); }    /* then terminate the program */
    else {                      /* if only a dialog bos */
      button.addActionListener(new ActionListener () {
        public void actionPerformed (ActionEvent e) {
          TabbedGUI.this.setVisible(false); } } );
    }                           /* close the dialog box */

    /* --- status line --- */
    this.status = new JTextField(title);
    this.status.setEditable(false);
    bottom = new JPanel(new BorderLayout());
    bottom.add(bbar,        BorderLayout.NORTH);
    bottom.add(this.status, BorderLayout.SOUTH);
    this.getContentPane().add(bottom, BorderLayout.SOUTH);
  }  /* base() */

  /*------------------------------------------------------------------*/
  /** Add a dialog tab.
   *  @param  title the title of the dialog tab to add
   *  @param  panel the dialog tab to add
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addTab (String title, DialogPanel panel)
  { this.pane.addTab(title, panel); }

  /*------------------------------------------------------------------*/
  /** Add an empty dialog tab.
   *  @param  title the title of the dialog tab to add
   *  @return the added empty dialog tab
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DialogPanel addTab (String title)
  {                             /* --- add an empty dialog tab */
    DialogPanel tab = new DialogPanel();
    this.pane.addTab(title, tab);
    return tab;                 /* create and add an empty dialog tab */
  }  /* addTab() */

  /*------------------------------------------------------------------*/
  /** Get the tab at a given index.
   *  @param  index the index of the tab to get
   *  @return the tab with the given index
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DialogPanel getTab (int index)
  { return (DialogPanel)this.pane.getComponentAt(index); }

  /*------------------------------------------------------------------*/
  /** Add a data format tab.
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel addFormatTab ()
  { return this.addFormatTab("Format", FormatPanel.ALL); }

  /*------------------------------------------------------------------*/
  /** Add a data format tab.
   *  @param  mode the mode of the format tab
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel addFormatTab (int mode)
  { return this.addFormatTab("Format", mode); }

  /*------------------------------------------------------------------*/
  /** Add a data format tab.
   *  @param  title the title of the format tab
   *  @param  mode  the mode  of the format tab
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel addFormatTab (String title, int mode)
  {                             /* --- add a data format tab */
    this.format = new FormatPanel(mode);
    this.pane.addTab(title, this.format);
    return this.format;         /* create and add a format tab */
  }  /* addFormatTab() */

  /*------------------------------------------------------------------*/
  /** Get the data format tab.
   *  @return the data format tab
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel getFormatTab ()
  { return this.format; }

  /*------------------------------------------------------------------*/
  /** Add a domain determination tab.
   *  @param  mode the mode of the domains tab
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsPanel addDomainsTab (int mode)
  { return this.addDomainsTab("Domains", mode); }

  /*------------------------------------------------------------------*/
  /** Add a domain determination tab.
   *  @param  title the title of the domains tab
   *  @param  mode  the mode  of the domains tab
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsPanel addDomainsTab (String title, int mode)
  {                             /* --- add a domains tab */
    this.domains = new DomainsPanel(mode, this.format);
    this.pane.addTab(title, this.domains);
    return this.domains;        /* create and add a domains tab */
  }  /* addDomainsTab() */

  /*------------------------------------------------------------------*/
  /** Get the domains tab.
   *  @return the domains tab
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsPanel getDomainsTab ()
  { return this.domains; }

  /*------------------------------------------------------------------*/
  /** Add a terminal output tab.
   *  @param  title the title of the domains tab
   *  @since  2014.10.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TerminalPanel addTerminalTab (String title)
  {                             /* --- add a terminal tab */
    this.terminal = new TerminalPanel(title);
    this.pane.addTab("Terminal", this.terminal);
    return this.terminal;       /* create and add a domains tab */
  }  /* addTerminalTab() */

  /*------------------------------------------------------------------*/
  /** Get the terminal tab.
   *  @return the terminal tab
   *  @since  2014.10.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TerminalPanel getTerminalTab ()
  { return this.terminal; }

  /*------------------------------------------------------------------*/
  /** Get the default tab.
   *  @return the default tab
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private DialogPanel dfltTab ()
  { return (this.domains != null) ? this.domains
         : (DialogPanel)this.pane.getComponentAt(0); }

  /*------------------------------------------------------------------*/
  /** Set the selected dialog tab.
   *  @param  index the index of the tab to select
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void selectTab (int index)
  { this.pane.setSelectedIndex(index); }

  /*------------------------------------------------------------------*/
  /** set the data format.
   *  @param  fmt the format panel to set the format from
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFormat (FormatPanel fmt)
  { if (this.format != null) this.format.copyFrom(fmt); }

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  { if (this.domains != null) this.domains.setDomainsFile(file); }

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  { if (this.domains != null) this.domains.setDataFile(file); }

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  { }

  /*------------------------------------------------------------------*/
  /** Get the message text (status line) of the window.
   *  @return the displayed message
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getMessage ()
  { return this.status.getText(); }

  /*------------------------------------------------------------------*/
  /** Set the message text (status line) of the window.
   *  @param  msg the message to display
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.status.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Get the file chooser.
   *  @return the file chooser
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected JFileChooser getFileChooser ()
  { return this.dfltTab().getFileChooser(); }

  /*------------------------------------------------------------------*/
  /** Get a file name and store it in a text field.
   *  @param  text the text field in which to store the file name
   *  @return the selected file or <code>null</code> if cancelled
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected File getFileName (JTextField text)
  { return this.dfltTab().getFileName(text); }

  /*------------------------------------------------------------------*/
  /** Get a file name and store it in a text field.
   *  @param  text  the text field in which to store the file name
   *  @param  title the title of the file chooser dialog
   *  @return the selected file or <code>null</code> if cancelled
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected File getFileName (JTextField text, String title)
  { return this.dfltTab().getFileName(text, title); }

  /*------------------------------------------------------------------*/
  /** Show a data table (to be read from a file).
   *  @param  text the text field containing the file name
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showTable (JTextField text)
  { this.dfltTab().showTable(new File(text.getText()), this.format); }

  /*------------------------------------------------------------------*/
  /** Edit domain descriptions.
   *  @param  text the text field containing the file name
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void editDomains (JTextField text)
  { this.dfltTab().editDomains(text); }

  /*------------------------------------------------------------------*/
  /** Edit a text file.
   *  @param  text the text field containing the file name
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void editFile (JTextField text)
  { this.dfltTab().editFile(text); }

  /*------------------------------------------------------------------*/
  /** Get the path to the external programs.
   *  @return the path to the external programs
   *  @since  2007.02.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getPath ()
  { return this.domains.getPath(); }

  /*------------------------------------------------------------------*/
  /** Set the path to the external programs.
   *  @param  path the path to the external programs
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPath (File path)
  { this.domains.setPath(path); }

  /*------------------------------------------------------------------*/
  /** Create a command to determine attribute domains.
   *  <p>The command is built according to the settings in the
   *  "domains" tab of this tabbed user interface.</p>
   *  @return a command to determine attribute domains
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String[] createDomainsCmd ()
  { return this.domains.createCmd(); }

  /*------------------------------------------------------------------*/
  /** Create a domain finder object.
   *  <p>The domain finder is configured according to the settings
   *  in the "domains" tab of this tabbed user interface.</p>
   *  @return a domain finder object
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executable createDomainsObj ()
  { return this.domains.createFinder(); }

  /*------------------------------------------------------------------*/
  /** Create the executor for a dialog tab.
   *  @param  i the index of the dialog tab
   *  @return the executor for the <code>i</code>-th dialog tab
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected abstract Executor createExecutor (int i);

  /*------------------------------------------------------------------*/
  /** Execute the current dialog tab.
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void start ()
  {                             /* --- execute a dialog tab */
    if (this.executor != null){ /* if a process is running, abort it */
      this.executor.abort(); return; }
    this.index    = this.pane.getSelectedIndex();
    this.executor = this.createExecutor(this.index);
    if (this.executor == null){ /* if the tab is not executable */
      JOptionPane.showMessageDialog(this,
        "The tab \"" +this.pane.getTitleAt(this.index)
                     +"\" is not executable."); return;
    }                           /* notify the user and abort */
    if      (this.executor instanceof ObjExecutor) {
      this.log.print("executing object: ");
      Object obj = ((ObjExecutor)this.executor).getObject();
      this.log.println(obj.getClass().getName()); }
    else if (this.executor instanceof CmdExecutor) {
      this.log.println("executing external command:");
      String[] cmd = ((CmdExecutor)this.executor).getCommand();
      for (int i = 0; i < cmd.length; i++)
        this.log.print(cmd[i] +" ");
      this.log.println();       /* if to execute an external command, */
    }                           /* print the command line */
    this.status.setText("Running...");
    this.exec.setText("Abort"); /* set status line and button text */
    this.start = System.currentTimeMillis();
    this.executor.start();      /* execute the command or the object */
  }  /* start() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  { return null; }

  /*------------------------------------------------------------------*/
  /** Get the result message of a determination of domains.
   *  @return the result message of a determination of domains
   *  @since  2007.07.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getDomainsMsg ()
  {                             /* --- get result of domains det. */
    int           i;            /* index variable */
    String        msg;          /* buffer for text and message */
    DomainsFinder df;           /* domains finder */

    if (this.executor instanceof CmdExecutor) {
      msg = ((CmdExecutor)this.executor).getErrorData();
      i   = msg.lastIndexOf("[", msg.indexOf("attribute(s)]"));
      msg = msg.substring(i+1, msg.indexOf("]", i)); }
    else {                      /* if no external command used */
      df  = (DomainsFinder)((ObjExecutor)this.executor).getObject();
      msg = df.getTable().getColumnCount() +" attribute(s)";
    }                           /* get the number of attributes */
    return "Domain descriptions of\n" +msg +" written.";
  }  /* getDomainsMsg() */

  /*------------------------------------------------------------------*/
  /** Process an event from the executor.
   *  @param  event the event to process
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void actionPerformed (ActionEvent event)
  {                             /* --- process event from executor */
    int    err;                 /* action/error id */
    String msg;                 /* buffer for message */

    if ((this.terminal != null) /* if there is a terminal */
    &&  (this.executor instanceof CmdExecutor)) {
      msg = ((CmdExecutor)this.executor).getErrorData()
          + ((CmdExecutor)this.executor).getOutputData() +"\n";
      this.terminal.append(msg);
    }                           /* copy output of external program */
    err = event.getID();        /* get the error id and message */
    msg = event.getActionCommand();
    if      (err == Executor.ABORTED) {
      this.status.setText(msg = "Execution was aborted."); }
    else if (err == Executor.INTERRUPTED) {
      this.status.setText("Execution was interrupted.");
      msg = "Execution was interrupted:\n" +msg; }
    else if (err == Executor.FAILED) {
      this.status.setText("Execution failed.");
      msg = "Execution failed:\n" +msg; }
    else {                      /* if process terminated abnormally */
      this.status.setText("Execution was successful.");
      msg = this.getResultMsg();
      if (msg == null) msg = "Execution was successful.";
    }                           /* get the result message */
    this.executor = null;       /* delete the executor */
    this.exec.setText("Run");   /* reset the button text */
    if (err == Executor.OK)     /* report execution result */
         JOptionPane.showMessageDialog(this, msg);
    else JOptionPane.showMessageDialog(this, msg,
              "Error", JOptionPane.ERROR_MESSAGE);
  }  /* actionPerformed() */

  /*------------------------------------------------------------------*/
  /** Read a line (of the configuration file).
   *  @param  reader the reader to read from
   *  @return the line read
   *  @throws IOException if an i/o error occurs
   *                      or no line could be read
   *  @since  2007.02.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String readLine (FileReader reader) throws IOException
  {                             /* --- read the next input line */
    int c = reader.read();      /* read the next character */
    if (c < 0) throw new IOException("premature end of file");
    if (this.buf == null)       /* create a buffer for a line */
      this.buf = new StringBuilder();
    this.buf.setLength(0);      /* clear the read buffer */
    while ((c >= 0) && (c != '\n')) {
      this.buf.append((char)c); /* append current character */
      c = reader.read();        /* to the read buffer and */
    }                           /* read the next character */
    return this.buf.toString(); /* return the input line read */
  }  /* readLine() */

  /*------------------------------------------------------------------*/
  /** Read an integer value (from the configuration file).
   *  @param  reader the reader to read from
   *  @return the integer value read
   *  @throws IOException if an i/o error occurs
   *                      or no field could be read
   *  @since  2006.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int readInt (FileReader reader) throws IOException
  {                             /* --- get next integer value */
    int c = reader.read();      /* read the next character */
    if (c < 0) throw new IOException("premature end of file");
    if (this.buf == null)       /* create a buffer for a field */
      this.buf = new StringBuilder();
    this.buf.setLength(0);      /* clear the read buffer */
    while ((c >= 0) && (c != ',') && (c != ';') && (c != '\n')) {
      this.buf.append((char)c); /* append current character */
      c = reader.read();        /* to the read buffer and */
    }                           /* read the next character */
    String s = this.buf.toString().trim();
    try { return Integer.parseInt(s); }
    catch (NumberFormatException e) {
      throw new IOException("malformed number: " +s); }
  }  /* readInt() */             /* decode and return the next field */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2006.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected abstract void loadConfig (File file);

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2006.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected abstract void saveConfig (File file);

  /*------------------------------------------------------------------*/
  /** Shrink a command to a given length.
   *  @param  cmd the command to shrink
   *  @param  n   the number of arguments
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected static String[] shrinkCmd (String[] cmd, int n)
  { return DomainsPanel.shrinkCmd(cmd, n); }

}  /* class TabbedGUI */
