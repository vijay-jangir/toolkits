/*----------------------------------------------------------------------
  File    : ColorDialog.java
  Contents: convenience class for a color selection dialog box
  Author  : Christian Borgelt
  History : 2007.02.09 file created
            2007.02.22 first version completed
            2007.02.24 function getTable added
            2007.07.18 attribute and value selection redesigned
            2013.04.22 adapted to class name change Type -> ColType
            2013.12.28 color levels for metric attributes added
            2019.03.31 fixed some deprecated functions etc.
----------------------------------------------------------------------*/
package dialog;

import java.io.IOException;
import java.io.FileReader;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.SpinnerNumberModel;
import javax.swing.JColorChooser;
import javax.swing.BorderFactory;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableModel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import util.TableReader;
import table.ColType;
import table.NominalType;
import table.MetricType;
import table.Column;
import table.Table;
import dialog.DialogPanel;

/*--------------------------------------------------------------------*/
/** Class for a table of attribute names.
 *  @author Christian Borgelt
 *  @since  2007.07.17 */
/*--------------------------------------------------------------------*/
class AttTable extends AbstractTableModel {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /* instance variables                                               */
  /*------------------------------------------------------------------*/
  /** the attributes as table columns */
  private Column[] atts = null;

  /*------------------------------------------------------------------*/
  /** Create a table of attribute names.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public AttTable ()
  { }

  /*------------------------------------------------------------------*/
  /** Set the attribute names.
   *  @param  cols an array of attributes as table columns
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setAtts (Column[] cols)
  {                             /* --- set the attributes */
    int o = this.getRowCount(); /* get the old and new number of rows */
    int n = (cols != null) ? cols.length : 0;
    this.atts = cols;           /* store the new attributes */
    if (o > n) this.fireTableRowsDeleted (n, o-1);
    this.fireTableDataChanged();/* update the display */
    if (n > o) this.fireTableRowsInserted(o, n-1);
  }  /* setAtts() */

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.atts != null) ? this.atts.length : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return always <code>1</code>
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return 1; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column given its index.
   *  @param  col the index of the column
   *  @return always the string <code>"Attribute"</code>
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int col)
  { return "Attribute"; }

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as an object.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return an object representing the value in the specified cell
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  { return this.atts[row].getName(); }

}  /* AttTable() */


/*--------------------------------------------------------------------*/
/** Class for a table of attribute values.
 *  @author Christian Borgelt
 *  @since  2007.07.17 */
/*--------------------------------------------------------------------*/
class ValueTable extends AbstractTableModel {

  private static final long serialVersionUID = 0x00010001L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the attribute values */
  private Object[] values = null;
  /** the associated colors */
  private Object[] colors = null;

  /*------------------------------------------------------------------*/
  /** Create a table of attribute values.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ValueTable ()
  { }

  /*------------------------------------------------------------------*/
  /** Set the attribute values.
   *  <p>The length of the array <code>cols</code> must coincide with
   *  the value returned by <code>type.getInfoCount()</code>.</p>
   *  @param  type the type providing the attribute values
   *  @param  cols the associated colors
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValues (ColType type, Object[] colors)
  {                             /* --- set the type and the colors */
    int i;                      /* loop variable */
    int o = this.getRowCount(); /* get the old and new number of rows */
    int n = (colors != null) ? colors.length : 0;
    if (type instanceof NominalType) {
      this.values = new Object[n];      /* if nominal type, */
      for (i = 0; i < n; i++)   /* get and store nominal values */
        this.values[i] = type.getValue(i); }
    else {                      /* if ordinal type */
      this.values = new Object[--n];    /* if metric type, */
      for (i = 0; i < n; i++)   /* create a list of levels */
        this.values[i] = String.format("level %d", i+1);
    }
    this.colors = colors;       /* store the associated colors */
    if (o > n) this.fireTableRowsDeleted (n, o-1);
    this.fireTableDataChanged();/* update the display */
    if (n > o) this.fireTableRowsInserted(o, n-1);
  }  /* setValues() */

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.colors != null) ? this.values.length : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return always <code>2</code>
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return 2; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column given its index.
   *  @param  col the index of the column
   *  @return <code>"Value"</code> if <code>col <= 0</code> and
   *          <code>"Color"</code> otherwise
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int col)
  { return (col <= 0) ? "Value" : "Color"; }

  /*------------------------------------------------------------------*/
  /** Get the class of a column given its index.
   *  @param  col the index of the column
   *  @return the class of the column
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getColumnClass (int col)
  { return (col <= 0) ? Object.class : Color.class; }

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as an object.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return an object representing the value in the specified cell
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  { return (col <= 0) ? this.values[row] : this.colors[row]; }

  /*------------------------------------------------------------------*/
  /** Set the value of a table cell.
   *  @param  value the value to set
   *  @param  row   the row    of the cell to set
   *  @param  col   the column of the cell to set
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object value, int row, int col)
  {                             /* --- set a value */
    if (col <= 0) return;       /* set only colors */
    if ((row < 0) || (this.colors == null)
    ||  (row >= this.colors.length))
      return;                   /* check for a valid row index */
    this.colors[row] = value;   /* store value and update display */
    this.fireTableCellUpdated(row, col);
  }  /* setValueAt() */

}  /* ValueTable() */


/*--------------------------------------------------------------------*/
/** Class for a dialog to choose colors for attribute values.
 *  @author Christian Borgelt
 *  @since  2007.02.18 */
/*--------------------------------------------------------------------*/
public class ColorDialog extends JDialog {

  private static final long serialVersionUID = 0x00010002L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the table for which to select colors */
  private Table          table    = null;
  /** the columns for which to select colors */
  private Column[]       columns  = null;
  /** the current colors (intermediate table) */
  private Object[][]     colors   = null;
  /** the main panel */
  private JPanel         main     = null;
  /** the attribute selector */
  private JScrollPane    attsel   = null;
  /** the table for the attribute names */
  private JTable         atts     = null;
  /** the identifier of the current attribute */
  private int            attid    = 0;
  /** the panel for the attribute value selector */
  private JPanel         valbox   = null;
  /** the attribute value selector */
  private JScrollPane    valsel   = null;
  /** the table for the attribute values */
  private JTable         vals     = null;
  /** the identifier of the current attribute value */
  private int            valid    = 0;
  /** the panel for the spinners for color range control */
  private JPanel         spinbox  = null;
  /** the number of color levels */
  private JSpinner       colcnt   = null;
  /** the color range expansion factor */
  private JSpinner       expand   = null;
  /** the color chooser */
  private JColorChooser  colsel   = null;
  /** the listener to notify when the colors are stored */
  private ActionListener listener = null;

  /*------------------------------------------------------------------*/
  /** Create a color selection dialog.
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColorDialog ()
  { this(null, "Select Color..."); }

  /*------------------------------------------------------------------*/
  /** Create a color selection dialog.
   *  @param  owner the component that is to own the dialog box
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColorDialog (Frame owner)
  { this(owner, "Select Color..."); }

  /*------------------------------------------------------------------*/
  /** Create a color selection dialog.
   *  @param  owner the component that is to own the dialog box
   *  @param  title the title of the dialog box
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColorDialog (Frame owner, String title)
  {                             /* --- create a color dialog */
    super(owner);               /* initialize this dialog */
    JPanel   bbar;              /* panel for the button bar */
    JButton  button;            /* button for apply and close */
    JSpinner s;                 /* buffer for a spinner object */

    this.setTitle(title);       /* set title and location */
    if (owner != null) this.setLocationRelativeTo(owner);
    else               this.setLocation(48, 48);

    this.atts = new JTable(new AttTable());
    this.atts.getTableHeader().setFont(DialogPanel.BOLD);
    // this.atts.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    this.atts.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    this.atts.getSelectionModel().addListSelectionListener(
      new ListSelectionListener () {
      public void valueChanged (ListSelectionEvent e) {
        ColorDialog cd  = ColorDialog.this;
        int         row = cd.atts.getSelectedRow();
        if ((row < 0) || (row == cd.attid)) return;
        cd.setValues(cd.attid = row);
      } } );
    this.attsel = new JScrollPane(this.atts);
    this.attsel.setBorder(BorderFactory.createCompoundBorder(
                          BorderFactory.createEmptyBorder(3, 0, 1, 4),
                          this.attsel.getBorder()));

    this.vals = new JTable(new ValueTable());
    this.vals.getTableHeader().setFont(DialogPanel.BOLD);
    // this.vals.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    this.vals.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    this.vals.getSelectionModel().addListSelectionListener(
      new ListSelectionListener () {
      public void valueChanged (ListSelectionEvent e) {
        ColorDialog cd  = ColorDialog.this;
        int         row = cd.vals.getSelectedRow();
        if ((row < 0) || (row == cd.valid)) return;
        TableModel  tm  = cd.vals.getModel();
        tm.setValueAt(cd.colsel.getColor(), cd.valid, 1);
        cd.colsel.setColor((Color)tm.getValueAt(cd.valid = row, 1));
      } } );
    this.vals.setDefaultRenderer(Color.class,
      new DefaultTableCellRenderer () {
      private static final long serialVersionUID = 0x00010000L;
      public void setValue (Object value) {
        if (value != null) this.setBackground((Color)value);
        else               this.setBackground(Color.WHITE);
      } } );
    this.valsel = new JScrollPane(this.vals);

    this.colcnt = s = new JSpinner(new SpinnerNumberModel( 5,1, 12, 1));
    ((DefaultEditor)s.getEditor()).getTextField()
      .setFont(DialogPanel.BOLD);
    this.colcnt.addChangeListener(new ChangeListener() {
      public void stateChanged (ChangeEvent e) {
        ColorDialog.this.setLevels(
          ((Integer)ColorDialog.this.colcnt.getValue()).intValue());
      } } );                    /* spinner for number of colors */
    this.expand = s = new JSpinner(new SpinnerNumberModel(33,0,100, 1));
    ((DefaultEditor)s.getEditor()).getTextField()
      .setFont(DialogPanel.BOLD);
    this.expand.addChangeListener(new ChangeListener() {
      public void stateChanged (ChangeEvent e) {
        ColorDialog.this.setExpand(0.01 *
          ((Integer)ColorDialog.this.expand.getValue()).intValue());
      } } );                    /* spinner for color range expansion */

    this.spinbox = new JPanel(new GridBagLayout());
    this.spinbox.setBorder(BorderFactory.createEmptyBorder(1, 0, 0, 1));
    this.spinbox.add(new JLabel("colors"),     DialogPanel.LEFT);
    this.spinbox.add(this.colcnt,              DialogPanel.RIGHT);
    this.spinbox.add(new JLabel("expand (%)"), DialogPanel.LEFT);
    this.spinbox.add(this.expand,              DialogPanel.RIGHT);

    JTextArea help = new JTextArea("Range expansion towards black\n"
                                  +"below level 1 / above level k.");
    this.spinbox.add(help, DialogPanel.RIGHT);
    help.setBackground(this.spinbox.getBackground());
    help.setFont(DialogPanel.SMALL);
    help.setEditable(false);    /* create and add a text area */
    help.setFocusable(false);   /* configure the text area */

    this.valbox = new JPanel(new GridBagLayout());
    this.valbox.setBorder(BorderFactory.createEmptyBorder(3, 0, 1, 4));
    this.valbox.add(this.valsel,  DialogPanel.FILL);
    this.valbox.add(this.spinbox, DialogPanel.RIGHT);

    this.colsel = new JColorChooser();
    this.colsel.getSelectionModel().addChangeListener(
      new ChangeListener () {
      public void stateChanged (ChangeEvent e) {
        ColorDialog cd = ColorDialog.this;
        TableModel  tm = cd.vals.getModel();
        tm.setValueAt(cd.colsel.getColor(), cd.valid, 1);
      } } );

    this.main = new DialogPanel();
    this.main.setBorder(BorderFactory.createEmptyBorder(2, 4, 0, 4));
    this.main.add(this.colsel);

    bbar = new JPanel(new GridLayout(1, 3, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ColorDialog.this.saveColorsInTable(); } } );
    bbar.add(button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ColorDialog.this.setVisible(false);
        ColorDialog.this.saveColorsInTable(); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ColorDialog.this.setVisible(false);
        ColorDialog.this.loadColorsFromTable();
        ColorDialog.this.setValues(-1); } } );

    this.getContentPane().add(this.main, BorderLayout.CENTER);
    this.getContentPane().add(bbar,      BorderLayout.SOUTH);
    this.pack();
  }  /* ColorDialog() */

  /*------------------------------------------------------------------*/
  /** Add a listener for finalizing a selection.
   *  @param  al the listener to add
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addActionListener (ActionListener al)
  { this.listener = al; }

  /*------------------------------------------------------------------*/
  /** Get currently selected color.
   *  @return the curently selected color
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Color getColor ()
  { return this.colsel.getColor(); }

  /*------------------------------------------------------------------*/
  /** Set the current color.
   *  @param  color the color to set
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setColor (Color color)
  { this.colsel.setColor(color); }

  /*------------------------------------------------------------------*/
  /** Set the table for which to select colors.
   *  @param  tab the table for which to select colors
   *  @return whether a selection is possible (at least one value)
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean setTable (Table tab)
  { return this.setTable(tab, false, 2); }

  /*------------------------------------------------------------------*/
  /** Set the table for which to select colors.
   *  @param  tab    the table for which to select colors
   *  @param  marked whether to consider only marked columns
   *  @return whether a selection is possible (at least one value)
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean setTable (Table tab, boolean marked)
  { return this.setTable(tab, marked, 2); }

  /*------------------------------------------------------------------*/
  /** Set the table for which to select colors.
   *  @param  tab  the table for which to select colors
   *  @param  show which selectors to show
   *  @return whether a selection is possible (at least one value)
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean setTable (Table tab, int show)
  { return this.setTable(tab, false, show); }

  /*------------------------------------------------------------------*/
  /** Set the table for which to select colors.
   *  @param  tab    the table for which to select colors
   *  @param  marked whether to consider only marked columns
   *  @param  show   which selectors to show
   *  @return whether a selection is possible (at least one value)
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean setTable (Table tab, boolean marked, int show)
  {                             /* --- set the table to modify */
    int     i, k, n;            /* loop variable */
    Column  c;                  /* to traverse the columns */
    ColType t;                  /* to traverse the column types */

    this.columns = null;        /* clear the column array */
    this.colors  = null;        /* and the color table */
    this.table   = tab;         /* note and check the given table */
    if (tab == null) return false;
    k = 0;                      /* initialize the column counter */
    for (i = n = tab.getColumnCount(); --i >= 0; ) {
      c = tab.getColumn(i);     /* traverse the table columns */
      t = c.getType();          /* and get their types */
      if ((!marked || (c.getMark() >= 0))
      &&  ((t instanceof NominalType) || (t instanceof MetricType)))
        k++;                    /* count the qualifying columns */
    }                           /* (marked nominal and metric types) */
    this.showSelectors((k > 0) ? show : 0);
    if (k <= 0) return false;   /* check for qualifying columns */
    this.columns = new Column[k];
    this.colors  = new Object[k][];
    for (i = k = 0; i < n; i++) {
      c = tab.getColumn(i);     /* traverse the table columns again */
      t = c.getType();          /* and get their types */
      if ((!marked || (c.getMark() >= 0))
      &&  ((t instanceof NominalType) || (t instanceof MetricType)))
        this.columns[k++] = c;  /* collect the qualifying columns */
    }
    this.loadColorsFromTable(); /* load the colors from the table */
    ((AttTable)this.atts.getModel()).setAtts(this.columns);
    this.atts.setPreferredScrollableViewportSize(
      this.atts.getPreferredSize());
    this.atts.setRowSelectionInterval(this.attid = 0, 0);
    this.setValues(0);          /* get values for first attribute */
    return true;                /* return 'selection is possible' */
  }  /* setTable() */

  /*------------------------------------------------------------------*/
  /** Get the table for which to select colors.
   *  @return the table for which to select colors
   *  @since  2007.02.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getTable ()
  { return this.table; }

  /*------------------------------------------------------------------*/
  /** Set the values of the selected attribute.
   *  @param  index the index of the selected attribute
   *  @since  2007.02.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setValues (int index)
  {                             /* --- set values of selected att. */
    if (this.columns == null) return;
    if (index < 0)              /* get current index if not given */
      index = this.atts.getSelectedRow();
    Object[] cols = this.colors[index];
    ((ValueTable)this.vals.getModel()).setValues(
      this.columns[index].getType(), cols);
    this.valid = 0;             /* get and set the stored colors */
    this.vals.setPreferredScrollableViewportSize(
      this.vals.getPreferredSize());
    if (cols.length <= 0) return;     /* set the initial color and */
    this.colsel.setColor((Color)cols[0]);  /* select the table row */
    this.vals.setRowSelectionInterval(0, 0);
    if (this.columns[index].getType() instanceof NominalType)
      this.spinbox.setVisible(false); /* hide spinners for nominal */
    else {                      /* for metric attributes */
      this.spinbox.setVisible(true);  /* show spinners for metric */
      int n = cols.length-1;    /* set the spinner values */
      this.colcnt.setValue(Integer.valueOf(n));
      n = (int)(((Double)cols[n]).doubleValue()*100 +0.5);
      if (n < 0) n = 0; else if (n > 100) n = 100;
      this.expand.setValue(Integer.valueOf(n));
    }                           /* set colors and expansion */
  }  /* setValues() */

  /*------------------------------------------------------------------*/
  /** Set the number of levels for the current attribute.
   *  @param  cnt the number of levels
   *  @since  2013.12.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setLevels (int cnt)
  { this.setLevels(this.attid, cnt); }

  /*------------------------------------------------------------------*/
  /** Set the number of levels for a metric attribute.
   *  @param  index the attribute/column index
   *  @param  cnt   the number of levels
   *  @since  2013.12.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setLevels (int index, int cnt)
  {                             /* --- set the number of levels */
    Object[] cols;              /* current/new color array */
    int      n;                 /* number of colors */
    float    hue;               /* value of a color (hue) */

    if (this.columns == null) return;
    if (!(this.columns[index].getType() instanceof MetricType))
      return;                   /* check for a metric attribute */
    cols = this.colors[index];  /* get the current color array */
    n    = cols.length-1;       /* and the number of colors */
    if (cnt == n) return;       /* check the new number of colors */
    cols = new Object[cnt+1];   /* and create a new color array */
    cols[cnt] = this.colors[index][n];
    for (n = cnt; --n >= 0; ) { /* traverse the colors */
      hue = (float)((cnt-1-n)/(double)(cnt-1) *(2/3.0));
      cols[n] = Color.getHSBColor(hue, 1, 1);
    }                           /* create a new rainbow color scale */
    this.colors[index] = cols;  /* set new colors and update table */
    ((ValueTable)this.vals.getModel()).setValues(
      this.columns[index].getType(), cols);
  }  /* setLevels() */

  /*------------------------------------------------------------------*/
  /** Set the color expansion percentage for the current attribute.
   *  @param  expand  the range expansion as a fraction (in [0,1])
   *  @since  2013.12.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setExpand (double expand)
  { this.setExpand(this.attid, expand); }

  /*------------------------------------------------------------------*/
  /** Set the expansion percentage for a color range.
   *  @param  index   the attribute/column index
   *  @param  expand  the range expansion as a fraction (in [0,1])
   *  @since  2013.12.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setExpand (int index, double expand)
  {                             /* --- set the number of levels */
    Object[] c;                 /* current color array */

    if (this.columns == null) return;
    if (!(this.columns[index].getType() instanceof MetricType))
      return;                   /* check for a metric attribute */
    c = this.colors[index];     /* update the expansion percentage */
    c[c.length-1] = Double.valueOf(expand);
  }  /* setExpand() */

  /*------------------------------------------------------------------*/
  /** Set the attribute for whose values to set colors.
   *  @param  name the name of the attribute to set
   *  @since  2007.02.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setSelectedAtt (String name)
  {                             /* --- set the selected attribute */
    int i;                      /* loop variable */

    if (this.columns == null) return;
    for (i = this.columns.length; --i >= 0; )
      if (name.equals(this.columns[i].getName())) break;
    if (i >= 0) this.atts.setRowSelectionInterval(i, i);
  }  /* setSelectedAtt() */

  /*------------------------------------------------------------------*/
  /** Set the value for which to set colors.
   *  @param  name the name of the value to set
   *  @since  2007.02.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setSelectedValue (String name)
  {                             /* --- set the selected value */
    int    i;                   /* loop variable */
    Column c;                   /* to access the selected column */

    if (this.columns == null) return;
    c = this.columns[this.attid];
    for (i = c.getValueCount(); --i >= 0; )
      if (name.equals(c.getValue(i).toString())) break;
    if (i >= 0) this.vals.setRowSelectionInterval(i, i);
  }  /* setSelectedValue() */

  /*------------------------------------------------------------------*/
  /** Show or hide the attribute and attribute value selectors.
   *  <p>Either both attribute selector attribute value selector can
   *  be shown (<code>cnt &ge; 2</code>), or only the attribute value
   *  selector can be shown (<code>cnt == 1</code>), or only the
   *  color chooser itself can be shown (<code>cnt == 0</code>).</p>
   *  @param  cnt the number of selectors to show
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void showSelectors (int cnt)
  {                             /* --- show selectors */
    this.main.removeAll();      /* remove all components */
    if (cnt >= 2) {             /* add attribute selector */
      this.main.add(this.attsel, DialogPanel.HALF);
      this.atts.setPreferredScrollableViewportSize(
        this.atts.getPreferredSize());
    }
    if (cnt >= 1) {             /* add attribute value selector */
      this.main.add(this.valbox, DialogPanel.MIDDLE);
      this.vals.setPreferredScrollableViewportSize(
        this.vals.getPreferredSize());
    }                           /* finally add the color selector */
    this.main.add(this.colsel, DialogPanel.LEFT);
    this.pack();                /* repack the dialog box */
    // this.spinbox.setVisible(false);
  }  /* showSelectors() */

  /*------------------------------------------------------------------*/
  /** Load colors from the table.
   *  <p>If a color does not exist, a default color is generated
   *  and stored in the table.</p>
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void loadColorsFromTable ()
  {                             /* --- load colors from the table */
    int      i, k, n;           /* loop variables */
    ColType  t;                 /* to traverse the column types */
    Object[] cols;              /* to traverse the color table */
    float    hue;               /* value of a color (hue) */

    if ((this.colors == null) || (this.columns == null))
      return;                   /* check prerequisites */
    for (i = this.colors.length; --i >= 0; ) {
      t    = this.columns[i].getType();
      cols = this.colors[i];    /* traverse column types and colors */
      if (cols != null) continue;
      if (t instanceof NominalType) {
        this.colors[i] = cols = new Object[n = t.getInfoCount()];
        for (k = 0; k < n; k++) {
          cols[k] = t.getInfo(k);
          if (cols[k] != null) continue;
          hue = (float)(k/(double)n);
          cols[k] = Color.getHSBColor(hue, 1, 1);
          t.setInfo(k, cols[k]);/* get the colors from the table */
        } }                     /* or create default colors */
      else {                    /* rainbow scale for metric type */
        k = t.getInfoCount();   /* get the number of colors */
        n = (k > 0) ? k : 6;    /* if there are none, get default */
        this.colors[i] = cols = new Object[n--];
        if (k > 0) {            /* if there are stored colors, */
          for (k = 0; k <= n; k++) /* get them from the column */
            cols[k] = t.getInfo(k); }
        else {                  /* if there are no stored colors */
          for (k = 0; k < n; k++) {
            hue = (float)((n-1-k)/(double)(n-1) *(2/3.0));
            cols[k] = Color.getHSBColor(hue, 1, 1);
            t.setInfo(String.valueOf(k), cols[k]);
          }                     /* create a default rainbow scale */
          t.setInfo("", cols[n] = Double.valueOf(0.33));
        }                       /* create a default expansion factor */
      }                         /* for the color range */
    }
  }  /* loadColorsFromTable() */

  /*------------------------------------------------------------------*/
  /** Save colors in the table.
   *  <p>If a listener has been registered with the dialog,
   *  it is notified that the colors have changed.</p>
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void saveColorsInTable ()
  {                             /* --- save colors in the table */
    int      i, k, n;           /* loop variables */
    ColType  t;                 /* to traverse the column types */
    Object[] cols;              /* to traverse the color table */

    if ((this.colors  != null)  /* if to store colors in a table */
    &&  (this.columns != null)) {
      for (i = this.colors.length; --i >= 0; ) {
        t   = this.columns[i].getType();
        cols = this.colors[i];   /* traverse column types and colors */
        if (t instanceof NominalType) {
          n = cols.length;       /* if nominal attribute type, */
          for (k = 0; k < n; k++)       /* simply copy colors */
            t.setInfo(k, cols[k]); }
        else {                  /* if metric attribute type */
          t.clearInfo();        /* clear all color information */
          n = cols.length -1;    /* get the number of colors */
          for (k = 0; k < n; k++)
            t.setInfo(String.valueOf(k), cols[k]);
          t.setInfo("", cols[n]);
        }                       /* store the new color levels */
      }                         /* and the expansion factor */
    }
    if (this.listener != null)  /* if there is a listener, notify it */
      this.listener.actionPerformed(
        new ActionEvent(this, 0, "colors changed"));
  }  /* saveColorsInTable() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.07.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    if (args.length <= 0) {     /* if no arguments are given */
      System.out.println("java dialog.ColorDialog <table>");
      return;                   /* print a usage message */
    }                           /* and abort the program */
    try {                       /* create a reader for the file */
      System.err.print("reading " +args[0] +" ... ");
      long        t      = System.currentTimeMillis();
      TableReader reader = new TableReader(new FileReader(args[0]));
      Table       tab    = new Table(args[0]);
      tab.read(reader, 0);      /* create a table reader and */
      reader.close();           /* read table from the given file */
      tab.autoType();           /* automatically determine types */
      t = System.currentTimeMillis() -t;
      System.err.print("[" +tab.getColumnCount() +" column(s), ");
      System.err.print(     tab.getRowCount()    +" row(s)] done");
      System.err.println(" [" +(t/(float)1000.0) +"s].");
      ColorDialog cd = new ColorDialog();
      cd.setTable(tab);         /* set the loaded table and */
      cd.setVisible(true); }    /* show the color selector */
    catch (IOException e) {     /* catch and report an i/o error */
      System.err.println(e.getMessage()); }
  }  /* main() */

}  /* class ColorDialog */
