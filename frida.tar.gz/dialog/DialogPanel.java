/*----------------------------------------------------------------------
  File    : DialogPanel.java
  Contents: panel for dialogs
  Author  : Christian Borgelt
  History : 2007.07.07 file created
            2007.07.26 convenience functions transferred from TabbedGUI
            2011.07.29 ipad fields of all grid bag constraints set
            2013.04.22 adapted to type argument of JComboBox
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package dialog;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.SpinnerNumberModel;
import javax.swing.InputVerifier;

import table.DomainsEditor;
import table.TableView;

/*--------------------------------------------------------------------*/
/** Class for a panel for dialogs.
 *  @author Christian Borgelt
 *  @since  2007.07.07 */
/*--------------------------------------------------------------------*/
public class DialogPanel extends JPanel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010001L;
  /** the font for input text fields */
  public  static final Font BOLD  = new Font("Dialog", Font.BOLD, 12);
  /** the font for help  text fields */
  public  static final Font SMALL = new Font("Dialog", Font.PLAIN,10);
  /** the grid bag constraints for labels */
  public  static final GridBagConstraints LEFT;
  /** the grid bag constraints for middle input fields */
  public  static final GridBagConstraints MIDDLE;
  /** the grid bag constraints for middle input fields */
  public  static final GridBagConstraints HALF;
  /** the grid bag constraints for right  input fields */
  public  static final GridBagConstraints RIGHT;
  /** the grid bag constraints for fillers */
  public  static final GridBagConstraints FILL;
  /** the buffer for reading a configuration file */
  protected StringBuilder buf = null;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the file chooser */
  protected JFileChooser chooser = null;

  /*------------------------------------------------------------------*/
  /*  class initialization code                                       */
  /*------------------------------------------------------------------*/

  static {                      /* --- initialize the class */
    LEFT            = new GridBagConstraints();
    LEFT.fill       = GridBagConstraints.BOTH;
    LEFT.weightx    = 0.0;
    LEFT.ipadx      = LEFT.ipady = 10;
    MIDDLE          = new GridBagConstraints();
    MIDDLE.fill     = GridBagConstraints.BOTH;
    MIDDLE.weightx  = 1.0;
    MIDDLE.ipadx    = MIDDLE.ipady = 1;
    HALF            = new GridBagConstraints();
    HALF.fill       = GridBagConstraints.BOTH;
    HALF.weightx    = 0.5;
    HALF.ipadx      = HALF.ipady = 1;
    RIGHT           = new GridBagConstraints();
    RIGHT.fill      = GridBagConstraints.BOTH;
    RIGHT.weightx   = 1.0;
    RIGHT.ipadx     = RIGHT.ipady = 1;
    RIGHT.gridwidth = GridBagConstraints.REMAINDER;
    FILL            = new GridBagConstraints();
    FILL.fill       = GridBagConstraints.BOTH;
    FILL.weightx    = FILL.weighty = 1.0;
    FILL.gridwidth  = GridBagConstraints.REMAINDER;
  }                             /* create the grid bag constraints */

  /*------------------------------------------------------------------*/
  /** Create a dialog panel.
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DialogPanel ()
  {                             /* --- create a tab panel */
    super(new GridBagLayout()); /* create the and configure the panel */
    this.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
  }  /* DialogPanel() */

  /*------------------------------------------------------------------*/
  /** Add a component.
   *  @param  comp the component to add
   *  @param  gbc  the grid bag constraints to use
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void add (Component comp, GridBagConstraints gbc)
  {                             /* --- add a component */
    ((GridBagLayout)this.getLayout()).setConstraints(comp, gbc);
    this.add(comp);             /* set constraints and add component */
  }  /* add() */

  /*------------------------------------------------------------------*/
  /** Add a help text.
   *  @param  text the help text
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JTextArea addHelp (String text)
  {                             /* --- add a help text to a panel */
    JTextArea help = new JTextArea(text);
    this.add(help, RIGHT);      /* create and add a text area */
    help.setBackground(this.getBackground());
    help.setFont(SMALL);        /* configure the text area */
    help.setEditable(false);
    help.setFocusable(false);
    return help;
  }  /* addHelp() */

  /*------------------------------------------------------------------*/
  /** Add a filler.
   *  @param  height the height of the filler
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addFiller (int height)
  {                             /* --- add a filler to a tab */
    JTextArea fill = new JTextArea((String)null);
    this.add(fill, (height <= 0) ? FILL : RIGHT);
    fill.setPreferredSize(new Dimension(0, height));
    fill.setBackground(this.getBackground());
    fill.setEditable(false);    /* configure the text area */
  }  /* addFiller() */

  /*------------------------------------------------------------------*/
  /** Add a label to a tab.
   *  @param  text the text of the label
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JLabel addLabel (String text)
  { return this.addLabel(text, LEFT); }

  /*------------------------------------------------------------------*/
  /** Add a label to a tab.
   *  @param  text the text of the label
   *  @param  gbc  the grid bag constraints to use
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JLabel addLabel (String text, GridBagConstraints gbc)
  {                             /* --- add a label to a tab */
    JLabel label = new JLabel(text);
    this.add(label, gbc);       /* create and add a label and */
    return label;               /* return the created label */
  }  /* addLabel() */

  /*------------------------------------------------------------------*/
  /** Add a button to a tab.
   *  @param  text the text of the button
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JButton addButton (String text)
  { return this.addButton(text, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a button to a tab.
   *  @param  text the text of the button
   *  @param  gbc  the grid bag constraints to use
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JButton addButton (String text, GridBagConstraints gbc)
  {                             /* --- add a button to a tab */
    JButton button = new JButton(text);
    this.add(button, gbc);      /* create and add a button and */
    return button;              /* return the created button */
  }  /* addButton() */

  /*------------------------------------------------------------------*/
  /** Add a text input field to a tab.
   *  @param  text the initial text of the text input field
   *  @return the created <code>JTextField</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JTextField addTextInput (String text)
  { return this.addTextInput(text, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a text input field to a tab.
   *  @param  text the initial text of the text input field
   *  @param  gbc  the grid bag constraints to use
   *  @return the created <code>JTextField</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JTextField addTextInput (String text, GridBagConstraints gbc)
  {                             /* --- add a text input to a tab */
    JTextField tfld = new JTextField(text);
    this.add(tfld, gbc);        /* create and add a text field and */
    tfld.setFont(BOLD);         /* and set bold font */
    return tfld;                /* return the created text field */
  }  /* addTextInput() */

  /*------------------------------------------------------------------*/
  /** Create a number input field.
   *  @param  text the initial text of the input field
   *  @return the created <code>JFormattedTextField</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static JTextField createNumberInput (String text)
  {                             /* --- create a number input field */
    JTextField tfld = new JTextField();
    tfld.setFont(BOLD);         /* create a text field */
    tfld.setText(text);         /* and configure it */
    tfld.setInputVerifier(new InputVerifier() {
      public boolean verify (JComponent comp) {
        String text = ((JTextField)comp).getText();
        if (text.length() <= 0) return true;
        try { Double.parseDouble(text); }
        catch (NumberFormatException e) { return false; }
        return true;            /* add a simple verifier */
      } } );                    /* for real-valued numbers */
    return tfld;                /* return the created text field */
  }  /* createNumberInput() */

  /*------------------------------------------------------------------*/
  /** Add a text input field to a tab.
   *  @param  text the initial text of the text input field
   *  @return the created <code>JFormattedTextField</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JTextField addNumberInput (String text)
  { return this.addNumberInput(text, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a text input field to a tab.
   *  @param  text the initial text of the text input field
   *  @param  gbc  the grid bag constraints to use
   *  @return the created <code>JFormattedTextField</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JTextField addNumberInput (String text, GridBagConstraints gbc)
  {                             /* --- add a number input to a tab */
    JTextField tfld = DialogPanel.createNumberInput(text);
    this.add(tfld, gbc);        /* create and add a text field */
    return tfld;                /* return the created text field */
  }  /* addNumberInput() */

  /*------------------------------------------------------------------*/
  /** Add a file input field to a tab.
   *  @param  text the initial text of the file input field
   *  @return the created <code>JTextField</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JTextField addFileInput (String text)
  { return this.addFileInput(text, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a text input field to a tab.
   *  @param  text the initial text of the file input field
   *  @param  gbc  the grid bag constraints to use
   *  @return the created <code>JTextField</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JTextField addFileInput (String text, GridBagConstraints gbc)
  {                             /* --- add a file input to a tab */
    JTextField tfld = new JTextField(text);
    this.add(tfld, gbc);        /* create and add a text field */
    return tfld;                /* return the created text field */
  }  /* addFileInput() */

  /*------------------------------------------------------------------*/
  /** Add a check box to a tab.
   *  @param  state the initial state of the check box
   *  @return the created <code>JCheckBox</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JCheckBox addCheckBox (boolean state)
  { return this.addCheckBox("", state, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a check box to a tab.
   *  @param  state the initial state of the check box
   *  @param  gbc  the grid bag constraints to use
   *  @return the created <code>JCheckBox</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JCheckBox addCheckBox (boolean state, GridBagConstraints gbc)
  { return this.addCheckBox("", state, gbc); }

  /*------------------------------------------------------------------*/
  /** Add a check box to a tab.
   *  @param  text  the text of the check box
   *  @param  state the initial state of the check box
   *  @return the created <code>JCheckBox</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JCheckBox addCheckBox (String text, boolean state)
  { return this.addCheckBox(text, state, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a check box to a tab.
   *  @param  text  the text of the check box
   *  @param  state the initial state of the check box
   *  @param  gbc  the grid bag constraints to use
   *  @return the created <code>JCheckBox</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JCheckBox addCheckBox (String text, boolean state,
                                GridBagConstraints gbc)
  {                             /* --- add a check box to a tab */
    JCheckBox cbox = new JCheckBox(text, state);
    this.add(cbox, gbc);        /* create and add a check box and */
    return cbox;                /* return the created check box */
  }  /* addCheckBox() */

  /*------------------------------------------------------------------*/
  /** Add a combo box to a tab.
   *  @param  items the list of items
   *  @return the created <code>JComboBox</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JComboBox<String> addComboBox (String[] items)
  { return this.addComboBox(items, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a combo box to a tab.
   *  @param  items the list of items
   *  @param  gbc   the grid bag constraints to use
   *  @return the created <code>JComboBox</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JComboBox<String> addComboBox
    (String[] items, GridBagConstraints gbc)
  {                             /* --- add a combo box to a tab */
    JComboBox<String> cbox = (items == null)
                           ? new JComboBox<String>()
                           : new JComboBox<String>(items);
    this.add(cbox, gbc);        /* create and add a combo box */
    cbox.setFont(BOLD);         /* and set bold font */
    return cbox;                /* return the created combo box */
  }  /* addComboBox() */

  /*------------------------------------------------------------------*/
  /** Add a spinner to a tab.
   *  @param  val  the initial value
   *  @param  min  the minimal value
   *  @param  max  the maximal value
   *  @param  step the step size
   *  @return the created <code>JSpinner</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JSpinner addSpinner (int val, int min, int max, int step)
  { return this.addSpinner(val, min, max, step, RIGHT); }

  /*------------------------------------------------------------------*/
  /** Add a combo box to a tab.
   *  @param  val  the initial value
   *  @param  min  the minimal value
   *  @param  max  the maximal value
   *  @param  step the step size
   *  @param  gbc  the grid bag constraints to use
   *  @return the created <code>JSpinner</code>
   *  @since  2007.07.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JSpinner addSpinner (int val, int min, int max, int step,
                              GridBagConstraints gbc)
  {                             /* --- add a combo box to a tab */
    JSpinner spin = new JSpinner(
      new SpinnerNumberModel(val, min, max, step));
    this.add(spin, gbc);        /* create and add a combo box */
    ((DefaultEditor)spin.getEditor()).getTextField().setFont(BOLD);
    return spin;                /* return the created combo box */
  }  /* addSpinner() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser.
   *  @return the file chooser
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure the chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Get a file name and store it in a text field.
   *  @param  text the text field in which to store the file name
   *  @return the selected file or <code>null</code> if cancelled
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getFileName (JTextField text)
  { return this.getFileName(text, "Select File..."); }

  /*------------------------------------------------------------------*/
  /** Get a file name and store it in a text field.
   *  @param  text  the text field in which to store the file name
   *  @param  title the title of the file chooser dialog
   *  @return the selected file or <code>null</code> if cancelled
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getFileName (JTextField text, String title)
  {                             /* -- get and store a file name */
    this.getFileChooser().setDialogTitle(title);
    File file = new File(text.getText());
    this.chooser.setCurrentDirectory(file);
    this.chooser.setSelectedFile(file);
    int r = this.chooser.showOpenDialog(this);
    if (r != JFileChooser.APPROVE_OPTION) return null;
    file = this.chooser.getSelectedFile();
    text.setText(file.getPath());
    return file;                /* return the selected file name */
  }  /* getFileName() */

  /*------------------------------------------------------------------*/
  /** Show a data table (to be read from a file).
   *  @param  text   the text field containing the file name
   *  @param  format the panel for the data format (if any)
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void showTable (JTextField text, FormatPanel format)
  { this.showTable(new File(text.getText()), format); }

  /*------------------------------------------------------------------*/
  /** Show a data table (to be read from a file).
   *  @param  file   the file containing the data table
   *  @param  format the panel for the data format (if any)
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void showTable (File file, FormatPanel format)
  {                             /* --- show a data table */
    TableView view = new TableView(this, TableView.ALL_ITEMS);
    if (format != null) view.setFormat(format);
    if (!view.loadTable(file)) return;
    view.setVisible(true);      /* load the table file */
    view.toFront();             /* and display the table */
  }  /* showTable() */

  /*------------------------------------------------------------------*/
  /** Edit domain descriptions.
   *  @param  text the text field containing the file name
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void editDomains (JTextField text)
  {                             /* --- edit domain descriptions */
    String fn = text.getText(); /* get and check the file name */
    if (fn.length() != 0) this.editDomains(new File(fn));
  }  /* editDomains() */

  /*------------------------------------------------------------------*/
  /** Edit domain descriptions.
   *  @param  file the file containing the domain descriptions to edit
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void editDomains (File file)
  {                             /* --- edit domain descriptions */
    DomainsEditor ed = new DomainsEditor(this, DomainsEditor.DIRS);
    if (!ed.loadDomains(file)) return;
    ed.setVisible(true);        /* load the file to edit */
    ed.toFront();               /* and display the editor */
  }  /* editDomains() */

  /*------------------------------------------------------------------*/
  /** Edit a text file.
   *  @param  text the text field containing the file name
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void editFile (JTextField text)
  {                             /* --- edit a text file */
    String fn = text.getText(); /* get and check the file name */
    if (fn.length() > 0) this.editFile(new File(fn));
  }  /* editFile() */

  /*------------------------------------------------------------------*/
  /** Edit a text file.
   *  @param  file the file to edit
   *  @since  2007.05.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void editFile (File file)
  {                             /* --- edit a text file */
    MiniEditor ed = new MiniEditor(this, 0);
    if (!ed.loadText(file)) return;
    ed.setVisible(true);        /* load the file to edit */
    ed.toFront();               /* and display the editor */
  }  /* editFile() */

  /*------------------------------------------------------------------*/
  /** Read a line (of the configuration file).
   *  @param  reader the reader to read from
   *  @return the line read
   *  @throws IOException if an i/o error occurs
   *                      or no line could be read
   *  @since  2013.11.26 (Christian Borgelt)
   *          (transferred from DialogPanel) */
  /*------------------------------------------------------------------*/

  protected String readLine (FileReader reader) throws IOException
  {                             /* --- read the next input line */
    int c = reader.read();      /* read the next character */
    if (c < 0) throw new IOException("premature end of file");
    if (this.buf == null)       /* create a buffer for a line */
      this.buf = new StringBuilder();
    this.buf.setLength(0);      /* clear the read buffer */
    while ((c >= 0) && (c != '\n')) {
      this.buf.append((char)c); /* append current character */
      c = reader.read();        /* to the read buffer and */
    }                           /* read the next character */
    return this.buf.toString(); /* return the input line read */
  }  /* readLine() */

  /*------------------------------------------------------------------*/
  /** Read an integer value (from the configuration file).
   *  @param  reader the reader to read from
   *  @return the integer value read
   *  @throws IOException if an i/o error occurs
   *                      or no field could be read
   *  @since  2013.11.26 (Christian Borgelt)
   *          (transferred from DialogPanel) */
  /*------------------------------------------------------------------*/

  protected int readInt (FileReader reader) throws IOException
  {                             /* --- get next integer value */
    int c = reader.read();      /* read the next character */
    if (c < 0) throw new IOException("premature end of file");
    if (this.buf == null)       /* create a buffer for a field */
      this.buf = new StringBuilder();
    this.buf.setLength(0);      /* clear the read buffer */
    while ((c >= 0) && (c != ',') && (c != ';') && (c != '\n')) {
      this.buf.append((char)c); /* append current character */
      c = reader.read();        /* to the read buffer and */
    }                           /* read the next character */
    String s = this.buf.toString().trim();
    try { return Integer.parseInt(s); }
    catch (NumberFormatException e) {
      throw new IOException("malformed number: " +s); }
  }  /* readInt() */             /* decode and return the next field */

}  /* class DialogPanel() */
