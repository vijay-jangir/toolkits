/*----------------------------------------------------------------------
  File    : DTree.java
  Contents: decision tree management for visualization
  Author  : Christian Borgelt
  History : 2004.05.10 file created
            2004.05.12 decision tree access partly redesigned
            2004.05.16 full subtree folding/unfolding/pruning added
            2004.05.18 range of values for integer/real domains added
            2004.05.19 layout modes (horiz./vertical/center) added
            2004.05.20 line number reporting added to parser
            2004.05.23 regression tree representation added
            2004.05.25 relative frequency parsing added
            2004.06.02 parsing of nominal value subsets added
            2005.02.20 adapted to scanner utility functions
            2006.05.13 classes DTAtt and DTNode moved to own files
            2007.05.16 function parse() restricted to scanners
            2007.07.19 adapted to changed Table class
            2013.04.22 adapted to class name change Type -> ColType
            2016.04.07 StringBuffer replaced by StringBuilder
            2020.10.23 layout mode REVERSE added (reverse branch order)
----------------------------------------------------------------------*/
package dtree;

import java.io.IOException;
import java.io.FileReader;
import java.awt.Dimension;

import util.Scanner;
import table.ColType;
import table.NominalType;
import table.RealType;
import table.Column;
import table.Table;

/*--------------------------------------------------------------------*/
/** Class for a decision/regression tree.
 *  @author Christian Borgelt
 *  @since  2004.05.10 */
/*--------------------------------------------------------------------*/
public class DTree {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** layout mode: vertical */
  public  static final int VERTICAL   = 0;
  /** layout mode: horizontal */
  public  static final int HORIZONTAL = 1;
  /** layout mode: compact */
  public  static final int COMPACT    = 2;
  /** layout mode: center parent node */
  public  static final int CENTER     = 4;
  /** layout mode: reverse branch order */
  public  static final int REVERSE    = 8;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the underlying attributes */
  protected Table   atts;
  /** the target/class attribute */
  protected Column  target;
  /** the id of the target/class attribute */
  protected int     trgid;
  /** the type of the target/class attribute */
  protected ColType type;
  /** the number of classes (decision tree) */
  protected int     clscnt;
  /** the root node of the tree */
  protected DTNode  root;
  /** the current node of the tree */
  protected DTNode  curr;
  /** the layout mode */
  protected int     mode;

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree.
   *  @param  atts    the underlying attributes
   *  @param  trgname the name of the target attribute
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTree (Table atts, String trgname)
  { this(atts, atts.getColumnIndex(trgname)); }

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree.
   *  @param  atts  the underlying attributes
   *  @param  trgid the id of the target attribute
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTree (Table atts, int trgid)
  {                            /* --- create an empty decision tree */
    this.atts   = atts;       /* note the attributes */
    this.trgid  = trgid;      /* initialize the variables */
    this.target = atts.getColumn(trgid);
    ColType t = this.target.getType();
    this.clscnt = (t instanceof NominalType)
                ? ((NominalType)t).getValueCount() : -1;
    this.root   = this.curr = null;
    this.mode   = VERTICAL;
  }  /* DTree() */

  /*------------------------------------------------------------------*/
  /** Get the underlying attributes.
   *  @return the underlying attributes
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getAtts ()
  { return this.atts; }

  /*------------------------------------------------------------------*/
  /** Get the target attribute of the tree.
   *  @return the target attribute of the tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column getTarget ()
  { return this.target; }

  /*------------------------------------------------------------------*/
  /** Get the id of the target attribute of the tree.
   *  @return the id of the target attribute of the tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getTargetId ()
  { return this.trgid; }

  /*------------------------------------------------------------------*/
  /** Get the type of the target attribute of the tree.
   *  @return the type of the target attribute of the tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColType getTargetType ()
  { return this.target.getType(); }

  /*------------------------------------------------------------------*/
  /** Add a node to the decision tree.
   *  <p>The node is added as a child of the current node.</p>
   *  @param  id   the id of the child node
   *  @param  node the node to add as a child
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addNode (int id, DTNode node)
  {                             /* --- add a node to the tree */
    if (this.curr == null)      /* if the tree is still empty, */
      this.root = this.curr = node;       /* set the root node */
    else                        /* otherwise add a child node */
      this.curr.addChild(id, node);
  }  /* addNode() */

  /*------------------------------------------------------------------*/
  /** Add a node to the decision tree.
   *  <p>The node is added as a child of the current node.</p>
   *  @param  value the value associated with the tree edge
   *  @param  node  the node to add as a child
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addNode (String value, DTNode node)
  {                             /* --- add a node to the tree */
    if (this.curr == null)      /* if the tree is still empty, */
      this.root = this.curr = node;       /* set the root node */
    else                        /* otherwise add a child node */
      this.curr.addChild(value, node);
  }  /* addNode() */

  /*------------------------------------------------------------------*/
  /** Get the root node of the decision/regression tree.
   *  @return the root node of the decision/regression tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode getRoot ()
  { return this.root; }

  /*------------------------------------------------------------------*/
  /** Get the current node of the decision/regression tree.
   *  @return the current node of the decision/regression tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode getCurrent ()
  { return this.curr; }

  /*------------------------------------------------------------------*/
  /** Check whether the current node is the root.
   *  @return whether the current node is the root
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isRoot ()
  { return this.curr == this.root; }

  /*------------------------------------------------------------------*/
  /** Check whether the current node is a leaf node.
   *  @return whether the current node is a leaf node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isLeaf ()
  { return this.curr.children == null; }

  /*------------------------------------------------------------------*/
  /** Set the current node to the root node.
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void goToRoot ()
  { this.curr = this.root; }

  /*------------------------------------------------------------------*/
  /** Go to the parent node of the current node.
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void goUp ()
  { this.curr = this.curr.parent; }

  /*------------------------------------------------------------------*/
  /** Get the number of children of the current node.
   *  @return the number of children of the current node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getChildCount ()
  { return this.curr.getChildCount(); }

  /*------------------------------------------------------------------*/
  /** Go to a child of the current node.
   *  @param  id the id of the child node to go to; must be in the
   *             range 0 to <code>getChildCount()-1</code>
   *  @return whether the child exists and thus was actually moved to
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean goDown (int id)
  {                             /* --- go down in the tree */
    DTNode child = this.curr.children[id];
    if (child == null) return false;
    this.curr = child; return true;
  }  /* goDown() */

  /*------------------------------------------------------------------*/
  /** Go to a child of the current node.
   *  @param  value the value associated with the tree edge
   *  @return whether the child exists and thus was actually moved to
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean goDown (String value)
  { NominalType nom = (NominalType)this.curr.att.getType();
    return this.goDown(nom.getValueId(value)); }

  /*------------------------------------------------------------------*/
  /** Get the height of the tree.
   *  @return the height of the tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getHeight ()
  { return (this.root != null) ? this.root.getHeight() : 0; }

  /*------------------------------------------------------------------*/
  /** Get the width of the tree.
   *  @return the width of the tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getWidth ()
  { return (this.root != null) ? this.root.getWidth()  : 0; }

  /*------------------------------------------------------------------*/
  /** Get the size of the tree (number of nodes).
   *  @return the size of the tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getSize ()
  { return (this.root != null) ? this.root.getSize()   : 0; }

  /*------------------------------------------------------------------*/
  /** Get the range of the prediction values.
   *  <p>The union of all ranges of all nodes is determined.</p>
   *  @return the range of the prediction values
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double[] getRange ()
  {                             /* --- get range of prediction */
    double[] range = new double[2];  /* minimum and maximum value */

    range[0] =  Double.MAX_VALUE;    /* initialize to inverse */
    range[1] = -Double.MAX_VALUE;    /* maximal interval */
    if (this.root != null) this.root.getRange(range);
    return range;               /* recursively process the tree */
  }  /* getRange() */

  /*------------------------------------------------------------------*/
  /** Lay out the nodes of the tree.
   *  @param  mode the layout mode
   *  @param  x    the x-coordinate of the upper left corner
   *  @param  y    the y-coordinate of the upper left corner
   *  @param  w    the width  of a cell for a node
   *  @param  h    the height of a cell for a node
   *  @return the width and height of the full tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Dimension layout (int mode, int x, int y, int w, int h)
  {                             /* --- do layout for visualization */
    int   i;                    /* loop variable */
    int   d;                    /* the height of the tree to show */
    int   m;                    /* minimum x-coord. of left border */
    int[] bdr;                  /* left/top border of the tree */

    if (this.root == null)      /* if there is no tree, abort */
      return new Dimension (x, y);
    this.mode = mode;           /* note the layout mode */
    if ((mode & DTree.COMPACT) == 0) { /* if standard tree layout */
      if ((mode & DTree.HORIZONTAL) != 0)
           this.root.layoutHorz(mode, x, y, w, h);
      else this.root.layoutVert(mode, x, y, w, h); }
    else {                      /* if compact tree layout */
      d = this.getHeight();     /* get the tree height/array size */
      if ((mode & DTree.HORIZONTAL) != 0) { /* -- horizontal layout */
        d = this.root.cloHorz1(mode, d, h, bdr = new int[d],new int[d]);
        for (m = bdr[0], i = 1; i < d; i++) /* tree layout, pass 1 */
          if (bdr[i] < m) m = bdr[i];       /* find shift value */
        this.root.cloHorz2(mode, x, y-m, w, h); }     /* pass 2 */
      else {                                /* -- vertical layout */
        d = this.root.cloVert1(mode, d, w, bdr = new int[d],new int[d]);
        for (m = bdr[0], i = 1; i < d; i++) /* tree layout, pass 1 */
          if (bdr[i] < m) m = bdr[i];       /* find shift value */
        this.root.cloVert2(mode, x-m, y, w, h);       /* pass 2 */
      }                         /* recursively lay out the tree */
    }                           /* return the extension of the tree */
    return new Dimension (this.root.trgt, this.root.tbot);
  }  /* layout() */

  /*------------------------------------------------------------------*/
  /** Find the node that is located at given coordinates.
   *  @param  x the x-coordinate
   *  @param  y the y-coordinate
   *  @return node that is located at the given coordinates
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode find (int x, int y)
  {                             /* --- find node by coordinates */
    if (this.root == null) return null;
    if ((this.mode & HORIZONTAL) != 0)  /* search from the root */
         return this.root.findHorz(x, y);
    else return this.root.findVert(x, y);
  }  /* find() */

  /*------------------------------------------------------------------*/
  /** Fold/unfold all nodes of the decision/regression tree.
   *  @param  f whether to fold all nodes
   *  @since  2004.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void fold (boolean f)
  { if (this.root != null) this.root.fold(f, true); }

  /*------------------------------------------------------------------*/
  /** Create a string description of the decision/regression tree.
   *  @return a string description of the decision/regression tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  {                             /* -- produce a string description */
    int           i;            /* loop variable */
    StringBuilder s;            /* created string description */

    if (this.target == null)    /* if there is no target attribute */
      return "";                /* return an empty string */
    s = new StringBuilder();    /* create a string buffer */
    s.append(this.atts.toString("domains"));
    s.append("\n/*");           /* add the domain descriptions */
    for (i = 70; --i >= 0; ) s.append('-');
    s.append("\n  decision tree\n");
    for (i = 70; --i >= 0; ) s.append('-');
    s.append("*/\n");           /* create decision tree header */
    s.append("dtree(");         /* start the tree description */
    s.append(this.target.getName());
    s.append(") =\n");          /* add the target name */
    if (this.root == null) s.append("{ }");
    else                   s.append(this.root.toString(0));
    s.append(";\n");            /* describe the decision tree */
    s.append("\n/*");           /* leave one line empty */
    for (i = 70; --i >= 0; ) s.append('-');
    s.append("\n  number of attributes: ");
    s.append(this.atts.getColumnCount());
    s.append("\n  tree height         : ");
    s.append(this.getHeight());
    s.append("\n  number of nodes     : ");
    s.append(this.getSize());
    s.append("\n  number of tuples    : ");
    s.append((this.root != null) ? this.root.getFreq() : 0);
    s.append("\n");             /* add additional information */
    for (i = 70; --i >= 0; ) s.append('-');
    s.append("*/\n");           /* terminate additional information */
    return s.toString();        /* and return the created string */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Parse a decision/regression tree description.
   *  @param  scan the scanner to read from
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static DTree parse (Scanner scan) throws IOException
  { return DTree.parse(scan, null); }

  /*------------------------------------------------------------------*/
  /** Parse a decision/regression tree description.
   *  @param  scan the scanner to read from
   *  @param  atts the underlying attributes
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static DTree parse (Scanner scan, Table atts)
    throws IOException
  {                             /* --- parse a tree description */
    DTree dtree;                /* created decision tree */
    int   tok;                  /* buffer for a token */

    if (atts == null)           /* parse domains if necessary */
      atts = Table.parse("domains", scan);
    scan.getID("dtree");        /* check for 'dtree' */
    scan.getChar('(');          /* check for a '(' */
    scan.getID();               /* check for an identifier */
    dtree = new DTree(atts, scan.value);
    if (dtree.target == null)   /* create a decision tree */
      throw new IOException("unknown target " +scan.value +scan.lno());
    scan.getChar(')');          /* check for a ')' */
    scan.getChar('=');          /* check for a '=' */
    scan.getChar('{');          /* check for a '{' */
    tok = scan.nextToken();     /* look ahead to the next token */
    scan.pushBack();            /* and put it back */
    if (tok != '}')             /* recursively parse the tree */
      dtree.root = dtree.curr = DTNode.parse(dtree, scan);
    scan.getChar('}');          /* check for a '}' */
    scan.getChar(';');          /* check for a ';' */
    return dtree;               /* return the created tree */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    Table  atts;                /* underlying attributes */
    Column a, b, c;             /* to create attributes */
    DTNode node;                /* to create nodes */
    DTree  dt;                  /* created decision tree */

    if (args.length <= 0) {     /* if no file name is given */
      atts = new Table("atts"); /* create default attributes */
      atts.addColumn(a = new Column("A", new NominalType()));
      atts.addColumn(b = new Column("B", new RealType()));
      atts.addColumn(c = new Column("C", new NominalType()));
      a.addValue("a1"); a.addValue("a2"); a.addValue("a3");
      c.addValue("c1"); c.addValue("c2"); c.addValue("c3");
      dt  = new DTree(atts, 2); /* create a default decision tree */
      node = new DTNode(dt, a);    dt.addNode(0, node);
      node = new DTNode(dt, b, 1); dt.addNode(0, node);
      dt.goDown(0);
      node = new DTNode(dt, c);    dt.addNode(0, node);
      node = new DTNode(dt, c);    dt.addNode(1, node);
      dt.goUp();
      node = new DTNode(dt, b, 2); dt.addNode(1, node);
      dt.goDown(1);
      node = new DTNode(dt, c);    dt.addNode(0, node);
      node = new DTNode(dt, c);    dt.addNode(1, node);
      dt.goUp();
      node = new DTNode(dt, b, 3); dt.addNode(2, node);
      dt.goDown(2);
      node = new DTNode(dt, c);    dt.addNode(0, node);
      node = new DTNode(dt, c);    dt.addNode(1, node);
      dt.goToRoot(); }          /* create a decision tree */
    else {                      /* if a file name is given */
      try {                     /* parse the file */
        dt = DTree.parse(new Scanner(new FileReader(args[0]))); }
      catch (IOException ioe) {
        System.err.println(ioe.getMessage()); return; }
    }
    System.out.print(dt);       /* print the read decision tree */
  }  /* main() */

}  /* class DTree */
