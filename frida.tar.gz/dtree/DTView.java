/*----------------------------------------------------------------------
  File    : DTView.java
  Contents: decision and regression tree visualization program
  Author  : Christian Borgelt
  History : 2004.05.10 file created from file JSkel.java
            2004.05.11 adapted to changes in DTree.java
            2004.05.12 class DTPanel moved to separate file
            2004.05.13 font selection added
            2004.05.14 error message dialog box added
            2004.05.15 start as a module made possible
            2004.05.16 full subtree folding/unfolding added
            2004.05.19 more layout options added, derived from JFrame
            2004.05.20 file menu added to visualization module
            2004.07.05 bug concerning save dialog fixed
            2004.09.13 function saveImage added
            2006.07.20 user interface creation moved to run method
            2007.02.10 adapted to about dialog utility class
            2007.02.11 javadoc added, cleaning up and restructuring
            2007.02.12 returned to delayed dialog box creation
            2007.02.23 color selection dialog added
            2007.03.12 function setMessage added
            2007.06.07 loading and saving simplified
            2007.07.07 adapted to new class DialogPanel
            2007.07.18 dialog boxes changed to "Apply", "Ok", "Cancel"
            2007.07.19 adapted to changed Table class
            2013.04.22 adapted to type argument of JComboBox
            2013.04.22 adapted to class name change Type -> ColType
            2014.10.23 changed from LGPL license to MIT license
            2015.12.02 compact layout added, layout dialog adapted
            2015.12.11 edge thickness and anti-aliasing added
            2020.10.23 layout mode REVERSE added (reverse branch order)
----------------------------------------------------------------------*/
package dtree;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileOutputStream;
import java.awt.Component;
import java.awt.Container;
import java.awt.Color;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.BorderFactory;
import javax.imageio.ImageIO;

import dialog.DialogPanel;
import dialog.ColorDialog;
import dialog.AboutDialog;
import table.NominalType;
import table.Column;
import table.Table;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for a decision and regression tree viewer.
 *  @author Christian Borgelt
 *  @since  2004.05.10 */
/*--------------------------------------------------------------------*/
public class DTView extends JFrame implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010019L;
  public  static final String VERSION = "1.26 (2020.10.23)";

  /** mode flag: the viewer is a stand-alone program */
  public final static int PROGRAM    = 1;
  /** mode flag: add menu items for loading trees */
  public final static int LOAD_ITEMS = 2;
  /** mode flag: add menu items for saving trees */
  public final static int SAVE_ITEMS = 4;
  /** mode flag: add menu items for loading and saving trees */
  public final static int FILE_ITEMS = LOAD_ITEMS | SAVE_ITEMS;
  /** mode flag: add all menu items */
  public final static int ALL_ITEMS  = FILE_ITEMS;

  /** the names of the layout directions */
  private static final String[] dirnames = {
    "vertical", "horizontal" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this decision tree viewer */
  private Component         owner   = null;
  /** the mode flags */
  private int               mode    = 0;
  /** the decision tree panel */
  private DTPanel           panel   = null;
  /** the status bar for messages */
  private JTextField        stat    = null;
  /** the file chooser */
  private JFileChooser      chooser = null;
  /** the current tree file */
  private File              curr    = null;

  /* --- layout dialog box --- */
  /** the layout dialog box */
  private JDialog           layout  = null;
  /** whether the layout is vertical or horizontal */
  private JComboBox<String> lodir   = null;
  /** whether the parent is centered over its children */
  private JCheckBox         center  = null;
  /** whether to use the compact layout */
  private JCheckBox         compact = null;
  /** whether to reverse the branch order */
  private JCheckBox         reverse = null;
  /** whether to antialias the edges */
  private JCheckBox         aaedge  = null;
  /** whether to antialias the text */
  private JCheckBox         aatext  = null;
  /** whether to draw direct connections between nodes */
  private JCheckBox         direct  = null;
  /** the width of a node */
  private JSpinner          width   = null;
  /** the height of a node */
  private JSpinner          height  = null;
  /** the horizontal distance between nodes */
  private JSpinner          horz    = null;
  /** the vertical distance between nodes */
  private JSpinner          vert    = null;
  /** the width of node shadows */
  private JSpinner          shadow  = null;
  /** the width of the frame around the tree */
  private JSpinner          wframe  = null;
  /** the thickness of the connecting edges */
  private JSpinner          thick   = null;

  /* --- font dialog box --- */
  /** the font selection dialog box */
  private JDialog           fontsel = null;
  /** the name of the font */
  private JComboBox<String> name    = null;
  /** whether font is bold */
  private JCheckBox         bold    = null;
  /** whether font is italic */
  private JCheckBox         italic  = null;
  /** the point size of the font */
  private JSpinner          ptsize  = null;

  /* --- color dialog box --- */
  /** the color selection dialog box */
  private ColorDialog       colsel  = null;

  /* --- about dialog box --- */
  /** the "About..." dialog box */
  private AboutDialog       about   = null;

  /*------------------------------------------------------------------*/
  /** Create a decision and regression tree viewer.
   *  @param  mode the mode flags
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTView (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create a decision and regression tree viewer.
   *  @param  owner the component that is to own this viewer
   *  @param  mode  the mode flags
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTView (Component owner, int mode)
  {                             /* --- create a decision tree viewer */
    this.owner = owner;         /* note the owner */
    this.mode  = mode;          /* and the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* DTView() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2006.07.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    if ((this.mode & PROGRAM) != 0)
      this.mode |= LOAD_ITEMS;  /* check and adapt the mode */

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    if ((this.mode & LOAD_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Load Tree...", 'l'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          DTView.this.loadDTree(null); } } );
      item = menu.add(new JMenuItem("Reload Tree", 'r'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          DTView.this.loadDTree(DTView.this.curr); } } );
      menu.addSeparator();
    }
    if ((this.mode & SAVE_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Save Tree", 's'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          DTView.this.saveDTree(DTView.this.curr); } } );
      item = menu.add(new JMenuItem("Save Tree as...", 'a'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          DTView.this.saveDTree(null); } } );
      menu.addSeparator();
    }
    item = menu.add(new JMenuItem("Save PNG Image...", 'i'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.saveImage(null); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          DTView.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("View"));
    menu.setMnemonic('v');
    item = menu.add(new JMenuItem("Set Layout...", 'l'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.getLayoutDlg().setVisible(true);
        DTView.this.layout.toFront();
      } } );
    item = menu.add(new JMenuItem("Set Font...", 'o'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.getFontSelDlg().setVisible(true);
        DTView.this.fontsel.toFront();
      } } );
    item = menu.add(new JMenuItem("Set Colors...", 'c'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.getColorDlg().setVisible(true);
        DTView.this.colsel.toFront();
      } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Unfold All", 'u'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.panel.fold(false); } } );
    item = menu.add(new JMenuItem("Fold All", 'f'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.panel.fold(true); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Redraw", 'r'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.panel.repaint(); } } );

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (DTView.this.about == null)
          DTView.this.about = new AboutDialog(DTView.this,
             "About DTView...", "DTView\n"
            +"A Decision Tree Visualization Program\n"
            +"Version " +DTView.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        DTView.this.about.setVisible(true);
        DTView.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    this.panel = new DTPanel();
    this.panel.setLayout(new BorderLayout());
    this.panel.setPreferredSize(new Dimension(640, 400));
    this.panel.addMouseListener(this.panel);
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(new JScrollPane(this.panel), BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    this.stat = new JTextField("");
    this.stat.setEditable(false);
    content.add(this.stat, BorderLayout.SOUTH);

    /* --- configure and show the frame window --- */
    this.setTitle("DTView");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the attribute selector dialog box (create if necessary).
   *  @return the attribute selector dialog box
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure the chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Set the layout.
   *  @since  2007.07.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setLayout ()
  {                             /* --- set the layout */
    this.panel.setMode(         /* edge drawing and relative position */
       ((this.lodir.getSelectedIndex() > 0)
                ? DTree.HORIZONTAL : DTree.VERTICAL)
      | (this.center.isSelected()  ? DTree.CENTER  : 0)
      | (this.compact.isSelected() ? DTree.COMPACT : 0)
      | (this.reverse.isSelected() ? DTree.REVERSE : 0));
    this.panel.setDirect(this.direct.isSelected());
    this.panel.setEdges(        /* edge parameters */
      ((Integer)this.thick.getValue()).intValue(),
      (this.aaedge.isSelected()));
    this.panel.setParams(       /* node layout */
      ((Integer)this.width.getValue()).intValue(),
      ((Integer)this.height.getValue()).intValue(),
      ((Integer)this.horz.getValue()).intValue(),
      ((Integer)this.vert.getValue()).intValue(),
      ((Integer)this.shadow.getValue()).intValue(),
      ((Integer)this.wframe.getValue()).intValue());
    this.panel.doLayout();      /* repaint the panel */
  }  /* setLayout() */

  /*------------------------------------------------------------------*/
  /** Get the layout dialog box (create if necessary).
   *  @return the layout dialog box
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getLayoutDlg ()
  {                             /* --- create layout params. dialog */
    DialogPanel tab;            /* panel for the dialog fields */
    JPanel      bbar;           /* panel for the button bar */
    JButton     button;         /* button for apply and close */

    if (this.layout != null)    /* if the dialog box exists, */
      return this.layout;       /* simply return it */
    this.layout = new JDialog(this);
    tab = new DialogPanel();    /* create the main panel */

    tab.addLabel("Layout direction:");
    this.lodir   = tab.addComboBox(DTView.dirnames);
    this.lodir.setSelectedIndex(0);
    tab.addLabel("Layout mode:");
    this.center  = tab.addCheckBox("center", true,  DialogPanel.MIDDLE);
    this.compact = tab.addCheckBox("compact",false, DialogPanel.RIGHT);
    tab.addLabel("");
    this.reverse = tab.addCheckBox("reverse branch order",
                                   false, DialogPanel.RIGHT);
    tab.addLabel("Edge drawing:");
    this.direct = tab.addCheckBox("direct", true, DialogPanel.MIDDLE);
    this.aaedge = tab.addCheckBox("anti-alias",false,DialogPanel.RIGHT);
    tab.addLabel("Edge thickness:");
    this.thick  = tab.addSpinner( 1,  1,    8, 1);
    tab.addLabel("Node width:");
    this.width  = tab.addSpinner(96, 16, 1024, 1);
    tab.addLabel("Node height:");
    this.height = tab.addSpinner(48, 24, 1024, 1);
    tab.addLabel("Horizontal distance:");
    this.horz   = tab.addSpinner( 8,  1, 1024, 1);
    tab.addLabel("Vertical distance:");
    this.vert   = tab.addSpinner(18,  1, 1024, 1);
    tab.addLabel("Shadow width:");
    this.shadow = tab.addSpinner( 4,  0, 1024, 1);
    tab.addLabel("Frame width:");
    this.wframe = tab.addSpinner( 8,  0, 1024, 1);

    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTView.this.setLayout(); } } );
    bbar.add(button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTView.this.layout.setVisible(false);
        DTView.this.setLayout(); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTView.this.layout.setVisible(false); } } );

    this.layout.getContentPane().add(tab,  BorderLayout.CENTER);
    this.layout.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.layout.setTitle("Set Layout...");
    this.layout.setLocationRelativeTo(this);
    this.layout.pack();
    return this.layout;
  }  /* getLayoutDlg() */

  /*------------------------------------------------------------------*/
  /** Set the font for the node labels.
   *  @since  2007.07.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setFont ()
  {                             /* --- set the font */
    this.panel.setFont(         /* create the font and set it */
      new Font((String)this.name.getSelectedItem(),
               (this.bold.isSelected()   ? Font.BOLD   : Font.PLAIN)
             | (this.italic.isSelected() ? Font.ITALIC : 0),
               ((Integer)this.ptsize.getValue()).intValue()),
               this.aatext.isSelected());
    this.panel.doLayout();      /* repaint the panel */
  }  /* setFont() */

  /*------------------------------------------------------------------*/
  /** Get the font selection dialog box (create if necessary).
   *  @return the font selection dialog box
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getFontSelDlg ()
  {                             /* --- create font dialog */
    DialogPanel tab;            /* panel for the dialog fields */
    JPanel      bbar;           /* panel for the button bar */
    JButton     button;         /* button for apply and close */

    if (this.fontsel != null)   /* if the dialog box exists, */
      return this.fontsel;      /* simply return it */
    this.fontsel = new JDialog(this);
    tab = new DialogPanel();    /* create the main panel */

    tab.addLabel("Font name:");
    this.name = tab.addComboBox(new String[] {
      "SansSerif", "Serif", "Monospaced", "Dialog", "DialogInput" });
    tab.addLabel("Font style:");
    this.bold   = tab.addCheckBox("bold",   true,  DialogPanel.MIDDLE);
    this.italic = tab.addCheckBox("italic", false, DialogPanel.RIGHT);
    tab.addLabel("Font size:");
    this.ptsize = tab.addSpinner(12, 6, 60, 1);
    tab.addLabel("Anti-aliasing:");
    this.aatext = tab.addCheckBox("(smooth edges)",
                                  false, DialogPanel.RIGHT);

    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTView.this.setFont(); } } );
    bbar.add(button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTView.this.fontsel.setVisible(false);
        DTView.this.setFont(); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTView.this.fontsel.setVisible(false); } } );

    this.fontsel.getContentPane().add(tab,  BorderLayout.CENTER);
    this.fontsel.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.fontsel.setTitle("Set Font...");
    this.fontsel.setLocationRelativeTo(this);
    this.fontsel.pack();
    return this.fontsel;
  }  /* getFontSelDlg() */

  /*------------------------------------------------------------------*/
  /** Get the color selection dialog box (create if necessary).
   *  @return the color selection dialog box
   *  @since  2007.02.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getColorDlg ()
  {                             /* --- create color chooser dialog */
    if (this.colsel != null)    /* if the dialog already exists, */
      return this.colsel;       /* simply return it */
    this.colsel = new ColorDialog(this, "Set Colors...");
    this.colsel.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTView.this.panel.updateColors();
        DTView.this.panel.repaint();
      } } );
    this.updateColorDlg(null);  /* create and update the dialog */
    return this.colsel;         /* return the created color dialog */
  }  /* getColorDlg() */

  /*------------------------------------------------------------------*/
  /** Update the color selection dialog box.
   *  @param  dtree the tree from which to update the colors
   *  @since  2007.02.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void updateColorDlg (DTree dtree)
  {                             /* --- update the color dialog */
    Column  target;             /* target of the tree */
    Table   table;              /* table for the target */
    boolean isdt;               /* flag for decision tree */

    if (this.colsel == null) return;
    if (dtree == null) dtree = this.panel.getDTree();
    if (dtree == null) { this.colsel.setTable(null); return; }
    table  = new Table("target");  /* create a table for the target, */
    target = dtree.getTarget();    /* get the tree target, and */
    table.addColumn(target);       /* add the corresponding column */
    isdt = (target.getType() instanceof NominalType);
    this.colsel.setTable(table, (isdt) ? 1 : 0);
    if (!isdt) this.colsel.setColor(new Color(0.65F, 0.60F, 1.00F));
  }  /* updateColorDlg() */     /* set the table in the dialog */

  /*------------------------------------------------------------------*/
  /** Set the message to display in the status line.
   *  @param  msg the message to display in the status line
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.stat.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void reportError (String msg)
  {                             /* --- report an i/o error */
    this.stat.setText(msg);     /* set message in status bar */
    System.err.println(msg);    /* and print message to stderr */
    JOptionPane.showMessageDialog(this, msg,
      "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */        /* show alert dialog box */

  /*------------------------------------------------------------------*/
  /** Set the decision or regression tree to display.
   *  @param  dtree the decision or regression tree to display
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDTree (DTree dtree)
  {                             /* --- set the tree to display */
    this.updateColorDlg(dtree); /* update the color dialog and */
    this.panel.setDTree(dtree); /* set the tree in the panel */
    this.stat.setText(((dtree.getTargetType() instanceof NominalType)
                        ? "decision" : "regression")
                        + " tree for " +dtree.getTarget().getName());
  }  /* setDTree() */

  /*------------------------------------------------------------------*/
  /** Set the currently displayed decision or regression tree
   *  @return the currently displayed decision or regression tree
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTree getDTree ()
  { return this.panel.getDTree(); }

  /*------------------------------------------------------------------*/
  /** Load the decision or regression tree to display.
   *  @param  file the file to load the tree from
   *  @return whether the file was successfully loaded
   *  @since  2005.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadDTree (File file)
  {                             /* --- load a decision tree */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create scanner for the file */
      System.err.print("reading " +file +" ... ");
      Scanner scan  = new Scanner(new FileReader(file));
      DTree   dtree = DTree.parse(scan);
      scan.close();             /* load the decision tree */
      this.setDTree(dtree);     /* and set it in the display */
      System.err.print("[" +(dtree.getAtts().getColumnCount()-1));
      System.err.print("+1 attribute(s), ");
      System.err.print(  dtree.getSize()   +" node(s), ");
      System.err.println(dtree.getHeight() +" level(s)] done."); }
    catch (IOException e) {     /* catch and report i/o errors */
      this.reportError(e.getMessage()); return false; }
    this.stat.setText(this.stat.getText() +" (" +file.getName() +")");
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadDTree() */

  /*------------------------------------------------------------------*/
  /** Save the displayed decision or regression tree.
   *  @param  file the file to save the tree to
   *  @return whether the file was successfully written
   *  @since  2005.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveDTree (File file)
  {                             /* --- save a decision tree */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a writer for the file */
      System.err.print("writing " +file +" ... ");
      DTree      dtree  = this.panel.getDTree();
      FileWriter writer = new FileWriter(file);
      writer.write(dtree.toString());
      writer.close();           /* save the decision/regression tree */
      System.err.print("[" +(dtree.getAtts().getColumnCount()-1));
      System.err.print("+1 attribute(s), ");
      System.err.print(  dtree.getSize()   +" node(s), ");
      System.err.println(dtree.getHeight() +" level(s)] done."); }
    catch (IOException e) {     /* catch and report i/o errors */
      this.reportError(e.getMessage()); return false; }
    this.curr = file;           /* note the new file name */
    return true;                /* return 'saving successful' */
  }  /* saveDTree() */

  /*------------------------------------------------------------------*/
  /** Save a PNG image of the panel.
   *  @param  file the file to save the image to
   *  @return whether the file was successfully written
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveImage (File file)
  {                             /* --- save image to a file */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* let the user choose a file name */
    try {                       /* open an output stream */
      System.err.print("writing " +file +" ... ");
      FileOutputStream stream = new FileOutputStream(file);
      ImageIO.write(this.panel.makeImage(), "png", stream);
      stream.close();           /* save the decision tree image */
      System.err.println("done."); }
    catch (IOException e) {     /* catch and report i/o errors */
      this.reportError(e.getMessage()); return false; }
    return true;                /* return 'ok' */
  }  /* saveImage() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    int     i, k = 0;           /* loop variables */
    String  s;                  /* to traverse the arguments */
    String  fn_in  = null;      /* name of an optional input  file */
    String  fn_out = null;      /* name of an optional output file */
    int     mode   = DTree.VERTICAL|DTree.CENTER;
    boolean aaedge = false;     /* edge anti-aliasing */
    boolean aatext = false;     /* text anti-aliasing */
    boolean direct = true;      /* layout parameters */
    int     thick  =  1;        /* edge thickness (in pixels) */
    int     wd     = 96;        /* node width */
    int     ht     = 48;        /* node height */
    int     dx     =  8;        /* horizontal distance */
    int     dy     = 18;        /* vertical   distance */
    int     sh     =  4;        /* shadow width */
    int     fr     =  8;        /* frame  width */
    String  dfont  = "SansSerif";
    int     style  = Font.BOLD;
    int     size   = 12;        /* font parameters */
    DTView  v;                  /* decision tree viewer */

    for (i = 0; i < args.length; i++) {
      s = args[i];              /* traverse the arguments */
      if ((s.length() > 0)      /* if the argument is an option */
      &&  (s.charAt(0) == '-')) {
        switch (s.charAt(1)) {  /* evaluate option */
          case 'r': mode  &= ~DTree.VERTICAL;
                    mode  |=  DTree.HORIZONTAL;                break;
          case 'c': mode  &= ~DTree.CENTER;                    break;
          case 'p': mode  |=  DTree.COMPACT;                   break;
          case 'e': aaedge = true;                             break;
          case 'l': aatext = true;                             break;
          case 'd': direct = false;                            break;
          case 't': thick  = Integer.parseInt(s.substring(2)); break;
          case 'w': wd     = Integer.parseInt(s.substring(2)); break;
          case 'h': ht     = Integer.parseInt(s.substring(2)); break;
          case 'x': dx     = Integer.parseInt(s.substring(2)); break;
          case 'y': dy     = Integer.parseInt(s.substring(2)); break;
          case 's': sh     = Integer.parseInt(s.substring(2)); break;
          case 'f': fr     = Integer.parseInt(s.substring(2)); break;
          case 'a': dfont  = s.substring(2);                   break;
          case 'b': style &= ~Font.BOLD;
                    style |=  Font.PLAIN;                      break;
          case 'i': style |=  Font.ITALIC;                     break;
          case 'z': size   = Integer.parseInt(s.substring(2)); break;
          default : System.err.print("Error: unknown option -");
                    System.err.println(s.charAt(1)); return;
        } }
      else {                    /* if the argument is no option */
        switch (k++) {          /* evaluate non-option */
          case  0: fn_in  = s; break;
          case  1: fn_out = s; break;
          default: System.err.println("Error: too many arguments");
                   return;      /* there should not be more */
        }                       /* than two fixed arguments: */
      }                         /* a core description and a */
    }                           /* name of an input file */
    v = new DTView((k < 2) ? PROGRAM|FILE_ITEMS : 0);
    if (k > 0)                  /* create a decision tree viewer */
      v.loadDTree(new File(fn_in));
    v.panel.setMode(mode);      /* set the layout parameters */
    v.panel.setDirect(direct);
    v.panel.setEdges(thick, aaedge);
    v.panel.setParams(wd, ht, dx, dy, sh, fr);
    v.panel.setFont(new Font(dfont, style, size), aatext);
    v.panel.doLayout();         /* re-layout the decision tree */
    if (k <= 1)                 /* if to show the viewer, */
      v.setVisible(true);       /* make the frame visible */
    else {                      /* if only to create an image */
      try {                     /* save the decision tree image */
        ImageIO.write(v.panel.makeImage(), "png",
                      new FileOutputStream(new File(fn_out))); }
      catch (java.io.IOException ioe) {
        System.err.println("file " +fn_out +":\n" +ioe.getMessage()); }
      System.exit(0);           /* after saving the image, */
    }                           /* the program can be terminated */
  }  /* main() */

}  /* class DTView */
