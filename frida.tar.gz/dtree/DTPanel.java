/*----------------------------------------------------------------------
  File    : DTPanel.java
  Contents: decision tree viewer panel
  Author  : Christian Borgelt
  History : 2004.05.10 file created from file JSkel.java
            2004.05.11 adapted to changes in DTree.java
            2004.05.12 decision tree drawing extended
            2004.05.13 node folding added, font selection added
            2004.05.16 full subtree folding/unfolding added
            2004.05.19 more layout options added
            2004.05.23 regression tree drawing added
            2004.05.24 pre-allocation of colors added
            2004.05.26 function setFont added
            2004.09.13 function makeImage added
            2007.02.17 javadoc added, parsing moved to static function
            2007.02.23 setting colors for classes and deviation added
            2013.04.22 adapted to class name change Type -> ColType
            2015.11.24 unnecessary variable in paint() eliminated
            2015.11.25 all floating point values changed to double
            2015.12.02 compact layout added (denser node placement)
            2015.12.11 edge thickness and anti-aliasing added
            2019.03.31 fixed some deprecated functions etc.
            2020.10.23 layout mode REVERSE added (reverse branch order)
----------------------------------------------------------------------*/
package dtree;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.Shape;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JMenuItem;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import table.ColType;
import table.NominalType;
import table.Column;

/*--------------------------------------------------------------------*/
/** Class for a panel for a decision/regression tree display.
 *  @author Christian Borgelt
 *  @since  2004.05.10 */
/*--------------------------------------------------------------------*/
public class DTPanel extends JPanel implements MouseListener {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010000L;
  /** the background color of a node */
  private static final Color bkgnd = new Color(0.90F, 0.90F, 0.90F);
  /** the color for the relative support of a node */
  private static final Color rsupp = new Color(0.67F, 0.67F, 0.67F);

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the tree to display */
  private DTree      dtree;
  /** the tree type, that is, the type of the target */
  private ColType    type;
  /** a buffer for a node */
  private DTNode     node;
  /** the layout mode (horizontal vs. vertical etc.) */
  private int        mode;
  /** the width of a node */
  private int        width;
  /** the height of a node */
  private int        height;
  /** the horizontal distance between nodes */
  private int        horz;
  /** the vertical distance between nodes */
  private int        vert;
  /** the width of the shadow of a node */
  private int        shadow;
  /** the width of the frame around the tree */
  private int        frame;
  /** the thickness of the connecting lines (in pixels) */
  private int        thick;
  /** the flag for direct edge drawing */
  private boolean    direct;
  /** the flag for antialiasing connecting lines */
  private boolean    aaedge;
  /** the flag for antialiasing text and labels */
  private boolean    aatext;
  /** the label font */
  private Font       font;
  /** the point size of font */
  private int        ptsize;
  /** the normalization factor (for the node support) */
  private double     norm;
  /** the colors for the classes (decision tree) */
  private Color[]    colors;
  /** the range of the prediction values (regression tree) */
  private double[]   range;
  /** the domain scaling parameters (regression tree) */
  private double     off, scl;
  /** the popup menu for folding a node/subtree */
  private JPopupMenu mfold = null;
  /** the popup menu for unfolding a node/subtree */
  private JPopupMenu munfo = null;

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree panel.
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTPanel ()
  {                             /* --- create a decision tree panel */
    this.dtree  = null;         /* there is no decision tree yet */
    this.mode   = DTree.VERTICAL|DTree.CENTER;
    this.width  = 96;           /* set default layout parameters */
    this.height = 48;
    this.horz   =  8;
    this.vert   = 18;
    this.shadow =  4;
    this.frame  =  8;
    this.thick  =  1;
    this.direct = true;
    this.aaedge = false;
    this.aatext = false;
    this.ptsize = 12;
    this.font   = new Font("SansSerif", Font.BOLD, this.ptsize);
  }  /* DTPanel() */

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree panel.
   *  @param  dtree the decision tree to display
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTPanel (DTree dtree)
  { this(); this.setDTree(dtree); }

  /*------------------------------------------------------------------*/
  /** Get the decision/regression tree to display.
   *  @return the currently displayed decision/regression tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTree getDTree ()
  { return this.dtree; }

  /*------------------------------------------------------------------*/
  /** Set the decision/regression tree to display.
   *  @param  dtree the decision/regression tree to display
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDTree (DTree dtree)
  {                             /* --- set a new decision tree */
    this.dtree = dtree;         /* store the new decision tree */
    this.type  = dtree.getTargetType();
    if (!(this.type instanceof NominalType))
      this.range = dtree.getRange();
    int n = dtree.clscnt;       /* create the color array */
    this.colors = new Color[(n > 0) ? n : 1];
    this.updateColors();        /* update the target colors */
    this.doLayout();            /* lay out the decision tree */
  }  /* setDTree() */

  /*------------------------------------------------------------------*/
  /** Update the color(s) for the target values.
   *  @since  2007.02.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void updateColors ()
  {                             /* --- update the target colors */
    int     i, n;               /* loop variables */
    ColType t;                  /* target type of the tree */
    Color   c;                  /* to traverse the colors */

    t = dtree.getTargetType();  /* if decision tree */
    if (t instanceof NominalType) {
      n = ((NominalType)t).getValueCount();
      for (i = 0; i < n; i++) { /* traverse the classes */
        c = (Color)((NominalType)t).getInfo(i);
        if (c == null) c = Color.getHSBColor(i/(float)n, 1, 1);
        this.colors[i] = c;     /* get stored orcreate default color */
      } }                       /* and store it for the class */
    else {                      /* if regression tree */
      c = (Color)dtree.getTarget().getInfo(0);
      if (c == null) c = new Color(0.65F, 0.60F, 1.00F);
      this.colors[0] = c;       /* get stored orcreate default color */
    }                           /* and store it for the deviation */
  }  /* updateColors() */

  /*------------------------------------------------------------------*/
  /** Set the layout mode (horizontal vs. vertical etc).
   *  @param  mode the layout mode
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMode (int mode)
  { this.mode = mode; }         /* --- set the layout mode */

  /*------------------------------------------------------------------*/
  /** Set the thickness of the connecting lines (in pixels).
   *  @param  thick the line thickness (in pixels)
   *  @since  2015.12.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setEdges (int thick)
  { this.setEdges(thick, true); }

  /*------------------------------------------------------------------*/
  /** Set the thickness of the connecting lines (in pixels).
   *  @param  thick the line thickness (in pixels)
   *  @param  antia whether to apply anti-aliasing to the edges
   *  @since  2015.12.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setEdges (int thick, boolean antia)
  { this.thick = thick; this.aaedge = antia; }

  /*------------------------------------------------------------------*/
  /** Set the edge drawing mode.
   *  @param  d whether to draw edges directly
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDirect (boolean d)
  { this.direct = d; }          /* --- set edge drawing mode */

  /*------------------------------------------------------------------*/
  /** Set the layout parameters.
   *  @param  width  the width  of a node
   *  @param  height the height of a node
   *  @param  horz   the horizontal distance between nodes
   *  @param  vert   the vertical   distance between nodes
   *  @param  shadow the width of the node shadow
   *  @param  frame  the width of the frame around the tree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setParams (int width, int height, int horz, int vert,
                         int shadow, int frame)
  {                             /* --- set layout parameters */
    this.width  = (width  > 16) ? width  : 16;  /* store the */
    this.height = (height > 24) ? height : 24;  /* layout parameters */
    this.horz   = (horz   >  2) ? horz   :  2;
    this.vert   = (vert   >  2) ? vert   :  2;
    this.shadow = (shadow >  0) ? shadow :  0;
    this.frame  = (frame  >  0) ? frame  :  0;
    int t = 2 *(int)(1.24*this.ptsize +0.5);
    if (this.height < t) this.height = t;
  }  /* setParams() */

  /*------------------------------------------------------------------*/
  /** Set the font for the node labels.
   *  @param  font the font for the node labels
   *  @since  2004.05.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFont (Font font)
  { this.setFont(font, false); }

  /*------------------------------------------------------------------*/
  /** Set the font for the node labels.
   *  @param  font  the font for the node labels
   *  @param  antia whether to apply anti-aliasing to the labels
   *  @since  2004.05.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFont (Font font, boolean antia)
  {                             /* --- set the font for the labels */
    this.ptsize = font.getSize();
    int t = 2 *(int)(1.24*this.ptsize +0.5);
    if (this.height < t) this.height = t;
    this.font   = font;         /* set the font and adapt */
    this.aatext = antia;        /* the node height if necessary */
  }  /* setFont() */

  /*------------------------------------------------------------------*/
  /** Lay out the subtree, that is, compute node positions.
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void doLayout ()
  {                             /* --- lay out the decision tree */
    Dimension d;                /* extension of the tree */

    if (dtree == null)          /* if no tree, set default size */
      this.setPreferredSize(new Dimension(640, 400));
    else {                      /* if a new tree was set, do layout */
      d = dtree.layout(this.mode, this.frame, this.frame,
                       this.width +this.horz, this.height +this.vert);
      d.width  += this.shadow +this.frame +1 -this.horz;
      d.height += this.shadow +this.frame +1 -this.vert;
      this.setPreferredSize(d); /* adapt the panel size */
    }
    this.revalidate();          /* adapt the enclosing scroll pane */
    this.repaint();             /* and redraw the decision tree */
  }  /* doLayout() */

  /*------------------------------------------------------------------*/
  /** Fold/unfold all nodes of the decision/regression tree.
   *  @param  f whether to fold all nodes
   *  @since  2004.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void fold (boolean f)
  {                             /* --- (un)fold all nodes of the tree */
    if (this.dtree == null) return;
    this.dtree.fold(f);         /* fold/unfold the decision tree */
    this.doLayout();            /* and do a re-layout */
  }  /* fold() */

  /*------------------------------------------------------------------*/
  /** Repaint shadows of a subtree of the decision/regression tree.
   *  @param  g    the graphics to use for painting
   *  @param  node the root node of the subtree to paint
   *  @since  2015.12.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void shadows (Graphics g, DTNode node)
  {                             /* --- (re)paint the decision tree */
    int    i;                   /* loop variable */
    int    beg, end, delta;     /* for child node traversal */
    DTNode child;               /* to traverse the child nodes */

    g.setColor(Color.darkGray); /* draw a shadow in dark gray */
    g.fillRect(node.getX() +this.shadow,
               node.getY() +this.shadow, this.width+1, this.height+1);
    if (node.isLeaf() || node.isFolded())
      return;                   /* end at leaves and folded nodes */
    if ((this.mode & DTree.REVERSE) != 0) {
      beg = node.getChildCount()-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = node.getChildCount();    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = node.getChild(i); /* traverse the children */
      if (child != null) this.shadows(g, child);
    }                           /* draw the subtree recursively */
  }  /* shadows() */

  /*------------------------------------------------------------------*/
  /** Repaint edges of a subtree of the decision/regression tree.
   *  @param  g    the graphics to use for painting
   *  @param  node the root node of the subtree to paint
   *  @since  2015.12.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void edges (Graphics g, DTNode node)
  {                             /* --- (re)paint the decision tree */
    int    i;                   /* loop variable, number of classes */
    int    beg, end, delta;     /* for child node traversal */
    int    x, y, z;             /* screen coordinates of current node */
    int    cx, cy;              /* screen coordinates of child node */
    DTNode child;               /* to traverse the child nodes */

    if (node.isLeaf() || node.isFolded())
      return;                   /* end at leaves and folded nodes */
    x = node.getX();            /* get the location */
    y = node.getY();            /* of the current node */
    if ((this.mode & DTree.HORIZONTAL) != 0) {
      x += this.width +1-this.thick/2; y += this.height/2; }
    else {                      /* compute connector point */
      y += this.height+1-this.thick/2; x += this.width /2; }
    if ((this.mode & DTree.REVERSE) != 0) {
      beg = node.getChildCount()-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = node.getChildCount();    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = node.getChild(i); /* traverse the children */
      if (child == null) continue;
      cx = child.getX();        /* get the location */
      cy = child.getY();        /* of the child node */
      if ((this.mode & DTree.HORIZONTAL) != 0) {
        cx += this.thick/2-1; cy += this.height/2; }
      else {                    /* compute connector point */
        cy += this.thick/2-1; cx += this.width /2; }
      g.setColor(Color.black);  /* set the line color */
      if (this.direct)          /* if direct edge connections */
        g.drawLine(x, y, cx, cy);
      else if ((this.mode & DTree.HORIZONTAL) != 0) {
        z = (x +cx) /2;         /* if horizontal layout */
        g.drawLine(x, y,  z,  y);
        g.drawLine(z, y,  z,  cy);
        g.drawLine(z, cy, cx, cy); }
      else {                    /* draw an s-shaped edge */
        z = (y +cy) /2;         /* if vertical layout */
        g.drawLine(x,  y, x,  z);
        g.drawLine(x,  z, cx, z);
        g.drawLine(cx, z, cx, cy);
      }                         /* draw an s-shaped edge */
      this.edges(g, child);     /* draw the subtree */
    }                           /* recursively */
  }  /* edges() */

  /*------------------------------------------------------------------*/
  /** Repaint the nodes of a subtree of the decision/regression tree.
   *  @param  g    the graphics to use for painting
   *  @param  node the root node of the subtree to paint
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void nodes (Graphics g, DTNode node)
  {                             /* --- (re)paint the decision tree */
    int    i, n;                /* loop variable, number of classes */
    int    beg, end, delta;     /* for child node traversal */
    int    x, y;                /* screen coordinates of current node */
    int    cx, cy;              /* screen coordinates of child node */
    int    v, w, h, t, o;       /* widths and height of bars */
    DTNode child;               /* to traverse the child nodes */
    double p, d;                /* probability/prediction and dev. */
    String s;                   /* buffer for label */
    Shape  clip;                /* buffer for clipping shape */

    /* --- draw node --- */
    x = node.getX();            /* get the location */
    y = node.getY();            /* of the current node */
    g.setColor(bkgnd);          /* draw background in light gray */
    g.fillRect(x+1, y+1, this.width-1, this.height-1);
    h = (int)(1.24*this.ptsize +0.5); /* compute label height */
    t = this.height -2 *h -1;   /* compute the bar height and */
    if (t > 0) {                /* if to show the distribution */
      if (t <= 8) o = 1;        /* if there is not enough space */
      else {                    /* do not draw a support bar */
        g.setColor(Color.black);
        o = t/4; if (o < 4) o = 4;
        v = y +h +o +1;         /* separate support bar */
        g.drawLine(x, v, x +this.width, v);
        if (!node.isRoot()) {   /* if this is not the root */
          w = (int)(node.getFreq() /node.getParent().getFreq()
                    *(this.width-1) +0.5);
          g.setColor(rsupp);
          g.fillRect(x +1, y +h +1, w, o);
        }                       /* draw relative support bar */
        w = (int)(node.getFreq() *this.norm +0.5);
        g.setColor(Color.darkGray);
        g.fillRect(x +1, y +h +1, w, o);
        t -= o+1; o += 2;       /* draw absolute support bar */
      }                         /* indicating the fraction of cases */
      if (this.type instanceof NominalType) {   /* if decision tree */
        n = this.dtree.clscnt;  /* get the number of classes */
        for (p = 0, i = v = 0; i < n; i++) {
          p += node.getProb(i); /* traverse the classes */
          w  = (int)(p *(this.width-1) +0.5);
          if (w <= v) continue; /* compute the width of the bar */
          g.setColor(this.colors[i]);
          g.fillRect(x +v +1, y +h +o, w -v, t);
          v = w;                /* draw a color bar for the class */
        } }                     /* and go to the next coordinate */
      else {                    /* if regression tree */
        p = node.getPred();     /* get the prediction value */
        d = node.getDev();      /* and its deviation */
        v = (int)((p -d -this.off) *this.scl +0.5);
        w = (int)((p +d -this.off) *this.scl +0.5);
        o += y +h;                  /* compute the borders */
        g.setColor(this.colors[0]); /* of the sigma interval */
        g.fillRect(x +v, o, w -v +1, t);
        g.setColor(Color.black);/* compute the center */
        v = (int)((p -this.off) *this.scl +0.5);
        g.drawLine(x +v, o, x +v, o +t);
      }                         /* draw a red bar for the range and */
    }                           /* a black bar for the prediction */

    /* --- draw node outline and print labels --- */
    g.setColor(Color.black);    /* outline the current node */
    g.drawRect(x, y, this.width, this.height);
    w = x +this.width; v = y +h;
    g.drawLine(x, v, w, v);     /* separate upper label field */
    v = y +this.height -h;
    g.drawLine(x, v, w, v);     /* separate lower label field */
    clip = g.getClip();         /* note current clipping region */
    g.clipRect(x+1, y+1, this.width-1, h-1);
    s = (node.isRoot()) ? this.dtree.getTarget().getName()
                        : node.getValue();
    g.drawString(s, x+2, y+this.ptsize);
    g.setClip(clip);            /* restore the clipping region */
    g.clipRect(x+1, v+1, this.width-1, h-1);
    if (node.isLeaf()           /* if this is a leaf */
    ||  node.isFolded()) {      /* or a folded inner node */
      if (!(this.type instanceof NominalType))
           s = String.valueOf(node.getPred());
      else s = ((NominalType)this.type).getValue(
                 node.getBest()).toString();
      if (!node.isLeaf()) {     /* mark folded nodes */
        g.setColor(Color.gray); s = "(" +s +")"; }
      g.drawString(s, x+2, v+this.ptsize); }
    else {                      /* if this is an inner node */
      s = node.getAtt().getName();
      g.drawString(s, x+2, v+this.ptsize);
    }                           /* print the decision attribute */
    g.setClip(clip);            /* restore the clipping region */

    /* --- recursively process children --- */
    if (node.isLeaf() || node.isFolded())
      return;                   /* end at leaves and folded nodes */
    if ((this.mode & DTree.REVERSE) != 0) {
      beg = node.getChildCount()-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = node.getChildCount();    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = node.getChild(i); /* traverse the children */
      if (child != null) this.nodes(g, child);
    }                           /* draw the subtree recursively */
  }  /* nodes() */

  /*------------------------------------------------------------------*/
  /** Repaint the whole panel.
   *  @param  g the graphics to use for painting
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void paint (Graphics g)
  {                             /* --- (re)paint the whole panel */
    Graphics2D g2;              /* for setting drawing parameters */
    Dimension  d;               /* (preferred) size of panel */
    int        w, h;            /* size of background rectangle */
    double     t;               /* temporary buffer */
    Object     v;               /* value for anti-aliasing */

    super.paint(g);             /* ensure proper rendering queue */
    d = this.getSize();         /* get the (preferred) panel size */
    w = d.width; h = d.height;  /* (whichever is larger) */
    d = this.getPreferredSize();
    if (d.width  > w) w = d.width;
    if (d.height > h) h = d.height;
    g.setColor(Color.white);    /* set the background color */
    g.fillRect(0, 0, w, h);     /* and draw the background */
    if (this.dtree == null)     /* if there is no tree, */
      return;                   /* abort the function */
    if (!(this.type instanceof NominalType)) {
      t = this.range[1] -this.range[0];   /* if regression tree, */
      this.off = this.range[0] -0.02F *t; /* compute the scaling */
      this.scl = (this.width-1) /(1.04F *t);
    }                           /* compute scaling for reg. tree */
    this.norm = (this.width-1)/this.dtree.getRoot().getFreq();
    g.setFont(this.font);       /* draw the decision/regression tree */
    if (this.shadow > 0)        /* draw the node shadows */
      this.shadows(g, this.dtree.getRoot());
    g2 = (Graphics2D)g;         /* set width of connecting lines */
    g2.setStroke(new BasicStroke(this.thick));
    v = (this.aaedge) ? RenderingHints.VALUE_ANTIALIAS_ON
                      : RenderingHints.VALUE_ANTIALIAS_OFF;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, v);
    this.edges(g, this.dtree.getRoot());
    g2.setStroke(new BasicStroke(1));
    v = (this.aatext) ? RenderingHints.VALUE_ANTIALIAS_ON
                      : RenderingHints.VALUE_ANTIALIAS_OFF;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, v);
    this.nodes(g, this.dtree.getRoot());
  }  /* paint() */

  /*------------------------------------------------------------------*/
  /** Create an image of the panel contents.
   *  @return an image of the panel contents
   *  @since  2004.09.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public BufferedImage makeImage ()
  {                             /* --- create an image of contents */
    BufferedImage img;          /* created image */
    Dimension     d;            /* size of panel */

    d   = this.getPreferredSize();
    img = new BufferedImage(d.width, d.height,
                            BufferedImage.TYPE_INT_ARGB);
    this.paint(img.getGraphics());
    return img;                 /* draw window contents to image */
  }  /* BufferedImage() */      /* and return the image */

  /*------------------------------------------------------------------*/
  /** Show detailed information about a decision tree node.
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void showDetails ()
  {                             /* --- show detailed node info. */
    DTInfo dti = new DTInfo((JFrame)SwingUtilities.getRoot(this));
    dti.setNode(this.node, this.colors);
    dti.setVisible(true);       /* set the current node */
  }  /* showDetails() */        /* and show the dialog */

  /*------------------------------------------------------------------*/
  /** Get the popup menu for folding a node/subtree.
   *  @return the popup menu for folding a node/subtree.
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JPopupMenu getFoldMenu ()
  {                             /* --- create popup for folding */
    JMenuItem item;             /* to create menu items */

    if (this.mfold != null)     /* if the popup menu already exist, */
      return this.mfold;        /* simply return it */
    this.mfold = new JPopupMenu();
    item = this.mfold.add(new JMenuItem("Details ..."));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.mfold.setVisible(false);
        DTPanel.this.showDetails();
      } });
    item = this.mfold.add(new JMenuItem("Fold Node"));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.mfold.setVisible(false);
        DTPanel.this.node.fold(true, false);
        DTPanel.this.doLayout();
      } });
    item = mfold.add(new JMenuItem("Fold Subtree"));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.mfold.setVisible(false);
        DTPanel.this.node.fold(true, true);
        DTPanel.this.doLayout();
      } });
    item = mfold.add(new JMenuItem("Prune Subtree"));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.mfold.setVisible(false);
        DTPanel.this.node.prune();
        DTPanel.this.doLayout();
      } });
    this.mfold.pack();          /* create popup menu for folding */
    return this.mfold;          /* and return it */
  }  /* getFoldMenu() */

  /*------------------------------------------------------------------*/
  /** Get the popup menu for unfolding a node/subtree.
   *  @return the popup menu for unfolding a node/subtree.
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JPopupMenu getUnfoldMenu ()
  {                             /* --- create popup for folding */
    JMenuItem item;             /* to create menu items */

    if (this.munfo != null)     /* if the popup menu already exist, */
      return this.munfo;        /* simply return it */
    this.munfo = new JPopupMenu();
    item = this.munfo.add(new JMenuItem("Details ..."));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.munfo.setVisible(false);
        DTPanel.this.showDetails();
      } });
    item = this.munfo.add(new JMenuItem("Unfold Node"));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.munfo.setVisible(false);
        DTPanel.this.node.fold(false, false);
        DTPanel.this.doLayout();
      } });
    item = munfo.add(new JMenuItem("Unfold Subtree"));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.munfo.setVisible(false);
        DTPanel.this.node.fold(false, true);
        DTPanel.this.doLayout();
      } });
    item = munfo.add(new JMenuItem("Prune Subtree"));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DTPanel.this.munfo.setVisible(false);
        DTPanel.this.node.prune();
        DTPanel.this.doLayout();
      } });
    this.munfo.pack();          /* create popup menu for unfolding */
    return this.munfo;          /* and return it */
  }  /* getUnfoldMenu() */

  /*------------------------------------------------------------------*/
  /** Handle folding/unfolding of nodes with the mouse.
   *  @param  e the event to process
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mousePressed (MouseEvent e)
  {                              /* --- handle folding/unfolding */
    int        x, y, dx, dy;     /* node coordinates and differences */
    DTNode     curr;             /* to access the node to change */
    JPopupMenu menu;             /* popup menu to show */
    int        i;                /* loop variable for menu items */
    Component  c, d;             /* to traverse the menu items */
    boolean    leaf;             /* flag for a leaf node */

    if (this.dtree == null) return;
    x = e.getX(); y = e.getY();  /* get the mouse position and */
    curr = this.dtree.find(x,y); /* find the node to change */
    if (curr == null) return;    /* if no node found, abort */
    dx = x -curr.getX();         /* compute the position relative */
    dy = y -curr.getY();         /* to the node position */
    if ((dx < 0) || (dx > this.width)
    ||  (dy < 0) || (dy > this.height))
      return;                    /* check whether the node was hit */
    if      (e.getModifiersEx() == InputEvent.BUTTON1_DOWN_MASK) {
      curr.fold(!curr.isFolded(), false);
      this.doLayout(); }         /* change fold state and re-layout */
    else if (e.getModifiersEx() == InputEvent.BUTTON3_DOWN_MASK) {
      this.node = curr;          /* store the current node */
      menu = (curr.isFolded()) ? this.getUnfoldMenu()
                               : this.getFoldMenu();
      leaf = curr.isLeaf();      /* check whether node is a leaf */
      d    = null;               /* clear buffer for first item */
      for (i = menu.getComponentCount(); --i >= 0; ) {
        c = menu.getComponent(i);/* traverse the menu items */
        if (!(c instanceof JMenuItem)) continue;
        d = c; c.setVisible(!leaf);
      }                          /* set menu items visible/invsible */
      if (d != null) d.setVisible(true);  /* set first item visible */
      menu.show(this, x, y);     /* show the popup menu */
    }                            /* corresponding to the node state */
  }  /* mousePressed() */

  /*------------------------------------------------------------------*/
  /** Needed for <code>MouseListener</code> interface.
   *  @param  e the event to process
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseReleased (MouseEvent e)
  { }

  /*------------------------------------------------------------------*/
  /** Needed for <code>MouseListener</code> interface.
   *  @param  e the event to process
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseClicked (MouseEvent e)
  { }

  /*------------------------------------------------------------------*/
  /** Needed for <code>MouseListener</code> interface.
   *  @param  e the event to process
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseEntered (MouseEvent e)
  { }

  /*------------------------------------------------------------------*/
  /** Needed for <code>MouseListener</code> interface.
   *  @param  e the event to process
   *  @since  2004.05.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseExited (MouseEvent e)
  { }

}  /* class DTPanel */
