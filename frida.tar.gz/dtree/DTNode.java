/*----------------------------------------------------------------------
  File    : DNode.java
  Contents: decision tree node management for visualization
  Author  : Christian Borgelt
  History : 2004.05.10 file created as part of DTree.java
            2004.05.11 methods getChildCount, layout etc. added
            2004.05.16 full subtree folding/unfolding/pruning added
            2004.05.19 layout modes (horiz./vertical/center) added
            2004.05.23 regression tree representation added
            2006.05.13 class moved to a separate file
            2007.02.17 javadoc added, parsing moved to static function
            2013.04.22 adapted to class name change Type -> ColType
            2015.11.25 frequencies changed to double precision
            2015.12.02 node finding redesigned, compact layout added
            2016.04.07 StringBuffer replaced by StringBuilder
            2020.10.23 layout mode REVERSE added (reverse branch order)
----------------------------------------------------------------------*/
package dtree;

import java.io.IOException;

import util.Scanner;
import table.ColType;
import table.NominalType;
import table.Column;

/*--------------------------------------------------------------------*/
/** Class for a decision/regression tree node.
 *  @author Christian Borgelt
 *  @since  2004.05.10 */
/*--------------------------------------------------------------------*/
public class DTNode {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the containing decision tree */
  protected DTree    tree;
  /** the test attribute */
  protected Column   att;
  /** the cut value */
  protected double   cut;
  /** the class frequencies (decision tree) */
  protected double[] freqs;
  /** the total frequency (total number of cases) */
  protected double   sum;
  /** the best class (highest probability) */
  protected int      best;
  /** the prediction value (regression tree) */
  protected double   pred;
  /** the deviation of the prediction value (regression tree) */
  protected double   dev;
  /** the vector of children */
  protected DTNode[] children;
  /** the parent node */
  protected DTNode   parent;
  /** parent attribute value id */
  protected int      valid;
  /** the set of attribute values */
  protected String   set;
  /** the left   border of the node cell */
  protected int      lft;
  /** the right  border of the node cell */
  protected int      rgt;
  /** the top    border of the node cell */
  protected int      top;
  /** the bottom border of the node cell */
  protected int      bot;
  /** the left   border of the subtree */
  protected int      tlft;
  /** the right  border of the subtree */
  protected int      trgt;
  /** the top    border of the subtree */
  protected int      ttop;
  /** the bottom border of the subtree */
  protected int      tbot;
  /** whether subtree is folded */
  protected boolean  folded;

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree node.
   *  @param  tree the corresponding decision/regression tree
   *  @param  att  the test attribute of the node
   *  @param  cut  the cut value of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode (DTree tree, Column att, double cut)
  {                             /* --- create a decision tree node */
    this.tree  = tree;          /* note the containing tree, */
    this.att   = att;           /* the test attribute and */
    this.cut   = cut;           /* a possible cut value */
    this.freqs = (tree.clscnt > 0) ? new double[tree.clscnt] : null;
    this.sum   = 0;             /* initialize the support */
    this.pred  = this.dev = 0;  /* and the prediction value */
    if (att == tree.target)     /* if this is a leaf node, */
      this.children = null;     /* it has no children */
    else {                      /* if this is an inner node, */
      ColType t = att.getType();/* get the test attribute type */
      this.children = new DTNode[(t instanceof NominalType)
                               ? ((NominalType)t).getValueCount() : 2];
    }                           /* create an array of children */
    this.parent = null;         /* init. the parent reference */
    this.set    = null;         /* and the other variables */
    this.valid  = -1;
    this.lft  = this.rgt  = 0;  /* init. the node cell extensions */
    this.top  = this.bot  = 0;  /* (horizontally and vertically) */
    this.tlft = this.trgt = 0;  /* init. the subtree extensions */
    this.ttop = this.tbot = 0;  /* (horizontally and vertically) */
    this.folded = false;        /* init. the "folded" flag */
  }  /* DTNode() */

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree node.
   *  @param  tree the corresponding decision/regression tree
   *  @param  att  the test attribute of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode (DTree tree, Column att)
  { this(tree, att, 0.0); }

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree node.
   *  @param  tree the corresponding decision/regression tree
   *  @param  name the name of the test attribute of the node
   *  @since  2007.02.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode (DTree tree, String name)
  { this(tree, tree.atts.getColumn(name), 0.0); }

  /*------------------------------------------------------------------*/
  /** Create a decision/regression tree leaf.
   *  @param  tree the corresponding decision/regression tree
   *  @since  2007.02.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode (DTree tree)
  { this(tree, tree.target, 0.0); }

  /*------------------------------------------------------------------*/
  /** Get the containing decision tree.
   *  @return the containing decision tree
   *  @since  2015.11.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTree getDTree ()
  { return this.tree; }

  /*------------------------------------------------------------------*/
  /** Check whether the node is a root node.
   *  @return whether the node is a root node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isRoot ()
  { return this.parent == null; }

  /*------------------------------------------------------------------*/
  /** Check whether the node is a leaf node.
   *  @return whether the node is a leaf node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isLeaf ()
  { return this.children == null; }

  /*------------------------------------------------------------------*/
  /** Get the value id associated with the edge to the node.
   *  @return the value id associated with the edge to the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getValueId ()
  { return this.valid; }

  /*------------------------------------------------------------------*/
  /** Get the value associated with the edge to the node.
   *  @return the value associated with the edge to the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getValue ()
  {                             /* --- return branch value in parent */
    ColType type;               /* the type of the parent attribute */

    if (this.valid < 0) return null;
    type = this.parent.att.getType();
    if (!(type instanceof NominalType))
      return ((this.valid <= 0) ? "<" : ">")
           + String.valueOf(this.parent.cut);
    if (this.set != null) return this.set;
    return ((NominalType)type).getValue(this.valid).toString();
  }  /* getValue() */

  /*------------------------------------------------------------------*/
  /** Get the test attribute of the node.
   *  @return the test attribute of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column getAtt ()
  { return this.att; }

  /*------------------------------------------------------------------*/
  /** Get the name of the test attribute of the node.
   *  @return the name of the test attribute of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getAttName ()
  { return this.att.getName(); }

  /*------------------------------------------------------------------*/
  /** Get the cut value of the node.
   *  @return the cut value of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getCut ()
  { return this.cut; }

  /*------------------------------------------------------------------*/
  /** Get the number of class frequencies.
   *  @return the number of class frequencies
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getFreqCount ()
  { return (this.freqs != null) ? this.freqs.length : 0; }

  /*------------------------------------------------------------------*/
  /** Get the total of the class frequencies.
   *  @return the total of the class frequencies
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getFreq ()
  { return this.sum; }

  /*------------------------------------------------------------------*/
  /** Get the frequency of a given class.
   *  @param  id the id of the class
   *  @return the frequency of the given class
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getFreq (int id)
  { return this.freqs[id]; }

  /*------------------------------------------------------------------*/
  /** Get the number of class probabilities.
   *  @return the number of class probabilities
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getProbCount ()
  { return (this.freqs != null) ? this.freqs.length : 0; }

  /*------------------------------------------------------------------*/
  /** Get the probability of a given class.
   *  @param  id the id of the class
   *  @return the probability of the given class
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getProb (int id)
  { return this.freqs[id] /this.sum; }

  /*------------------------------------------------------------------*/
  /** Get the best class of the node.
   *  @return the id of the best class
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getBest ()
  { return this.best; }

  /*------------------------------------------------------------------*/
  /** Get the prediction value of the node.
   *  @return the prediction value of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getPred()
  { return this.pred; }

  /*------------------------------------------------------------------*/
  /** Get the deviation of the prediction value of the node.
   *  @return the deviation of the prediction value of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getDev ()
  { return this.dev; }

  /*------------------------------------------------------------------*/
  /** Get the parent of the node.
   *  @return the parent of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode getParent ()
  { return this.parent; }

  /*------------------------------------------------------------------*/
  /** Get the number of children of the node.
   *  @return the number of children of the node
   *  @since  2004.05.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getChildCount ()
  { return this.children.length; }

  /*------------------------------------------------------------------*/
  /** Get a child of the node.
   *  @param  id the id of the child node
   *  @return the child with the given id
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTNode getChild (int id)
  { return this.children[id]; }

  /*------------------------------------------------------------------*/
  /** Add a child node.
   *  @param  id    the id of the child node
   *  @param  child the child node to add
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addChild (int id, DTNode child)
  {                             /* --- add a child node */
    this.children[id] = child;  /* store the child node */
    child.parent = this;        /* set the child's parent pointer */
    child.valid  = id;          /* and its attribute value id */
  }  /* addChild() */

  /*------------------------------------------------------------------*/
  /** Add a child node.
   *  @param  value the value associated with the edge to the child
   *  @param  child the child node to add
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addChild (String value, DTNode child)
  {                             /* --- add a child node */
    int i = ((NominalType)this.att.getType()).getValueId(value);
    this.addChild(i, child);    /* get value id and add child */
  }  /* addChild() */

  /*------------------------------------------------------------------*/
  /** Get the x-coordinate of the node.
   *  @return the x-coordinate of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getX ()
  { return this.lft; }

  /*------------------------------------------------------------------*/
  /** Get the y-coordinate of the node.
   *  @return the y-coordinate of the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getY ()
  { return this.top; }

  /*------------------------------------------------------------------*/
  /** Check whether the subtree rooted at the node is folded.
   *  @return whether the subtree rooted at the node is folded
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isFolded ()
  { return this.folded; }

  /*------------------------------------------------------------------*/
  /** Fold/unfold the subtree rooted at the node.
   *  @param  f   whether to fold the subtree
   *  @param  all whether to fold/unfold all descendants recursively
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void fold (boolean f, boolean all)
  {                             /* --- (un)fold all nodes of subtree */
    int    i;                   /* loop variable */
    DTNode child;               /* to traverse the children */

    this.folded = f;            /* set/clear the "folded" flag */
    if (!all                    /* if not to fold all */
    || (this.children == null)) /* or this is a leaf node, */
      return;                   /* terminate the recursion */
    for (i = this.children.length; --i >= 0; ) {
      child = this.children[i]; /* traverse the children */
      if (child != null) child.fold(f, true);
    }                           /* recursively fold the children */
  }  /* fold() */

  /*------------------------------------------------------------------*/
  /** Prune the subtree rooted at the node, that is,
   *  replace it with a leaf.
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void prune ()
  {                             /* --- turn subtree into a leaf */
    int    i;                   /* loop variable */
    DTNode node;                /* leaf to get target attribute from */

    if (this.isLeaf()) return;  /* if it is a leaf, do nothing */
    for (node = this; !node.isLeaf(); ) {
      for (i = node.children.length; --i >= 0; )
        if (node.children[i] != null) break;
      node = node.children[i];  /* go down in the decision tree */
    }                           /* and find a leaf node */
    this.att = node.att;        /* get the target attribute */
    this.children = null;       /* and remove all child nodes */
  }  /* prune() */

  /*------------------------------------------------------------------*/
  /** Get the height of the subtree rooted at the node.
   *  @return the height of the subtree rooted at the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int getHeight ()
  {                             /* --- determine the node height */
    int    i, t, max = 0;       /* loop variables, height buffers */
    DTNode child;               /* to traverse the children */

    if (this.children == null)  /* if this is a leaf node, */
      return 1;                 /* terminate the recursion */
    for (i = this.children.length; --i >= 0; ) {
      child = this.children[i]; /* traverse the children */
      if (child == null) continue;
      t = child.getHeight();    /* determine the child's height */
      if (t > max) max = t;     /* recursively and take the */
    }                           /* maximum over all children */
    return max +1;              /* return the node height */
  }  /* getHeight() */

  /*------------------------------------------------------------------*/
  /** Get the width of the subtree rooted at the node
   *  (total number of leaves in the subtree).
   *  @return the width of the subtree rooted at the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int getWidth ()
  {                             /* --- determine the node width */
    int    i, s = 0;            /* loop variables, sum of nodes */
    DTNode child;               /* to traverse the children */

    if (this.children == null)  /* if this is a leaf node, */
      return 1;                 /* terminate the recursion */
    for (i = this.children.length; --i >= 0; ) {
      child = this.children[i]; /* traverse the children */
      if (child != null) s += child.getWidth();
    }                           /* sum width over all children */
    return s;                   /* return the node width */
  }  /* getWidth() */

  /*------------------------------------------------------------------*/
  /** Get the size of the subtree rooted at the node.
   *  <p>The size of a tree/subtree is its number of nodes.</p>
   *  @return the size of the subtree rooted at the node
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int getSize ()
  {                             /* --- count the nodes in the subtree */
    int    i, s = 0;            /* loop variables, number of leaves */
    DTNode child;               /* to traverse the children */

    if (this.children == null)  /* if this is a leaf node, */
      return 1;                 /* terminate the recursion */
    for (i = this.children.length; --i >= 0; ) {
      child = this.children[i]; /* traverse the children */
      if (child != null) s += child.getSize();
    }                           /* sum sizes over all children */
    return s +1;                /* return the number of nodes */
  }  /* getSize() */

  /*------------------------------------------------------------------*/
  /** Get the range of prediction values in the subtree.
   *  @param  range the range of prediction values in the subtree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void getRange (double[] range)
  {                             /* --- get prediction range */
    int    i;                   /* loop variable */
    DTNode child;               /* to traverse the children */
    double t;                   /* temporary buffer */

    t = this.pred -this.dev;    /* adapt lower bound if necessary */
    if (t < range[0]) range[0] = t;
    t = this.pred +this.dev;    /* adapt upper bound if necessary */
    if (t > range[1]) range[1] = t;
    if (this.children == null)  /* if this is a leaf node, */
      return;                   /* terminate the recursion */
    for (i = this.children.length; --i >= 0; ) {
      child = this.children[i]; /* traverse the children */
      if (child != null) child.getRange(range);
    }                           /* process children recursively */
  }  /* getRange() */

  /*------------------------------------------------------------------*/
  /** Do a vertical layout of the subtree.
   *  @param  mode layout mode (center, reverse etc.)
   *  @param  x    the x-coordinate of the upper left corner
   *  @param  y    the y-coordinate of the upper left corner
   *  @param  w    the width  of a cell for a node
   *  @param  h    the height of a cell for a node
   *  @return the right border of the rectangle used
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int layoutVert (int mode, int x, int y, int w, int h)
  {                             /* --- lay out a subtree vertically */
    int    i;                   /* loop variable */
    int    beg, end, delta;     /* for child node traversal */
    int    l, r;                /* left and right border of subtree */
    DTNode child;               /* to traverse the children */

    this.lft = this.tlft = x;   /* store the coordinates */
    this.top = this.ttop = y;   /* of the top left corner */
    y += h;                     /* compute y-coord. for child level */
    if ((this.children == null) /* if this is a leaf node */
    ||   this.folded) {         /* or the subtree is folded */
      this.rgt = this.trgt = x+w;
      this.bot = this.tbot = y; /* store the bottom right corner */
      return this.trgt;         /* return the right border */
    }
    l = r = 0; this.tbot = y;   /* init. first and last coordinate */
    if ((mode & DTree.REVERSE) != 0) {
      beg = this.children.length-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = this.children.length;    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = this.children[i]; /* traverse the child nodes */
      if (child == null) continue;
      x = child.layoutVert(mode, x, y, w, h);
      r = child.lft;            /* do subtree layout and note the */
      if (l <= 0) l = r;        /* x-coords. of first and last child */
      if (child.tbot > this.tbot) this.tbot = child.tbot;
    }                           /* update the bottom border */
    if ((mode & DTree.CENTER) != 0) /* if to center the parent, */
      this.lft = (l+r)/2;       /* adapt the x-coordinate */
    this.rgt = this.lft +w;     /* set bottom right corner */
    this.bot = this.top +h;     /* of the node cell */
    return this.trgt = x;       /* return right border of subtree */
  }  /* layoutVert() */

  /*------------------------------------------------------------------*/
  /** Do a compact vertical layout of the subtree (pass 1).
   *  @param  mode layout mode (center, reverse etc.)
   *  @param  n    the (potentially remaining) depth of the subtree
   *  @param  w    the width of a cell for a node
   *  @param  lft  the left  border of the subtree (to be filled)
   *  @param  rgt  the right border of the subtree (to be filled)
   *  @return the number of (valid) entries in the border arrays
   *  @since  2015.12.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int cloVert1 (int mode, int n, int w,
                          int[] lft, int[] rgt)
  {                             /* --- compact vertical layout */
    int    i, k, m;             /* loop variables */
    int    beg, end, delta;     /* for child node traversal */
    DTNode child;               /* to traverse the children */
    int    d, e;                /* number of entries in shape arrays */
    int    x, s;                /* coordinate and shift value */
    int    l, r;                /* coords. of left and right child */
    int[]  clft, crgt;          /* left and right border of child */

    this.rgt = 0;               /* clear the horizontal shift value */
    if ((this.children == null) /* if this is a leaf node */
    ||   this.folded) {         /* or the subtree is folded */
      lft[0] = this.lft = 0;    /* init. left and right border */
      rgt[0] = w; return 1;     /* and subtree shape and return */
    }                           /* (terminate the recursion) */
    clft = new int[n];          /* init. child shape arrays */
    crgt = new int[n];          /* (left and right borders) and */
    l = r = d = 0;              /* coords. of first and last child */
    if ((mode & DTree.REVERSE) != 0) {
      beg = this.children.length-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = this.children.length;    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = this.children[i]; /* traverse the children */
      if (child == null) continue;
      m = child.cloVert1(mode, n-1, w, clft, crgt);
      e = (d <  m) ? d : m;     /* process subtree recursively */
      s = (d <= 0) ? 0 : -Integer.MAX_VALUE;
      for (k = 0; k < e; k++) { /* traverse right shape of subtree */
        x = rgt[k+1] -clft[k];  /* left shape of child subtree */
        if (x > s) s = x;       /* and find minimum shift value */
      }                         /* (relative position of sibling) */
      child.rgt = s;            /* note shift value in the child */
      r = clft[0]+s;            /* collect the x-coordinates */
      if (d <= 0) l = r;        /* of the first and last child */
      for (k = 0; k < m; k++) { /* traverse the child border */
        rgt[k+1] = crgt[k]+s; x = clft[k]+s;
        if ((k >= d) || (x < lft[k+1])) lft[k+1] = x;
      }                         /* adapt the subtree borders */
      if (m > d) d = m;         /* adapt the valid array section */
    }
    lft[0] = this.lft = ((mode & DTree.CENTER) != 0) ? (l+r)/2 : l;
    rgt[0] = lft[0] +w;         /* get coordinates of root node */
    return d+1;                 /* return number of valid entries */
  }  /* cloVert1() */

  /*------------------------------------------------------------------*/
  /** Do a compact vertical layout of the subtree (pass 2).
   *  @param  mode layout mode (center, reverse etc.)
   *  @param  x      the x-coordinate of the upper left corner
   *  @param  y      the y-coordinate of the upper left corner
   *  @param  w      the width  of a cell for a node
   *  @param  h      the height of a cell for a node
   *  @since  2015.12.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void cloVert2 (int mode, int x, int y, int w, int h)
  {                             /* --- compact vertical layout */
    int    i;                   /* loop variable */
    int    beg, end, delta;     /* for child node traversal */
    DTNode child;               /* to traverse the children */

    x += this.rgt;              /* add the horizontal shift value */
    this.tlft = this.lft += x;  /* adapt the horizontal position */
    this.ttop = this.top  = y;  /* and set the top left corner */
    y += h;                     /* compute y-coord. for child level */
    if ((this.children == null) /* if this is a leaf node */
    ||   this.folded) {         /* or the subtree is folded */
      this.trgt = this.rgt = this.lft+w;
      this.tbot = this.bot = y; /* store the bottom right corner */
      return;                   /* and terminate the recursion */
    }
    this.trgt = this.lft +w;    /* init. right and bottom borders */
    this.tbot = y;              /* of the subtree rectangle */
    if ((mode & DTree.REVERSE) != 0) {
      beg = this.children.length-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = this.children.length;    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = this.children[i]; /* traverse the child nodes */
      if (child == null) continue;
      child.cloVert2(mode, x, y, w, h);
      if (child.tlft < this.tlft) this.tlft = child.tlft;
      if (child.trgt > this.trgt) this.trgt = child.trgt;
      if (child.tbot > this.tbot) this.tbot = child.tbot;
    }                           /* update the bottom border */
    this.rgt = this.lft +w;     /* set bottom right corner */
    this.bot = this.top +h;     /* of the node cell */
  }  /* cloVert2() */

  /*------------------------------------------------------------------*/
  /** Do a horizontal layout of the subtree.
   *  @param  mode layout mode (center, reverse etc.)
   *  @param  x    the x-coordinate of the upper left corner
   *  @param  y    the y-coordinate of the upper left corner
   *  @param  w    the width  of a cell for a node
   *  @param  h    the height of a cell for a node
   *  @return the bottom border of the rectangle used
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int layoutHorz (int mode, int x, int y, int w, int h)
  {                             /* --- lay out a subtree horizontally */
    int    i;                   /* loop variable */
    int    beg, end, delta;     /* for child node traversal */
    int    t, b;                /* top and bottom border of subtree */
    DTNode child;               /* to traverse the children */

    this.lft = this.tlft = x;   /* store the coordinates */
    this.top = this.ttop = y;   /* of the top left corner */
    x += w;                     /* get x-coord. of child level */
    if ((this.children == null) /* if this is a leaf node */
    ||   this.folded) {         /* or the subtree is folded, */
      this.rgt = this.trgt = x; /* set the bottom right corner */
      this.bot = this.tbot = y+h;
      return this.tbot;         /* return the bottom border */
    }
    t = b = 0; this.trgt = x;   /* init. first and last coordinate */
    if ((mode & DTree.REVERSE) != 0) {
      beg = this.children.length-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = this.children.length;    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = this.children[i]; /* traverse the child nodes */
      if (child == null) continue;
      y = child.layoutHorz(mode, x, y, w, h);
      b = child.top;            /* do subtree layout and note the */
      if (t <= 0) t = b;        /* y-coords. of first and last child */
      if (child.trgt > this.trgt) this.trgt = child.trgt;
    }                           /* update the bottom border */
    if ((mode & DTree.CENTER) != 0) /* if to center the parent, */
      this.top = (t+b)/2;       /* adapt the y-coordinate */
    this.rgt = this.lft +w;     /* set bottom right corner */
    this.bot = this.top +h;     /* of the node cell */
    return this.tbot = y;       /* return bottom border of subtree */
  }  /* layoutHorz() */

  /*------------------------------------------------------------------*/
  /** Do a compact horizontal layout of the subtree (pass 1).
   *  @param  mode layout mode (center, reverse etc.)
   *  @param  n    the (potentially remaining) depth of the subtree
   *  @param  h    the height of a cell for a node
   *  @param  top  the top    border of the subtree (to be filled)
   *  @param  bot  the bottom border of the subtree (to be filled)
   *  @return the number of (valid) entries in the border arrays
   *  @since  2015.12.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected int cloHorz1 (int mode, int n, int h,
                          int[] top, int[] bot)
  {                             /* --- compact vertical layout */
    int    i, k, m;             /* loop variables */
    int    beg, end, delta;     /* for child node traversal */
    DTNode child;               /* to traverse the children */
    int    d, e;                /* number of entries in shape arrays */
    int    x, s;                /* coordinate and shift value */
    int    l, r;                /* coords. of left and right child */
    int[]  ctop, cbot;          /* top and bottom border of child */

    this.bot = 0;               /* clear the vertical shift value */
    if ((this.children == null) /* if this is a leaf node */
    ||   this.folded) {         /* or the subtree is folded */
      top[0] = this.top = 0;    /* init. top and bottom border */
      bot[0] = h; return 1;     /* and subtree shape and return */
    }                           /* (terminate the recursion) */
    ctop = new int[n];          /* init. child shape arrays */
    cbot = new int[n];          /* (top and bottom borders) and */
    l = r = d = 0;              /* coords. of first and last child */
    if ((mode & DTree.REVERSE) != 0) {
      beg = this.children.length-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = this.children.length;    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = this.children[i]; /* traverse the children */
      if (child == null) continue;
      m = child.cloHorz1(mode, n-1, h, ctop, cbot);
      e = (d <  m) ? d : m;     /* process subtree recursively */
      s = (d <= 0) ? 0 : -Integer.MAX_VALUE;
      for (k = 0; k < e; k++) { /* traverse right shape of subtree */
        x = bot[k+1] -ctop[k];  /* left shape of child subtree */
        if (x > s) s = x;       /* and find minimum shift value */
      }                         /* (relative position of sibling) */
      child.bot = s;            /* note shift value in the child */
      r = ctop[0]+s;            /* collect the y-coordinates */
      if (d <= 0) l = r;        /* of the first and last child */
      for (k = 0; k < m; k++) { /* traverse the child border */
        bot[k+1] = cbot[k]+s; x = ctop[k]+s;
        if ((k >= d) || (x < top[k+1])) top[k+1] = x;
      }                         /* adapt the subtree borders */
      if (m > d) d = m;         /* adapt the valid array section */
    }
    top[0] = this.top = ((mode & DTree.CENTER) != 0) ? (l+r)/2 : l;
    bot[0] = top[0] +h;         /* get coordinates of root node */
    return d+1;                 /* return number of valid entries */
  }  /* cloHorz1() */

  /*------------------------------------------------------------------*/
  /** Do a compact horizontal layout of the subtree (pass 2).
   *  @param  mode layout mode (center, reverse etc.)
   *  @param  x      the x-coordinate of the upper left corner
   *  @param  y      the y-coordinate of the upper left corner
   *  @param  w      the width  of a cell for a node
   *  @param  h      the height of a cell for a node
   *  @since  2015.12.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void cloHorz2 (int mode, int x, int y, int w, int h)
  {                             /* --- compact horizontal layout */
    int    i;                   /* loop variable */
    int    beg, end, delta;     /* for child node traversal */
    DTNode child;               /* to traverse the children */

    y += this.bot;              /* add the vertical shift value */
    this.ttop = this.top += y;  /* adapt the horizontal position */
    this.tlft = this.lft  = x;  /* and set the top left corner */
    x += w;                     /* compute x-coord. for child level */
    if ((this.children == null) /* if this is a leaf node */
    ||   this.folded) {         /* or the subtree is folded */
      this.tbot = this.bot = this.top+h;
      this.trgt = this.rgt = x; /* store the bottom right corner */
      return;                   /* and terminate the recursion */
    }
    this.tbot = this.top +h;    /* init. right and bottom borders */
    this.trgt = x;              /* of the subtree rectangle */
    if ((mode & DTree.REVERSE) != 0) {
      beg = this.children.length-1; end = -1; delta = -1; }
    else {                      /* get child traversal parameters */
      beg = 0; end = this.children.length;    delta = +1; }
    for (i = beg; i != end; i += delta) {
      child = this.children[i]; /* traverse the child nodes */
      if (child == null) continue;
      child.cloHorz2(mode, x, y, w, h);
      if (child.ttop < this.ttop) this.ttop = child.ttop;
      if (child.tbot > this.tbot) this.tbot = child.tbot;
      if (child.trgt > this.trgt) this.trgt = child.trgt;
    }                           /* update the right border */
    this.bot = this.top +h;     /* set bottom right corner */
    this.rgt = this.lft +w;     /* of the node cell */
  }  /* cloHorz2() */

  /*------------------------------------------------------------------*/
  /** Find the node that is located at given coordinates.
   *  @param  x the x-coordinate
   *  @param  y the y-coordinate
   *  @return node that is located at the given coordinates
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected DTNode findVert (int x, int y)
  {                             /* --- find node by screen coords. */
    int    i;                   /* loop variable */
    DTNode node = null;         /* to traverse the children */

    if (y < this.top)           /* if above this node cell, */
      return null;              /* no node can be found */
    if (y < this.bot)           /* check whether in this node cell */
      return (x >= this.lft) && (x < this.rgt) ? this : null;
    if ((this.children == null) /* if this is a leaf */
    ||  this.folded)            /* or the node is folded, */
      return null;              /* no node can be found */
    for (i = 0; i < this.children.length; i++) {
      node = this.children[i];  /* traverse the child nodes */
      if ((node != null) && (x >= node.tlft) && (x < node.trgt)) {
        node = node.findVert(x, y);
        if (node != null) return node;
      }                         /* check recursively whether node */
    }                           /* is in the subtree of the child */
    return null;                /* return that no node was found */
  }  /* findVert() */

  /*------------------------------------------------------------------*/
  /** Find the node that is located at given coordinates.
   *  @param  x the x-coordinate
   *  @param  y the y-coordinate
   *  @return node that is located at the given coordinates
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected DTNode findHorz (int x, int y)
  {                             /* --- find node by screen coords. */
    int    i;                   /* loop variable */
    DTNode node = null;         /* to traverse the children */

    if (x < this.lft)           /* if left of this node cell, */
      return null;              /* no node can be found */
    if (x < this.rgt)           /* check whether in this node cell */
      return (y >= this.top) && (y < this.bot) ? this : null;
    if ((this.children == null) /* if this is a leaf */
    ||  this.folded)            /* or the node is folded, */
      return null;              /* no node can be found */
    for (i = 0; i < this.children.length; i++) {
      node = this.children[i];  /* traverse the child nodes */
      if ((node != null) && (x >= node.ttop) && (x < node.tbot)) {
        node = node.findHorz(x, y);
        if (node != null) return node;
      }                         /* check recursively whether node */
    }                           /* is in the subtree of the child */
    return null;                /* return that no node was found */
  }  /* findHorz() */

  /*------------------------------------------------------------------*/
  /** Create a string description of the subtree.
   *  @return a string description of the subtree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String toString (int depth)
  {                             /* --- create a string description */
    int     i, k, n;            /* loop variable */
    ColType type;               /* type of the node attribute */
    DTNode  child;              /* to traverse the children */
    String  val;                /* branch value */
    StringBuilder s;            /* created string description */

    s = new StringBuilder("{ ");/* start the node description */
    type = this.att.getType();  /* get the node attribute type */
    if (this.children == null){ /* if this is a leaf node */
      if (type instanceof NominalType) {
        n = this.freqs.length;  /* if decision tree */
        for (i = k = 0; i < n; i++) {
          if (this.freqs[i] <= 0) continue;
          if (k++ > 0) s.append(", ");
          s.append(((NominalType)this.att.getType()).getValue(i));
          s.append(": "); s.append(this.freqs[i]);
        } }                     /* list the class probabilities */
      else {                    /* if regression tree */
        s.append(this.pred); s.append(" ~");
        s.append(this.dev);  s.append(" [");
        s.append(this.sum);  s.append("]");
      } }                       /* print prediction and deviation */
    else {                      /* if this is an inner node */
      s.append("(");            /* print the test attribute */
      s.append(this.att.getName());
      if (!(type instanceof NominalType)) {
        s.append("|"); s.append(this.cut); }
      s.append(")\n");          /* append a possible cut value */
      for (i = n = 0; i < this.children.length; i++) {
        child = this.children[i];  /* traverse the children */
        if (child == null) continue;
        if (n++ > 0) s.append(",\n");
        for (k = depth+2; --k >= 0; )
          s.append(" ");        /* indent the line */
        if (type instanceof NominalType)
             val = ((NominalType)type).getValue(i).toString();
        else val = (i == 0) ? "<" : ">";
        s.append(val +": ");    /* print the attribute value */
        s.append(child.toString(depth +val.length() +4));
      }                         /* process the child recursively */
    }
    s.append(" }");             /* terminate the node description */
    return s.toString();        /* return the created string */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Parse a decision/regression tree node/subtree.
   *  @param  dtree the corresponding decision tree
   *  @param  scan  the scanner to read from
   *  @return the parsed decision/regression tree node/subtree
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected static DTNode parse (DTree dtree, Scanner scan)
    throws IOException
  {                             /* --- recursively parse a subtree */
    DTNode      node;           /* created decision tree node */
    DTNode      child;          /* to create the child nodes */
    ColType     type;           /* the type of the test attribute */
    NominalType nom;            /* attribute type if nominal */
    int         id, i;          /* value identifier, loop variable */
    double      p;              /* probability of a class */
    String      vset;           /* set of nominal values */

    if (scan.nextToken() == '(') {  /* if test node (inner node) */
      scan.getID();             /* check for an identifier */
      node = new DTNode(dtree, scan.value);
      if (node.att == null)     /* get the test attribute */
        throw new IOException("unknown attribute "
                              +scan.value +scan.lno());
      type = node.att.getType();/* get the type of the test attribute */
      nom  = (type instanceof NominalType) ? (NominalType)type : null;
      if (nom == null) {        /* if test attribute is metric, */
        scan.getChar('|');      /* check for a '|' */
        scan.getNumber();       /* check for a number */
        node.cut = Double.parseDouble(scan.value);
      }                         /* parse the cut value */
      scan.getChar(')');        /* check for a ')' */
      do {                      /* read list of children */
        vset = null;            /* initialize the set of values */
        if (nom != null) {      /* if test attribute is nominal */
          while (true) {        /* value set read loop */
            scan.getID();       /* read the branch value */
            id = nom.getValueId(scan.value);
            if (id < 0) throw new IOException("unknown value "
                                             +scan.value +scan.lno());
            if (vset != null) vset += "," +nom.getValue(id).toString();
            if (scan.nextToken() != ',') break;
            if (vset == null) vset  =      nom.getValue(id).toString();
          }                     /* collect the set values */
          scan.pushBack(); }    /* push back the last token */
        else {                  /* if test attribute is metric */
          if (scan.nextToken() == '<') id = 0;
          else if (scan.ttype  == '>') id = 1;
          else throw new IOException("'<' or '>' expected instead of '"
                                     +scan.value +"'" +scan.lno());
        }                       /* get the value identifier */
        scan.getChar(':');      /* check for a ':' */
        scan.getChar('{');      /* check for a '{' */
        node.children[id] = child = DTNode.parse(dtree, scan);
        child.parent = node;    /* recursively parse */
        child.valid  = id;      /* a child node */
        child.set    = vset;
        if (!(dtree.getTargetType() instanceof NominalType)) {
          node.sum  += p = child.sum;   /* if regression tree, */
          node.pred += p * child.pred;  /* aggregate prediction */
          node.dev  += p *(child.dev*child.dev +child.pred*child.pred);}
        else {                  /* if decision tree */
          for (id = dtree.clscnt; --id >= 0; )
            node.freqs[id] += child.freqs[id];
        }                       /* aggregate child frequencies */
        scan.getChar('}');      /* check for a '}' */
      } while (scan.nextToken() == ',');
      scan.pushBack();          /* put back last token */
      if (!(dtree.getTargetType() instanceof NominalType)) {
        node.pred /= node.sum;  /* if regression tree */
        p = node.dev /node.sum -node.pred *node.pred;
        node.dev = Math.sqrt(p);
      } }                       /* compute prediction and deviation */
    else {                      /* if leaf node */
      scan.pushBack();          /* push back the last token */
      node = new DTNode(dtree); /* create a leaf node */
      if (dtree.getTargetType() instanceof NominalType) {
        nom = (NominalType)dtree.target.getType();
        do {                    /* if leaf node in decision tree */
          scan.getID();         /* read the class name */
          id = nom.getValueId(scan.value);
          if (id < 0) throw new IOException("unknown value "
                                           +scan.value +scan.lno());
          scan.getChar(':');     /* check for a ':' */
          scan.getNumber();      /* check for a number */
          p = Double.parseDouble(scan.value);
          if (p  < 0) throw new IOException("illegal number "
                                           +scan.value +scan.lno());
          node.freqs[id] = p;   /* store the probability */
          if (scan.nextToken() != '(')
            scan.pushBack();    /* check for relative frequency */
          else {                /* and consume it */
            scan.getNumber();   /* check for a number */
            scan.getChar('%');  /* check for a '%' */
            scan.getChar(')');  /* check for a ')' */
          }                     /* while another class follows */
        } while (scan.nextToken() == ',');
        scan.pushBack(); }      /* put back last token */
      else {                    /* if leaf node in regression tree */
        scan.getNumber();       /* check for a number (prediction) */
        node.pred = Double.parseDouble(scan.value);
        scan.getChar('~');      /* check for a '~' */
        scan.getNumber();       /* check for a number (deviation) */
        node.dev  = Double.parseDouble(scan.value);
        scan.getChar('[');      /* check for a '[' */
        scan.getNumber();       /* check for a number (support) */
        node.sum  = Double.parseDouble(scan.value);
        scan.getChar(']');      /* check for a ']' */
      }
    }
    if (dtree.getTargetType() instanceof NominalType) {
      for (i = node.freqs.length; --i >= 0; ) {
        node.sum += node.freqs[i];
        if (node.freqs[i] > node.freqs[node.best]) node.best = i;
      }                         /* sum the class frequencies and */
    }                           /* determine the majority class */
    return node;                /* return the created subtree */
  }  /* parse() */

}  /* class DTNode */
