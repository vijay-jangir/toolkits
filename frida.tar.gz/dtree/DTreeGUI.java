/*----------------------------------------------------------------------
  File    : DTreeGUI.java
  Contents: decision and regression tree graphical user interface
  Author  : Christian Borgelt
  History : 2004.05.25 file created from file DTView.java
            2004.05.27 simple editor for domain files added
            2004.06.04 external command execution improved
            2004.11.09 adapted to time output of dtree programs
            2007.02.10 javadoc added, adapted to dialog classes
            2007.02.11 redesigned, made part of frida package
            2007.02.16 command generation improved
            2007.03.12 function loadDTree removed
            2007.05.08 adapted to new executor classes
            2007.05.18 result message creation improved
            2007.06.05 numeric inputs changed to JFormattedTextField
            2007.07.07 adapted to new class DialogPanel
            2007.10.25 bug in function getResultMsg() fixed
            2013.04.22 adapted to type argument of JComboBox
            2014.10.20 trimming of spaces from number arguments added
            2014.10.23 terminal added, changed from LGPL to MIT license
----------------------------------------------------------------------*/
package dtree;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTextArea;

import dialog.TabbedGUI;
import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.DomainsPanel;
import dialog.AboutPanel;
import util.Executor;
import util.CmdExecutor;

/*--------------------------------------------------------------------*/
/** Class for a user interface to the decision tree C programs.
 *  @author Christian Borgelt
 *  @since  2004.05.25 */
/*--------------------------------------------------------------------*/
public class DTreeGUI extends TabbedGUI {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010012L;
  public  static final String VERSION = "1.18 (2014.10.23)";

  /** tab index: domain determination */
  private static final int DOMAINS   = 1;
  /** tab index: induction parameters */
  private static final int PARAMS    = 2;
  /** tab index: decision/regression tree induction */
  private static final int INDUCTION = 3;
  /** tab index: decision/regression tree pruning */
  private static final int PRUNING   = 4;
  /** tab index: decision/regression tree execution */
  private static final int EXECUTION = 5;

  /** the names of the class frequency balancing methods */
  private static final String[] balnames = {
    "no", "lower", "boost", "shift" };
  /** the codes of the class frequency balancing methods */
  private static final String[] balcodes = {
    "", "l", "b", "s" };

  /** the names of the decision tree evaluation measures */
  private static final String[] decnames = {
    "no measure",
    "information gain",
    "balanced information gain",
    "information gain ratio",
    "sym. information gain ratio 1",
    "sym. information gain ratio 2",
    "quadratic information gain",
    "balanced quadratic information gain",
    "quadratic information gain ratio",
    "sym. quadratic information gain ratio 1",
    "sym. quadratic information gain ratio 2",
    "Gini index",
    "symmetric Gini index",
    "modified Gini index",
    "relief measure",
    "sum of weighted differences",
    "chi^2 measure",
    "normalized chi^2 measure",
    "weight of evidence",
    "relevance",
    "Bayesian-Dirichlet / K2 metric",
    "modified Bayesian-Dirichlet / K2 metric",
    "reduction of desc. length (rel. freq.)",
    "reduction of desc. length (abs. freq.)",
    "stochastic complexity",
    "specificity gain",
    "balanced specificity gain",
    "specificity gain ratio",
    "sym. specificity gain ratio 1",
    "sym. specificity gain ratio 2" };
  /** the codes of the decision tree evaluation measures */
  private static final String[] deccodes = {
    "none",
    "infgain", "infgbal", "infgr",   "infsgr1", "infsgr2",
    "qigain",  "qigbal",  "qigr",    "qisgr1",  "qisgr2",
    "gini",    "ginisym", "ginimod", "relief",
    "wdiff",   "chi2",    "chi2nrm", "wevid",   "relev",
    "bdm",     "bdmod",   "rdlrel",  "rdlabs",  "stoco",
    "spcgain", "spcgbal", "spcgr",   "spcsgr1", "spcsgr2" };

  /** the names of the regression tree evaluation measures */
  private static final String[] regnames = {
    "no measure",
    "sum of squared errors",
    "mean squared error",
    "square root of mean squared error",
    "variance (unbiased estimator)",
    "standard deviation (from variance)" };
  /** the codes of the regression tree evaluation measures */
  private static final String[] regcodes = {
    "none", "sse", "mse", "rmse", "var", "sd" };

  /** the names of the pruning methods */
  private static final String[] prnnames = {
    "none", "pessimistic", "confidence level" };
  /** the codes of the pruning methods */
  private static final String[] prncodes = {
    "none", "pess", "clvl" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /* --- parameters --- */
  /** whether to weight the evaluation measure */
  private JCheckBox         weight;
  /** the evaluation measure for a nominal target */
  private JComboBox<String> emdec;
  /** the evaluation measure for a metric target */
  private JComboBox<String> emreg;
  /** the minimal value of the evaluation measure for a split */
  private JTextField        minval;
  /** the sensitivity parameter of the evaluation measure */
  private JTextField        sensit;
  /** the prior probability / equivalent sample size */
  private JTextField        prior;
  /** the maximum height of the tree */
  private JTextField        maxht;
  /** the minimum support of at least two branches */
  private JTextField        minsupp;
  /** whether to try to form subsets of nominal attribute values */
  private JCheckBox         subsets;

  /* --- induction --- */
  /** the name of the domains file */
  private JTextField        fn_dom;
  /** the name of the table file */
  private JTextField        fn_grow;
  /** the name of the target attribute */
  private JTextField        target;
  /** whether to balance the class frequencies */
  private JComboBox<String> balgrow;
  /** the name of the decision tree file */
  private JTextField        fn_dt;

  /* --- pruning --- */
  /** the name of the decision tree input file */
  private JTextField        fn_dtin;
  /** the pruning method */
  private JComboBox<String> method;
  /** the parameter of the pruning method */
  private JTextField        param;
  /** whether to check a replacement by the largest branch */
  private JCheckBox         branch;
  /** the name of the table file to use for pruning */
  private JTextField        fn_prune;
  /** whether to balance class frequencies */
  private JComboBox<String> balprune;
  /** the name of the decision tree output file */
  private JTextField        fn_dtout;

  /* --- execution --- */
  /** the name of the decision tree file */
  private JTextField        fn_exec;
  /** the name of the table input file */
  private JTextField        fn_in;
  /** the name of the prediction field */
  private JTextField        pred;
  /** the name of the support field */
  private JTextField        supp;
  /** the name of the confidence field */
  private JTextField        conf;
  /** whether to write the field names to the first record */
  private JCheckBox         write;
  /** the name of the table output file */
  private JTextField        fn_out;

  /*------------------------------------------------------------------*/
  /** Create a decision and regression tree GUI.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTreeGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a decision and regression tree GUI.
   *  @param  owner the component that is to own this dialog
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTreeGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    DialogPanel tab;            /* current tab of the tabbed pane */
    JTextArea   help;           /* buffer for a help text */

    /* --- basic tabs --- */
    this.base("Decision and Regression Tree Tools");
    this.addFormatTab (FormatPanel.ALL);
    this.addDomainsTab(DomainsPanel.LOCATE);

    /* --- Parameters --- */
    tab = this.addTab("Parameters");

    tab.addLabel("Evaluation measure:");
    this.weight = tab.addCheckBox("weighted", true);
    this.emdec  = tab.addComboBox(DTreeGUI.decnames);
    this.emdec.setSelectedIndex(3);
    this.emreg  = tab.addComboBox(DTreeGUI.regnames);
    this.emreg.setSelectedIndex(2);

    tab.addLabel("Minimum value for split:");
    this.minval = tab.addNumberInput("");
    tab.addHelp("An empty minimum value means that there is "
               +"no limit -\nany value of the evaluation measure "
               +"will lead to a split.");

    tab.addLabel("Measure sensitivity:");
    this.sensit = tab.addNumberInput("");
    tab.addLabel("Prior/equiv. sample size:");
    this.prior  = tab.addNumberInput("");

    tab.addLabel("Maximum tree height:");
    this.maxht = tab.addNumberInput("" );

    tab.addLabel("Minimum support:");
    this.minsupp = tab.addNumberInput("2");

    tab.addLabel("Try to form subsets:");
    this.subsets = tab.addCheckBox(false);
    tab.addHelp("Try to group the values of nominal attributes "
               +"into subsets.");
    tab.addFiller(0);

    /* --- Induction --- */
    tab = this.addTab("Induction");

    tab.addLabel("Domains file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_dom); } } );
    tab.addButton("Edit", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.editDomains(DTreeGUI.this.fn_dom); } } );
    this.fn_dom = tab.addFileInput("noname.dom");

    tab.addLabel("Target attribute:");
    this.target = tab.addTextInput("");
    tab.addHelp("If no target attribute is specified, the one listed "
               +"last in the\ndomains file is used. The type of the "
               +"target attribute and\nthus the tree type is "
               +"determined from the domains file.");

    tab.addLabel("Data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_grow); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showTable(DTreeGUI.this.fn_grow); } } );
    this.fn_grow = tab.addFileInput("noname.tab");

    tab.addLabel("Balance classes:         ");
    this.balgrow = tab.addComboBox(DTreeGUI.balnames);
    tab.addHelp("Balancing helps with highly uneven class "
               +"distributions.\nHowever, it distorts the "
               +"statistics of the data set.");

    tab.addLabel("Output tree file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_dt); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showDTree(DTreeGUI.this.fn_dt); } } );
    this.fn_dt = tab.addFileInput("noname.dt");
    tab.addFiller(0);

    /* --- Pruning --- */
    tab = this.addTab("Pruning");

    tab.addLabel("Input tree file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_dtin); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showDTree(DTreeGUI.this.fn_dtin); } } );
    this.fn_dtin = tab.addFileInput("noname.dt");

    tab.addLabel("Pruning method:");
    this.method = tab.addComboBox(DTreeGUI.prnnames);
    this.method.setSelectedIndex(2);
    tab.addLabel("Pruning parameter:");
    this.param = tab.addNumberInput("0.5");

    tab.addLabel("Check largest branch:");
    this.branch = tab.addCheckBox(false, DialogPanel.MIDDLE);
    tab.add(help = new JTextArea("(needs data)"), DialogPanel.RIGHT);
    help.setBorder(BorderFactory.createEmptyBorder(6,0,0,0));
    help.setBackground(tab.getBackground());
    help.setFont(DialogPanel.SMALL);
    tab.addHelp("Each subtree is checked against its largest branch.\n"
               +"Attention: this can be very time consuming!");

    tab.addLabel("Data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_prune); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showTable(DTreeGUI.this.fn_prune); } } );
    this.fn_prune = tab.addFileInput("noname.tab");

    tab.addLabel("Balance classes:           ");
    this.balprune = tab.addComboBox(DTreeGUI.balnames);

    tab.addLabel("Output tree file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_dtout); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showDTree(DTreeGUI.this.fn_dtout); } } );
    this.fn_dtout = tab.addFileInput("noname.pdt");
    tab.addFiller(0);

    /* --- decision and regression tree execution --- */
    tab = this.addTab("Execution");

    tab.addLabel("Input tree file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_exec); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showDTree(DTreeGUI.this.fn_exec); } } );
    this.fn_exec = tab.addFileInput("noname.dt");

    tab.addLabel("Input data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_in); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showTable(DTreeGUI.this.fn_in); } } );
    this.fn_in = tab.addFileInput("noname.tab");

    tab.addLabel("Prediction field name:");
    this.pred = tab.addTextInput("dt");
    tab.addLabel("Support field name:");
    this.supp = tab.addTextInput("");

    tab.addLabel("Confidence field name:");
    this.conf = tab.addTextInput("");
    tab.addHelp("Support (number of cases in node) and confidence "
               +"(relative\nclass frequency) indicate how reliable "
               +"the prediction is.");

    tab.addLabel("Write field names:");
    this.write = tab.addCheckBox(true);

    tab.addLabel("Output data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.getFileName(DTreeGUI.this.fn_out); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DTreeGUI.this.showTable(DTreeGUI.this.fn_out); } } );
    this.fn_out = tab.addFileInput("noname.out");
    tab.addFiller(0);

    /* --- Terminal --- */
    this.addTerminalTab("Terminal output of external programs");

    /* --- About --- */
    this.addTab("About", new AboutPanel(
       "Decision and Regression Tree Tools",
       "A simple user interface for the dtree programs.\n\n"
      +"Version " +DTreeGUI.VERSION +"\n"
      +"written by Christian Borgelt\n"
      +"European Center for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.pack();
    this.selectTab(INDUCTION);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  {                             /* --- set the domains file */
    this.domains.setDomainsFile(file);
    this.fn_dom.setText(file.getPath());
  }  /* setDomainsFile() */

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  {                             /* --- set the data file */
    this.domains.setDataFile(file);
    String path = file.getPath();
    this.fn_grow.setText(path);
    this.fn_prune.setText(path);
  }  /* setDataFile() */

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  { this.fn_in.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Show a decision/regression tree.
   *  @param  txt the text field containing the file name
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showDTree (JTextField txt)
  { this.showDTree(new File(txt.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a decision/regression tree.
   *  @param  file the file to load the decision/regression tree from
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showDTree (File file)
  {                             /* --- show a decision tree */
    DTView view = new DTView(this, DTView.FILE_ITEMS);
    if (!view.loadDTree(file)) return;
    view.setVisible(true); view.toFront();
  }  /* showDTree() */

  /*------------------------------------------------------------------*/
  /** Create a command to induce a decision/regression tree.
   *  @return the command to induce a decision/regression tree
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createInductionCmd ()
  {                             /* --- grow a decision/regress. tree */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[32];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"dti";
    n = this.format.addFormatArgs(cmd, FormatPanel.ALL);
    s = this.target.getText();  /* target attribute */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    s = DTreeGUI.balcodes[this.balgrow.getSelectedIndex()];
    if (s.length() > 0) cmd[n++] = "-q" +s;
    cmd[n++] = "-" +(this.weight.isSelected() ? "" : "w")
             + "e"  +deccodes[this.emdec.getSelectedIndex()]
             + ":"  +regcodes[this.emreg.getSelectedIndex()];
    s = this.sensit.getText().trim();  /* measure parameters */
    if (s.length() > 0) cmd[n++] = "-z" +s;
    s = this.prior.getText().trim();
    if (s.length() > 0) cmd[n++] = "-p" +s;
    s = this.minval.getText().trim();
    if (s.length() > 0) cmd[n++] = "-i" +s;
    s = this.maxht.getText().trim();   /* maximal tree height */
    if (s.length() > 0) cmd[n++] = "-t" +s;
    s = this.minsupp.getText().trim(); /* minimal support for split */
    if (s.length() > 0) cmd[n++] = "-k" +s;
    if (this.subsets.isSelected())
      cmd[n++] = "-s";          /* form subset for nominal atts. */
    cmd[n++] = "-v";            /* print relative frequencies */
    cmd[n++] = this.fn_dom.getText();
    cmd[n++] = this.fn_grow.getText();
    cmd[n++] = this.fn_dt.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createInductionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a command to prune a decision/regression tree.
   *  @return the command to prune a decision/regression tree
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createPruningCmd ()
  {                             /* --- prune a decision/regress. tree */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[32];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"dtp";
    n = this.format.addFormatArgs(cmd, FormatPanel.ALL);
    s = DTreeGUI.balcodes[this.balprune.getSelectedIndex()];
    if (s.length() > 0) cmd[n++] = "-q" +s;
    cmd[n++] = "-m" +DTreeGUI.prncodes[this.method.getSelectedIndex()];
    s = this.param.getText().trim();   /* pruning parameters */
    if (s.length() > 0) cmd[n++] = "-p" +s;
    if (this.branch.isSelected())
      cmd[n++] = "-k";          /* check largest branch */
    s = this.maxht.getText();   /* maximal tree height */
    if (s.length() > 0) cmd[n++] = "-t" +s;
    cmd[n++] = this.fn_dtin.getText();
    cmd[n++] = this.fn_dtout.getText();
    s = this.fn_prune.getText();
    if (s.length() > 0) cmd[n++] = s;
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createPruningCmd() */   /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a command to execute a decision/regression tree.
   *  @return the command to execute a decision/regression tree
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createExecutionCmd ()
  {                             /* --- execute a decision/reg. tree */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[16];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"dtx";
    n = this.format.addFormatArgs(cmd, FormatPanel.ALL);
    s = this.pred.getText();    /* prediction field name */
    if (s.length() > 0) cmd[n++] = "-p" +s;
    s = this.supp.getText();    /* support    field name */
    if (s.length() > 0) cmd[n++] = "-s" +s;
    s = this.conf.getText();    /* confidence field name */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    if (!this.write.isSelected())
      cmd[n++] = "-w";          /* do not write field names */
    cmd[n++] = this.fn_exec.getText();
    cmd[n++] = this.fn_in.getText();
    cmd[n++] = this.fn_out.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createExecutionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create an executor for a dialog tab.
   *  @param  i the index of the dialog tab
   *  @return the executor for the <code>i</code>-th dialog tab
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- create a dialog tab executor */
    String[] cmd;               /* the command to execute */

    switch (i) {                /* evaluate the dialog tab index */
      case DOMAINS  : cmd = this.createDomainsCmd();   break;
      case PARAMS   :
      case INDUCTION: cmd = this.createInductionCmd(); break;
      case PRUNING  : cmd = this.createPruningCmd();   break;
      case EXECUTION: cmd = this.createExecutionCmd(); break;
      default: return null;     /* get the command to execute, */
    }                           /* return null if not executable */
    return new CmdExecutor(cmd, this);
  }  /* createExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    int    i;                   /* index/character position */
    String msg;                 /* message of external program */

    if (this.index == DOMAINS)  /* if domain determination */
      return this.getDomainsMsg();
    if ((this.index == PARAMS)  /* if tree induction or tree pruning */
    ||  (this.index == INDUCTION)
    ||  (this.index == PRUNING)) {
      msg = ((CmdExecutor)this.executor).getErrorData();
      i   = msg.lastIndexOf("[", msg.lastIndexOf("node(s)]"));
      msg = msg.substring(i+1, msg.indexOf(']', i));
      return ((this.index == INDUCTION) ? "Created" : "Pruned")
           +" tree has\n" +msg +".";
    }                           /* extract tree description */
    if  (this.index == EXECUTION) { /* if tree execution */
      msg = ((CmdExecutor)this.executor).getLastErrorLine();
      return "Tree execution leads to\n" +msg +".";
    }
    return null;                /* otherwise there is no message */
  }  /* getResultMsg() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  {                             /* --- load configuration file */
    if (file == null) {         /* if no file name is given */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Load Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileReader reader = new FileReader(file);
      /* --- Format & Domains --- */
      this.format.loadConfig(reader);
      this.domains.loadConfig(reader);
      /* --- text parameters --- */
      /* --- Parameters --- */
      this.minval.setText  (this.readLine(reader));
      this.sensit.setText  (this.readLine(reader));
      this.prior.setText   (this.readLine(reader));
      this.maxht.setText   (this.readLine(reader));
      this.minsupp.setText (this.readLine(reader));
      /* --- Induction --- */
      this.fn_dom.setText  (this.readLine(reader));
      this.fn_grow.setText (this.readLine(reader));
      this.fn_dt.setText   (this.readLine(reader));
      this.target.setText  (this.readLine(reader));
      /* --- Pruning --- */
      this.fn_dtin.setText (this.readLine(reader));
      this.fn_prune.setText(this.readLine(reader));
      this.fn_dtout.setText(this.readLine(reader));
      this.param.setText   (this.readLine(reader));
      /* --- Execution --- */
      this.fn_exec.setText (this.readLine(reader));
      this.fn_in.setText   (this.readLine(reader));
      this.fn_out.setText  (this.readLine(reader));
      this.pred.setText    (this.readLine(reader));
      this.supp.setText    (this.readLine(reader));
      this.conf.setText    (this.readLine(reader));
      /* --- flags and indices --- */
      /* --- Parameters --- */
      this.weight.setSelected (this.readInt(reader) != 0);
      this.emdec.setSelectedIndex   (this.readInt(reader));
      this.emreg.setSelectedIndex   (this.readInt(reader));
      this.subsets.setSelected(this.readInt(reader) != 0);
      /* --- Induction --- */
      this.balgrow.setSelectedIndex (this.readInt(reader));
      /* --- Pruning --- */
      this.method.setSelectedIndex  (this.readInt(reader));
      this.balprune.setSelectedIndex(this.readInt(reader));
      this.branch.setSelected (this.readInt(reader) != 0);
      /* --- Execution --- */
      this.write.setSelected  (this.readInt(reader) != 0);
      reader.close(); }         /* read the configuration values */
    catch (IOException e) {     /* and close the input file */
      JOptionPane.showMessageDialog(this,
        "Error reading configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* check for successful reading */
    this.status.setText("configuration loaded: " +file.getName());
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  {                             /* --- save configuration file */
    if (file == null) {         /* if no file name is given, */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Save Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileWriter writer = new FileWriter(file);
      /* --- Format & Domains --- */
      this.format.saveConfig(writer);
      this.domains.saveConfig(writer);
      /* --- text parameters --- */
      /* --- Parameters --- */
      writer.write(this.minval.getText());   writer.write('\n');
      writer.write(this.sensit.getText());   writer.write('\n');
      writer.write(this.prior.getText());    writer.write('\n');
      writer.write(this.maxht.getText());    writer.write('\n');
      writer.write(this.minsupp.getText());  writer.write('\n');
      /* --- Induction --- */
      writer.write(this.fn_dom.getText());   writer.write('\n');
      writer.write(this.fn_grow.getText());  writer.write('\n');
      writer.write(this.fn_dt.getText());    writer.write('\n');
      writer.write(this.target.getText());   writer.write('\n');
      /* --- Pruning --- */
      writer.write(this.fn_dtin.getText());  writer.write('\n');
      writer.write(this.fn_prune.getText()); writer.write('\n');
      writer.write(this.fn_dtout.getText()); writer.write('\n');
      writer.write(this.param.getText());    writer.write('\n');
      /* --- Execution --- */
      writer.write(this.fn_exec.getText());  writer.write('\n');
      writer.write(this.fn_in.getText());    writer.write('\n');
      writer.write(this.fn_out.getText());   writer.write('\n');
      writer.write(this.pred.getText());     writer.write('\n');
      writer.write(this.supp.getText());     writer.write('\n');
      writer.write(this.conf.getText());     writer.write('\n');
      /* --- flags and indices --- */
      /* --- Parameters --- */
      writer.write(this.weight.isSelected()  ? "1," : "0,");
      writer.write(this.emdec.getSelectedIndex()    +",");
      writer.write(this.emreg.getSelectedIndex()    +",");
      writer.write(this.subsets.isSelected() ? "1," : "0,");
      /* --- Induction --- */
      writer.write(this.balgrow.getSelectedIndex()  +",");
      /* --- Pruning --- */
      writer.write(this.method.getSelectedIndex()   +",");
      writer.write(this.balprune.getSelectedIndex() +",");
      writer.write(this.branch.isSelected()  ? "1," : "0,");
      /* --- Execution --- */
      writer.write(this.write.isSelected()   ? "1," : "0,");
      writer.write('\n');       /* write the configuration values */
      writer.close(); }         /* and close the output file */
    catch (IOException e) {     /* check for successful writing */
      JOptionPane.showMessageDialog(this,
        "Error writing configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show a status message */
    this.status.setText("configuration saved: " +file.getName());
  }  /* saveConfig() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2004.05.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    DTreeGUI gui = new DTreeGUI();
    if (args.length > 0)        /* load configuration if necessary */
      gui.loadConfig(new File(args[0]));
    gui.setVisible(true);       /* show the user interface */
  }  /* main() */

}  /* class DTreeGUI */
