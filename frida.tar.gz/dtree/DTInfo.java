/*----------------------------------------------------------------------
  File    : DTInfo.java
  Contents: class for a decision tree node information window
  Author  : Christian Borgelt
  History : 2015.11.13 file created
            2015.11.24 first version completed
            2015.11.25 color column added for decision tree nodes
----------------------------------------------------------------------*/
package dtree;

import java.io.IOException;
import java.io.FileReader;
import java.awt.Color;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.BorderFactory;
import javax.swing.table.TableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableColumn;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.event.ListSelectionListener;

import util.Scanner;
import table.ColType;
import table.NominalType;
import dialog.DialogPanel;

/*--------------------------------------------------------------------*/
/** Class for a table of decision tree path conditions.
 *  @author Christian Borgelt
 *  @since  2015.11.13 */
/*--------------------------------------------------------------------*/
class PathTable extends AbstractTableModel {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the names of the test attributes on the path */
  private String atts[] = null;
  /** the comparison operators for the test attribute values */
  private String ops[]  = null;
  /** the test attribute values to compare to */
  private String vals[] = null;

  /*------------------------------------------------------------------*/
  /** Create a table of attribute values.
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public PathTable ()
  { }

  /*------------------------------------------------------------------*/
  /** Set the the decision tree path conditions.
   *  @param  node the node to which the path is to be shown
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNode (DTNode node)
  {                             /* --- set the decision tree node */
    int o = this.getRowCount(); /* get the old number of rows */
    int n = 0;                  /* init. the new number of rows */
    DTNode  p;                  /* to traverse nodes on the path */
    ColType t;                  /* test attribute type */

    for (p = node; p.parent != null; p = p.parent)
      n += 1;                   /* count nodes on path to root */
    this.atts = new String[n];  /* create arrays for */
    this.ops  = new String[n];  /* test attribute names, */
    this.vals = new String[n];  /* operators and values */
    for ( ; node.parent != null; node = p) {
      p = node.parent;          /* traverse the path to the root */
      this.atts[--n] = p.att.getName();
      t = p.att.getType();      /* get test attribute name and type */
      if (t instanceof NominalType) {
        this.ops [n] = "=";     /* if nominal test attribute */
        this.vals[n] = (node.set != null) ? node.set
          : ((NominalType)t).getValue(node.valid).toString(); }
      else {                    /* if numeric test attribute */
        this.ops [n] = (node.valid <= 0) ? "<" : ">";
        this.vals[n] = String.valueOf(p.cut);
      }                         /* get operator and value */
    }
    if (o > n) this.fireTableRowsDeleted (n, o-1);
    this.fireTableDataChanged();/* update the display */
    if (n > o) this.fireTableRowsInserted(o, n-1);
  }  /* setNode() */

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2015.11.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.atts != null) ? this.atts.length : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return always <code>3</code>
   *  @since  2015.11.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return 3; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column given its index.
   *  @param  col the index of the column
   *  @return <code>attribute</code>, <code>op</code>
   *          or <code>value(s)</code>, respectively
   *  @since  2015.11.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int col)
  {                             /* --- get a column name */
    if (col <= 0) return "attribute";
    if (col <= 1) return "op";
    if (col <= 2) return "value(s)";
    return "";                  /* fallback for safety */
  }  /* getColumnName() */

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as an object.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return an object representing the value in the specified cell
   *  @since  2015.11.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  {                             /* --- get table cell content */
    if ((this.atts == null) || (row >= this.atts.length)) return "";
    if (col <= 0) return this.atts[row];
    if (col <= 1) return this.ops [row];
    if (col <= 2) return this.vals[row];
    return "";                  /* fallback for safety */
  }  /* getValueAt() */

}  /* PathTable() */


/*--------------------------------------------------------------------*/
/** Class for a target/class distribution table.
 *  @author Christian Borgelt
 *  @since  2015.11.13 */
/*--------------------------------------------------------------------*/
class DistTable extends AbstractTableModel {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /* instance variables                                               */
  /*------------------------------------------------------------------*/
  /** the decision tree node */
  private DTNode   node = null;
  /** the fraction of cases in this node */
  private double   frac = 0.0;
  /** the colors associated to the classes */
  private Object[] cols = null;

  /*------------------------------------------------------------------*/
  /** Create a class distribution table.
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DistTable ()
  { }

  /*------------------------------------------------------------------*/
  /** Set the class distribution of a decision tree node.
   *  @param  node the decision tree node to show
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNode (DTNode node, Color[] cols)
  {                             /* --- set the decision tree node */
    int     k, n;               /* loop variables */
    ColType t;                  /* target attribute type (for colors) */

    this.node = node;           /* note the decision tree node */
    this.frac = (node == null) ? 0
              : node.getFreq() /node.tree.getRoot().getFreq() *100.0;
    this.cols = cols;           /* note fraction of cases and colors */
    this.fireTableStructureChanged();
  }  /* setNode() */

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  {                             /* --- get the number of rows */
    if (this.node == null) return 0;
    int n = this.node.tree.clscnt;
    return (n > 0) ? n : 1;     /* number of classes or one row */
  }  /* getRowCount() */        /* if regression tree */

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return always <code>4</code>
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return 4; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column given its index.
   *  @param  col the index of the column
   *  @return the target attribute name (for <code>col = 0</code>
   *          and column names depending on the target type
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int col)
  {                             /* --- get the column names */
    if (this.node == null) return "";
    if (this.node.freqs != null) { /* if decision tree node */
      if (col <= 0) return "";  /* color and class name columns */
      if (col <= 1) return this.node.tree.target.getName();
      if (col <= 2) return String.format("%.2f%%", this.frac);
      if (col <= 3) return String.format("%.1f", this.node.getFreq()); }
    else {                      /* if regression tree node */
      if (col <= 0) return this.node.tree.target.getName();
      if (col <= 1) return "dev";
      if (col <= 2) return "rel";
      if (col <= 3) return "abs";
    }                           /* target name, std. dev., support */
    return "";                  /* fallback for safety */
  }  /* getColumnName() */

  /*------------------------------------------------------------------*/
  /** Get the class of a column given its index.
   *  @param  col the index of the column
   *  @return the class of the column
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getColumnClass (int col)
  {                             /* --- get the column classes */
    if ((this.node == null) || (this.node.freqs == null))
      return String.class;      /* all strings for regression trees */
    return (col <= 0) ? Color.class : String.class;
  }  /* getColumnClass() */     /* otherwise color for first column */

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as an object.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return an object representing the value in the specified cell
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  {                             /* --- get the cell values */
    if (this.node.freqs != null) {
      DTree t = this.node.tree; /* if decision tree node */
      if (col <= 0)             /* class color */
        return (this.cols != null) ? this.cols[row] : Color.WHITE;
      if (col <= 1)             /* class name */
        return ((NominalType)t.target.getType()).getValue(row);
      if (col <= 2)             /* relative class frequency */
        return String.format("%.2f%%", this.node.getProb(row) *100.0);
      if (col <= 3)             /* absolute class frequency */
        return String.format("%.1f",   this.node.getFreq(row)); }
    else {                      /* if regression tree node */
      if (col <= 0)             /* predicted value */
        return String.valueOf(this.node.getPred());
      if (col <= 1)             /* standard deviation */
        return String.valueOf(this.node.getDev());
      if (col <= 2)             /* support (percentage of cases) */
        return String.format("%.2f%%", this.frac);
      if (col <= 3)             /* support (number of cases) */
        return String.format("%.1f", this.node.getFreq());
    }
    return "";                  /* fallback for safety */
  }  /* getValueAt() */

}  /* DistTable() */


/*--------------------------------------------------------------------*/
/** Class for a dialog to display decision tree node information.
 *  @author Christian Borgelt
 *  @since  2015.11.13 */
/*--------------------------------------------------------------------*/
public class DTInfo extends JDialog {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the main panel */
  private DialogPanel main = null;
  /** the table for the path conditions */
  private JTable      path = null;
  /** the table for the target distribution */
  private JTable      dist = null;
  /** a cell renderer with right alignment */
  private DefaultTableCellRenderer rrgt = null;
  /** a cell renderer with center alignment */
  private DefaultTableCellRenderer rctr = null;
  /** a cell renderer for color column */
  private DefaultTableCellRenderer rcol = null;

  /*------------------------------------------------------------------*/
  /** Create a decision tree node information dialog.
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTInfo ()
  { this(null, "Node Details..."); }

  /*------------------------------------------------------------------*/
  /** Create a decision tree node information dialog.
   *  @param  owner the component that is to own the dialog box
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTInfo (Frame owner)
  { this(owner, "Node Details..."); }

  /*------------------------------------------------------------------*/
  /** Create a decision tree node information dialog.
   *  @param  owner the component that is to own the dialog box
   *  @param  title the title of the dialog box
   *  @since  2015.11.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DTInfo (Frame owner, String title)
  {                             /* --- create a color dialog */
    super(owner);               /* initialize this dialog */
    JTable      tab;            /* path/distribution table */
    JScrollPane pane;           /* scroll pane to enclose table */
    GridBagConstraints gbc;     /* grid bag layout contraints */

    this.setTitle(title);       /* set title and location */
    if (owner != null) this.setLocationRelativeTo(owner);
    else               this.setLocation(48, 48);

    /* create special table cell renderers */
    this.rrgt = new DefaultTableCellRenderer();
    this.rrgt.setHorizontalAlignment(DefaultTableCellRenderer.RIGHT);
    this.rctr = new DefaultTableCellRenderer();
    this.rctr.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
    this.rcol = new DefaultTableCellRenderer () {
      private static final long serialVersionUID = 0x00010000L;
      public void setValue (Object value) {
        Color c; String s;      /* color and text to set */
        if      (value == null)          { s = ""; c = Color.WHITE;  }
        else if (value instanceof Color) { s = ""; c = (Color)value; }
        else {                  s = (String)value; c = Color.WHITE;  }
        this.setBackground(c); this.setText(s);
      } };                      /* set color and/or text */

    /* create path conditions and target distribution tables */
    this.path = new JTable(new PathTable());
    this.path.getTableHeader().setFont(DialogPanel.BOLD);
    this.path.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    this.dist = new JTable(new DistTable());
    this.dist.getTableHeader().setFont(DialogPanel.BOLD);
    this.dist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    /* create the dialog window */
    this.main = new DialogPanel();
    this.main.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    gbc         = new GridBagConstraints();
    gbc.fill    = GridBagConstraints.BOTH;
    gbc.gridx   = 0;
    gbc.gridy   = GridBagConstraints.RELATIVE;
    gbc.weightx = 1.0;          /* vertically stacked elements, */
    gbc.weighty = 0.0;          /* label is not resized vertically */
    this.main.add(new JLabel("Path conditions"),     gbc);
    gbc.weighty = 1.0;          /* table is resized vertically */
    pane = new JScrollPane(this.path);
    pane.setBorder(BorderFactory.createCompoundBorder(
                   BorderFactory.createEmptyBorder(0, 0, 3, 0),
                   pane.getBorder()));
    this.main.add(pane, gbc);   /* add path conditions table */
    gbc.weighty = 0.0;          /* label is not resized vertically */
    this.main.add(new JLabel("Target distribution"), gbc);
    gbc.weighty = 1.0;          /* table is resized vertically */
    pane = new JScrollPane(this.dist);
    pane.setBorder(BorderFactory.createCompoundBorder(
                   BorderFactory.createEmptyBorder(0, 0, 0, 0),
                   pane.getBorder()));
    this.main.add(pane, gbc);   /* add target distribution table */
    this.getContentPane().add(this.main, BorderLayout.CENTER);
    this.pack();                /* pack the dialog elements */
  }  /* DTInfo() */

  /*------------------------------------------------------------------*/
  /** Set the decision tree node to display.
   *  @param  node the decision tree node to display
   *  @since  2015.11.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNode (DTNode node, Color[] cols)
  {                             /* --- set the node to display */
    TableColumnModel m;         /* to modify columns */
    TableColumn      c;         /* to modify columns */

    ((PathTable)this.path.getModel()).setNode(node);
    this.path.setPreferredScrollableViewportSize(
      this.path.getPreferredSize());
    m = this.path.getColumnModel();
    c = m.getColumn(0);         /* the first column (attribute names) */
    c.setPreferredWidth(120);      /* should be somewhat wider */
    c = m.getColumn(1);         /* the middle column (operator) */
    c.setCellRenderer(this.rctr);  /* should show centered text */
    c.setPreferredWidth(8);        /* and should be very narrow */

    ((DistTable)this.dist.getModel()).setNode(node, cols);
    this.dist.setPreferredScrollableViewportSize(
      this.dist.getPreferredSize());
    m = this.dist.getColumnModel();
    if (node.freqs != null) {   /* if decision tree node */
      c = m.getColumn(0);       /* the first column (class colors) */
      c.setCellRenderer(this.rcol); /* should show colors and */
      c.setPreferredWidth(8);       /* should be very narrow */
      c = m.getColumn(1);       /* the second column (class names) */
      c.setPreferredWidth(120); }   /* should be somewhat wider */
    else {                      /* if regression tree node */
      c = m.getColumn(0);       /* the first column (pred. value) */
      c.setPreferredWidth(120);     /* should be somewhat wider */
      c = m.getColumn(1);       /* the second column (std. dev.) */
      c.setPreferredWidth(48);      /* should be somewhat narrower */
    }
    c = m.getColumn(2);         /* the third  column (relative freq.) */
    c.setCellRenderer(this.rrgt);   /* should be right aligned */
    c.setPreferredWidth(40);        /* and somewhat narrower */
    c = m.getColumn(3);         /* the fourth column (absolute freq.) */
    c.setCellRenderer(this.rrgt);   /* should be right aligned */
    c.setPreferredWidth(48);        /* and somewhat narrower */

    this.pack();                /* repack the dialog */
  }  /* setNode() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2015.11.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    DTree  dt;                  /* created decision tree */
    DTInfo info;                /* info. for a decision tree node */

    if (args.length <= 0) {     /* if no arguments are given */
      System.out.println("java dtree.DTInfo <dtree>");
      return;                   /* print a usage message */
    }                           /* and abort the program */
    try {                       /* parse the file */
      dt   = DTree.parse(new Scanner(new FileReader(args[0])));
      info = new DTInfo();      /* create an information dialog */
      info.setNode(dt.getRoot(), null);
      info.setVisible(true); }  /* display the information dialog */
    catch (IOException e) {     /* catch and report an i/o error */
      System.err.println(e.getMessage()); }
  }  /* main() */

}  /* class DTInfo */
