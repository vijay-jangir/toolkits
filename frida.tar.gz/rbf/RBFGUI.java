/*----------------------------------------------------------------------
  File    : RBFGUI.java
  Contents: graphical user interface for radial basis function networks
  Author  : Christian Borgelt
  History : 2007.07.08 file created
            2013.04.22 adapted to type argument of JComboBox
            2014.10.21 trimming of spaces from number arguments added
            2014.10.23 terminal added, changed from LGPL to MIT license
            2018.11.14 replaced some deprecated functions
----------------------------------------------------------------------*/
package rbf;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JSpinner;

import util.Executable;
import util.Executor;
import util.ObjExecutor;
import util.CmdExecutor;
import dialog.TabbedGUI;
import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.DomainsPanel;
import dialog.AboutPanel;

/*--------------------------------------------------------------------*/
/** Class for a graphical user interface for the radial basis function
 *  network programs.
 *  @author Christian Borgelt
 *  @since  2007.07.08 */
/*--------------------------------------------------------------------*/
public class RBFGUI extends TabbedGUI {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010004L;
  public  static final String VERSION = "1.5 (2018.11.14)";

  /** tab index: domain determination */
  private static final int DOMAINS   = 1;
  /** tab index: neuron parameters */
  private static final int NEURONS   = 2;
  /** tab index: initialization parameters */
  private static final int INIT      = 3;
  /** tab index: initialization parameters */
  private static final int PATTERNS  = 4;
  /** tab index: update parameters */
  private static final int UPDATE    = 5;
  /** tab index: regularization parameters */
  private static final int REGULAR   = 6;
  /** tab index: multilayer perceptron training */
  private static final int INDUCTION = 7;
  /** tab index: multilayer perceptron execution */
  private static final int EXECUTION = 8;

  /** the names of the radial functions */
  private static final String[] radnames = {
    "Cauchy", "Gauss" };
  /** the names of the shape parameters */
  private static final String[] shapenames = {
    "none", "variances", "covariances" };
  /** the names of the initialization modes */
  private static final String[] ininames = {
    "center", "uniform", "diagonal", "latin hypercube", "points" };
  /** the names of the initialization modes */
  private static final String[] inicodes = {
    "center", "uniform", "diag", "latin", "points" };
  /** the names of the update methods */
  private static final String[] updnames = {
    "standard backpropagation",
    "super self-adaptive backpropagation",
    "resilient backpropagation",
    "quick backpropagation",
    "manhattan training" };
  /** the names of the update codes */
  private static final String[] updcodes = {
    "bkprop", "supersab", "rprop", "quick", "manhattan" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /* --- neurons --- */
  /** the number of hidden neurons/clusters */
  private JSpinner          clscnt;
  /** the radial function type */
  private JComboBox<String> radial;
  /** the radial function parameter 0 */
  private JTextField        param0;
  /** the radial function parameter 1 */
  private JTextField        param1;
  /** the adaptable cluster shape (variances/covariances) */
  private JComboBox<String> shape;
  /** the flag for adaptable size */
  private JCheckBox         size;
  /** the flag for normalization to unit integral */
  private JCheckBox         uinteg;

  /* --- initialization --- */
  /** the initialization mode */
  private JComboBox<String> init;
  /** the random offset range */
  private JTextField        range;
  /** the initial cluster radius */
  private JTextField        radius;
  /** the seed for random numbers */
  private JTextField        seed;

  /* --- points --- */
  /** the maximum number of epochs */
  private JSpinner          epochs;
  /** the number of data points between updates */
  private JSpinner          ptcnt;
  /** the flag for data point shuffling */
  private JCheckBox         shuffle;
  /** the flag for mormalized input ranges */
  private JCheckBox         irnorm;

  /* --- update --- */
  /** the parameter update method */
  private JComboBox<String> update;
  /** the learning rate for the cluster centers */
  private JTextField        lrate0;
  /** the learning rate for the (co)variances */
  private JTextField        lrate1;
  /** the learning rate for the output weights */
  private JTextField        lrate2;
  /** the momentum term */
  private JTextField        moment;
  /** the growth factor for learning rate or weight change */
  private JTextField        growth;
  /** the shrink factor for learning rate or weight change */
  private JTextField        shrink;
  /** the minimal change of learning rate or weight change  */
  private JTextField        minchg;
  /** the maximal change of learning rate or weight change  */
  private JTextField        maxchg;
  /** the weight decay factor */
  private JTextField        decay;
  /** the maximum change for termination */
  private JTextField        term;

  /* --- regularization --- */
  /** the shape regularization parameter */
  private JTextField        rshape;
  /** the size regularization parameter 0 */
  private JTextField        rsize0;
  /** the size regularization parameter 1 */
  private JTextField        rsize1;
  /** the size regularization parameter 2 */
  private JTextField        rsize2;

  /* --- induction --- */
  /** the name of the domain file */
  private JTextField        fn_dom;
  /** the name of the target attribute */
  private JTextField        target;
  /** the name of the table file */
  private JTextField        fn_tab;
  /** the name of the network file */
  private JTextField        fn_rbf;

  /* --- execution --- */
  /** the name of the network file */
  private JTextField        fn_exec;
  /** the name of the table input file */
  private JTextField        fn_in;
  /** the name of the prediction field */
  private JTextField        pred;
  /** the name of the confidence field */
  private JTextField        conf;
  /** whether to write the field names to the first record */
  private JCheckBox         write;
  /** the name of the table output file */
  private JTextField        fn_out;

  /*------------------------------------------------------------------*/
  /** Create a radial basis function network GUI.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RBFGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a radial basis function network GUI.
   *  @param  owner the component that is to own this dialog
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RBFGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create a dec. tree toolbox */
    DialogPanel tab;            /* current tab of the tabbed pane */
    JPanel      bar;            /* bar of input fields */

    /* --- basic tabs --- */
    this.base("Radial Basis Function Network Tools");
    this.addFormatTab (FormatPanel.HEADER
                     | FormatPanel.WEIGHT
                     | FormatPanel.NONULLS);
    this.addDomainsTab(DomainsPanel.LOCATE);

    /* --- Neurons --- */
    tab = this.addTab("Neurons");

    tab.addLabel("Number of hidden neurons:");
    this.clscnt = tab.addSpinner(2, 1, 1000, 1);
    tab.addHelp("Each hidden neuron describes a cluster in the input "
               +"space,\nits output can be seen as a degree of "
               +"membership to this\ncluster. The network output is "
               +"a weighted sum of these\nmembership degrees.");

    tab.addLabel("Radial function:");
    this.radial = tab.addComboBox(RBFGUI.radnames);
    this.radial.setSelectedIndex(1);
    tab.addLabel("Function parameters:");
    this.param0 = tab.addNumberInput("2", DialogPanel.MIDDLE);
    this.param1 = tab.addNumberInput("1", DialogPanel.RIGHT);

    tab.addLabel("Adaptable shapes:");
    this.shape   = tab.addComboBox(RBFGUI.shapenames);
    tab.addLabel("Adaptable sizes:");
    this.size    = tab.addCheckBox(false);

    tab.addLabel("Normalize to unit integral:");
    this.uinteg  = tab.addCheckBox(false);
    tab.addHelp("This makes it possible to interpret each hidden "
               +"neuron\nas a description of a probability density "
               +"function.");
    tab.addFiller(0);

    /* --- Initialization --- */
    tab = this.addTab("Initialization");

    tab.addLabel("Initialization mode:");
    this.init = tab.addComboBox(RBFGUI.ininames);
    this.init.setSelectedIndex(4);
    tab.addHelp("The initial cluster centers are chosen randomly, "
               +"either by\nsampling from the given data set or "
               +"by sampling from a\ndistribution on (a subset) of "
               +"the data space");

    tab.addLabel("Random offset range:");
    this.range = tab.addNumberInput("");
    tab.addHelp("A random offset may be added to the initial "
               +"cluster centers\nin order to avoid equal centers "
               +"(e.g. mode \"center\").");

    tab.addLabel("(Initial) cluster size:");
    this.radius = tab.addNumberInput("1");
    tab.addHelp("Depending on the choice of the radial function, "
               +"the cluster\nsize may have an influence on the "
               +"training result.\nIf sizes are adaptable, "
               +"an initial cluster size is needed.");

    tab.addFiller(0);
    tab.addLabel("Seed for random numbers:");
    this.seed = tab.addNumberInput("");
    tab.addHelp("If no value is given, "
               +"the current time is used as a seed.");

    /* --- Patterns --- */
    tab = this.addTab("Patterns");

    tab.addLabel("Maximum update epochs:");
    this.epochs = tab.addSpinner(1000, 0, 999999, 1);

    tab.addLabel("Patterns between updates:");
    this.ptcnt = tab.addSpinner(0, 0, 999999, 1);
    tab.addHelp("If the number of patterns to be processed between "
               +"weight\nupdates is zero, weights are updated "
               +"once per traversal\nof the data set (epoch). "
               +"A value of 1 means online update.");

    tab.addLabel("Shuffle between epochs:");
    this.shuffle = tab.addCheckBox(true);
    tab.addHelp("If the number of patterns to be processed between "
               +"weight\nupdates is less than the number of available "
               +"patterns,\nshuffling is recommended to avoid order "
               +"effects.");

    tab.addLabel("Normalize input ranges:");
    this.irnorm = tab.addCheckBox(true);
    tab.addHelp("If this box is checked, all input attributes "
               +"are normalized\nto mean 0 and variance 1 "
               +"in order to avoid scaling effects.");
    tab.addFiller(0);

    /* --- Update --- */
    tab = this.addTab("Update");

    tab.addLabel("Update method:", DialogPanel.RIGHT);
    this.update = tab.addComboBox(RBFGUI.updnames);
    this.update.setSelectedIndex(0);
    tab.addFiller(1);

    tab.addLabel("Learning rates:");
    bar = new JPanel(new GridLayout(1, 3, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.lrate0 = DialogPanel.createNumberInput("0.02"));
    bar.add(this.lrate1 = DialogPanel.createNumberInput("0.01"));
    bar.add(this.lrate2 = DialogPanel.createNumberInput("0.001"));

    tab.addLabel("Momentum coefficient:");
    this.moment = tab.addNumberInput("");

    tab.addLabel("Growth and shrink factor:");
    this.growth = tab.addNumberInput("1.2", DialogPanel.MIDDLE);
    this.shrink = tab.addNumberInput("0.5", DialogPanel.RIGHT);

    tab.addLabel("Minimal/maximal change:");
    this.minchg = tab.addNumberInput("0", DialogPanel.MIDDLE);
    this.maxchg = tab.addNumberInput("2", DialogPanel.RIGHT);

    tab.addLabel("Weight decay factor:");
    this.decay = tab.addNumberInput("");
    tab.addHelp("Weight decay can improve the stability "
               +"of training results.");

    tab.addLabel("Change for termination:");
    this.term = tab.addNumberInput("");
    tab.addHelp("If the changes of the center coordinates and those "
               +"of\nthe output connection weights do not exceed "
               +"this value,\nthe weight update is terminated.");
    tab.addFiller(0);

    /* --- Regularization --- */
    tab = this.addTab("Regularization");

    tab.addLabel("Shape regularization:");
    this.rshape = tab.addNumberInput("0");
    tab.addHelp("Cluster shape regularization introduces a tendency "
               +"towards\nspherical clusters (positive value) or "
               +"limits the length ratio\nof the longest to the "
               +"shortest major axis (negative value).");

    tab.addLabel("Size regularization:");
    bar = new JPanel(new GridLayout(1, 3, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.rsize0 = DialogPanel.createNumberInput("0"));
    this.rsize0.setFont(DialogPanel.BOLD);
    bar.add(this.rsize1 = DialogPanel.createNumberInput("1"));
    this.rsize1.setFont(DialogPanel.BOLD);
    bar.add(this.rsize2 = DialogPanel.createNumberInput("1"));
    this.rsize2.setFont(DialogPanel.BOLD);
    tab.addHelp("Cluster size regularization introduces a tendency "
               +"towards\nequally sized clusters (positive value) "
               +"or limits the size ratio\nof the largest to the "
               +"smallest cluster radius (negative value).");

    tab.addFiller(16);
    tab.addHelp("Regularization is performed after each update step.");
    tab.addFiller(0);

    /* --- Induction --- */
    tab = this.addTab("Induction");

    tab.addLabel("Domains file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.getFileName(RBFGUI.this.fn_dom); } } );
    tab.addButton("Edit", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.editDomains(RBFGUI.this.fn_dom); } } );
    this.fn_dom = tab.addFileInput("noname.dom");
    tab.addHelp("The domains file may also be a cluster model "
               +"containing the\ndescription of a clustering "
               +"of the data. Note, however, that\nin addition "
               +"to the cluster model a description of the domain\n"
               +"of the target attribute must be present.");

    tab.addLabel("Target attribute:          ");
    this.target = tab.addTextInput("");
    tab.addHelp("If no target attribute is specified, the one listed "
               +"last in the\ndomains file is used. The type of the "
               +"target attribute and\nthus the network type is "
               +"determined from the domains file.");

    tab.addLabel("Training data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.getFileName(RBFGUI.this.fn_tab); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.showTable(RBFGUI.this.fn_tab); } } );
    this.fn_tab = tab.addFileInput("noname.tab");

    tab.addLabel("Output network file:    ");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.getFileName(RBFGUI.this.fn_rbf); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.showRBF(RBFGUI.this.fn_rbf,
                                    RBFGUI.this.fn_tab); } } );
    this.fn_rbf = tab.addFileInput("noname.rbf");
    tab.addFiller(0);

    /* --- RBF model execution --- */
    tab = this.addTab("Execution");

    tab.addLabel("Network file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.getFileName(RBFGUI.this.fn_exec); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.showRBF(RBFGUI.this.fn_exec,
                            RBFGUI.this.fn_in); } } );
    this.fn_exec = tab.addFileInput("noname.rbf");

    tab.addLabel("Input data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.getFileName(RBFGUI.this.fn_in); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.showTable(RBFGUI.this.fn_in); } } );
    this.fn_in = tab.addFileInput("noname.tab");

    tab.addLabel("Prediction field name:");
    this.pred = tab.addTextInput("mlp");
    tab.addLabel("Confidence field name:");
    this.conf = tab.addTextInput("");
    tab.addHelp("The confidence indicates how reliable "
               +"the prediction is.\nIt is derived from the "
               +"activations of the output neurons.");

    tab.addLabel("Write field names:");
    this.write = tab.addCheckBox(true);

    tab.addLabel("Output data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.getFileName(RBFGUI.this.fn_out); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RBFGUI.this.showTable(RBFGUI.this.fn_out); } } );
    this.fn_out = tab.addFileInput("noname.out");
    tab.addFiller(0);

    /* --- Terminal --- */
    this.addTerminalTab("Terminal output of external programs");

    /* --- About --- */
    this.addTab("About", new AboutPanel(
       "Radial Basis Function Network Tools",
       "A simple user interface for the RBF programs.\n\n"
      +"Version " +RBFGUI.VERSION +"\n"
      +"written by Christian Borgelt\n"
      +"European Center for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.pack();
    this.selectTab(INDUCTION);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  {                             /* --- set the domains file */
    this.domains.setDomainsFile(file);
    this.fn_dom.setText(file.getPath());
  }  /* setDomainsFile() */

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  {                             /* --- set the data file */
    this.domains.setDataFile(file);
    this.fn_tab.setText(file.getPath());
  }  /* setDataFile() */

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  { this.fn_in.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Show a RBF model.
   *  @param  model the text field with the RBF model file name
   *  @param  data  the text field with the data file name
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showRBF (JTextField model, JTextField data)
  { this.showRBF(new File(model.getText()),
                     new File( data.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a RBF model.
   *  @param  model the file to load the RBF model tree from
   *  @param  data  the file to load the table data from
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showRBF (File model, File data)
  {                             /* --- show a RBF model */
    String cmd[] = new String[3];
    cmd[0] = System.getProperty("os.name").startsWith("Windows")
           ? "wbcview" : "xbcview";
    cmd[1] = model.getPath();
    cmd[2] = data.getPath();
    try { Runtime.getRuntime().exec(cmd); }
    catch (IOException e) {     /* try to start the process */
      System.err.println(e.getMessage()); }
  }  /* showRBF() */

  /*------------------------------------------------------------------*/
  /** Create a command to induce a Bayes classifier.
   *  @return the command to inducea Bayes classifier
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createInductionCmd ()
  {                             /* --- induce a Bayes classifier */
    int      n = 0, i;          /* number of arguments, buffer */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s, p, q;           /* buffers for arguments */

    cmd    = new String[48];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"rbft";
    n = this.format.addFormatArgs(cmd);
    cmd[n++] = "-c" +this.clscnt.getValue();
                                /* number of RBFs */
    if (this.radial.getSelectedIndex() <= 0)
      cmd[n++] = "-Y";          /* radial function type */
    s = this.param0.getText().trim(); if (s.length() <= 0) s = "1";
    p = this.param1.getText().trim(); if (p.length() <= 0) p = "0";
    cmd[n++] = "-p" +s +":" +p; /* radial function parameters */
    i = this.shape.getSelectedIndex();
    if      (i == 1) cmd[n++] = "-v";  /* adaptable variances */
    else if (i == 2) cmd[n++] = "-V";  /* adaptable covariances */
    if (this.size.isSelected())
      cmd[n++] = "-Z";          /* adaptable size */
    if (this.uinteg.isSelected())
      cmd[n++] = "-N";          /* normalize to unit integral */
    i = this.init.getSelectedIndex();  /* initialization mode */
    cmd[n++] = "-i" +RBFGUI.inicodes[i];
    s = this.range.getText().trim();   /* random offset range */
    if (s.length() > 0) cmd[n++] = "-w" +s;
    s = this.radius.getText().trim();  /* initial RBF radius */
    if (s.length() > 0) cmd[n++] = "-I" +s;
    s = this.seed.getText().trim();    /* seed for random numbers */
    if (s.length() > 0) cmd[n++] = "-S" +s;
    cmd[n++] = "-e" +this.epochs.getValue();
                                /* maximum number of epochs */
    cmd[n++] = "-k" +this.ptcnt.getValue();
                                /* number of points between updates */
    if (!this.shuffle.isSelected())
      cmd[n++] = "-s";          /* do not shuffle between updates */
    if (!this.irnorm.isSelected())
      cmd[n++] = "-q";          /* normalize input ranges */
    i = this.update.getSelectedIndex();  /* update method */
    cmd[n++] = "-a" +RBFGUI.updcodes[i];
    s = this.lrate0.getText().trim(); if (s.length() <= 0) s = "0";
    p = this.lrate1.getText().trim(); if (p.length() <= 0) p = "0";
    q = this.lrate2.getText().trim(); if (q.length() <= 0) q = "0";
    cmd[n++] = "-t" +s +":" +p +":" +q;  /* learning rates */
    s = this.moment.getText();  /* momentum coefficient */
    if (s.length() > 0) cmd[n++] = "-m" +s;
    s = this.growth.getText().trim(); if (s.length() <= 0) s = "1";
    p = this.shrink.getText().trim(); if (p.length() <= 0) p = "1";
    cmd[n++] = "-g" +s +":" +p; /* growth and shrink factor */
    s = this.minchg.getText().trim(); if (s.length() <= 0) s = "0";
    p = this.maxchg.getText().trim(); if (p.length() <= 0) p = "2";
    cmd[n++] = "-z" +s +":" +p; /* growth and shrink factor */
    s = this.decay.getText().trim();   /* weight decay factor */
    if (s.length() > 0) cmd[n++] = "-y" +s;
    s = this.term.getText().trim();    /* change for termination */
    if (s.length() > 0) cmd[n++] = "-T" +s;
    s = this.rshape.getText().trim();  /* shape regularization */
    if (s.length() > 0) cmd[n++] = "-H" +s;
    s = this.rsize0.getText().trim(); if (s.length() <= 0) s = "0";
    p = this.rsize1.getText().trim(); if (p.length() <= 0) p = "1";
    q = this.rsize2.getText().trim(); if (q.length() <= 0) q = "1";
    cmd[n++] = "-R" +s +":" +p +":" +q;  /* size regularization */
    s = this.target.getText();  /* target attribute to exclude */
    if (s.length() > 0) cmd[n++] = "-o" +s;
    cmd[n++] = this.fn_dom.getText();
    cmd[n++] = this.fn_tab.getText();
    cmd[n++] = this.fn_rbf.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createInductionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a command to execute a multilayer perceptron.
   *  @return the command to execute a multilayer perceptron
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createExecutionCmd ()
  {                             /* --- execute a Bayes classifier */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[20];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"rbfx";
    n = this.format.addFormatArgs(cmd);
    s = this.pred.getText();    /* prediction field name */
    if (s.length() > 0) cmd[n++] = "-p" +s;
    s = this.conf.getText();    /* confidence field name */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    if (!this.write.isSelected())
      cmd[n++] = "-w";          /* do not write field names */
    cmd[n++] = this.fn_exec.getText();
    cmd[n++] = this.fn_in.getText();
    cmd[n++] = this.fn_out.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createExecutionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Get command for the current dialog tab.
   *  @return the command to execute
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- get a dialog tab executor */
    String[]   cmd;             /* command for external program */
    Executable obj;             /* executable object */

    if (this.domains.useExternal()) {
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS  : cmd = this.createDomainsCmd();     break;
        case NEURONS  : case INIT: case PATTERNS:
        case UPDATE   : case REGULAR:
        case INDUCTION: cmd = this.createInductionCmd();   break;
        case EXECUTION: cmd = this.createExecutionCmd();   break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new CmdExecutor(cmd, this); }
    else {                      /* if to use internal programs */
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS: obj = this.createDomainsObj(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new ObjExecutor(obj, this);
    }                           /* create and return the executor */
  }  /* createExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    int    i, k;                /* index variables */
    String txt, msg;            /* buffers for text and message */

    if (this.index == DOMAINS)  /* if domain determination */
      return this.getDomainsMsg();
    if ((this.index >= NEURONS) /* ifnetwork training */
    &&  (this.index <= INDUCTION)) {
      txt = ((CmdExecutor)this.executor).getErrorData();
      i   = txt.indexOf("[", txt.lastIndexOf("creating network ... ["));
      k   = txt.indexOf(",", i);
      msg = txt.substring(i+1, k);
      i   = txt.indexOf("]", k);
      msg = msg +" and" +txt.substring(k+1, i);
      i   = txt.lastIndexOf("[");
      k   = txt.indexOf("]", i);
      return "Trained radial basis function network\nhas "
          + msg +"\n" +txt.substring(i, k+1) +".";
    }                           /* extract network description */
    if (this.index == EXECUTION) {  /* if network execution */
      msg = ((CmdExecutor)this.executor).getLastErrorLine();
      return "RBF network execution leads to\n" +msg +".";
    }                           /* extract error information */
    return null;                /* otherwise there is no message */
  }  /* getResultMsg() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  {                             /* --- load configuration file */
    if (file == null) {         /* if no file name is given */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Load Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileReader reader = new FileReader(file);
      /* --- Format & Domains --- */
      this.format.loadConfig(reader);
      this.domains.loadConfig(reader);
      /* --- text parameters --- */
      /* --- Neurons --- */
      this.param0.setText (this.readLine(reader));
      this.param1.setText (this.readLine(reader));
      /* --- Initialization --- */
      this.range.setText  (this.readLine(reader));
      this.radius.setText (this.readLine(reader));
      this.seed.setText   (this.readLine(reader));
      /* --- Patterns --- */
      /* --- Update --- */
      this.lrate0.setText (this.readLine(reader));
      this.lrate1.setText (this.readLine(reader));
      this.lrate2.setText (this.readLine(reader));
      this.moment.setText (this.readLine(reader));
      this.growth.setText (this.readLine(reader));
      this.shrink.setText (this.readLine(reader));
      this.minchg.setText (this.readLine(reader));
      this.maxchg.setText (this.readLine(reader));
      this.decay.setText  (this.readLine(reader));
      this.term.setText   (this.readLine(reader));
      /* --- Regularization --- */
      this.rshape.setText (this.readLine(reader));
      this.rsize0.setText (this.readLine(reader));
      this.rsize1.setText (this.readLine(reader));
      this.rsize2.setText (this.readLine(reader));
      /* --- Induction --- */
      this.fn_dom.setText (this.readLine(reader));
      this.fn_tab.setText (this.readLine(reader));
      this.fn_rbf.setText (this.readLine(reader));
      this.target.setText (this.readLine(reader));
      /* --- Execution --- */
      this.fn_exec.setText(this.readLine(reader));
      this.fn_in.setText  (this.readLine(reader));
      this.fn_out.setText (this.readLine(reader));
      this.pred.setText   (this.readLine(reader));
      this.conf.setText   (this.readLine(reader));
      /* --- flags and indices --- */
      /* --- Neurons --- */
      this.clscnt.setValue(Integer.valueOf(this.readInt(reader)));
      this.radial.setSelectedIndex(this.readInt(reader));
      this.shape.setSelectedIndex (this.readInt(reader));
      this.size.setSelected   (this.readInt(reader) != 0);
      this.uinteg.setSelected (this.readInt(reader) != 0);
      /* --- Initialization --- */
      this.init.setSelectedIndex  (this.readInt(reader));
      /* --- Patterns --- */
      this.epochs.setValue(Integer.valueOf(this.readInt(reader)));
      this.ptcnt.setValue (Integer.valueOf(this.readInt(reader)));
      this.shuffle.setSelected(this.readInt(reader) != 0);
      this.irnorm.setSelected (this.readInt(reader) != 0);
      /* --- Update --- */
      this.update.setSelectedIndex(this.readInt(reader));
      /* --- Regularization --- */
      /* --- Execution --- */
      this.write.setSelected  (this.readInt(reader) != 0);
      reader.close(); }         /* read the configuration values */
    catch (IOException e) {     /* and close the input file */
      JOptionPane.showMessageDialog(this,
        "Error reading configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* check for successful reading */
    this.status.setText("configuration loaded: " +file.getName());
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  {                             /* --- save configuration file */
    if (file == null) {         /* if no file name is given, */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Save Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileWriter writer = new FileWriter(file);
      /* --- Format & Domains --- */
      this.format.saveConfig(writer);
      this.domains.saveConfig(writer);
      /* --- text parameters --- */
      /* --- Neurons --- */
      writer.write(this.param0.getText());  writer.write('\n');
      writer.write(this.param1.getText());  writer.write('\n');
      /* --- Initialization --- */
      writer.write(this.range.getText());   writer.write('\n');
      writer.write(this.radius.getText());  writer.write('\n');
      writer.write(this.seed.getText());    writer.write('\n');
      /* --- Patterns --- */
      /* --- Update --- */
      writer.write(this.lrate0.getText());  writer.write('\n');
      writer.write(this.lrate1.getText());  writer.write('\n');
      writer.write(this.lrate2.getText());  writer.write('\n');
      writer.write(this.moment.getText());  writer.write('\n');
      writer.write(this.growth.getText());  writer.write('\n');
      writer.write(this.shrink.getText());  writer.write('\n');
      writer.write(this.minchg.getText());  writer.write('\n');
      writer.write(this.maxchg.getText());  writer.write('\n');
      writer.write(this.decay.getText());   writer.write('\n');
      writer.write(this.term.getText());    writer.write('\n');
      /* --- Regularization --- */
      writer.write(this.rshape.getText());  writer.write('\n');
      writer.write(this.rsize0.getText());  writer.write('\n');
      writer.write(this.rsize1.getText());  writer.write('\n');
      writer.write(this.rsize2.getText());  writer.write('\n');
      /* --- Induction --- */
      writer.write(this.fn_dom.getText());  writer.write('\n');
      writer.write(this.fn_tab.getText());  writer.write('\n');
      writer.write(this.fn_rbf.getText());  writer.write('\n');
      writer.write(this.target.getText());  writer.write('\n');
      /* --- Execution --- */
      writer.write(this.fn_exec.getText()); writer.write('\n');
      writer.write(this.fn_in.getText());   writer.write('\n');
      writer.write(this.fn_out.getText());  writer.write('\n');
      writer.write(this.pred.getText());    writer.write('\n');
      writer.write(this.conf.getText());    writer.write('\n');
      /* --- flags and indices --- */
      /* --- Neurons --- */
      writer.write(((Integer)this.clscnt.getValue()).intValue() +",");
      writer.write(this.radial.getSelectedIndex() +",");
      writer.write(this.shape.getSelectedIndex()  +",");
      writer.write(this.size.isSelected()    ? "1," : "0,");
      writer.write(this.uinteg.isSelected()  ? "1," : "0,");
      /* --- Initialization --- */
      writer.write(this.init.getSelectedIndex()   +",");
      /* --- Patterns --- */
      writer.write(((Integer)this.epochs.getValue()).intValue() +",");
      writer.write(((Integer)this.ptcnt.getValue()).intValue()  +",");
      writer.write(this.shuffle.isSelected() ? "1," : "0,");
      writer.write(this.irnorm.isSelected()  ? "1," : "0,");
      /* --- Update --- */
      writer.write(this.update.getSelectedIndex() +",");
      /* --- Regularization --- */
      /* --- Execution --- */
      writer.write(this.write.isSelected()   ? "1," : "0,");
      writer.write('\n');       /* write the configuration values */
      writer.close(); }         /* and close the output file */
    catch (IOException e) {     /* check for successful writing */
      JOptionPane.showMessageDialog(this,
        "Error writing configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show a status message */
    this.status.setText("configuration saved: " +file.getName());
  }  /* saveConfig() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    RBFGUI gui = new RBFGUI();  /* create an RBF user interface */
    if (args.length > 0)        /* load configuration if necessary */
      gui.loadConfig(new File(args[0]));
    gui.setVisible(true);       /* show the user interface */
  }  /* main() */

}  /* class RBFGUI */
