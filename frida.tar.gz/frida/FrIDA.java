/*----------------------------------------------------------------------
  File    : FrIDA.java
  Contents: Free Intelligent Data Analysis Toolbox
  Author  : Christian Borgelt
  History : 2007.02.12 file created
            2007.03.12 association rule toolbox added
            2007.07.07 adapted to new class DialogPanel
            2007.07.09 MoSS added (molecular substructure mining)
            2007.07.19 adapted to changed Table class
            2007.07.25 domain finder dialog added
            2007.10.17 bug in format panel handling fixed
            2014.04.01 menu entry for C program location added
            2014.09.25 tabs distinguishing different data types added
            2014.10.23 changed from LGPL license to MIT license
            2016.11.04 adapted to Pattern, PatternSet, PatternView etc.
----------------------------------------------------------------------*/
package frida;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.awt.Component;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JFileChooser;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.FormatDialog;
import dialog.DomainsDialog;
import dialog.AboutDialog;
import dialog.MiniEditor;

import bayes.BayesGUI;
import regress.RegGUI;
import dtree.DTreeGUI;
import mlp.MLPGUI;
import rbf.RBFGUI;
import cluster.ClusterGUI;
import fim.TrActView;
import fim.PatternView;
import fim.ARuleView;
import fim.FIMGUI;
import fim.ARuleGUI;
import moss.MoSS;
import moss.MoSSTable;

/*--------------------------------------------------------------------*/
/** Class for FrIDA - the Free Intelligent Data Analysis Toolbox.
 *  @author Christian Borgelt
 *  @since  2007.02.12 */
/*--------------------------------------------------------------------*/
public class FrIDA extends JFrame implements Runnable, ChangeListener {

  private static final long serialVersionUID = 0x0001000eL;
  public  static final String VERSION = "1.14 (2016.11.04)";

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the main tabbed pane */
  private JTabbedPane    pane       = null;
  /** the status line (for messages) */
  private JTextField     status     = null;

  /** the menu item for the format dialog */
  private JMenuItem      mi_format  = null;
  /** the menu item for the domains dialog */
  private JMenuItem      mi_domains = null;
  /** the menu item for Bayes classifiers */
  private JMenuItem      mi_bayes   = null;
  /** the menu item for decision trees */
  private JMenuItem      mi_dtree   = null;
  /** the menu item for multivariate polynomial regression */
  private JMenuItem      mi_regress = null;
  /** the menu item for multilayer perceptrons */
  private JMenuItem      mi_mlp     = null;
  /** the menu item for radial basis function networks */
  private JMenuItem      mi_rbf     = null;
  /** the menu item for fuzzy and probabilistic clustering */
  private JMenuItem      mi_cluster = null;
  /** the menu item for frequent item set mining */
  private JMenuItem      mi_fim     = null;
  /** the menu item for association rule mining */
  private JMenuItem      mi_arules  = null;
  /** the menu item for molecular substructure mining */
  private JMenuItem      mi_moss    = null;

  /** the panel for tabular data */
  private DialogPanel    table    = null;
  /** the file name of the domains file */
  private JTextField     fn_dom   = null;
  /** the file name of the data table file */
  private JTextField     fn_tab   = null;
  /** the file name of the test data file */
  private JTextField     fn_test  = null;

  /** the panel for transaction data */
  private DialogPanel    trans    = null;
  /** the file name of the transactions file */
  private JTextField     fn_tra   = null;
  /** the file name of the rules file */
  private JTextField     fn_out   = null;
  /** the file name of the item appearances file */
  private JTextField     fn_app   = null;

  /** the panel for graph data */
  private DialogPanel    graphs   = null;
  /** the file name of the graphs input file */
  private JTextField     fn_gra   = null;
  /** the file name of the substructure output file */
  private JTextField     fn_sub   = null;
  /** the file name of the identifier output file */
  private JTextField     fn_ids   = null;

  /* --- dialog boxes --- */
  /** the data format dialog box */
  private FormatDialog   format   = null;
  /** the domains dialog box */
  private DomainsDialog  domains  = null;
  /** the "About..." dialog box */
  private AboutDialog    about    = null;

  /* --- tools --- */
  /** the array of tools */
  private Component[]    tools   = null;
  /** the array of classes of tools */
  private static Class<?>[] classes = {
    bayes.BayesGUI.class,
    dtree.DTreeGUI.class,
    regress.RegGUI.class,
    mlp.MLPGUI.class,
    rbf.RBFGUI.class,
    cluster.ClusterGUI.class,
    fim.ARuleGUI.class,
    moss.MoSS.class };

  /** the Bayes classifier tools */
  private BayesGUI       bayes    = null;
  /** the decision and regression tree tools */
  private DTreeGUI       dtree    = null;
  /** the multivariate polynomial regression tools */
  private RegGUI         regress  = null;
  /** the multilayer perceptron tools */
  private MLPGUI         mlp      = null;
  /** the radial basis function network tools */
  private RBFGUI         rbf      = null;
  /** the fuzzy and probabilistic clustering tools */
  private ClusterGUI     cluster  = null;
  /** the frequent item set mining tools */
  private FIMGUI         fim      = null;
  /** the association rule mining tools */
  private ARuleGUI       arules   = null;
  /** the molecular substructure mining tools */
  private MoSS           moss     = null;

  /** the file chooser */
  protected JFileChooser chooser  = null;
  /** the path to the C programs */
  protected File         path     = null;

  /*------------------------------------------------------------------*/
  /** Create a FrIDA main window.
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FrIDA ()
  {                             /* --- create a FrIDA frame */
    this.tools = new Component[classes.length];
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* FrIDA() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create a FrIDA main window */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    /* --- configure and show the frame window --- */
    this.setTitle("FrIDA");
    this.setLocation(48, 48);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());
    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    item = menu.add(new JMenuItem("Locate Programs...", 'p'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        JFileChooser c = FrIDA.this.getFileChooser();
          c.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
          c.setDialogTitle("Locate Program...");
          if (FrIDA.this.path != null)
            c.setCurrentDirectory(FrIDA.this.path);
          int r = c.showOpenDialog(FrIDA.this);
          if (r == JFileChooser.APPROVE_OPTION)
            FrIDA.this.setPath(c.getSelectedFile());
      } } );
    menu.addSeparator();
    this.mi_format = menu.add(new JMenuItem("Data Format...", 'f'));
    this.mi_format.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getFormatDialog().setVisible(true);
        FrIDA.this.format.toFront();
      } } );
    menu.addSeparator();
    this.mi_domains = menu.add(new JMenuItem("Domains...", 'd'));
    this.mi_domains.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DomainsDialog dlg = FrIDA.this.getDomainsDialog();
        dlg.setDataFile   (new File(FrIDA.this.fn_tab.getText()));
        dlg.setDomainsFile(new File(FrIDA.this.fn_dom.getText()));
        dlg.setVisible(true); dlg.toFront();
      } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Quit", 'q'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        System.exit(0); } } );

    menu = mbar.add(new JMenu("Tools"));
    menu.setMnemonic('t');
    this.mi_bayes = menu.add(
      new JMenuItem("Naive/Full Bayes Classifiers...", 'b'));
    this.mi_bayes.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getBayesGUI().setVisible(true);
        FrIDA.this.bayes.toFront();
      } } );
    this.mi_dtree = menu.add(
      new JMenuItem("Decision/Regression Trees...", 't'));
    this.mi_dtree.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getDTreeGUI().setVisible(true);
        FrIDA.this.dtree.toFront();
      } } );
    this.mi_regress = menu.add(
      new JMenuItem("Linear/Polynomial Regression...", 'r'));
    this.mi_regress.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getRegGUI().setVisible(true);
        FrIDA.this.regress.toFront();
      } } );
    this.mi_mlp = menu.add(
      new JMenuItem("Multilayer Perceptrons...", 'p'));
    this.mi_mlp.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getMLPGUI().setVisible(true);
        FrIDA.this.mlp.toFront();
      } } );
    this.mi_rbf = menu.add(
      new JMenuItem("Radial Basis Function Networks...", 'n'));
    this.mi_rbf.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getRBFGUI().setVisible(true);
        FrIDA.this.rbf.toFront();
      } } );
    this.mi_cluster = menu.add(
      new JMenuItem("Fuzzy/Probabilistic Clustering...", 'c'));
    this.mi_cluster.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getClusterGUI().setVisible(true);
        FrIDA.this.cluster.toFront();
      } } );
    this.mi_fim = menu.add(
      new JMenuItem("Frequent Item Sets...", 'i'));
    this.mi_fim.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getFIMGUI().setVisible(true);
        FrIDA.this.fim.toFront();
      } } );
    this.mi_arules = menu.add(
      new JMenuItem("Association Rules...", 'a'));
    this.mi_arules.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getARuleGUI().setVisible(true);
        FrIDA.this.arules.toFront();
      } } );
    this.mi_moss = menu.add(
      new JMenuItem("Molecular Substructure Mining...", 'm'));
    this.mi_moss.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.getMoSS().setVisible(true);
        FrIDA.this.moss.toFront();
      } } );

    //menu = mbar.add(new JMenu("Tools"));
    //menu.setMnemonic('t');
    //for (int i = 0; i < FrIDA.classes.length; i++) {
    //  item = menu.add(new JMenuItem(FrIDA.classes[i].getName()));
    //  item.addActionListener(new ActionListener() {
    //    public void actionPerformed (ActionEvent e) {
    //      System.err.println(e.getActionCommand());
    //    } } );
    //}

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (FrIDA.this.about == null)
          FrIDA.this.about = new AboutDialog(FrIDA.this,
             "About FrIDA...", "FrIDA\n"
            +"Free Intelligent Data Analysis Toolbox\n"
            +"Version " +FrIDA.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        FrIDA.this.about.setVisible(true);
        FrIDA.this.about.toFront();
      } } );

    /* --- create the tabbled pane with a status bar --- */
    this.pane = new JTabbedPane(JTabbedPane.TOP,
                                JTabbedPane.SCROLL_TAB_LAYOUT);
    this.getContentPane().add(this.pane, BorderLayout.CENTER);
    this.status = new JTextField(
      "Free Intelligent Data Analysis Toolbox");
    this.status.setEditable(false);
    this.getContentPane().add(this.status, BorderLayout.SOUTH);

    /* --- create and set the table panel --- */
    this.table = new DialogPanel();
    this.pane.addTab("Table", this.table);

    /* --- domains file --- */
    this.table.addLabel("Domains file:");
    this.table.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.table.getFileName(FrIDA.this.fn_dom);
        FrIDA.this.setDomainsFile(null); } } );
    this.table.addButton("Edit", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.table.editDomains(FrIDA.this.fn_dom); } } );
    this.fn_dom = this.table.addFileInput("noname.dom");

    /* --- data table file --- */
    this.table.addLabel("Data table file:");
    this.table.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.table.getFileName(FrIDA.this.fn_tab);
        FrIDA.this.setTableFile(null); } } );
    this.table.addButton("View", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.table.showTable(FrIDA.this.fn_tab,
                                   FrIDA.this.getFormat()); } } );
    this.fn_tab = this.table.addFileInput("noname.tab");

    /* --- test data file --- */
    this.table.addLabel("Test data file:");
    this.table.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.table.getFileName(FrIDA.this.fn_test);
        FrIDA.this.setTestFile(null); } } );
    this.table.addButton("View", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.table.showTable(FrIDA.this.fn_test,
                                   FrIDA.this.getFormat()); } } );
    this.fn_test = this.table.addFileInput("noname.tab");

    /* --- create and set the transactions panel --- */
    this.trans = new DialogPanel();
    this.pane.addTab("Transactions", this.trans);

    /* --- transactions file --- */
    this.trans.addLabel("Transactions file:");
    this.trans.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.trans.getFileName(FrIDA.this.fn_tra);
        FrIDA.this.setTrActsFile(null); } } );
    this.trans.addButton("View", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.showTrActs(FrIDA.this.fn_tra); } } );
    this.fn_tra = this.trans.addFileInput("noname.tra");

    /* --- rule output file --- */
    this.trans.addLabel("Output file:");
    this.trans.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.trans.getFileName(FrIDA.this.fn_out);
        FrIDA.this.setOutputFile(null); } } );
    this.trans.addButton("View", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.showPatsOrRules(FrIDA.this.fn_out); } } );
    this.fn_out = this.trans.addFileInput("noname.fis");
    this.trans.addFiller(0);

    /* --- item appearances file --- */
    this.trans.addLabel("Item apps. file:");
    this.trans.addButton("Select", DialogPanel.MIDDLE)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.trans.getFileName(FrIDA.this.fn_app);
        FrIDA.this.setItemAppFile(null); } } );
    this.trans.addButton("Edit", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        String     fn = FrIDA.this.fn_app.getText();
        if (fn.length() <= 0) return;
        MiniEditor ed = new MiniEditor(0);
        ed.loadText(new File(fn));
        ed.setVisible(true);
      } } );
    this.fn_app = this.trans.addFileInput("");

    /* --- create and set the graphs panel --- */
    this.graphs = new DialogPanel();
    this.pane.addTab("Graphs", this.graphs);

    /* --- graphs input file --- */
    this.graphs.addLabel("Graphs/molecules file:");
    this.graphs.addButton("Select", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.graphs.getFileName(FrIDA.this.fn_gra);
        FrIDA.this.setGraphsFile(null); } } );
    this.fn_gra = this.graphs.addFileInput("noname.gra");

    /* --- substructure output file --- */
    this.graphs.addLabel("Substructure output file:");
    this.graphs.addButton("Select", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.graphs.getFileName(FrIDA.this.fn_sub);
        FrIDA.this.setSubsFile(null); } } );
    this.fn_sub = this.graphs.addFileInput("noname.sub");

    /* --- identifier output file file --- */
    this.graphs.addLabel("Identifier output file:");
    this.graphs.addButton("Select", DialogPanel.RIGHT)
      .addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        FrIDA.this.graphs.getFileName(FrIDA.this.fn_ids);
        FrIDA.this.setIdsFile(null); } } );
    this.fn_ids = this.graphs.addFileInput("");

    this.pane.addChangeListener(this);
    this.pane.setSelectedIndex(1);
    this.pane.setSelectedIndex(0);
    this.pack();
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Context sensitive tools menu.
   *  @param  e the action event to evaluate
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void stateChanged (ChangeEvent e)
  {                             /* --- context sensitive tools menu */
    int i = this.pane.getSelectedIndex();
    this.mi_format.setEnabled(i != 2);
    this.mi_domains.setEnabled(i == 0);
    this.mi_bayes.setEnabled(i == 0);
    this.mi_dtree.setEnabled(i == 0);
    this.mi_regress.setEnabled(i == 0);
    this.mi_mlp.setEnabled(i == 0);
    this.mi_rbf.setEnabled(i == 0);
    this.mi_cluster.setEnabled(i == 0);
    this.mi_fim.setEnabled(i == 1);
    this.mi_arules.setEnabled(i == 1);
    this.mi_moss.setEnabled(i == 2);
  }  /* actionPerfomed() */

  /*------------------------------------------------------------------*/
  /** Get the data format panel.
   *  @return the data format panel
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel getFormat ()
  { return this.getFormatDialog().getPanel(); }

  /*------------------------------------------------------------------*/
  /** Set the data format.
   *  @param  format the data format panel describing the format
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFormat (FormatPanel format)
  {                             /* --- set the data format */
    FormatPanel f = this.getFormat();
    if (format != f) f.copyFrom(format);
    if (this.bayes   != null) this.bayes.setFormat  (format);
    if (this.dtree   != null) this.dtree.setFormat  (format);
    if (this.regress != null) this.regress.setFormat(format);
    if (this.mlp     != null) this.mlp.setFormat    (format);
    if (this.rbf     != null) this.rbf.setFormat    (format);
    if (this.cluster != null) this.cluster.setFormat(format);
    if (this.fim     != null) this.fim.setFormat    (format);
    if (this.arules  != null) this.arules.setFormat (format);
  }  /* setFormat() */

  /*------------------------------------------------------------------*/
  /** Get the path to the C programs.
   *  @return the path to the C programs
   *  @since  2014.04.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public File getPath ()
  { return this.path; }

  /*------------------------------------------------------------------*/
  /** Set the path to the C programs.
   *  @param  path the path to the C programs
   *  @since  2014.04.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPath (File path)
  {                             /* --- set the data format */
    this.path = path;           /* note and propagate the path */
    if (this.bayes   != null) this.bayes.setPath  (path);
    if (this.dtree   != null) this.dtree.setPath  (path);
    if (this.regress != null) this.regress.setPath(path);
    if (this.mlp     != null) this.mlp.setPath    (path);
    if (this.rbf     != null) this.rbf.setPath    (path);
    if (this.cluster != null) this.cluster.setPath(path);
    if (this.fim     != null) this.fim.setPath    (path);
    if (this.arules  != null) this.arules.setPath (path);
  }  /* setPath() */

  /*------------------------------------------------------------------*/
  /** Get the data format dialog (create if necessary).
   *  @return the data format dialog
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private FormatDialog getFormatDialog ()
  {                             /* --- get the data format dialog */
    if (this.format == null) {  /* if it does not exist, create it */
      this.format = new FormatDialog(this);
      this.format.addActionListener(new ActionListener () {
        public void actionPerformed (ActionEvent e) {
          FrIDA.this.setFormat(FrIDA.this.getFormat()); } } );
    }                           /* set the listener for approval */
    return this.format;         /* return the data format dialog */
  }  /* getFormatDialog() */

  /*------------------------------------------------------------------*/
  /** Get the data format dialog (create if necessary).
   *  @return the data format dialog
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private DomainsDialog getDomainsDialog ()
  {                             /* --- get the domains dialog */
    if (this.domains == null) { /* if it does not exist, create it */
      this.domains = new DomainsDialog(this);
      this.domains.setFormat(this.getFormat());
    }                           /* set the data format panel */
    return this.domains;        /* return the domains dialog */
  }  /* getDomainsDialog() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser.
   *  @return the file chooser
   *  @since  2014.04.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure the chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Get Bayes classifier graphical user interface.
   *  @return the created Bayes classifier graphical user interface
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private BayesGUI getBayesGUI ()
  {                             /* --- get Bayes classifier GUI */
    if (this.bayes != null)     /* if it already exists, return it, */
      return this.bayes;        /* otherwise create and configure it */
    this.bayes = new BayesGUI(this);
    this.bayes.setPath       (this.path);
    this.bayes.setFormat     (this.getFormat());
    this.bayes.setDomainsFile(new File(this.fn_dom.getText()));
    this.bayes.setDataFile   (new File(this.fn_tab.getText()));
    this.bayes.setTestFile   (new File(this.fn_test.getText()));
    return this.bayes;          /* return the created GUI */
  }  /* getBayesGUI() */

  /*------------------------------------------------------------------*/
  /** Get decision and regression tree graphical user interface.
   *  @return the created decision and regression tree
   *          graphical user interface
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private DTreeGUI getDTreeGUI ()
  {                             /* --- get decision tree GUI */
    if (this.dtree != null)     /* if it already exists, return it, */
      return this.dtree;        /* otherwise create and configure it */
    this.dtree = new DTreeGUI(this);
    this.dtree.setPath       (this.path);
    this.dtree.setFormat     (this.getFormat());
    this.dtree.setDomainsFile(new File(this.fn_dom.getText()));
    this.dtree.setDataFile   (new File(this.fn_tab.getText()));
    this.dtree.setTestFile   (new File(this.fn_test.getText()));
    return this.dtree;          /* return the created GUI */
  }  /* getDTreeGUI() */

  /*------------------------------------------------------------------*/
  /** Get regression graphical user interface.
   *  @return the created regression graphical user interface
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private RegGUI getRegGUI ()
  {                             /* --- get regression GUI */
    if (this.regress != null)   /* if it already exists, return it, */
      return this.regress;      /* otherwise create and configure it */
    this.regress = new RegGUI(this);
    this.regress.setPath       (this.path);
    this.regress.setFormat     (this.getFormat());
    this.regress.setDomainsFile(new File(this.fn_dom.getText()));
    this.regress.setDataFile   (new File(this.fn_tab.getText()));
    this.regress.setTestFile   (new File(this.fn_test.getText()));
    return this.regress;        /* return the created GUI */
  }  /* getRegGUI() */

  /*------------------------------------------------------------------*/
  /** Get multilayer perceptron graphical user interface.
   *  @return the created multilayer perceptron graphical user interface
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private MLPGUI getMLPGUI ()
  {                             /* --- get multilayer perceptron GUI */
    if (this.mlp != null)       /* if it already exists, return it, */
      return this.mlp;          /* otherwise create and configure it */
    this.mlp = new MLPGUI(this);
    this.mlp.setPath       (this.path);
    this.mlp.setFormat     (this.getFormat());
    this.mlp.setDomainsFile(new File(this.fn_dom.getText()));
    this.mlp.setDataFile   (new File(this.fn_tab.getText()));
    this.mlp.setTestFile   (new File(this.fn_test.getText()));
    return this.mlp;            /* return the created GUI */
  }  /* getMLPGUI() */

  /*------------------------------------------------------------------*/
  /** Get radial basis function network graphical user interface.
   *  @return the created radial basis function network
   *          graphical user interface
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private RBFGUI getRBFGUI ()
  {                             /* --- get radial basis function GUI */
    if (this.rbf != null)       /* if it already exists, return it, */
      return this.rbf;          /* otherwise create and configure it */
    this.rbf = new RBFGUI(this);
    this.rbf.setPath       (this.path);
    this.rbf.setDomainsFile(new File(this.fn_dom.getText()));
    this.rbf.setDataFile   (new File(this.fn_tab.getText()));
    this.rbf.setTestFile   (new File(this.fn_test.getText()));
    this.rbf.setFormat(this.getFormat());
    return this.rbf;            /* return the created GUI */
  }  /* getRBFGUI() */

  /*------------------------------------------------------------------*/
  /** Get clustering graphical user interface.
   *  @return the created clustering graphical user interface
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private ClusterGUI getClusterGUI ()
  {                             /* --- get clustering GUI */
    if (this.cluster != null)   /* if it already exists, return it, */
      return this.cluster;      /* otherwise create and configure it */
    this.cluster = new ClusterGUI(this);
    this.cluster.setPath       (this.path);
    this.cluster.setDomainsFile(new File(this.fn_dom.getText()));
    this.cluster.setDataFile   (new File(this.fn_tab.getText()));
    this.cluster.setTestFile   (new File(this.fn_test.getText()));
    this.cluster.setFormat(this.getFormat());
    return this.cluster;        /* return the created GUI */
  }  /* getClusterGUI() */

  /*------------------------------------------------------------------*/
  /** Get frequent item sets graphical user interface.
   *  @return the created frequent item sets graphical user interface
   *  @since  2014.10.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private FIMGUI getFIMGUI ()
  {                             /* --- get frequent item set GUI */
    if (this.fim == null)       /* if it does not exist, create it */
      this.fim = new FIMGUI(this);
    this.fim.setPath      (this.path);
    this.fim.setTrActsFile(new File(this.fn_tra.getText()));
    this.fim.setOutputFile(new File(this.fn_out.getText()));
    this.fim.setItemSelFile(new File(this.fn_app.getText()));
    this.fim.setFormat    (this.getFormat());
    return this.fim;            /* return the GUI */
  }  /* getFIMUI() */

  /*------------------------------------------------------------------*/
  /** Get association rule graphical user interface.
   *  @return the created association rule graphical user interface
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private ARuleGUI getARuleGUI ()
  {                             /* --- get association rule GUI */
    if (this.arules == null)    /* if it does not exist, create it */
      this.arules = new ARuleGUI(this);
    this.arules.setPath      (this.path);
    this.arules.setTrActsFile(new File(this.fn_tra.getText()));
    this.arules.setOutputFile(new File(this.fn_out.getText()));
    this.arules.setItemAppFile(new File(this.fn_app.getText()));
    this.arules.setFormat    (this.getFormat());
    return this.arules;         /* return the GUI */
  }  /* getARuleGUI() */

  /*------------------------------------------------------------------*/
  /** Get molecular substructure miner.
   *  @return the created molecular substructure miner
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private MoSS getMoSS ()
  {                             /* --- get molecular substruct. miner */
    if (this.moss == null)      /* if it does not exist, create it */
      this.moss = new MoSS(this);
    this.moss.setGraphsFile(new File(this.fn_gra.getText()));
    this.moss.setSubsFile  (new File(this.fn_sub.getText()));
    this.moss.setIdsFile   (new File(this.fn_ids.getText()));
    return this.moss;           /* return the GUI */
  }  /* getMoSS() */

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  {                             /* --- set the domains file */
    if (file == null) file = new File(this.fn_dom.getText());
    else              this.fn_dom.setText(file.getPath());
    if (this.bayes   != null) this.bayes.setDomainsFile(file);
    if (this.dtree   != null) this.dtree.setDomainsFile(file);
    if (this.regress != null) this.regress.setDomainsFile(file);
    if (this.mlp     != null) this.mlp.setDomainsFile(file);
    if (this.rbf     != null) this.rbf.setDomainsFile(file);
    if (this.cluster != null) this.cluster.setDomainsFile(file);
  }  /* setDomainsFile() */

  /*------------------------------------------------------------------*/
  /** Set the data table file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTableFile (File file)
  {                             /* --- set the data file */
    if (file == null) file = new File(this.fn_tab.getText());
    else              this.fn_tab.setText(file.getPath());
    if (this.bayes   != null) this.bayes.setDataFile(file);
    if (this.dtree   != null) this.dtree.setDataFile(file);
    if (this.regress != null) this.regress.setDataFile(file);
    if (this.mlp     != null) this.mlp.setDataFile(file);
    if (this.rbf     != null) this.rbf.setDataFile(file);
    if (this.cluster != null) this.cluster.setDataFile(file);
  }  /* setTableFile() */

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  {                             /* --- set the test file */
    if (file == null) file = new File(this.fn_test.getText());
    else              this.fn_test.setText(file.getPath());
    if (this.bayes   != null) this.bayes.setTestFile(file);
    if (this.dtree   != null) this.dtree.setTestFile(file);
    if (this.regress != null) this.regress.setTestFile(file);
    if (this.mlp     != null) this.mlp.setTestFile(file);
    if (this.rbf     != null) this.rbf.setTestFile(file);
    if (this.cluster != null) this.cluster.setTestFile(file);
  }  /* setTestFile() */

  /*------------------------------------------------------------------*/
  /** Set the transactions file.
   *  @param  file the transactions file to set
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTrActsFile (File file)
  {                             /* --- set the transactions file */
    if (file == null) file = new File(this.fn_tra.getText());
    else              this.fn_tra.setText(file.getPath());
    if (this.fim    != null) this.fim.setTrActsFile(file);
    if (this.arules != null) this.arules.setTrActsFile(file);
  }  /* setTrActsFile() */

  /*------------------------------------------------------------------*/
  /** Set the association rule output file.
   *  @param  file the association rule output file to set
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutputFile (File file)
  {                             /* --- set the set/rule output file */
    if (file == null) file = new File(this.fn_out.getText());
    else              this.fn_out.setText(file.getPath());
    if (this.fim    != null) this.fim.setOutputFile(file);
    if (this.arules != null) this.arules.setOutputFile(file);
  }  /* setRulesFile() */

  /*------------------------------------------------------------------*/
  /** Set the item appearances file.
   *  @param  file the item appearances file to set
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setItemAppFile (File file)
  {                             /* --- set the item app. file */
    if (file == null) file = new File(this.fn_app.getText());
    else              this.fn_app.setText(file.getPath());
    if (this.fim    != null) this.fim.setItemSelFile(file);
    if (this.arules != null) this.arules.setItemAppFile(file);
  }  /* setItemAppFile() */

  /*------------------------------------------------------------------*/
  /** Set the graphs/molecules file.
   *  @param  file the graphs/molecules file to set
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setGraphsFile (File file)
  {                             /* --- set the graphs/molecules file */
    if (file == null) file = new File(this.fn_gra.getText());
    else              this.fn_gra.setText(file.getPath());
    if (this.moss != null) this.moss.setGraphsFile(file);
  }  /* setGraphsFile() */

  /*------------------------------------------------------------------*/
  /** Set the substructure output file.
   *  @param  file the substructure output file to set
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setSubsFile (File file)
  {                             /* --- set the item app. file */
    if (file == null) file = new File(this.fn_sub.getText());
    else              this.fn_sub.setText(file.getPath());
    if (this.moss != null) this.moss.setSubsFile(file);
  }  /* setSubsFile() */

  /*------------------------------------------------------------------*/
  /** Set the substructure output file.
   *  @param  file the substructure output file to set
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setIdsFile (File file)
  {                             /* --- set the identifier file */
    if (file == null) file = new File(this.fn_ids.getText());
    else              this.fn_ids.setText(file.getPath());
    if (this.moss != null) this.moss.setIdsFile(file);
  }  /* setIdsFile() */

  /*------------------------------------------------------------------*/
  /** Show a data table (to be read from a file).
   *  @param  txt the text field containing the file name
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showTable (JTextField txt)
  { this.table.showTable(new File(txt.getText()), this.getFormat()); }

  /*------------------------------------------------------------------*/
  /** Show a data table (to be read from a file).
   *  @param  file the file containing the data table
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showTable (File file)
  { this.table.showTable(file, this.getFormat()); }

  /*------------------------------------------------------------------*/
  /** Show a transactions file (to be read from a file).
   *  @param  txt the text field containing the file name
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showTrActs (JTextField txt)
  { this.showTrActs(new File(txt.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a transactions file (to be read from a file).
   *  @param  file the file containing the transactions
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showTrActs (File file)
  {                             /* --- show a list of transactions */
    TrActView    view;          /* viewer for the transactions */
    FormatDialog fmtdlg;        /* format dialog of the viewer */

    view = new TrActView(this, TrActView.FILE_ITEMS);
    if (!view.loadTrActs(file)) return;
    this.getFormat();           /* create a transaction viewer */
    fmtdlg = view.getFormatDlg();   /* and transfer characters */
    fmtdlg.setMode   (this.format.getMode());
    fmtdlg.setRecSeps(this.format.getRecSeps());
    fmtdlg.setFldSeps(this.format.getFldSeps());
    fmtdlg.setBlanks (this.format.getBlanks());
    fmtdlg.setComment(this.format.getComment());
    view.setVisible(true); view.toFront();
  }  /* showTrActs() */

  /*------------------------------------------------------------------*/
  /** Show frequent item patterns or association rules.
   *  @param  txt the text field containing the file name
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showPatsOrRules (JTextField txt)
  { this.showPatsOrRules(new File(txt.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a set of association rules.
   *  @param  file the file to load the association rules from
   *  @since  2014.09.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showPatsOrRules (File file)
  {                             /* --- show a set of ass. rules */
    int            n = 0;       /* number of commas in add. info. */
    BufferedReader r = null;    /* reader for first line */
    String         s = "(,)";   /* default first line */

    try { r = new BufferedReader(new FileReader(file));
          s = r.readLine(); }   /* read first line of sets/rules file */
    catch (Exception e) { }     /* (to determine the file type) */
    try { if (r != null) r.close(); }
    catch (Exception e) { }     /* close the item sets/rules file */
    do {                        /* find add. information by () */
      int i = s.lastIndexOf('('); if (i < 0) break;
      int k = s.lastIndexOf(')'); if (k < 0) break;
      while (++i < k) { if (s.charAt(i) == ',') n += 1; }
    } while (false);            /* count commas in add. information */
    if (n < 2) {                /* if only 2 pieces of add. info. */
      PatternView view = new PatternView(this, PatternView.FILE_ITEMS);
      if (!view.loadPatterns(file)) return;
      view.setVisible(true); view.toFront(); }
    else {                      /* if > 2 piecesof add. info. */
      ARuleView view = new ARuleView(this, ARuleView.FILE_ITEMS);
      if (!view.loadRules(file)) return;
      view.setVisible(true); view.toFront();
    }                           /* create the appropriate viewer */
  }  /* showPatsOrRules() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    FrIDA frida = new FrIDA();  /* create a FrIDA object */
    if (args.length > 0)        /* load configuration if necessary */
      frida.setPath(new File(args[0]));
    frida.setVisible(true);     /* show the main window */
  }  /* main() */

}  /* class FrIDA */
