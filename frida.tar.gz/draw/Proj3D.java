/*----------------------------------------------------------------------
  File    : Proj3D.java
  Contents: projection of 3D points to a 2D plane
  Author  : Christian Borgelt
  History : 2004.06.02 file created from file proj3d.c
            2004.06.03 reset function added
            2004.06.05 output scaling added
            2007.02.07 javadoc added, function copyFrom added
            2013.12.13 changed default field of view to 30 degrees
----------------------------------------------------------------------*/
package draw;

/*--------------------------------------------------------------------*/
/** Class for projecting 3D points to a 2D plane.
 *  @author Christian Borgelt
 *  @since  2004.06.02 */
/*--------------------------------------------------------------------*/
public class Proj3D {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** mode: change the view (coordinate system) */
  public final static int VIEW = 1;
  /** mode: change the eye position */
  public final static int EYE  = 2;
  /** mode: change view and eye position */
  public final static int BOTH = 3;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the eye (that is, the point to look from) */
  private double[]   eye;
  /** the coordinate cross for the view: x-direction */
  private double[]   cx;
  /** the coordinate cross for the view: y-direction */
  private double[]   cy;
  /** the coordinate cross for the view: z-direction */
  private double[]   cz;
  /** the distance of the near plane of the viewing frustrum */
  private double     dnear;
  /** the distance of the far  plane of the viewing frustrum */
  private double     dfar;
  /** the distance to the projection plane */
  private double     dpp;
  /** the scaling for the result */
  private double     scale;
  /** a buffer for a rotation matrix */
  private double[][] mat;
  /** a buffer for a projected point */
  private double[]   pt;

  /*------------------------------------------------------------------*/
  /** Compute a rotation matrix from a vector and an angle.
   *  @param  mat the matrix into which to store the rotation matrix
   *  @param  vec the vector around which to rotate
   *  @param  phi the angle by which to rotate
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static void _rotmat (double[][] mat, double[] vec, double phi)
  {                             /* --- compute rotation matrix */
    double sin_p, cos_p;        /* sin(phi) and cos(phi) */
    double _1_cos_p;            /* 1 - cos(phi) */
    double t;                   /* temporary buffer */

    sin_p = Math.sin(phi); cos_p = Math.cos(phi);
    _1_cos_p = 1 -cos_p;        /* compute rotation parameters */
    mat[0][0] = _1_cos_p *vec[0]*vec[0] +cos_p;
    mat[1][1] = _1_cos_p *vec[1]*vec[1] +cos_p;
    mat[2][2] = _1_cos_p *vec[2]*vec[2] +cos_p;
    mat[1][0] = mat[0][1] = _1_cos_p *vec[0]*vec[1];
    mat[2][0] = mat[0][2] = _1_cos_p *vec[0]*vec[2];
    mat[2][1] = mat[1][2] = _1_cos_p *vec[1]*vec[2];
    mat[1][0] += t = sin_p *vec[2]; mat[0][1] -= t;
    mat[2][0] -= t = sin_p *vec[1]; mat[0][2] += t;
    mat[2][1] += t = sin_p *vec[0]; mat[1][2] -= t;
  }  /* _rotmat() */

  /*------------------------------------------------------------------*/
  /** Rotate a vector by multiplying it with a rotation matrix.
   *  <p>The given vector will be modified.</p>
   *  @param  mat the rotation matrix
   *  @param  vec the vector to rotate
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static void _rotate (double[][] mat, double[] vec)
  {                             /* --- rotate a vector */
    double x, y;                /* buffers for coordinates */

    x      = mat[0][0]*vec[0] + mat[1][0]*vec[1] + mat[2][0]*vec[2];
    y      = mat[0][1]*vec[0] + mat[1][1]*vec[1] + mat[2][1]*vec[2];
    vec[2] = mat[0][2]*vec[0] + mat[1][2]*vec[1] + mat[2][2]*vec[2];
    vec[1] = y; vec[0] = x;     /* matrix multiplication from right */
  }  /* _rotate() */

  /*------------------------------------------------------------------*/
  /** Rotate a coordinate cross.
   *  <p>The second and third vectors of the coordinate cross will be
   *  modified. Note that the third vector is actually not rotated but
   *  computed as the vector product of the first two.</p>
   *  @param  mat the rotation matrix
   *  @param  a   the first  vector of the coordinate cross;
   *              it must be the vector around which to rotate
   *  @param  b   the second vector of the coordinate cross
   *  @param  c   the third  vector of the coordinate cross
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static void _rotcrd (double[][] mat,
                               double[] a, double[] b, double[] c)
  {                             /* --- rotate a coordinate cross */
    double x, y, z;             /* buffers for coordinates */
    double t;                   /* recipocal length of vector */

    x = mat[0][0]*b[0] + mat[1][0]*b[1] + mat[2][0]*b[2];
    y = mat[0][1]*b[0] + mat[1][1]*b[1] + mat[2][1]*b[2];
    z = mat[0][2]*b[0] + mat[1][2]*b[1] + mat[2][2]*b[2];
    t = 1/Math.sqrt(x*x +y*y +z*z); /* matrix mult. from right */
    b[0] = x*t; b[1] = y*t; b[2] = z*t;
    c[0] = a[1]*b[2] - a[2]*b[1];   /* renormalize the rotated vector */
    c[1] = a[2]*b[0] - a[0]*b[2];   /* and compute the third as the */
    c[2] = a[0]*b[1] - a[1]*b[0];   /* cross product of the other two */
  }  /* _rotcrd() */

  /*------------------------------------------------------------------*/
  /** Create a 3D to 2D projection.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Proj3D ()
  {                             /* --- create a 3D to 2D projection */
    this.eye   = new double[3];
    this.cx    = new double[3];
    this.cy    = new double[3];
    this.cz    = new double[3];
    this.mat   = new double[3][3];
    this.pt    = new double[3];
    this.scale = 1.0;
    this.reset();               /* allocate fields and init. view */
   }  /* Proj3D() */

  /*------------------------------------------------------------------*/
  /** Set the scaling factor.
   *  @param  scale the scaling factor to set
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setScale (double scale)
  { this.scale = scale; }

  /*------------------------------------------------------------------*/
  /** Reset all viewing parameters to their initial values.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void reset ()
  {                             /* --- reset viewing parameters */
    this.eye[0] = 0; this.eye[1] = -5.8; this.eye[2] = 0;
    this.cx[0]  = 1; this.cx[1]  =  0;   this.cx[2]  = 0;
    this.cy[0]  = 0; this.cy[1]  =  1;   this.cy[2]  = 0;
    this.cz[0]  = 0; this.cz[1]  =  0;   this.cz[2]  = 1;
    this.dnear  = 1e-6;         /* set default viewing parameters */
    this.dfar   = 1e+6;         /* (look towards the origin) */
    this.dpp    = 1/Math.tan(Math.PI/12);
  }  /* reset() */

  /*------------------------------------------------------------------*/
  /** Copy a projection object into another.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void copyTo (Proj3D p)
  {                             /* --- copy a projection object */
    System.arraycopy(this.eye, 0, p.eye, 0, 3);
    System.arraycopy(this.cx,  0, p.cx,  0, 3);
    System.arraycopy(this.cy,  0, p.cy,  0, 3);
    System.arraycopy(this.cz,  0, p.cz,  0, 3);
    p.dnear = this.dnear;       /* copy the defining vectors */
    p.dfar  = this.dfar;        /* and the distances to */
    p.dpp   = this.dpp;         /* the different planes */
  }  /* copyTo() */

  /*------------------------------------------------------------------*/
  /** Copy a projection object into this.
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void copyFrom (Proj3D p)
  {                             /* --- copy a projection object */
    System.arraycopy(p.eye, 0, this.eye, 0, 3);
    System.arraycopy(p.cx,  0, this.cx,  0, 3);
    System.arraycopy(p.cy,  0, this.cy,  0, 3);
    System.arraycopy(p.cz,  0, this.cz,  0, 3);
    this.dnear = p.dnear;       /* copy the defining vectors */
    this.dfar  = p.dfar;        /* and the distances to */
    this.dpp   = p.dpp;         /* the different planes */
  }  /* copyFrom() */

  /*------------------------------------------------------------------*/
  /** Set the eye position (point to look from).
   *  @param  x the x-coordinate of the eye
   *  @param  y the y-coordinate of the eye
   *  @param  z the z-coordinate of the eye
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setEye (double x, double y, double z)
  { this.eye[0] = x; this.eye[1] = y; this.eye[2] = z; }

  /*------------------------------------------------------------------*/
  /** Set the eye position (point to look from).
   *  @param  x the position of the eye as a vector
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setEye (double[] x)
  { this.eye[0] = x[0]; this.eye[1] = x[1]; this.eye[2] = x[2]; }

  /*------------------------------------------------------------------*/
  /** Move the eye position (point to look from).
   *  <p>The movement coordinates are interpreted in the view
   *  coordinate system, not in the world coordinate system.</p>
   *  @param  x the amount to move in x direction
   *  @param  y the amount to move in y direction
   *  @param  z the amount to move in z direction
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void moveEye (double x, double y, double z)
  {                             /* --- change eye position */
    if (x != 0) { this.eye[0] += x *this.cx[0];
                  this.eye[1] += x *this.cx[1];
                  this.eye[2] += x *this.cx[2]; }
    if (y != 0) { this.eye[0] += y *this.cy[0];
                  this.eye[1] += y *this.cy[1];
                  this.eye[2] += y *this.cy[2]; }
    if (z != 0) { this.eye[0] += z *this.cz[0];
                  this.eye[1] += z *this.cz[1];
                  this.eye[2] += z *this.cz[2]; }
  }  /* moveEye() */

  /*------------------------------------------------------------------*/
  /** Move the eye position (point to look from).
   *  <p>The movement coordinates are interpreted in the view
   *  coordinate system, not in the world coordinate system.</p>
   *  @param  d the vector by which to move the eye
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void moveEye (double[] d)
  { this.moveEye(d[0], d[1], d[2]); }

  /*------------------------------------------------------------------*/
  /** Set the direction of view.
   *  @param  h the heading/yaw angle
   *  @param  p the pitch       angle
   *  @param  r the roll        angle
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setView (double h, double p, double r)
  {                             /* --- set direction of view */
    double sin_h, cos_h;        /* sine/cosine of heading angle */
    double sin_p, cos_p;        /* sine/cosine of pitch   angle */
    double sin_r, cos_r;        /* sine/cosine of roll    angle */

    sin_h = Math.sin(h); cos_h = Math.cos(h);  /* compute sines */
    sin_p = Math.sin(p); cos_p = Math.cos(p);  /* and cosines of */
    sin_r = Math.sin(r); cos_r = Math.cos(r);  /* rotation angles */
    this.cx[0] =  cos_h*cos_r + sin_h*sin_p*sin_r;
    this.cx[1] =  sin_h*cos_r - cos_h*sin_p*sin_r;
    this.cx[2] =  cos_p*sin_r;  /* x-axis for viewing */
    this.cy[0] = -sin_h*cos_p;
    this.cy[1] =  cos_h*cos_p;
    this.cy[2] =  sin_p;        /* y-axis for viewing */
    this.cz[0] = -cos_h*sin_r + sin_h*sin_p*cos_r;
    this.cz[1] = -sin_h*sin_r - cos_h*sin_p*cos_r;
    this.cz[2] =  cos_p*cos_r;  /* z-axis for viewing */
  }  /* setView() */

  /*------------------------------------------------------------------*/
  /** Set the viewing frustrum.
   *  @param  fov   the field of view (viewing angle)
   *  @param  dnear the distance to the near plane
   *  @param  dfar  the distance to the far  plane
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFrustrum (double fov, double dnear, double dfar)
  {                             /* --- set viewing frustrum */
    this.dpp = 1/Math.tan(0.5*fov);  /* compute dist. to proj. plane */
    this.dnear = dnear;         /* note the distances */
    this.dfar  = dfar;          /* to the near and far planes */
  }  /* setFrustrum() */        /* of the viewing frustrum */

  /*------------------------------------------------------------------*/
  /** Set the heading/yaw angle.
   *  @param  phi  the heading/yaw angle
   *  @param  mode the mode for the adaptation
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setYaw (double phi, int mode)
  {                             /* --- change heading angle */
    _rotmat(this.mat, this.cz, phi);
    if ((mode & VIEW) != 0)     /* rotate coordinate cross */
      _rotcrd(this.mat, this.cz, this.cx, this.cy);
    if ((mode & EYE)  != 0)     /* rotate vector to the eye */
      _rotate(this.mat, this.eye);
  }  /* setYaw() */

  /*------------------------------------------------------------------*/
  /** Set the pitch angle.
   *  @param  phi  the pitch angle
   *  @param  mode the mode for the adaptation
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setPitch (double phi, int mode)
  {                             /* --- change pitch angle */
    _rotmat(this.mat, this.cx, phi);
    if ((mode & VIEW) != 0)     /* rotate coordinate cross */
      _rotcrd(this.mat, this.cx, this.cy, this.cz);
    if ((mode & EYE)  != 0)     /* rotate vector to the eye */
      _rotate(this.mat, this.eye);
  }  /* setPitch() */

  /*------------------------------------------------------------------*/
  /** Set the roll angle.
   *  @param  phi  the roll angle
   *  @param  mode the mode for the adaptation
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setRoll (double phi, int mode)
  {                             /* --- change roll angle */
    _rotmat(this.mat, this.cy, phi);
    if ((mode & VIEW) != 0)     /* rotate coordinate cross */
      _rotcrd(this.mat, this.cy, this.cz, this.cx);
    if ((mode & EYE)  != 0)     /* rotate vector to the eye */
      _rotate(this.mat, this.eye);
  }  /* setRoll() */

  /*------------------------------------------------------------------*/
  /** Project a given point into the plane.
   *  @param  x the x-coordinate of the point
   *  @param  y the y-coordinate of the point
   *  @param  z the z-coordinate of the point
   *  @param  p the vector into which to store the result
   *  @return whether the point is inside the viewing frustrum,
   *           0: inside viewing frustrum,
   *          -1: before near or beyond far plane,
   *           1: between near and far plane, but outside field of view.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int project (double x, double y, double z, double[] p)
  {                             /* --- project a point */
    double dx, dy, dz;          /* vector to object */
    double t;                   /* length of projection, factor */
    int    r;                   /* result code */

    dx = x -this.eye[0];        /* compute the vector from the eye */
    dy = y -this.eye[1];        /* to the object and its projection */
    dz = z -this.eye[2];        /* to the normal of the proj. plane */
    if (p.length > 2)           /* note (squared) distance to the eye */
      p[2] = dx*dx +dy*dy +dz*dz;
    t  = dx*this.cy[0] + dy*this.cy[1] + dz*this.cy[2];
    if ((t < this.dnear) || (t > this.dfar))
      return -1;                /* if outside viewing frustrum, abort */
    t  = 1 /t;                  /* compute factor to object */
    dx = dx *t -this.cy[0];     /* determine projection */
    dy = dy *t -this.cy[1];     /* and the coordinates */
    dz = dz *t -this.cy[2];     /* in the projection plane */
    p[0] = (dx*this.cx[0] + dy*this.cx[1] + dz*this.cx[2])
         * this.dpp;            /* compute x-coordinate of projection */
    p[1] = (dx*this.cz[0] + dy*this.cz[1] + dz*this.cz[2])
         * this.dpp;            /* compute y-coordinate of projection */
    r = ((Math.abs(p[0]) > 1) && (Math.abs(p[1]) > 1))
      ? 1 : 0;                  /* check againts the side planes */
    if (this.scale != 1) {      /* scale the output */
      p[0] *= this.scale; p[1] *= this.scale; }
    return r;                   /* return whether the point is */
  }  /* project() */            /* inside the viewing frustrum */

  /*------------------------------------------------------------------*/
  /** Project a given point into the plane.
   *  @param  x the point to project as a vector
   *  @param  p the vector into which to store the result
   *  @return whether the point is inside the viewing frustrum,
   *           0: inside viewing frustrum,
   *          -1: before near or beyond far plane,
   *           1: between near and far plane, but outside field of view.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int project (double[] x, double[] p)
  { return this.project(x[0], x[1], x[2], p); }

  /*------------------------------------------------------------------*/
  /** Project a given point into the plane.
   *  <p>The result of the projection is stored in an internal
   *  buffer.</p>
   *  @param  x the point to project as a vector
   *  @return whether the point is inside the viewing frustrum,
   *           0: inside viewing frustrum,
   *          -1: before near or beyond far plane,
   *           1: between near and far plane, but outside field of view.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int project (double[] x)
  { return this.project(x[0], x[1], x[2], this.pt); }

  /*------------------------------------------------------------------*/
  /** Get the x coordinate of a projection result.
   *  @return the x-coordinate of the projection result
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getX ()
  { return this.pt[0]; }

  /*------------------------------------------------------------------*/
  /** Get the y coordinate of a projection result.
   *  @return the y-coordinate of the projection result
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getY ()
  { return this.pt[1]; }

  /*------------------------------------------------------------------*/
  /** Get the z coordinate of a projection result.
   *  @return the z-coordinate of the projection result
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getZ ()
  { return this.pt[2]; }

  /*------------------------------------------------------------------*/
  /** Check whether (the upper side of) a plane is visible.
   *  @param  x  the x-coordinate of a support vector of the plane
   *  @param  y  the y-coordinate of a support vector of the plane
   *  @param  z  the z-coordinate of a support vector of the plane
   *  @param  nx the x-coordinate of a normal  vector of the plane
   *  @param  ny the y-coordinate of a normal  vector of the plane
   *  @param  nz the z-coordinate of a normal  vector of the plane
   *  @return whether (the upper side of) a plane is visible
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isVisible (double x,  double y,  double z,
                            double nx, double ny, double nz)
  {                               /* --- determine visibility */
    return ((x -this.eye[0]) *nx  /* check normal vector against */
           +(y -this.eye[1]) *ny  /* the vector from the eye */
           +(z -this.eye[2]) *nz < 0);
  }  /* isVisible() */

  /*------------------------------------------------------------------*/
  /** Check whether (the upper side of) a plane is visible.
   *  @param  x a support vector of the plane
   *  @param  n a normal  vector of the plane
   *  @return whether (the upper side of) a plane is visible
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isVisible (double[] x, double[] n)
  {                               /* --- determine visibility */
    return ((x[0] -this.eye[0]) *n[0]  /* check normal vector against */
           +(x[1] -this.eye[1]) *n[1]  /* the vector from the eye */
           +(x[2] -this.eye[2]) *n[2] < 0);
  }  /* isVisible() */

  /*------------------------------------------------------------------*/
  /** Compute the cosine of the angle between the viewing direction
   *          and the normal vector of the plane.
   *  @param  x  the x-coordinate of a support vector of the plane
   *  @param  y  the y-coordinate of a support vector of the plane
   *  @param  z  the z-coordinate of a support vector of the plane
   *  @param  nx the x-coordinate of a normal  vector of the plane
   *  @param  ny the y-coordinate of a normal  vector of the plane
   *  @param  nz the z-coordinate of a normal  vector of the plane
   *  @return the cosine of the angle between the viewing direction
   *          and the normal vector of the plane
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double cosine (double x,  double y,  double z,
                        double nx, double ny, double nz)
  {                               /* --- determine cosine of angle */
    double t;                     /* product of vector lengths */

    x = this.eye[0] -x;           /* compute the vector */
    y = this.eye[1] -y;           /* from the point to the eye */
    z = this.eye[2] -z;           /* and compute vector lengths */
    t = Math.sqrt(x*x +y*y +z*z) * Math.sqrt(nx*nx +ny*ny +nz*nz);
    if (t <= 0) return 0;         /* return sine of angle to normal */
    return (x *nx +y *ny +z *nz) /t;
  }  /* cosine() */

  /*------------------------------------------------------------------*/
  /** Compute the cosine of the angle between the viewing direction
   *          and the normal vector of the plane.
   *  @param  x a support vector of the plane
   *  @param  n a normal  vector of the plane
   *  @return the cosine of the angle between the viewing direction
   *          and the normal vector of the plane
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double cosine (double[] x, double[] n)
  { return cosine(x[0], x[1], x[2], n[0], n[1], n[2]); }

}  /* Proj3D */
