/*----------------------------------------------------------------------
  File    : BarChart.java
  Contents: frame class for a 3D BarChart
  Author  : Christian Borgelt
  History : 2004.06.05 file created from file ScatterPlot.java
            2007.02.09 adapted to new table classes
            2007.02.09 some cleaning up and restructuring
            2007.02.11 owner handling and positioning corrected
            2007.02.12 returned to delayed dialog box creation
            2007.02.20 adapted to new class ColorDialog
            2007.07.07 adapted to new class DialogPanel
            2007.07.18 dialog boxes changed to "Apply", "Ok", "Cancel"
            2013.04.22 adapted to type argument of JComboBox
            2013.04.22 adapted to class name change Type -> ColType
            2013.11.27 using a third attribute for height added
            2013.12.12 reducing bins for nominal attributes enabled
            2013.12.13 changed default field of view to 30 degrees
            2013.12.29 color levels and color range expansion added
            2013.12.30 third attribute for metric x- and y-axis enabled
            2014.10.23 changed from LGPL license to MIT license
            2018.11.14 replaced some deprecated functions
----------------------------------------------------------------------*/
package draw;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.BorderFactory;
import javax.imageio.ImageIO;

import util.TableReader;
import table.ColType;
import table.NominalType;
import table.MetricType;
import table.RealType;
import table.Column;
import table.Table;
import dialog.DialogPanel;
import dialog.FormatDialog;
import dialog.ColorDialog;
import dialog.AboutDialog;

/*--------------------------------------------------------------------*/
/** Class for a 3D bar chart frame.
 *  @author Christian Borgelt
 *  @since  2004.06.05 */
/*--------------------------------------------------------------------*/
public class BarChart extends JFrame implements Runnable {

  private static final long serialVersionUID = 0x0001000cL;
  public  static final String VERSION = "1.12 (2018.11.14)";

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** mode flag: the scatter plot is a stand-alone program */
  public final static int PROGRAM    = 1;
  /** mode flag: add menu items for loading tables */
  public final static int LOAD_ITEMS = 2;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this bar chart */
  private Component         owner   = null;
  /** the mode flags */
  private int               mode    = 0;
  /** the 3D bar chart panel */
  private Chart3D           panel   = null;
  /** the status bar for messages */
  private JTextField        status  = null;
  /** the file chooser */
  private JFileChooser      chooser = null;
  /** the current table file */
  private File              curr    = null;
  /** the full data table */
  private Table             table   = null;
  /** the selectable columns of the data */
  private Column[]          cols    = null;
  /** the minimum values for the metric columns */
  private double            mins[]  = null;
  /** the maximum values for the metric columns */
  private double            maxs[]  = null;
  /** the numbers of bins for the metric columns */
  private int               bins[]  = null;
  /** the data to display */
  private double[][]        data    = null;
  /** the scaling factor for the data */
  private double            scale   = 1.0;

  /* --- data format dialog box --- */
  /** the data format dialog box */
  private FormatDialog      format  = null;

  /* --- attributes dialog box --- */
  /** the attribute selector */
  private JDialog           attsel  = null;
  /** the attribute for the x-axis */
  private JComboBox<String> xatt    = null;
  /** the minimum value of the attribute for the x-axis */
  private JTextField        xmin    = null;
  /** the maximum value of the attribute for the x-axis */
  private JTextField        xmax    = null;
  /** the number of bins for the x-axis */
  private JSpinner          xbin    = null;
  /** the attribute for the y-axis */
  private JComboBox<String> yatt    = null;
  /** the minimum value of the attribute for the y-axis */
  private JTextField        ymin    = null;
  /** the maximum value of the attribute for the y-axis */
  private JTextField        ymax    = null;
  /** the number of bins for the y-axis */
  private JSpinner          ybin    = null;
  /** the attribute for the z-axis */
  private JComboBox<String> zatt    = null;
  /** the minimum value of the attribute for the z-axis */
  private JTextField        zmin    = null;
  /** the maximum value of the attribute for the z-axis */
  private JTextField        zmax    = null;

  /* --- layout dialog box --- */
  /** the layout dialog box */
  private JDialog           layout  = null;
  /** the field of view */
  private JSpinner          fov     = null;
  /** the thickness of the base plate */
  private JSpinner          thick   = null;
  /** the label font size */
  private JSpinner          size    = null;
  /** the label offset */
  private JSpinner          offset  = null;
  /** the z-scaling factor for the frequencies */
  private JSpinner          zscl    = null;
  /** the gap between the bars */
  private JSpinner          gap     = null;

  /* --- color dialog box --- */
  /** the color selection dialog box */
  private ColorDialog       colsel  = null;
  /** the type for the color levels */
  private RealType          coltype = null;

  /* --- about dialog box --- */
  /** the "About..." dialog box */
  private AboutDialog       about   = null;

  /*------------------------------------------------------------------*/
  /** Create a 3D bar chart frame.
   *  @param  mode the mode flags
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public BarChart (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create a 3D bar chart frame.
   *  @param  owner the component that is to own this bar chart
   *  @param  mode  the mode flags
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public BarChart (Component owner, int mode)
  {                             /* --- create a scatter plot frame */
    this.owner = owner;         /* note the owner */
    this.mode  = mode;          /* and the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* BarChart() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create a bar chart viewer */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    if ((this.mode & PROGRAM) != 0)
      this.mode |= LOAD_ITEMS;  /* check and adapt the mode */

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    if ((this.mode & LOAD_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Load Table...", 'l'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          BarChart.this.loadTable(null); } } );
      item = menu.add(new JMenuItem("Reload Table", 'r'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          BarChart.this.loadTable(BarChart.this.curr); } } );
      menu.addSeparator();
      item = menu.add(new JMenuItem("Data Format...", 'f'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          BarChart.this.getFormatDlg().setVisible(true);
          BarChart.this.format.toFront();
        } } );
      menu.addSeparator();
    }
    item = menu.add(new JMenuItem("Save PNG Image...", 'i'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.saveImage(null); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          BarChart.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("View"));
    menu.setMnemonic('v');
    item = menu.add(new JMenuItem("Set Attributes...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.getAttSelDlg().setVisible(true);
        BarChart.this.attsel.toFront();
      } } );
    item = menu.add(new JMenuItem("Set Layout...", 'l'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.getLayoutDlg().setVisible(true);
        BarChart.this.layout.toFront();
      } } );
    item = menu.add(new JMenuItem("Set Color...", 'c'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.getColorDlg().setVisible(true);
        BarChart.this.colsel.toFront();
      } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Reset View", 'v'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.panel.resetView();
        BarChart.this.panel.repaint();
      } } );
    item = menu.add(new JMenuItem("Redraw", 'r'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.panel.repaint(); } } );

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (BarChart.this.about == null)
          BarChart.this.about = new AboutDialog(BarChart.this,
             "About BarChart...", "BarChart\n"
            +"A 3D Bar Chart Program\n"
            +"Version " +BarChart.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        BarChart.this.about.setVisible(true);
        BarChart.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    this.panel = new Chart3D();
    this.panel.setLayout(new BorderLayout());
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(this.panel, BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    this.status = new JTextField("");
    this.status.setEditable(false);
    content.add(this.status,  BorderLayout.SOUTH);

    /* --- configure and show the frame window --- */
    this.setTitle("BarChart");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser (create if necessary).
   *  @return the file chooser
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure the chooser */
  }  /* createChooser() */

  /*------------------------------------------------------------------*/
  /** Get the data format dialog (create if necessary).
   *  @return the data format dialog
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private FormatDialog getFormatDlg()
  {                             /* --- get the data format dialog */
    if (this.format == null)    /* if it does not exist, create it */
      this.format = new FormatDialog(this);
    return this.format;         /* return the data format dialog */
  }  /* getFormatDlg() */

  /*------------------------------------------------------------------*/
  /** Set range of values in input widgets.
   *  @param  bin the spinner for the number of bins
   *  @param  min the input widget for the minimum value
   *  @param  max the input widget for the maximum value
   *  @param  id  the index of the attribute
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setRange (JSpinner bin,
                         JTextField min, JTextField max, int id)
  {                             /* --- set range in input widgets */
    int k = ((id >= 0) && (id < this.cols.length))
          ? this.bins[id] : -1; /* get number of bins */
    if (k <= 0) {               /* if nominal attribute */
      min.setText(""); min.setEditable(false);
      max.setText(""); max.setEditable(false);
      if ((id >= 0) && (id < this.cols.length) && (bin != null))
        bin.setModel(new SpinnerNumberModel(-k, 1, -k, 1)); }
    else {                      /* if metric attribute */
      min.setText(String.valueOf(this.mins[id])); min.setEditable(true);
      max.setText(String.valueOf(this.maxs[id])); max.setEditable(true);
      if (bin != null)
        bin.setModel(new SpinnerNumberModel(k, 1, 1000, 1));
    }                           /* configure the input widgets */
  }  /* setRange() */

  /*------------------------------------------------------------------*/
  /** Get the attribute selector dialog box (create if necessary).
   *  @return the attribute selector dialog box
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getAttSelDlg ()
  {                             /* --- create attribute selector */
    DialogPanel tab;            /* panel for the dialog fields */
    JPanel      bbar;           /* panel for the button bar */
    JButton     button;         /* button for apply and close */

    if (this.attsel != null)    /* if the dialog box exists, */
      return this.attsel;       /* simply return it */
    this.attsel = new JDialog(this);
    tab = new DialogPanel();    /* create the main panel */

    /* --- input widgets for x-axis --- */
    tab.addLabel("X-axis:");
    this.xatt = tab.addComboBox(null);
    this.xatt.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart bc = BarChart.this;
        int      i  = bc.xatt.getSelectedIndex();
        bc.setRange(bc.xbin, bc.xmin, bc.xmax, i);
      } } );
    tab.addLabel("Range of values:");
    this.xmin = tab.addNumberInput("", DialogPanel.MIDDLE);
    this.xmax = tab.addNumberInput("", DialogPanel.RIGHT);
    tab.addLabel("Number of bins:");
    this.xbin = tab.addSpinner(5, 1, 1000, 1);

    /* --- input widgets for x-axis --- */
    tab.addLabel("Y-axis:");
    this.yatt = tab.addComboBox(null);
    this.yatt.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart bc = BarChart.this;
        int      i  = bc.yatt.getSelectedIndex();
        bc.setRange(bc.ybin, bc.ymin, bc.ymax, i);
      } } );
    tab.addLabel("Range of values:");
    this.ymin = tab.addNumberInput("", DialogPanel.MIDDLE);
    this.ymax = tab.addNumberInput("", DialogPanel.RIGHT);
    tab.addLabel("Number of bins:");
    this.ybin = tab.addSpinner(5, 1, 1000, 1);

    /* --- input widgets for z-axis --- */
    tab.addLabel("Z-axis:");
    this.zatt = tab.addComboBox(null);
    this.zatt.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart bc = BarChart.this;
        int      i  = bc.zatt.getSelectedIndex();
        bc.setRange(null, bc.zmin, bc.zmax, i);
      } } );
    tab.addLabel("Range of values:");
    this.zmin = tab.addNumberInput("", DialogPanel.MIDDLE);
    this.zmax = tab.addNumberInput("", DialogPanel.RIGHT);

    /* --- button bar --- */
    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.setAtts(); } } );
    bbar.add(button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.attsel.setVisible(false);
        BarChart.this.setAtts(); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.attsel.setVisible(false); } } );

    this.attsel.getContentPane().add(tab,  BorderLayout.CENTER);
    this.attsel.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.attsel.setTitle("Set Attributes...");
    this.attsel.setLocationRelativeTo(this);
    this.attsel.pack();
    return this.attsel;
  }  /* getAttSelDlg() */

  /*------------------------------------------------------------------*/
  /** Scale the data to display in the bar chart.
   *  @param  scale the scaling factor for the data
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void scaleData (double scale)
  {                             /* --- scale the data table */
    int   x, y;                 /* loop variables */
    double s;                   /* scaling factor */

    if (this.data == null) return;
    s = scale /this.scale;      /* compute the (re)scaling factor */
    this.scale = scale;         /* and note the new scaling factor */
    for (x = this.data.length; --x >= 0; )
      for (y = this.data[0].length; --y >= 0; )
        this.data[x][y] *= s;   /* scale the data values */
  }  /* scaleData() */

  /*------------------------------------------------------------------*/
  /** Set the layout of the bar chart.
   *  @since  2007.07.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setLayout ()
  {                             /* --- set the layout */
    this.panel.setFOV(          /* field of view */
      ((Integer)this.fov.getValue()).intValue()*Math.PI/180);
    this.panel.setLayout(       /* bar parameters */
      ((Integer)this.gap.getValue()).intValue()    *0.01,
      ((Integer)this.thick.getValue()).intValue()  *0.01,
      ((Integer)this.offset.getValue()).intValue() *0.01,
      ((Integer)this.size.getValue()).intValue()   *0.01);
    float s = ((Integer)this.zscl.getValue()).floatValue();
    this.scaleData(0.01 *s);    /* z-scaling */
    this.panel.build();         /* set the new layout parameters */
    this.panel.repaint();       /* and repaint the panel */
  }  /* setLayout() */

  /*------------------------------------------------------------------*/
  /** Get the layout dialog box (create if necessary).
   *  @return the layout dialog box
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getLayoutDlg ()
  {                             /* --- create layout params. dialog */
    DialogPanel tab;            /* panel for the dialog fields */
    JPanel      bbar;           /* panel for the button bar */
    JButton     button;         /* button for apply and close */

    if (this.layout != null)    /* if the dialog box exists, */
      return this.layout;       /* simply return it */
    this.layout = new JDialog(this);
    tab = new DialogPanel();    /* create the main panel */

    tab.addLabel("Field of view (angle):");
    this.fov    = tab.addSpinner(30, 1, 160, 1);
    tab.addLabel("Base thickness:");
    this.thick  = tab.addSpinner(15, 0, 100, 1);
    tab.addLabel("Label size:");
    this.size   = tab.addSpinner(12, 0, 200, 1);
    tab.addLabel("Label offset:");
    this.offset = tab.addSpinner(4, 0, 200, 1);
    tab.addLabel("Z-axis scaling (percent):");
    this.zscl   = tab.addSpinner(100, 1, 99999, 10);
    tab.addLabel("Gap width (percent):");
    this.gap    = tab.addSpinner(25, 0, 1000, 1);

    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.setLayout(); } } );
    bbar.add(button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.layout.setVisible(false);
        BarChart.this.setLayout(); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.layout.setVisible(false); } } );

    this.layout.getContentPane().add(tab,  BorderLayout.CENTER);
    this.layout.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.layout.setTitle("Set Layout...");
    this.layout.setLocationRelativeTo(this);
    this.layout.pack();
    return this.layout;
  }  /* getLayoutDlg() */

  /*------------------------------------------------------------------*/
  /** Set the color of the bars (if single color bars).
   *  @param  c the color of the bars
   *  @since  2007.07.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setColor (Color c)
  {                             /* --- set the color of the bars */
    this.panel.setColor(c);     /* set the bar color */
    this.panel.repaint();       /* repaint the panel */
  }  /* setColor() */

  /*------------------------------------------------------------------*/
  /** Set the color levels for the bars (if multi-colored bars).
   *  @param  levels the color levels for the bars
   *                 (If <code>levels</code> is <code>null</code>,
   *                 a default rainbow scale of colors is used.)
   *  @param  expand the color range expansion towards black
   *                 as a fraction (that is, a number in [0,1])
   *  @since  2013.12.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setLevels (Color[] levels, double expand)
  {                             /* --- set color levels for the bars */
    this.panel.setLevels(levels, expand);
    this.panel.repaint();       /* set the color levels */
  }  /* setLevels() */          /* and repaint the panel */

  /*------------------------------------------------------------------*/
  /** Set the color levels for of the bars (if multi-colored bars)
   *  from the type used in the color dialog.
   *  @since  2013.12.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setLevels ()
  {                             /* --- set color levels for the bars */
    int     i, n;               /* loop variable, number of colors */
    Color[] levels;             /* color levels for the bars */
    double  expand;             /* color range expansion */

    n = this.coltype.getInfoCount()-1;
    if (n <= 0) return;         /* get the color level parameters */
    expand = ((Double)this.coltype.getInfo(n)).doubleValue();
    levels = new Color[n];      /* create a color array and */
    for (i = 0; i < n; i++)     /* get and set the color levels */
      levels[i] = (Color)this.coltype.getInfo(i);
    this.setLevels(levels, expand);
  }  /* setLevels() */

  /*------------------------------------------------------------------*/
  /** Get the color selection dialog box (create if necessary).
   *  @return the color selection dialog box
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getColorDlg ()
  {                             /* --- create color chooser dialog */
    int   k;                    /* loop variable */
    Table tab;                  /* one-column table for color sel. */
    Color c;                    /* to traverse the color range */

    if (this.colsel != null)    /* if the dialog box exists, */
      return this.colsel;       /* simply return it */
    tab = new Table("colors");  /* create a one-column table */
    tab.addColumn("levels", this.coltype = new RealType(0.0,1.0));
    for (k = 0; k < 5; k++) {   /* create a default rainbow scale */
      c = Color.getHSBColor((float)((4-k)/4.0 *(2/3.0)), 1, 1);
      this.coltype.setInfo(String.valueOf(k), c);
    }                           /* set colors and range expansion */
    this.coltype.setInfo("", Double.valueOf(0.33));
    this.colsel = new ColorDialog(this, "Set Color...");
    this.colsel.setTable(tab,1);/* configure the color chooser */
    this.colsel.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        BarChart.this.setLevels(); } } );
    return this.colsel;         /* return the created color dialog */
  }  /* getColorDlg() */

  /*------------------------------------------------------------------*/
  /** Set the range of values from inputs.
   *  @param  index the index of the metric column
   *  @param  smin  the minimum value as a string
   *  @param  smax  the maximum value as a string
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setRange (int index, JTextField tfmin, JTextField tfmax)
  {                             /* --- set range of values */
    double min, max, t;         /* minimum and maximum value, buffer */

    try { min = Double.parseDouble(tfmin.getText()); }
    catch (NumberFormatException e) { min = 0; }
    try { max = Double.parseDouble(tfmax.getText()); }
    catch (NumberFormatException e) { max = 0; }
    if (max <  min) { t = min; min = max; max = t; }
    if (max <= min) { max += min; min =  0; }
    if (max <= min) { max = +1;   min = -1; }
    this.mins[index] = min;     /* get and adapt the range of values */
    this.maxs[index] = max;     /* and store this range */
  }  /* setRange() */

  /*------------------------------------------------------------------*/
  /** Set the selected attributes from inputs.
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setAtts ()
  {                             /* --- set selected attributes */
    int      i,  n;             /* loop variables */
    int      ix, iy, iz;        /* indices of colums */
    int      bx, by;            /* number of bins */
    Column   cx, cy, cz;        /* data columns */
    int[]    rx, ry;            /* raw data arrays of nominal columns */
    double   xoff = 0, yoff = 0;/* offsets for scaling */
    double   xscl = 1, yscl = 1;/* scaling factors */
    int      x,  y;             /* indices of bin */
    double   max, z;            /* (maximum of) data value(s) */

    this.panel.setData(null);   /* clear the data */
    if ((this.cols == null) || (this.cols.length <= 0)) {
      this.panel.setXLabel(""); /* if there are no columns */
      this.panel.setYLabel(""); return;
    }                           /* remove all labels */

    ix = this.xatt.getSelectedIndex();
    cx = this.cols[ix];         /* get column for x-direction */
    this.panel.setXLabel(cx.getName());
    this.setRange(ix, this.xmin, this.xmax);
    bx = ((Integer)this.xbin.getValue()).intValue();
    if (bx <= 0) bx = 1;        /* get the number of bins */
    if (this.bins[ix] < 0) {    /* if x-direction is nominal, */
      this.bins[ix] = -bx;      /* set negative bin number */
      rx = (int[])cx.getData(); /* get the raw data column */
      xscl = 1.0; xoff = 0.0; } /* and set identity scaling */
    else {                      /* if x-direction is metric, */
      this.bins[ix] = +bx;      /* set positive bin number */
      xscl = bx /(this.maxs[ix] -this.mins[ix]);
      xoff = this.mins[ix];     /* compute the scaling parameters */
      rx   = null;              /* and invalidate the raw data */
    }

    iy = this.yatt.getSelectedIndex();
    cy = this.cols[iy];         /* get column for y-direction */
    this.panel.setYLabel(cy.getName());
    this.setRange(iy, this.ymin, this.ymax);
    by = ((Integer)this.ybin.getValue()).intValue();
    if (by <= 0) by = 1;        /* get the number of bins */
    if (this.bins[iy] < 0) {    /* if x-direction is nominal, */
      this.bins[iy] = -by;      /* set negative bin number */
      ry = (int[])cy.getData(); /* get the raw data column */
      yscl = 1.0; yoff = 0.0; } /* and set identity scaling */
    else {                      /* if y-direction is metric, */
      this.bins[iy] = +by;      /* set positive bin number */
      yscl = by /(this.maxs[iy] -this.mins[iy]);
      yoff = this.mins[iy];     /* compute the scaling parameters */
      ry   = null;              /* and invalidate the raw data */
    }

    iz = this.zatt.getSelectedIndex();

    /* --- build the data table --- */
    this.data = new double[bx][by];
    n = cx.getRowCount();       /* create the counter table */
    if (iz < this.cols.length){ /* if to use a third attribute */
      for (x = 0; x < bx; x++)  /* traverse the counter table */
        for (y = 0; y < by; y++)/* and invalidate all entries */
          this.data[x][y] = -1; /* (no blocks for zero height) */
      cz = this.cols[iz];       /* get column for z-direction */
      for (i = 0; i < n; i++) { /* traverse the rows */
        if (cx.isNull(i) || cy.isNull(i) || cz.isNull(i))
          continue;             /* skip rows with a null value */
        x = (rx != null)        /* get index of bin in x-direction */
          ?  rx[i] : (int)((cx.getNumberAt(i) -xoff) *xscl);
        y = (ry != null)        /* get index of bin in y-direction */
          ?  ry[i] : (int)((cy.getNumberAt(i) -yoff) *yscl);
        if ((x >= bx) || (y >= by))
          continue;             /* check whether in chart range */
        z = cz.getNumberAt(i);  /* get the data value */
        if ((z >= this.mins[iz])
        &&  (z <= this.maxs[iz])) {
          if (this.data[x][y] < 0) this.data[x][y] = 0;
          this.data[x][y] += z -this.mins[iz];
        }                       /* sum the occurring values */
      } }
    else {                      /* if histogram */
      for (i = 0; i < n; i++) { /* traverse the rows */
        if (cx.isNull(i) || cy.isNull(i))
          continue;             /* skip rows with a null value */
        x = (rx != null)        /* get index of bin in x-direction */
          ?  rx[i] : (int)((cx.getNumberAt(i) -xoff) *xscl);
        y = (ry != null)        /* get index of bin in y-direction */
          ?  ry[i] : (int)((cy.getNumberAt(i) -yoff) *yscl);
        if ((x < bx) && (y < by))
          this.data[x][y] += 1; /* if the bin is in chart range */
      }                         /* count the tuple for the bin */
      for (x = 0; x < bx; x++)  /* traverse the counter table */
        for (y = 0; y < by; y++)/* and invalidate zero counters */
          if (this.data[x][y] <= 0) this.data[x][y] = -1;
    }
    max = 0;                    /* initialize the maximum */
    for (x = 0; x < bx; x++)    /* traverse the counter table */
      for (y = 0; y < by; y++)  /* and find the maximum value */
        if (this.data[x][y] > max) max = this.data[x][y];
    this.scale = max;           /* store the number of rows */
    this.getLayoutDlg();        /* ensure that this.zscl exists */
    xscl = ((Integer)this.zscl.getValue()).doubleValue();
    this.scaleData(0.01 *xscl); /* scale the data set */
    this.panel.setData(this.data);   /* set the data table */
    this.panel.build();         /* and build the bar chart */
    this.panel.repaint();       /* finally repaint the panel */
  }  /* setAtts() */

  /*------------------------------------------------------------------*/
  /** Set the table to display.
   *  @param  tab    the table to display
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTable (Table tab)
  { this.setTable(tab, 0, 1, -1); }

  /*------------------------------------------------------------------*/
  /** Set the table to display.
   *  @param  tab the table to display
   *  @param  x   the column index for the x-direction
   *  @param  y   the column index for the y-direction
   *  @param  z   the column index for the z-direction (height)
   *  @since  2013.11.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTable (Table tab, int x, int y, int z)
  {                             /* --- set the data points */
    int     i, k, n;            /* loop variables, counter */
    String  name;               /* buffer for column name */
    Column  c;                  /* to traverse the columns */
    ColType t;                  /* to traverse the column types */
    double  min, max;           /* buffers for minimum and maximum */
    Integer b;                  /* buffer for dummy number */

    this.table = tab;           /* note the table */
    this.getAttSelDlg();        /* create attribute selector */

    /* --- determine scaling parameters --- */
    n = (tab != null) ? tab.getColumnCount() : 0;
    for (i = k = 0; i < n; i++){/* traverse the table columns */
      t = tab.getColumn(i).getType();
      if ((t instanceof NominalType) || (t instanceof MetricType))
        k++;                    /* count metric and nominal columns */
    }                           /* (for column array allocation) */
    this.cols = (k > 0) ? new Column[k] : null;
    this.mins = (k > 0) ? new double[k] : null;
    this.maxs = (k > 0) ? new double[k] : null;
    this.bins = (k > 0) ? new int[k]    : null;
    for (i = k = 0; i < n; i++) {
      c = tab.getColumn(i);     /* traverse the table columns again */
      t = c.getType();          /* and evaluate their types */
      if      (t instanceof NominalType) {
        this.bins[k  ] = -((NominalType)t).getValueCount();
        this.cols[k++] = c; }   /* note the column */
      else if (t instanceof MetricType) {
        min = ((MetricType)t).getMinNumber();
        max = ((MetricType)t).getMaxNumber();
        if (max <= min) { max += min; min =  0; }
        if (max <= min) { max = +1;   min = -1; }
        this.mins[k  ] = min;   /* adapt the range of values, */
        this.maxs[k  ] = max;   /* so that it is not empty, and */
        this.bins[k  ] = 5;     /* note this range of values */
        this.cols[k++] = c;     /* set a default number of bins */
      }                         /* and note the column */
    }                           /* (all other columns are ignored) */

    /* --- build selectors --- */
    this.xatt.removeAllItems();
    this.yatt.removeAllItems();
    this.zatt.removeAllItems();
    for (i = 0; i < k; i++) {   /* traverse the selected columns */
      this.xatt.addItem(name = this.cols[i].getName());
      this.yatt.addItem(name);  /* add the names of all columns */
      this.zatt.addItem(name);  /* to all attribute selectors and */
    }                           /* histogram item for z-direction */
    this.zatt.addItem("<histogram>");
    if (k <= 0) {               /* if there are no columns */
      this.xmin.setText(""); this.xmax.setText("");
      this.xbin.setValue(b = Integer.valueOf(5));
      this.ymin.setText(""); this.ymax.setText("");
      this.ybin.setValue(b);    /* set input widgets empty */
      this.zmin.setText(""); this.zmax.setText(""); }
    else {                      /* if there are columns */
      this.xatt.setSelectedIndex(i = x % k);
      this.setRange(this.xbin, this.xmin, this.xmax, i);
      this.yatt.setSelectedIndex(i = y % k);
      this.setRange(this.ybin, this.ymin, this.ymax, i);
      this.zatt.setSelectedIndex(i = (z >= 0) ? z % k : k);
      if (i < k) this.setRange(null, this.zmin, this.zmax, i);
    }                           /* set ranges and numbers of bins */

    this.setAtts();             /* set the initial selection and */
    this.attsel.pack();         /* reformat the attribute selector */
    this.status.setText(tab.getName());
  }  /* setTable() */

  /*------------------------------------------------------------------*/
  /** Get the currently displayed table.
   *  @return the currently displayed table
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getTable ()
  { return this.table; }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void reportError (String msg)
  {                             /* --- report an i/o error */
    this.status.setText(msg);   /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this, msg,
      "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load the table to display.
   *  @param  file the file to load the table from
   *  @return whether the file was successfully loaded
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadTable (File file)
  {                             /* --- load a data table */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get the selected file */
    this.getFormatDlg();        /* create format dialog if necessary */
    try {                       /* and create corresp. table reader */
      System.err.print("reading " +file +" ... ");
      long        t      = System.currentTimeMillis();
      TableReader reader = this.format.createReader(file);
      Table       tab    = new Table(file.getPath());
      tab.read(reader, this.format.getTableMode());
      reader.close();           /* read table from the given file */
      tab.autoType();           /* determine types automatically */
      this.setTable(tab);       /* set the loaded table */
      t = System.currentTimeMillis() -t;
      System.err.print("[" +tab.getColumnCount() +" column(s), ");
      System.err.print(     tab.getRowCount()    +" row(s)] done");
      System.err.println(" [" +(t/(float)1000.0) +"s]."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.panel.resetView();     /* reset the view of the panel */
    if ((this.cols == null)     /* if there are no columns */
    ||  (this.cols.length <= 0)) {
      JOptionPane.showMessageDialog(this,
        "file " +file.getName() +":\nno appropriate columns",
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show an alert box */
    this.status.setText(file.getPath());
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadTable() */

  /*------------------------------------------------------------------*/
  /** Save a PNG image of the panel.
   *  @param  file the file to save the image to
   *  @return whether the file was successfully written
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveImage (File file)
  {                             /* --- save image to a file */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* let the user choose a file name */
    try {                       /* open an output stream */
      System.err.print("writing " +file +" ... ");
      long             t      = System.currentTimeMillis();
      FileOutputStream stream = new FileOutputStream(file);
      ImageIO.write(this.panel.makeImage(), "png", stream);
      stream.close();           /* save the decision tree image */
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/(float)1000.0) +"s]."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    return true;                /* return 'ok' */
  }  /* saveImage() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    BarChart bc = new BarChart(PROGRAM);
    if (args.length > 0) bc.loadTable(new File(args[0]));
    bc.setVisible(true);        /* create and show a bar chart */
  }  /* main() */

}  /* class BarChart */
