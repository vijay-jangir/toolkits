/*----------------------------------------------------------------------
  File    : Mouse3D.java
  Contents: mouse event handling for 3D projection
  Author  : Christian Borgelt
  History : 2004.06.05 file created from Plot3D.java
            2007.02.07 javadoc added
----------------------------------------------------------------------*/
package draw;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/*--------------------------------------------------------------------*/
/** Class for mouse event handling for 3D projection.
 *  @author Christian Borgelt
 *  @since  2004.06.02 */
/*--------------------------------------------------------------------*/
public class Mouse3D implements MouseListener, MouseMotionListener {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** movement mode: rotate freely */
  private static final int ROTATE = 1;
  /** movement mode: change yaw angle */
  private static final int YAW    = 2;
  /** movement mode: change pitch angle */
  private static final int PITCH  = 3;
  /** movement mode: change roll angle */
  private static final int ROLL   = 4;
  /** movement mode: change zoom */
  private static final int ZOOM   = 5;
  /** movement mode: move freely */
  private static final int MOVE   = 6;
  /** movement mode: move only horizontally */
  private static final int MOVE_H = 7;
  /** movement mode: move only vertically */
  private static final int MOVE_V = 8;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the component to control */
  private Component comp;
  /** the current 3D to 2D projection */
  private Proj3D    proj;
  /** the saved 3D to 2D projection */
  private Proj3D    save;
  /** the mouse movement mode */
  private int       mode;
  /** the x-coordinate of the mouse pointer */
  private int       mx;
  /** the y-coordinate of the mouse pointer */
  private int       my;
  /** the scaling factor for movements */
  private double    scale;

  /*------------------------------------------------------------------*/
  /** Create a mouse event handler for 3D projections.
   *  @param  comp the component to control
   *  @param  proj the 3D to 2D projection used
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Mouse3D (Component comp, Proj3D proj)
  {                             /* --- create a mouse handling object */
    this.comp  = comp;          /* note the component and */
    this.proj  = proj;          /* the projection manager */
    this.save  = new Proj3D();  /* create a projection buffer */
    this.scale = 72/480.0;      /* initialize the scaling */
    comp.addMouseListener(this);
    comp.addMouseMotionListener(this);
  }  /* Mouse3D() */

  /*------------------------------------------------------------------*/
  /** Set the scaling factor for the movement.
   *  @param  scale the scaling factor to set
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setScale (double scale)
  { this.scale = scale; }

  /*------------------------------------------------------------------*/
  /** Handle start of rotation or movement.
   *  @param  e the mouse event that occurred
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mousePressed (MouseEvent e)
  {                             /* --- handle start of rotation */
    this.mx = e.getX();         /* note the coordinates of the point */
    this.my = e.getY();         /* at which the mouse was pressed */
    this.proj.copyTo(this.save);/* note the state of the projection */
    if (e.isControlDown()) {    /* together with control key */
      switch (e.getButton()) {
        case MouseEvent.BUTTON1: this.mode = MOVE;   break;
        case MouseEvent.BUTTON2: this.mode = MOVE_H; break;
        case MouseEvent.BUTTON3: this.mode = MOVE_V; break;
        default:                 this.mode = 0;      break;
      } }                       /* set the mode corr. to the button */
    else if (e.isShiftDown()) { /* together with shift key */
      switch (e.getButton()) {
        case MouseEvent.BUTTON1: this.mode = PITCH;  break;
        case MouseEvent.BUTTON2: this.mode = ROLL;   break;
        case MouseEvent.BUTTON3: this.mode = YAW;    break;
        default:                 this.mode = 0;      break;
      } }                       /* set the mode corr. to the button */
    else {                      /* if shift key is not pressed */
      switch (e.getButton()) {
        case MouseEvent.BUTTON1: this.mode = ROTATE; break;
        case MouseEvent.BUTTON2: this.mode = ROLL;   break;
        case MouseEvent.BUTTON3: this.mode = ZOOM;   break;
        default:                 this.mode = 0;      break;
      }                         /* set the mode corr. to the button */
    }
  }  /* mousePressed() */

  /*------------------------------------------------------------------*/
  /** Handle rotation or movement.
   *  @param  e the mouse event that occurred
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseDragged (MouseEvent e)
  {                             /* --- handle rotation/movement */
    int dx, dy;                 /* pixels mouse was moved */

    dx = e.getX() -this.mx;     /* get the number of pixels */
    dy = e.getY() -this.my;     /* the mouse was moved */
    switch (this.mode) {        /* according to the movement mode */
      case ROTATE:              /* free rotation (pitch and yaw) */
        if ((dx == 0) && (dy == 0)) return;
        this.save.copyTo(this.proj);
        this.proj.setPitch(dy*this.scale*(Math.PI/180), Proj3D.BOTH);
        this.proj.setYaw  (dx*this.scale*(Math.PI/180), Proj3D.BOTH);
        this.comp.repaint(); return;
      case YAW:                 /* change the yaw angle */
        if (dx == 0) return;
        this.save.copyTo(this.proj);
        this.proj.setYaw  (dx*this.scale*(Math.PI/180), Proj3D.BOTH);
        this.comp.repaint(); return;
      case PITCH:               /* change the pitch angle */
        if (dy == 0) return;
        this.save.copyTo(this.proj);
        this.proj.setPitch(dy*this.scale*(Math.PI/180), Proj3D.BOTH);
        this.comp.repaint(); return;
      case ROLL:                /* change the roll angle */
        if (dx == 0) return;
        this.save.copyTo(this.proj);
        this.proj.setRoll (dy*this.scale*(Math.PI/180), Proj3D.BOTH);
        this.comp.repaint(); return;
      case ZOOM:                /* zoom in and out */
        if (dy == 0) return;
        this.save.copyTo(this.proj);
        this.proj.moveEye(0, dy*0.02, 0);
        this.comp.repaint(); return;
      case MOVE:                /* move horizontally and vertically */
        if (dy == 0) return;
        this.save.copyTo(this.proj);
        this.proj.moveEye(-dx*0.02*this.scale, 0, dy*0.02*this.scale);
        this.comp.repaint(); return;
      case MOVE_H:              /* move only horizontally */
        if (dx == 0) return;
        this.save.copyTo(this.proj);
        this.proj.moveEye(-dx*0.02*this.scale, 0, 0);
        this.comp.repaint(); return;
      case MOVE_V:              /* move only vertically */
        if (dy == 0) return;
        this.save.copyTo(this.proj);
        this.proj.moveEye(0, 0, dy*0.02*this.scale);
        this.comp.repaint(); return;
    }                           /* change the viewing parameters */
  }  /* mouseDragged() */

  /*------------------------------------------------------------------*/
  /** Dummy needed for <code>MouseListener</code> interface.
   *  @param  e the mouse event that occurred
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseReleased (MouseEvent e)
  { }

  /*------------------------------------------------------------------*/
  /** Dummy needed for <code>MouseListener</code> interface.
   *  @param  e the mouse event that occurred
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseClicked (MouseEvent e)
  { }

  /*------------------------------------------------------------------*/
  /** Dummy needed for <code>MouseListener</code> interface.
   *  @param  e the mouse event that occurred
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseEntered (MouseEvent e)
  { }

  /*------------------------------------------------------------------*/
  /** Dummy needed for <code>MouseListener</code> interface.
   *  @param  e the mouse event that occurred
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseExited (MouseEvent e)
  { }

  /*------------------------------------------------------------------*/
  /** Dummy needed for <code>MouseListener</code> interface.
   *  @param  e the mouse event that occurred
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void mouseMoved (MouseEvent e)
  { }

}  /* Mouse3D */
