/*----------------------------------------------------------------------
  File    : Chart3D.java
  Contents: panel for a 3D bar chart
  Author  : Christian Borgelt
  History : 2004.06.05 file created from Plot3D.java
            2004.06.06 preallocation of colors added
            2007.02.07 javadoc added
            2007.02.09 function makeImage added
            2013.11.26 drawing with rainbow color scale added
            2013.11.27 drawing of bars with zero height added
            2013.12.29 free choice of color levels added (rainbow)
----------------------------------------------------------------------*/
package draw;

import java.util.Arrays;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/*--------------------------------------------------------------------*/
/** Class for a 3D bar chart panel.
 *  @author Christian Borgelt
 *  @since  2004.06.05 */
/*--------------------------------------------------------------------*/
public class Chart3D extends JPanel {

  private static final long serialVersionUID = 0x00010002L;

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** an empty data table */
  public static final double[][] empty = { { 0 } };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the 3D to 2D projection */
  private Proj3D     proj;
  /** the font handler for drawing text in 3D */
  private Font3D     font;
  /** the mouse movement manager */
  private Mouse3D    mouse;
  /** the colors for the bars */
  private Color[]    colors;
  /** the color levels for the bars */
  private Color[]    levels;
  /** the color range expansion for the bars */
  private double     expand;
  /** the bar height offset for the color computation */
  private double     coff;
  /** the bar height scaling factor for the color computation */
  private double     cscl;
  /** the thickness of the base plate */
  private double     thick;
  /** the gap width (relative to the block width) */
  private double     gap;
  /** the offset for the labels */
  private double     offset;
  /** the label for the x-axis */
  private String     xlabel;
  /** the label for the y-axis */
  private String     ylabel;
  /** the the data to display (2-dimensional) */
  private double[][] data;
  /** the maximum height of a block */
  private double     maxht;
  /** the base plate of the chart */
  private Block3D    base;
  /** the blocks of the bar chart */
  private Block3D[]  blocks;

  /*------------------------------------------------------------------*/
  /** Create a 3D bar chart panel.
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Chart3D ()
  {                             /* --- create a 3D bar chart panel */
    this.proj      = new Proj3D();
    this.font      = new Font3D(this.proj);
    this.mouse     = new Mouse3D(this, this.proj);
    this.colors    = new Color[7];
    this.colors[6] = Color.BLUE;
    this.setLevels(null, 0.33);
    this.data      = Chart3D.empty;
    this.xlabel    = this.ylabel = null;
    this.gap       = 0.50;
    this.thick     = 0.15;
    this.offset    = 0.04;
    this.font.setSize(0.12);
    this.font.setClip(-1.0, 1.0,-1.0, 1.0,-1.0, 1.0);
    this.resetView();
    this.build();
    this.setPreferredSize(new Dimension(400, 400));
  }  /* Chart3D() */

  /*------------------------------------------------------------------*/
  /** Reset the view of the panel.
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void resetView ()
  { this.proj.reset(); this.proj.setEye(0, -5.8, 0.5); }

  /*------------------------------------------------------------------*/
  /** Set the field of view (viewing angle) of the panel.
   *  @param  angle the field of view (viewing angle)
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFOV (double angle)
  { this.proj.setFrustrum(angle, 1e-6, 1e6); }

  /*------------------------------------------------------------------*/
  /** Set the layout parameters for the bars.
   *  @param  gap    the (relative) gap between the bars
   *  @param  thick  the thickness of the base plate
   *  @param  offset the label offset from base plate sides
   *  @param  size   the size of the label font
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setLayout (double gap,    double thick,
                         double offset, double size)
  {                             /* --- set layout parameters */
    this.gap    = (gap   > 1e-6) ? gap   : 1e-6;
    this.thick  = (thick > 0)    ? thick : 0;
    this.offset = offset;       /* gap between bars, base thickness, */
    this.font.setSize(size);    /* label offset and label font size */
  }  /* setLayout() */

  /*------------------------------------------------------------------*/
  /** Set the label for the x-axis.
   *  @param  label the label for the x-axis
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setXLabel (String label)
  { this.xlabel = label; }

  /*------------------------------------------------------------------*/
  /** Set the label for the y-axis.
   *  @param  label the label for the y-axis
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setYLabel (String label)
  { this.ylabel = label; }

  /*------------------------------------------------------------------*/
  /** Set the color of the bars (for single color bars).
   *  @param  color the color of the bars
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setColor (Color color)
  { this.colors[6] = color; this.levels = null; }

  /*------------------------------------------------------------------*/
  /** Set the color levels for the bars (for multi-colored bars).
   *  @param  levels the color levels for the bars
   *                 (If <code>levels</code> is <code>null</code>,
   *                 a default rainbow scale of colors is used.)
   *  @param  expand the color range expansion towards black
   *                 as a fraction (that is, a number in [0,1])
   *  @since  2013.12.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setLevels (Color[] levels, double expand)
  {                             /* --- set color levels for bars */
    int   k, n;                 /* loop variable, number of colors */
    float hue;                  /* value of a color (hue) */

    if (levels == null) {       /* if no color levels are given */
      this.levels    = new Color[7];
      this.levels[0] = this.levels[6] = Color.BLACK;
      for (k = 0; k < 5; k++) { /* create a default rainbow scale */
        hue = (float)((4-k)/4.0 *(2/3.0));
        this.levels[k+1] = Color.getHSBColor(hue, 1, 1);
      }                         /* set five colors from blue to red */
      this.expand = (expand >= 0) ? expand : 0.33; }
    else {                      /* if color levels are given */
      n = levels.length;        /* check for a single color */
      if ((n <= 1) && (expand <= 0)) {
        this.setColor(levels[0]); return; }
      this.levels = new Color[n+2];
      this.levels[0] = this.levels[n+1] = Color.BLACK;
      System.arraycopy(levels, 0, this.levels, 1, n);
      this.expand = expand;     /* copy the given color levels and */
    }                           /* set the color range expansion */
  }  /* setLevels() */

  /*------------------------------------------------------------------*/
  /** Set the data to display.
   *  @param  data the data to display (2-dimensional)
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setData (double[][] data)
  { this.data = (data != null) ? data : Chart3D.empty; }

  /*------------------------------------------------------------------*/
  /** Build the bars of the chart.
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void build ()
  {                             /* --- build the bars of the chart */
    int    i, k, n;             /* loop variables, number of blocks */
    double dx, dy, wx, wy;      /* step and width for block placement */

    this.maxht = 0;             /* clear the maximum height */
    for (n = 0, i = this.data.length; --i >= 0; ) {
      for (k = this.data[i].length; --k >= 0; ) {
        if (data[i][k] >  this.maxht) this.maxht = data[i][k];
        if (data[i][k] >= 0) n++;
      }                         /* find maximum block height */
    }                           /* and count the needed blocks */
    this.base   = new Block3D(-1, -1, -this.thick, 2, 2, this.thick);
    this.blocks = new Block3D[n];
    if (n <= 0) return;         /* create base and block vector */
    wx = 2.0 /(this.data.length    +(this.data.length    -1) *this.gap);
    dx = (1 +this.gap) *wx;     /* width and step for x-axis */
    wy = 2.0 /(this.data[0].length +(this.data[0].length -1) *this.gap);
    dy = (1 +this.gap) *wy;     /* width and step for y-axis */
    for (n = 0, i = this.data.length; --i >= 0; )
      for (k = this.data[i].length; --k >= 0; )
        if (this.data[i][k] >= 0)  /* create blocks for non-zero data */
          this.blocks[n++] = new Block3D(i*dx-1, k*dy-1, 0,
                                         wx, wy, this.data[i][k]);
  }  /* build() */

  /*------------------------------------------------------------------*/
  /** Blend two colors (linear interpolation in RGB space).
   *  @param  c1  the first  color to blend
   *  @param  c2  the second color to blend
   *  @param  w   the weight of the first color;
   *              (weight of the second color is 1-w)
   *  @since  2013.12.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static Color blend (Color c1, Color c2, double w)
  {                             /* --- blend two colors */
    int r = (int)(w *c1.getRed()   +(1-w) *c2.getRed()   +0.5);
    int g = (int)(w *c1.getGreen() +(1-w) *c2.getGreen() +0.5);
    int b = (int)(w *c1.getBlue()  +(1-w) *c2.getBlue()  +0.5);
    if (r < 0) r = 0; if (r > 255) r = 255;
    if (g < 0) g = 0; if (g > 255) g = 255;
    if (b < 0) b = 0; if (b > 255) b = 255;
    return new Color(r, g, b);  /* return the blended color */
  }  /* blend() */

  /*------------------------------------------------------------------*/
  /** Get the color corresponding to a bar height.
   *  @param  h the height of the bar
   *  @since  2013.11.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private Color getColor (double h)
  {                             /* --- get color shades for drawing */
    int i, n;                   /* color index, number of colors */

    h = (h -this.coff) *this.cscl;
    i = (int)h;                 /* get the scaled bar height and */
    n = this.levels.length-2;   /* compute the color level index */
    if (i < 0)                    return this.levels[0];
    if (i > this.levels.length-2) return this.levels[n+1];
    return Chart3D.blend(this.levels[i+1], this.levels[i], h-i);
  }  /* getColor() */

  /*------------------------------------------------------------------*/
  /** Get the color shades needed for a shadowed drawing.
   *  @param  c the base color for the bars
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void getShades (Color c)
  {                             /* --- get color shades for drawing */
    float r, g, b;              /* red, green and blue part */
    float x;                    /* brightness of color */

    if (c == null) c = Color.white;
    r = c.getRed()   /255.0F;   /* compute the shades */
    g = c.getGreen() /255.0F;   /* from the base color */
    b = c.getBlue()  /255.0F;   /* and the face cosines */
    x = (float)this.proj.cosine( 1,  0,  0, -1,  0,  0);
    this.colors[0] = (x > 0) ? new Color(x*r, x*g, x*b) : Color.BLACK;
    x = (float)this.proj.cosine( 0,  1,  0,  0, -1,  0);
    this.colors[1] = (x > 0) ? new Color(x*r, x*g, x*b) : Color.BLACK;
    x = (float)this.proj.cosine( 0,  0, -1,  0,  0, -1);
    this.colors[2] = (x > 0) ? new Color(x*r, x*g, x*b) : Color.BLACK;
    x = (float)this.proj.cosine(-1,  0,  0,  1,  0,  0);
    this.colors[3] = (x > 0) ? new Color(x*r, x*g, x*b) : Color.BLACK;
    x = (float)this.proj.cosine( 0, -1,  0,  0,  1,  0);
    this.colors[4] = (x > 0) ? new Color(x*r, x*g, x*b) : Color.BLACK;
    x = (float)this.proj.cosine( 0,  0, -1,  0,  0,  1);
    this.colors[5] = (x > 0) ? new Color(x*r, x*g, x*b) : Color.BLACK;
  }  /* getShades() */

  /*------------------------------------------------------------------*/
  /** (Re)paint the 3D bar chart panel.
   *  @param  g the graphics to use for the painting
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void paint (Graphics g)
  {                             /* --- (re)paint the whole panel */
    int       i, n;             /* loop variable, buffer */
    Dimension d;                /* size of the panel */
    double    r, v;             /* coordinate of label reference */

    super.paint(g);             /* ensure proper rendering queue */
    d = this.getSize();         /* get the panel's size */
    g.setColor(Color.white);    /* and draw the background */
    g.fillRect(0, 0, d.width, d.height);
    g.translate(n = d.width >> 1, d.height >> 1);
    this.proj.setScale(n);      /* set the drawing parameters */
    this.mouse.setScale(72.0 /n);

    /* --- draw the base plate I --- */
    this.base.project(this.proj);
    if (this.base.isTopVisible())  {
      g.setColor(Color.white);
      this.getShades(Color.white);
      this.base.paint(g, this.colors);
    }                           /* (if visible from top) */

    /* --- draw the blocks --- */
    for (i = this.blocks.length; --i >= 0; )
      this.blocks[i].project(this.proj);
    Arrays.sort(this.blocks, 0, this.blocks.length);
    if (this.levels == null) {  /* if to use a specific color */
      this.getShades(this.colors[6]);
      for (i = this.blocks.length; --i >= 0; )
        this.blocks[i].paint(g, this.colors); }
    else {                      /* if to use a rainbow scale */
      n = this.levels.length-2; /* compute the scaling parameters */
      this.cscl = (this.maxht <= 0) ? 1.0
                : (n-1+2*this.expand) /this.maxht;
      this.coff = (this.cscl  <= 0) ? 0.0
                : (this.expand-1)     /this.cscl;
      for (i = this.blocks.length; --i >= 0; ) {
        this.getShades(this.getColor(this.blocks[i].getHeight()));
        this.blocks[i].paint(g, this.colors);
      }                         /* for each block get a color */
    }                           /* that corresponds to its height */

    /* --- draw the base plate II --- */
    if (!this.base.isTopVisible())  {
      g.setColor(Color.white);
      this.getShades(Color.white);
      this.base.paint(g, this.colors);
    }                           /* (if not visible from top) */

    /* --- draw the labels --- */
    g.setColor(Color.BLACK);    /* set black for writing */
    r = 1 - this.offset;        /* get the label coordinates */
    v = this.offset -this.thick;
    if (base.isFrontVisible())  /* draw label on base front */
      this.font.draw(g, -r, -1, v,
                     Font3D.H_POS_X|Font3D.V_POS_Z, this.xlabel);
    if (base.isBackVisible())   /* draw label on base back */
      this.font.draw(g,  r,  1, v,
                     Font3D.H_NEG_X|Font3D.V_POS_Z, this.xlabel);
    if (base.isLeftVisible())   /* draw label on base left */
      this.font.draw(g, -1,  r, v,
                     Font3D.H_NEG_Y|Font3D.V_POS_Z, this.ylabel);
    if (base.isRightVisible())  /* draw label on base right */
      this.font.draw(g,  1, -r, v,
                     Font3D.H_POS_Y|Font3D.V_POS_Z, this.ylabel);
  }  /* paint() */

  /*------------------------------------------------------------------*/
  /** Create an image of the panel contents.
   *  @return an image of the panel contents
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public BufferedImage makeImage ()
  {                             /* --- create an image of contents */
    BufferedImage img;          /* created image */
    Dimension     d;            /* size of panel */

    d   = this.getPreferredSize();
    img = new BufferedImage(d.width, d.height,
                            BufferedImage.TYPE_INT_ARGB);
    this.paint(img.getGraphics());
    return img;                 /* draw window contents to image */
  }  /* BufferedImage() */      /* and return the image */

}  /* Chart3D */
