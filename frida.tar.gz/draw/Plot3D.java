/*----------------------------------------------------------------------
  File    : Plot3D.java
  Contents: panel for a 3D scatter plot
  Author  : Christian Borgelt
  History : 2004.06.02 file created from file DTView.java
            2004.06.03 drawing of labels of axes added
            2004.06.05 adapted to mouse movement manager
            2007.02.07 javadoc added, function makeImage added
            2007.02.22 setting colors for overlay value added
            2007.02.23 color allocation moved to function build
            2009.06.19 bug in function makeImage() fixed (image size)
            2014.01.27 inset percentage moved here from ScatterPlot
----------------------------------------------------------------------*/
package draw;

import java.util.Arrays;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/*--------------------------------------------------------------------*/
/** Class for a panel for a 3D scatter plot.
 *  @author Christian Borgelt
 *  @since  2004.06.02 */
/*--------------------------------------------------------------------*/
public class Plot3D extends JPanel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010000L;
  /** the block size for the points vector */
  private static final int BLKSIZE = 32;
  /** the corners of a cube from (-1,-1,-1) to (1,1,1) */
  private static final double c3d[][] =
  { { -1, -1, -1 }, { 1, -1, -1 }, {  1,  1, -1 }, { -1,  1, -1 },
    { -1, -1,  1 }, { 1, -1,  1 }, {  1,  1,  1 }, { -1,  1,  1 } };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the 3D to 2D projection to use */
  private Proj3D     proj;
  /** the font handler for drawing text in 3D */
  private Font3D     font;
  /** the mouse movement manager */
  private Mouse3D    mouse;
  /** the projections of cube corners */
  private double[][] c2d;
  /** the screen coordinates of the cube corners */
  private int[][]    csc;
  /** the offset for the labels */
  private double     offset;
  /** the label for the x-axis */
  private String     xlabel;
  /** the label for the y-axis */
  private String     ylabel;
  /** the label for the z-axis */
  private String     zlabel;
  /** the number of points to draw */
  private int        ptcnt;
  /** the (colored) points in 3D space */
  private Point3D[]  points;
  /** the number of colors */
  private int        colcnt;
  /** the colors for the points */
  private Color[]    colors;
  /** the inset percentage */
  private double     inset = 5.0;
  /** the marker size */
  private int        msize;
  /** the corrected marker size */
  private int        mcorr;

  /*------------------------------------------------------------------*/
  /** Create a panel for a 3D scatter plot.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Plot3D ()
  {                             /* --- create a 3d plot panel */
    this.proj   = new Proj3D();
    this.font   = new Font3D(this.proj);
    this.mouse  = new Mouse3D(this, this.proj);
    this.c2d    = new double[8][3];
    this.csc    = new int   [8][2];
    this.xlabel = this.ylabel = this.zlabel = null;
    this.offset = 0.04;
    this.font.setSize(0.12);
    this.font.setClip(-1.0, 1.0,-1.0, 1.0,-1.0, 1.0);
    this.setMarker(6);
    this.clear();
    this.setPreferredSize(new Dimension(400, 400));
  }  /* Plot3D() */

  /*------------------------------------------------------------------*/
  /** Reset the view of the panel.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void resetView ()
  { this.proj.reset(); }

  /*------------------------------------------------------------------*/
  /** Set the field of view (viewing angle) of the panel.
   *  @param  angle the field of view (viewing angle)
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFOV (double angle)
  { this.proj.setFrustrum(angle, 1e-6, 1e6); }

  /*------------------------------------------------------------------*/
  /** Set the layout parameters for the labels.
   *  @param  offset the offset from the cube sides
   *  @param  size   the size of the font
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setLayout (double offset, double size)
  { this.offset = offset; this.font.setSize(size); }

  /*------------------------------------------------------------------*/
  /** Set the label for the x-axis.
   *  @param  label the label for the x-axis
   *  @since  2004.06.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setXLabel (String label)
  { this.xlabel = label; }

  /*------------------------------------------------------------------*/
  /** Set the label for the y-axis.
   *  @param  label the label for the y-axis
   *  @since  2004.06.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setYLabel (String label)
  { this.ylabel = label; }

  /*------------------------------------------------------------------*/
  /** Set the label for the z-axis.
   *  @param  label the label for the z-axis
   *  @since  2004.06.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setZLabel (String label)
  { this.zlabel = label; }

  /*------------------------------------------------------------------*/
  /** Set the inset percentage (for all axes).
   *  @param  inset the insert percentage
   *  @since  2014.01.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInset (double inset)
  {                             /* --- set inset percentage */
    int    i;                   /* loop variable */
    double s;                   /* scaling factor to adapt inset */

    if (inset == this.inset)    /* if there is no change, */
      return;                   /* abort the function */
    s = (1.0 -0.01*inset)/(1.0 -0.01*this.inset);
    for (i = 0; i < this.ptcnt; i++)
      this.points[i].scale(s);  /* rescale the points with new inset */
    this.inset = inset;         /* note the new inset percentage */
  }  /* setInset() */

  /*------------------------------------------------------------------*/
  /** Set the size of the markers.
   *  @param  size the size of the markers (in pixels)
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMarker (int size)
  {                             /* --- set the marker size */
    this.msize = size;          /* not size and corrected size */
    this.mcorr = System.getProperty("os.name").startsWith("Windows")
               ? size +1 : size;
  }  /* setMarker() */

  /*------------------------------------------------------------------*/
  /** Remove all stored points.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clear ()
  { this.ptcnt = this.colcnt = 0; this.points = null; }

  /*------------------------------------------------------------------*/
  /** Remove all stored points.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void removeAllPoints ()
  { this.clear(); }

  /*------------------------------------------------------------------*/
  /** Add a colored point.
   *  @param  x the x-coordinate of the point
   *  @param  y the y-coordinate of the point
   *  @param  z the z-coordinate of the point
   *  @param  c the color of the point
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addPoint (double x, double y, double z, int c)
  {                             /* --- add a point to plot */
    int       n;                /* size of point vector */
    Point3D[] vec;              /* buffer for reallocation */
    double    s;                /* factor for inset percentage */

    if ((Math.abs(x) > 1.0001)  /* point must be inside cube, */
    ||  (Math.abs(y) > 1.0001)  /* but we allow for a slight */
    ||  (Math.abs(z) > 1.0001)) /* overshoot in order to */
      return -1;                /* handle roundoff errors */
    s = 1.0 -0.01*this.inset;   /* rescale the coordinates */
    x *= s; y *= s; z *= s;     /* to take inset into account */
    n = (this.points != null) ? this.points.length : 0;
    if (this.ptcnt >= n) {      /* if the point vector is full */
      n += (n > BLKSIZE) ? n >> 1 : BLKSIZE;
      vec = new Point3D[n];     /* create a new point vector and */
      if (this.points != null)  /* copy the old vector to the new */
        System.arraycopy(this.points, 0, vec, 0, this.ptcnt);
      this.points = vec;        /* set the new point vector */
    }
    if (c >= this.colcnt)       /* update the number of colors */
      this.colcnt = c +1;       /* (color range 0 to colcnt -1) */
    this.points[this.ptcnt] = new Point3D(x, y, z, c);
    return this.ptcnt++;        /* add the new point to the vector */
  }  /* addPoint() */           /* and return the point index */

  /*------------------------------------------------------------------*/
  /** Build the scatter plot.
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void build ()
  { this.build(false); }

  /*------------------------------------------------------------------*/
  /** Build the scatter plot.
   *  @param  rainbow whe
   *  @since  2013.12.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void build (boolean rainbow)
  {                             /* --- build the scatter plot */
    if ((this.colors != null)   /* check if new colors are needed */
    &&  (this.colcnt == this.colors.length)) return;
    this.colors = new Color[this.colcnt];
    for (int i = 0; i < this.colcnt; i++) {
      this.colors[i] = (!rainbow) ? Color.RED
                     : Color.getHSBColor(i/(float)this.colcnt, 1, 1);
    }                           /* create/set default point colors */
  }  /* build() */

  /*------------------------------------------------------------------*/
  /** Set a color for an overlay value.
   *  <p>Colors can be set only after the scatter plot
   *  has been built.</p>
   *  @param  index the index of the color to set
   *  @param  color the color to set
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setColor (int index, Color color)
  {                             /* --- set a color */
    if ((color == null) || (this.colors == null)
    ||  ((index < 0) || (index >= this.colors.length)))
      return;                   /* check colors and index */
    this.colors[index] = color; /* store the given color */
  }  /* setColor() */

  /*------------------------------------------------------------------*/
  /** Draw an edge of the reference cube.
   *  @param  g   the graphics to use
   *  @param  src the index of the source      corner
   *  @param  dst the index of the destination corner
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void edge (Graphics g, int src, int dst)
  {                             /* --- draw a cube edge */
    g.drawLine(this.csc[src][0], this.csc[src][1],
               this.csc[dst][0], this.csc[dst][1]);
  }  /* edge() */

  /*------------------------------------------------------------------*/
  /** (Re)paint the 3D scatter plot panel.
   *  @param  g the graphics to use for the painting
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void paint (Graphics g)
  {                             /* --- (re)paint the whole panel */
    int       i, c;             /* loop variable, flags, buffer */
    int       x, y;             /* screen coordinates */
    int       s, t, o;          /* marker size parameters */
    Dimension d;                /* size of the panel */
    Point3D   p;                /* point to draw */
    double    r;                /* coordinate of label reference */

    super.paint(g);             /* ensure proper rendering queue */
    d = this.getSize();         /* get the panel size */
    g.setColor(Color.white);    /* draw the background */
    g.fillRect(0, 0, d.width, d.height);
    g.translate(t = d.width >> 1, d.height >> 1);
    this.proj.setScale(t);      /* set drawing parameters */
    this.mouse.setScale(72.0 /t);

    /* --- project the cube corners --- */
    for (i = 8; --i >= 0; ) {   /* traverse the cube's corners */
      if (this.proj.project(Plot3D.c3d[i], this.c2d[i]) < 0) {
        this.c2d[i][2] = -1; continue; }
      this.csc[i][0] =  (int)(this.c2d[i][0] +0.5);
      this.csc[i][1] = -(int)(this.c2d[i][1] +0.5);
    }                           /* compute projections */

    /* --- draw the labels --- */
    g.setColor(Color.gray);     /* draw labels in gray */
    c = 0; r = 1 -this.offset;  /* mark edges to draw */
    if (this.proj.isVisible(-1,-1,-1, 1, 0, 0)) {
      c |= 0x0988;              /* left plane */
      this.font.draw(g, -1, -r, -r,
                     Font3D.H_POS_Y|Font3D.V_POS_Z, this.ylabel);
      this.font.draw(g, -1,  r,  r,
                     Font3D.H_NEG_Y|Font3D.V_NEG_Z, this.ylabel);
      this.font.draw(g, -1,  r, -r,
                     Font3D.H_POS_Z|Font3D.V_NEG_Y, this.zlabel);
      this.font.draw(g, -1, -r,  r,
                     Font3D.H_NEG_Z|Font3D.V_POS_Y, this.zlabel);
    }
    if (this.proj.isVisible(-1,-1,-1, 0, 1, 0)) {
      c |= 0x0311;              /* front plane */
      this.font.draw(g, -r, -1, -r,
                     Font3D.H_POS_Z|Font3D.V_POS_X, this.zlabel);
      this.font.draw(g,  r, -1,  r,
                     Font3D.H_NEG_Z|Font3D.V_NEG_X, this.zlabel);
      this.font.draw(g,  r, -1, -r,
                     Font3D.H_NEG_X|Font3D.V_POS_Z, this.xlabel);
      this.font.draw(g, -r, -1,  r,
                     Font3D.H_POS_X|Font3D.V_NEG_Z, this.xlabel);
    }
    if (this.proj.isVisible(-1,-1,-1, 0, 0, 1)) {
      c |= 0x000f;              /* bottom plane */
      this.font.draw(g, -r, -r, -1,
                     Font3D.H_POS_X|Font3D.V_POS_Y, this.xlabel);
      this.font.draw(g,  r,  r, -1,
                     Font3D.H_NEG_X|Font3D.V_NEG_Y, this.xlabel);
      this.font.draw(g,  r, -r, -1,
                     Font3D.H_POS_Y|Font3D.V_NEG_X, this.ylabel);
      this.font.draw(g, -r,  r, -1,
                     Font3D.H_NEG_Y|Font3D.V_POS_X, this.ylabel);
    }
    if (this.proj.isVisible( 1, 1, 1,-1, 0, 0)) {
      c |= 0x0622;              /* right plane */
      this.font.draw(g,  1, -r, -r,
                     Font3D.H_POS_Z|Font3D.V_POS_Y, this.zlabel);
      this.font.draw(g,  1,  r,  r,
                     Font3D.H_NEG_Z|Font3D.V_NEG_Y, this.zlabel);
      this.font.draw(g,  1,  r, -r,
                     Font3D.H_NEG_Y|Font3D.V_POS_Z, this.ylabel);
      this.font.draw(g,  1, -r,  r,
                     Font3D.H_POS_Y|Font3D.V_NEG_Z, this.ylabel);
    }
    if (this.proj.isVisible( 1, 1, 1, 0,-1, 0)) {
      c |= 0x0c44;              /* back plane */
      this.font.draw(g, -r,  1, -r,
                     Font3D.H_POS_X|Font3D.V_POS_Z, this.xlabel);
      this.font.draw(g,  r,  1,  r,
                     Font3D.H_NEG_X|Font3D.V_NEG_Z, this.xlabel);
      this.font.draw(g,  r,  1, -r,
                     Font3D.H_POS_Z|Font3D.V_NEG_X, this.zlabel);
      this.font.draw(g, -r,  1,  r,
                     Font3D.H_NEG_Z|Font3D.V_POS_X, this.zlabel);
    }
    if (this.proj.isVisible( 1, 1, 1, 0, 0,-1)) {
      c |= 0x00f0;              /* top plane */
      this.font.draw(g, -r, -r,  1,
                     Font3D.H_POS_Y|Font3D.V_POS_X, this.ylabel);
      this.font.draw(g,  r,  r,  1,
                     Font3D.H_NEG_Y|Font3D.V_NEG_X, this.ylabel);
      this.font.draw(g,  r, -r,  1,
                     Font3D.H_NEG_X|Font3D.V_POS_Y, this.xlabel);
      this.font.draw(g, -r,  r,  1,
                     Font3D.H_POS_X|Font3D.V_NEG_Y, this.xlabel);
    }
    if (this.c2d[0][2] < 0) c &= ~0x0109;
    if (this.c2d[1][2] < 0) c &= ~0x0203;
    if (this.c2d[2][2] < 0) c &= ~0x0406;
    if (this.c2d[3][2] < 0) c &= ~0x080c;
    if (this.c2d[4][2] < 0) c &= ~0x0190;
    if (this.c2d[5][2] < 0) c &= ~0x0230;
    if (this.c2d[6][2] < 0) c &= ~0x0460;
    if (this.c2d[7][2] < 0) c &= ~0x08c0;

    /* --- draw the cube edges --- */
    g.setColor(Color.black);
    if ((c & 0x0001) != 0) this.edge(g, 0, 1);
    if ((c & 0x0002) != 0) this.edge(g, 1, 2);
    if ((c & 0x0004) != 0) this.edge(g, 2, 3);
    if ((c & 0x0008) != 0) this.edge(g, 0, 3);
    if ((c & 0x0010) != 0) this.edge(g, 4, 5);
    if ((c & 0x0020) != 0) this.edge(g, 5, 6);
    if ((c & 0x0040) != 0) this.edge(g, 6, 7);
    if ((c & 0x0080) != 0) this.edge(g, 4, 7);
    if ((c & 0x0100) != 0) this.edge(g, 0, 4);
    if ((c & 0x0200) != 0) this.edge(g, 1, 5);
    if ((c & 0x0400) != 0) this.edge(g, 2, 6);
    if ((c & 0x0800) != 0) this.edge(g, 3, 7);

    /* --- draw the data points --- */
    if (this.ptcnt <= 0)        /* if there are no points, */
      return;                   /* abort the function */
    for (i = this.ptcnt; --i >= 0; )  /* project the points */
      this.points[i].project(this.proj);
    Arrays.sort(this.points, 0, this.ptcnt);
    s = this.msize; o = s >> 1; /* sort points according to depth and */
    t = this.mcorr;             /* compute the marker size parameters */
    for (i = this.ptcnt; --i >= 0; ) {
      p = this.points[i];       /* traverse the projected points */
      if (p.p[2] < 0) continue; /* check for successful projection */
      x =  (int)(p.p[0] +0.5) -o;  /* compute the */
      y = -(int)(p.p[1] +0.5) -o;  /* screen coordinates */
      g.setColor(this.colors[p.c]); g.fillOval(x, y, t, t);
      g.setColor(Color.black);      g.drawOval(x, y, s, s);
    }                           /* draw a marker at the point */
  }  /* paint() */

  /*------------------------------------------------------------------*/
  /** Create an image of the panel contents.
   *  @return an image of the panel contents
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public BufferedImage makeImage ()
  {                             /* --- create an image of contents */
    BufferedImage img;          /* created image */
    Dimension     d;            /* size of panel */

    d   = this.getSize();       /* get the current window size */
    img = new BufferedImage(d.width, d.height,
                            BufferedImage.TYPE_INT_ARGB);
    this.paint(img.getGraphics());
    return img;                 /* draw window contents to image */
  }  /* BufferedImage() */      /* and return the image */

}  /* Plot3D */
