/*----------------------------------------------------------------------
  File    : Block3D.java
  Contents: 3D block management
  Author  : Christian Borgelt
  History : 2004.06.05 file created
            2007.02.09 made a separate file
            2013.11.26 block height stored separately
----------------------------------------------------------------------*/
package draw;

import java.awt.Graphics;
import java.awt.Color;

/*--------------------------------------------------------------------*/
/** Internal class for a 3D block.
 *  @author Christian Borgelt
 *  @since  2004.06.05 */
/*--------------------------------------------------------------------*/
public class Block3D implements Comparable<Block3D> {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the corner points of the block */
  private Point3D[] cs;
  /** the visibility flags for the side planes */
  private boolean[] vs;
  /** the x-coordinates of the polygon to draw */
  private int[]     xs;
  /** the y-coordinates of the polygon to draw */
  private int[]     ys;
  /** the height of the block */
  private double    ht;
  /** the minimum distance of a corner to the eye */
  private double    min;

  /*------------------------------------------------------------------*/
  /** Create a 3D block.
   *  @param  x the x-coordinate of the lower left corner
   *  @param  y the y-coordinate of the lower left corner
   *  @param  z the z-coordinate of the lower left corner
   *  @param  w the width  of the block
   *  @param  d the depth  of the block
   *  @param  h the height of the block
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Block3D (double x, double y, double z,
                  double w, double d, double h)
  {                             /* --- create a block */
    this.cs    = new Point3D[8];/* create the eight corner points */
    this.cs[0] = new Point3D(x,   y,   z  );
    this.cs[1] = new Point3D(x+w, y,   z  );
    this.cs[2] = new Point3D(x+w, y+d, z  );
    this.cs[3] = new Point3D(x,   y+d, z  );
    this.cs[4] = new Point3D(x,   y,   z+h);
    this.cs[5] = new Point3D(x+w, y,   z+h);
    this.cs[6] = new Point3D(x+w, y+d, z+h);
    this.cs[7] = new Point3D(x,   y+d, z+h);
    this.vs    = new boolean[6];
    this.xs    = new int[12];   /* create coordinate vectors */
    this.ys    = new int[12];   /* for polygon drawing */
    this.ht    = h;             /* note the bar height */
  }  /* Block3D() */

  /*------------------------------------------------------------------*/
  /** Project the block to 2D.
   *  <p>The projection is stored internally and is used when the
   *  block is to be drawn.</p>
   *  @param  proj the 3D to 2D projection to use
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void project (Proj3D proj)
  {                             /* --- compute projection to 2D */
    int    i;                   /* loop variable */
    double x, y, z;             /* coordinates of reference point */

    for (i = 8; --i >= 0; ) {   /* project all corner points */
      if (this.cs[i].project(proj) < 0) continue;
      this.xs[4+i] =  (int)(this.cs[i].p[0] +0.5);
      this.ys[4+i] = -(int)(this.cs[i].p[1] +0.5);
    }                           /* compute visibility sines */
    for (this.min = Double.MAX_VALUE, i = 4; --i >= 0; )
      if (this.cs[i].p[2] < this.min) this.min = this.cs[i].p[2];
    x = this.cs[0].x; y = this.cs[0].y; z = this.cs[0].z;
    this.vs[0] = proj.isVisible(x, y, z, -1,  0,  0);
    this.vs[1] = proj.isVisible(x, y, z,  0, -1,  0);
    this.vs[2] = proj.isVisible(x, y, z,  0,  0, -1);
    x = this.cs[6].x; y = this.cs[6].y; z = this.cs[6].z;
    this.vs[3] = proj.isVisible(x, y, z,  1,  0,  0);
    this.vs[4] = proj.isVisible(x, y, z,  0,  1,  0);
    this.vs[5] = proj.isVisible(x, y, z,  0,  0,  1);
  }  /* project() */

  /*------------------------------------------------------------------*/
  /** Check whether the left side of the block is visible.
   *  @return whether the left side of the block is visible
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isLeftVisible   ()
  { return this.vs[0]; }

  /*------------------------------------------------------------------*/
  /** Check whether the front side of the block is visible.
   *  @return whether the front side of the block is visible
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isFrontVisible  ()
  { return this.vs[1]; }

  /*------------------------------------------------------------------*/
  /** Check whether the bottom side of the block is visible.
   *  @return whether the bottom side of the block is visible
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isBottomVisible ()
  { return this.vs[2]; }

  /*------------------------------------------------------------------*/
  /** Check whether the right side of the block is visible.
   *  @return whether the right side of the block is visible
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isRightVisible  ()
  { return this.vs[3]; }

  /*------------------------------------------------------------------*/
  /** Check whether the back side of the block is visible.
   *  @return whether the back side of the block is visible
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isBackVisible   ()
  { return this.vs[4]; }

  /*------------------------------------------------------------------*/
  /** Check whether the top side of the block is visible.
   *  @return whether the top side of the block is visible
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isTopVisible    ()
  { return this.vs[5]; }

  /*------------------------------------------------------------------*/
  /** Get the height of the block.
   *  @return the height of the block
   *  @since  2013.11.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getHeight        ()
  { return this.ht; }

  /*------------------------------------------------------------------*/
  /** Compare the depth of the projections of two blocks.
   *  @param  obj the block to compare to
   *  @return -1, if this block is nearer  to   the eye,<br>
   *          +1, if this block is farther from the eye,<br>
   *          0, if both blocks have the same (minimum) distance
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int compareTo (Block3D obj)
  {                             /* --- compare depth of projections */
    if (this.min < obj.min) return -1;
    if (this.min > obj.min) return +1;
    return 0;                   /* return sign of depth difference */
  }  /* compareTo() */

  /*------------------------------------------------------------------*/
  /** Draw an edge of a block.
   *  @param  g   the graphics to use for the drawing
   *  @param  src the index of the source      corner
   *  @param  dst the index of the destination corner
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void edge (Graphics g, int src, int dst)
  {                             /* --- draw a block edge */
    g.drawLine(this.xs[4 +src], this.ys[4 +src],
               this.xs[4 +dst], this.ys[4 +dst]);
  }  /* edge() */

  /*------------------------------------------------------------------*/
  /** Paint a block.
   *  @param  g      the graphics to use for the drawing
   *  @param  colors the colors to use for the different sides
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void paint (Graphics g, Color[] colors)
  {                             /* --- paint block */
    int   e = 0;                /* edge flags */
    Color c = g.getColor();     /* buffer for current color */

    /* --- paint the planes --- */
    if (this.vs[0]) {           /* if left plane visible */
      e |= 0x0988;              /* mark the plane's edges */
      this.xs[0] = this.xs[ 4]; this.ys[0] = this.ys[ 4];
      this.xs[1] = this.xs[ 7]; this.ys[1] = this.ys[ 7];
      this.xs[2] = this.xs[11]; this.ys[2] = this.ys[11];
      this.xs[3] = this.xs[ 8]; this.ys[3] = this.ys[ 8];
      if (colors != null) g.setColor(colors[0]);
      g.fillPolygon(this.xs, this.ys, 4);
    }
    if (this.vs[1]) {           /* if front plane visible */
      e |= 0x0311;              /* mark the plane's edges */
      this.xs[0] = this.xs[ 4]; this.ys[0] = this.ys[ 4];
      this.xs[1] = this.xs[ 5]; this.ys[1] = this.ys[ 5];
      this.xs[2] = this.xs[ 9]; this.ys[2] = this.ys[ 9];
      this.xs[3] = this.xs[ 8]; this.ys[3] = this.ys[ 8];
      if (colors != null) g.setColor(colors[1]);
      g.fillPolygon(this.xs, this.ys, 4);
    }
    if (this.vs[2]) {           /* if bottom plane visible */
      e |= 0x000f;              /* mark the plane's edges */
      this.xs[0] = this.xs[ 4]; this.ys[0] = this.ys[ 4];
      this.xs[1] = this.xs[ 5]; this.ys[1] = this.ys[ 5];
      this.xs[2] = this.xs[ 6]; this.ys[2] = this.ys[ 6];
      this.xs[3] = this.xs[ 7]; this.ys[3] = this.ys[ 7];
      if (colors != null) g.setColor(colors[2]);
      g.fillPolygon(this.xs, this.ys, 4);
    }
    if (this.vs[3]) {           /* if right plane visible */
      e |= 0x0622;              /* mark the plane's edges */
      this.xs[0] = this.xs[ 5]; this.ys[0] = this.ys[ 5];
      this.xs[1] = this.xs[ 6]; this.ys[1] = this.ys[ 6];
      this.xs[2] = this.xs[10]; this.ys[2] = this.ys[10];
      this.xs[3] = this.xs[ 9]; this.ys[3] = this.ys[ 9];
      if (colors != null) g.setColor(colors[3]);
      g.fillPolygon(this.xs, this.ys, 4);
    }
    if (this.vs[4]) {           /* if back plane visible */
      e |= 0x0c44;              /* mark the plane's edges */
      this.xs[0] = this.xs[ 6]; this.ys[0] = this.ys[ 6];
      this.xs[1] = this.xs[ 7]; this.ys[1] = this.ys[ 7];
      this.xs[2] = this.xs[11]; this.ys[2] = this.ys[11];
      this.xs[3] = this.xs[10]; this.ys[3] = this.ys[10];
      if (colors != null) g.setColor(colors[4]);
      g.fillPolygon(this.xs, this.ys, 4);
    }
    if (this.vs[5]) {           /* if top plane visible */
      e |= 0x00f0;              /* mark the plane's edges */
      this.xs[0] = this.xs[ 8]; this.ys[0] = this.ys[ 8];
      this.xs[1] = this.xs[ 9]; this.ys[1] = this.ys[ 9];
      this.xs[2] = this.xs[10]; this.ys[2] = this.ys[10];
      this.xs[3] = this.xs[11]; this.ys[3] = this.ys[11];
      if (colors != null) g.setColor(colors[5]);
      g.fillPolygon(this.xs, this.ys, 4);
      g.setColor(Color.black);
    }

    /* --- draw the edges --- */
    if (this.cs[0].p[2] < 0) e &= ~0x0109;
    if (this.cs[1].p[2] < 0) e &= ~0x0203;
    if (this.cs[2].p[2] < 0) e &= ~0x0406;
    if (this.cs[3].p[2] < 0) e &= ~0x080c;
    if (this.cs[4].p[2] < 0) e &= ~0x0190;
    if (this.cs[5].p[2] < 0) e &= ~0x0230;
    if (this.cs[6].p[2] < 0) e &= ~0x0460;
    if (this.cs[7].p[2] < 0) e &= ~0x08c0;
    g.setColor(Color.black);
    if ((e & 0x0001) != 0) this.edge(g, 0, 1);
    if ((e & 0x0002) != 0) this.edge(g, 1, 2);
    if ((e & 0x0004) != 0) this.edge(g, 2, 3);
    if ((e & 0x0008) != 0) this.edge(g, 0, 3);
    if ((e & 0x0010) != 0) this.edge(g, 4, 5);
    if ((e & 0x0020) != 0) this.edge(g, 5, 6);
    if ((e & 0x0040) != 0) this.edge(g, 6, 7);
    if ((e & 0x0080) != 0) this.edge(g, 4, 7);
    if ((e & 0x0100) != 0) this.edge(g, 0, 4);
    if ((e & 0x0200) != 0) this.edge(g, 1, 5);
    if ((e & 0x0400) != 0) this.edge(g, 2, 6);
    if ((e & 0x0800) != 0) this.edge(g, 3, 7);
    g.setColor(c);          /* restore the drawing color */
  }  /* paint() */

  /*------------------------------------------------------------------*/
  /** Draw a label on a block.
   *  @param  g    the graphics to use for the drawing
   *  @param  font the font to use for the text
   *  @param  s    the string to label the block with
   *  @since  2004.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void label (Graphics g, Font3D font, String s)
  {                             /* --- label a block */
    font.draw(g, this.cs[4].x, this.cs[4].y, this.cs[4].z,
              Font3D.H_POS_X|Font3D.V_POS_Y, s);
  }  /* label() */

}  /* Block3D */
