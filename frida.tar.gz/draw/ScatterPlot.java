/*----------------------------------------------------------------------
  File    : ScatterPlot.java
  Contents: frame class for a 3D scatter plot
  Author  : Christian Borgelt
  History : 2004.06.02 file created from file DTView.java
            2007.02.07 adapted to new table classes
            2007.02.08 data format dialog box added
            2007.02.09 some cleaning up and restructuring
            2007.02.11 owner handling and positioning corrected
            2007.02.12 returned to delayed dialog box creation
            2007.02.22 color selection dialog added
            2007.02.23 color selection extended and debugged
            2007.07.07 adapted to new class DialogPanel
            2007.07.18 dialog boxes changed to "Apply", "Ok", "Cancel"
            2007.07.19 adapted to changed Table class
            2013.04.22 adapted to type argument of JComboBox
            2013.04.22 adapted to class name change Type -> ColType
            2013.12.12 nominal attributes for axes made possible
            2013.12.13 changed default field of view to 30 degrees
            2013.12.28 metric attributes added as possible overlays
            2014.01.27 inset percentage moved to layout dialog
            2014.10.23 changed from LGPL license to MIT license
            2018.11.14 replaced some deprecated functions
----------------------------------------------------------------------*/
package draw;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.awt.Component;
import java.awt.Container;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.BorderFactory;
import javax.imageio.ImageIO;

import util.TableReader;
import table.ColType;
import table.NominalType;
import table.MetricType;
import table.RealType;
import table.Column;
import table.Table;
import dialog.DialogPanel;
import dialog.FormatDialog;
import dialog.ColorDialog;
import dialog.AboutDialog;

/*--------------------------------------------------------------------*/
/** Class for a 3D scatter plot frame.
 *  @author Christian Borgelt
 *  @since  2004.06.02 */
/*--------------------------------------------------------------------*/
public class ScatterPlot extends JFrame implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010010L;
  public  static final String VERSION = "1.16 (2018.11.14)";

  /** mode flag: the scatter plot is a stand-alone program */
  public final static int PROGRAM    = 1;
  /** mode flag: add menu items for loading tables */
  public final static int LOAD_ITEMS = 2;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this scatter plot */
  private Component         owner   = null;
  /** the mode flags */
  private int               mode    = 0;
  /** the scatter plot panel */
  private Plot3D            panel   = null;
  /** the status bar for messages */
  private JTextField        status  = null;
  /** the file chooser */
  private JFileChooser      chooser = null;
  /** the current table file */
  private File              curr    = null;
  /** the full data table */
  private Table             table   = null;
  /** the columns/attributes of the data (nominal and metric) */
  private Column[]          atts    = null;
  /** the minimum values for the columns/attributes */
  private double[]          mins    = null;
  /** the maximum values for the columns/attributes */
  private double[]          maxs    = null;

  /* --- data format dialog box --- */
  /** the data format dialog box */
  private FormatDialog      format  = null;

  /* --- attributes dialog box --- */
  /** the attribute selector dialog box */
  private JDialog           attsel  = null;
  /** the attribute for the x-axis */
  private JComboBox<String> xatt    = null;
  /** the minimum value of the attribute for the x-axis */
  private JTextField        xmin    = null;
  /** the maximum value of the attribute for the x-axis */
  private JTextField        xmax    = null;
  /** the attribute for the y-axis */
  private JComboBox<String> yatt    = null;
  /** the minimum value of the attribute for the y-axis */
  private JTextField        ymin    = null;
  /** the maximum value of the attribute for the y-axis */
  private JTextField        ymax    = null;
  /** the attribute for the z-axis */
  private JComboBox<String> zatt    = null;
  /** the minimum value of the attribute for the z-axis */
  private JTextField        zmin    = null;
  /** the maximum value of the attribute for the z-axis */
  private JTextField        zmax    = null;
  /** the attribute for the overlay */
  private JComboBox<String> over    = null;
  /** the index of the attribute for the overlay */
  private int               ovlid   = 0;

  /* --- layout dialog box --- */
  /** the layout dialog box */
  private JDialog           layout  = null;
  /** the field of view */
  private JSpinner          fov     = null;
  /** the label font size */
  private JSpinner          size    = null;
  /** the label offset */
  private JSpinner          offset  = null;
  /** the marker size */
  private JSpinner          mark    = null;
  /** the inset percentage */
  private JSpinner          inset   = null;

  /* --- color dialog box --- */
  /** the color selection dialog box */
  private ColorDialog       colsel  = null;

  /* --- about dialog box --- */
  /** the "About..." dialog box */
  private AboutDialog       about   = null;

  /*------------------------------------------------------------------*/
  /** Create a 3D scatter plot frame.
   *  @param  mode the mode flags
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ScatterPlot (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create a 3D scatter plot frame.
   *  @param  owner the component that is to own this scatter plot
   *  @param  mode  the mode flags
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ScatterPlot (Component owner, int mode)
  {                             /* --- create a scatter plot frame */
    this.owner = owner;         /* note the owner */
    this.mode  = mode;          /* and the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* ScatterPlot() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create a scatter plot viewer */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    if ((this.mode & PROGRAM) != 0)
      this.mode |= LOAD_ITEMS;  /* check and adapt the mode */

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    if ((this.mode & LOAD_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Load Table...", 'l'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ScatterPlot.this.loadTable(null); } } );
      item = menu.add(new JMenuItem("Reload Table", 'r'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ScatterPlot.this.loadTable(ScatterPlot.this.curr); } } );
      menu.addSeparator();
      item = menu.add(new JMenuItem("Data Format...", 'f'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ScatterPlot.this.getFormatDlg().setVisible(true);
          ScatterPlot.this.format.toFront();
        } } );
      menu.addSeparator();
    }
    item = menu.add(new JMenuItem("Save PNG Image...", 'i'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.saveImage(null); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          ScatterPlot.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("View"));
    menu.setMnemonic('v');
    item = menu.add(new JMenuItem("Set Attributes...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.getAttSelDlg().setVisible(true);
        ScatterPlot.this.attsel.toFront();
      } } );
    item = menu.add(new JMenuItem("Set Layout...", 'l'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.getLayoutDlg().setVisible(true);
        ScatterPlot.this.layout.toFront();
      } } );
    item = menu.add(new JMenuItem("Set Colors...", 'c'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.getColorDlg().setVisible(true);
        ScatterPlot.this.colsel.toFront();
      } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Reset View", 'v'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.panel.resetView();
        ScatterPlot.this.panel.repaint();
      } } );
    item = menu.add(new JMenuItem("Redraw", 'r'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.panel.repaint(); } } );

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (ScatterPlot.this.about == null)
          ScatterPlot.this.about = new AboutDialog(ScatterPlot.this,
             "About ScatterPlot...", "ScatterPlot\n"
            +"A 3D Scatter Plot Program\n"
            +"Version " +ScatterPlot.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        ScatterPlot.this.about.setVisible(true);
        ScatterPlot.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    this.panel = new Plot3D();
    this.panel.setLayout(new BorderLayout());
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(this.panel, BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    this.status = new JTextField("");
    this.status.setEditable(false);
    content.add(this.status,  BorderLayout.SOUTH);

    /* --- configure and show the frame window --- */
    this.setTitle("ScatterPlot");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser (create if necessary).
   *  @return the file chooser
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure the chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Get the data format dialog (create if necessary).
   *  @return the data format dialog
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private FormatDialog getFormatDlg()
  {                             /* --- get the data format dialog */
    if (this.format == null)    /* if it does not exist, create it */
      this.format = new FormatDialog(this);
    return this.format;         /* return the data format dialog */
  }  /* getFormatDlg() */

  /*------------------------------------------------------------------*/
  /** Get the attribute selector dialog box (create if necessary).
   *  @return the attribute selector dialog box
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getAttSelDlg ()
  {                             /* --- create attribute selector */
    DialogPanel tab;            /* panel for the dialog fields */
    JPanel      bbar;           /* panel for the button bar */
    JButton     button;         /* button for apply and close */

    if (this.attsel != null)    /* if the dialog box exists, */
      return this.attsel;       /* simply return it */
    this.attsel = new JDialog(this);
    tab = new DialogPanel();    /* create the main panel */

    /* --- input widgets for x-axis --- */
    tab.addLabel("X-axis:");
    this.xatt = tab.addComboBox(null);
    tab.addLabel("Range of values:");
    this.xmin = tab.addNumberInput("", DialogPanel.MIDDLE);
    this.xmax = tab.addNumberInput("", DialogPanel.RIGHT);
    this.xatt.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        int i = ScatterPlot.this.xatt.getSelectedIndex();
        if (i < 0) return;
        ScatterPlot.this.xmin.setText(
          String.valueOf(ScatterPlot.this.mins[i]));
        ScatterPlot.this.xmax.setText(
          String.valueOf(ScatterPlot.this.maxs[i]));
      } } );

    /* --- input widgets for y-axis --- */
    tab.addLabel("Y-axis:");
    this.yatt = tab.addComboBox(null);
    tab.addLabel("Range of values:");
    this.ymin = tab.addNumberInput("", DialogPanel.MIDDLE);
    this.ymax = tab.addNumberInput("", DialogPanel.RIGHT);
    this.yatt.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        int i = ScatterPlot.this.yatt.getSelectedIndex();
        if (i < 0) return;
        ScatterPlot.this.ymin.setText(
          String.valueOf(ScatterPlot.this.mins[i]));
        ScatterPlot.this.ymax.setText(
          String.valueOf(ScatterPlot.this.maxs[i]));
      } } );

    /* --- input widgets for z-axis --- */
    tab.addLabel("Z-axis:");
    this.zatt = tab.addComboBox(null);
    tab.addLabel("Range of values:");
    this.zmin = tab.addNumberInput("", DialogPanel.MIDDLE);
    this.zmax = tab.addNumberInput("", DialogPanel.RIGHT);
    this.zatt.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        int i = ScatterPlot.this.zatt.getSelectedIndex();
        if (i < 0) return;
        ScatterPlot.this.zmin.setText(
          String.valueOf(ScatterPlot.this.mins[i]));
        ScatterPlot.this.zmax.setText(
          String.valueOf(ScatterPlot.this.maxs[i]));
      } } );

    /* --- input widgets for overlay --- */
    tab.addLabel("Overlay:");
    this.over = tab.addComboBox(null);
    this.over.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        if (ScatterPlot.this.colsel == null) return;
        ScatterPlot.this.colsel.setSelectedAtt(
          (String)ScatterPlot.this.over.getSelectedItem());
      } } );

    /* --- button bar --- */
    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.setAxesAtts(); } } );
    bbar.add(button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.attsel.setVisible(false);
        ScatterPlot.this.setAxesAtts(); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.attsel.setVisible(false); } } );

    this.attsel.getContentPane().add(tab,  BorderLayout.CENTER);
    this.attsel.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.attsel.setTitle("Set Attributes...");
    this.attsel.setLocationRelativeTo(this);
    this.attsel.pack();
    return this.attsel;
  }  /* getAttSelDlg() */

  /*------------------------------------------------------------------*/
  /** Set the layout.
   *  @since  2007.07.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setLayout ()
  {                             /* --- set the layout */
    this.panel.setFOV(          /* field of view */
      ((Integer)this.fov.getValue()).intValue()*Math.PI/180);
    this.panel.setLayout(       /* label offset and size */
      ((Integer)this.offset.getValue()).intValue() *0.01,
      ((Integer)this.size.getValue()).intValue()   *0.01);
    this.panel.setMarker(       /* data point marker size */
      ((Integer)this.mark.getValue()).intValue());
    this.panel.setInset(((Integer)this.inset.getValue()).doubleValue());
    this.panel.repaint();       /* repaint the panel */
  }  /* setLayout() */

  /*------------------------------------------------------------------*/
  /** Get the layout dialog box (create if necessary).
   *  @return the layout dialog box
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getLayoutDlg ()
  {                             /* --- create layout params. dialog */
    DialogPanel tab;            /* panel for the dialog fields */
    JPanel      bbar;           /* panel for the button bar */
    JButton     button;         /* button for apply and close */

    if (this.layout != null)    /* if the dialog box exists, */
      return this.layout;       /* simply return it */
    this.layout = new JDialog(this);
    tab = new DialogPanel();    /* create the main panel */

    tab.addLabel("Field of view (angle):");
    this.fov    = tab.addSpinner(30, 1, 160, 1);
    tab.addLabel("Label size:");
    this.size   = tab.addSpinner(12, 0, 200, 1);
    tab.addLabel("Label offset:");
    this.offset = tab.addSpinner( 4, 0, 200, 1);
    tab.addLabel("Marker size (pixels):");
    this.mark   = tab.addSpinner( 6, 1, 255, 1);
    tab.addLabel("Inset percentage:");
    this.inset  = tab.addSpinner( 5, 0,  99, 1);

    bbar = new JPanel(new GridLayout(1, 2, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(0, 4, 4, 4));
    bbar.add(button = new JButton("Apply"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.setLayout(); } } );
    bbar.add(button = new JButton("Ok"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.layout.setVisible(false);
        ScatterPlot.this.setLayout(); } } );
    bbar.add(button = new JButton("Cancel"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.layout.setVisible(false); } } );

    this.layout.getContentPane().add(tab,  BorderLayout.CENTER);
    this.layout.getContentPane().add(bbar, BorderLayout.SOUTH);
    this.layout.setTitle("Set Layout...");
    this.layout.setLocationRelativeTo(this);
    this.layout.pack();
    return this.layout;
  }  /* getLayoutDlg() */

  /*------------------------------------------------------------------*/
  /** Get the color selection dialog box (create if necessary).
   *  @return the color selection dialog box
   *  @since  2007.02.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JDialog getColorDlg ()
  {                             /* --- create color chooser dialog */
    if (this.colsel != null)    /* if the dialog already exists, */
      return this.colsel;       /* simply return it */
    this.colsel = new ColorDialog(this, "Set Colors...");
    this.setColorAtts();        /* set the relevant attributes */
    this.colsel.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        ScatterPlot.this.setColors(); } } );
    return this.colsel;         /* return the created color dialog */
  }  /* getColorDlg() */

  /*------------------------------------------------------------------*/
  /** Set the range of values from inputs.
   *  @param  index the index of the metric column
   *  @param  tfmin the text field containing the minimum value
   *  @param  tfmax the text field containing the maximum value
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setRange (int index, JTextField tfmin, JTextField tfmax)
  {                             /* --- set range of values */
    double min, max, t;         /* minimum and maximum value, buffer */

    try { min = Double.parseDouble(tfmin.getText()); }
    catch (NumberFormatException e) { min = 0; }
    try { max = Double.parseDouble(tfmax.getText()); }
    catch (NumberFormatException e) { max = 0; }
    if (max <  min) { t = min; min = max; max = t; }
    if (max <= min) { max += min; min =  0; }
    if (max <= min) { max = +1;   min = -1; }
    this.mins[index] = min;     /* get and adapt the range of values */
    this.maxs[index] = max;     /* and store this range */
  }  /* setRange() */

  /*------------------------------------------------------------------*/
  /** Set the selected attributes for the axes from the inputs.
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setAxesAtts ()
  {                             /* --- set selected axes attributes */
    int    i, n, c;             /* loop variable, color */
    int    ix, iy, iz, io;      /* indices of data colums */
    Column cx, cy, cz, co;      /* data columns */
    int[]  rx, ry, rz, ro;      /* raw nominal data */
    double xoff, yoff, zoff;    /* offsets for scaling */
    double xscl, yscl, zscl;    /* scaling factors */
    double x, y, z, o;          /* coordinates, overlay value */

    this.panel.clear();         /* remove all points */
    if ((this.atts == null) || (this.atts.length <= 1)) {
      this.panel.setXLabel(""); /* if there are no metric columns, */
      this.panel.setYLabel(""); /* remove all labels */
      this.panel.setZLabel(""); return;
    }
    rx = ry = rz = ro = null;   /* clear the raw data arrays */

    ix = this.xatt.getSelectedIndex();
    cx = this.atts[ix];         /* get range and scaling for x-dir. */
    this.panel.setXLabel(cx.getName());
    if      (ix >= this.atts.length-1) cx = null;
    else if (cx.getType() instanceof NominalType)
      rx = (int[])cx.getData(); /* for nominal column get raw data */
    this.setRange(ix, this.xmin, this.xmax);
    xoff = 0.5 *(this.maxs[ix] +this.mins[ix]);
    xscl = 2.0 /(this.maxs[ix] -this.mins[ix]);

    iy = this.yatt.getSelectedIndex();
    cy = this.atts[iy];         /* get range and scaling for x-dir. */
    this.panel.setYLabel(cy.getName());
    if      (iy >= this.atts.length-1) cy = null;
    else if (cy.getType() instanceof NominalType)
      ry = (int[])cy.getData(); /* for nominal column get raw data */
    this.setRange(iy, this.ymin, this.ymax);
    yoff = 0.5 *(this.maxs[iy] +this.mins[iy]);
    yscl = 2.0 /(this.maxs[iy] -this.mins[iy]);

    iz = this.zatt.getSelectedIndex();
    cz = this.atts[iz];         /* get range and scaling for x-dir. */
    this.panel.setZLabel(cz.getName());
    if      (iz >= this.atts.length-1) cz = null;
    else if (cz.getType() instanceof NominalType)
      rz = (int[])cz.getData(); /* for nominal column get raw data */
    this.setRange(iz, this.zmin, this.zmax);
    zoff = 0.5 *(this.maxs[iz] +this.mins[iz]);
    zscl = 2.0 /(this.maxs[iz] -this.mins[iz]);

    this.ovlid = io = this.over.getSelectedIndex();
    co = this.atts[io];         /* get range and scaling for x-dir. */
    if      (io >= this.atts.length-1) co = null;
    else if (co.getType() instanceof NominalType)
      ro = (int[])co.getData(); /* for nominal column get raw data */

    n = this.table.getRowCount();
    for (i = 0; i < n; i++) {   /* traverse the table rows */
      if      ( rx != null)   x = (double)rx[i];
      else if ( cx == null)   x = 0;
      else if (!cx.isNull(i)) x = cx.getNumberAt(i);
      else continue;            /* get the x-coordinate */
      if      ( ry != null)   y = (double)ry[i];
      else if ( cy == null)   y = 0;
      else if (!cy.isNull(i)) y = cy.getNumberAt(i);
      else continue;            /* get the y-coordinate */
      if      ( rz != null)   z = (double)rz[i];
      else if ( cz == null)   z = 0;
      else if (!cz.isNull(i)) z = cz.getNumberAt(i);
      else continue;            /* get the y-coordinate */
      if      ( ro != null)   c = ro[i];
      else if ( co == null)   c = 0;
      else if (!co.isNull(i)) c = i;
      else continue;            /* get the overlay value */
      if (c < 0) continue;      /* check for a valid color index */
      this.panel.addPoint(xscl *(x -xoff),
                          yscl *(y -yoff),
                          zscl *(z -zoff), c);
    }                           /* add all data points */
    this.panel.build();         /* build the scatter plot */
    this.setColors();           /* set the overlay colors */
    this.panel.repaint();       /* and repaint the panel */
  }  /* setAxesAtts() */

  /*------------------------------------------------------------------*/
  /** Set attributes for color selection.
   *  @since  2007.02.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setColorAtts ()
  {                             /* --- set attributes for color sel. */
    int    i, n;                /* loop variables */
    Table  tab;                 /* table of nominal columns */
    Column col;                 /* to traverse the columns */

    if (this.colsel == null) return;
    if ((this.atts == null) || (this.atts.length <= 0)) {
      this.colsel.setTable(null); return; }
    tab = new Table("overlay"); /* create table of overlay columns */
    for (n = this.atts.length-1, i = 0; i < n; i++) {
      col = this.atts[i];       /* traverse the overlay columns */
      tab.addColumn(new Column(col.getName(), col.getType()));
    }                           /* add column copies to the table */
    tab.addColumn(this.atts[n]);/* add column for default color */
    this.colsel.setTable(tab);  /* set the created table copy */
  }  /* setColorAtts() */

  /*------------------------------------------------------------------*/
  /** Blend two colors (linear interpolation in RGB space).
   *  @param  c1  the first  color to blend
   *  @param  c2  the second color to blend
   *  @param  w   the weight of the first color;
   *              (weight of the second color is 1-w)
   *  @since  2013.12.28 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private static Color blend (Color c1, Color c2, double w)
  {                             /* --- blend two colors */
    int r = (int)(w *c1.getRed()   +(1-w) *c2.getRed()   +0.5);
    int g = (int)(w *c1.getGreen() +(1-w) *c2.getGreen() +0.5);
    int b = (int)(w *c1.getBlue()  +(1-w) *c2.getBlue()  +0.5);
    if (r < 0) r = 0; if (r > 255) r = 255;
    if (g < 0) g = 0; if (g > 255) g = 255;
    if (b < 0) b = 0; if (b > 255) b = 255;
    return new Color(r, g, b);  /* return the blended color */
  }  /* blend() */

  /*------------------------------------------------------------------*/
  /** Set selected overlay colors.
   *  @since  2007.02.22 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void setColors ()
  {                             /* --- set the overlay colors */
    int     i, k, n;            /* loop variables */
    Column  c;                  /* overlay column */
    ColType t;                  /* type of overlay column */
    Color   h;                  /* to traverse the colors */
    Color[] cols;               /* array of color levels */
    double  x;                  /* color range expansion, value */
    double  o, s;               /* offset and scaling factor */
    float   hue;                /* value of a color (hue) */

    if ((this.atts == null)     /* check for a valid overlay */
    ||  (this.ovlid < 0) || (this.ovlid >= this.atts.length))
      return;                   /* abort if there is no overlay */
    c = this.atts[this.ovlid];  /* get the overlay column */
    t = c.getType();            /* and its type */
    if (t instanceof NominalType) {
      n = t.getInfoCount();     /* if nominal column/attribute */
      for (i = 0; i < n; i++) { /* traverse the attribute values */
        h = (Color)t.getInfo(i);/* get and check the stored color */
        if (h == null) {        /* if there is no stored color */
          hue = (float)(i/(double)n);
          t.setInfo(i, h = Color.getHSBColor(hue, 1, 1));
        }                       /* create a default color */
        this.panel.setColor(i, h);
      } }                       /* set the color for the value */
    else {                      /* if metric column/attribute */
      n = t.getInfoCount()-1;   /* get the number of color levels */
      if (n <= 0) {             /* if there are no color levels */
        for (i = n = 5; --i >= 0; ) {
          hue = (float)(i/(double)(n-1) *(2/3.0));
          t.setInfo("level " +i, Color.getHSBColor(hue, 1, 1));
        }                       /* create a default rainbow scale */
        t.setInfo("", Double.valueOf(0.33));
      }                         /* create a default expansion factor */
      cols = new Color[n+2];    /* create an array of color levels */
      cols[0] = cols[n+1] = Color.BLACK;
      for (i = 0; i < n; i++)   /* get the color levels of the type */
        cols[i+1] = (Color)t.getInfo(i);
      x = ((Double)t.getInfo(n)).doubleValue();
      o = ((MetricType)t).getMinNumber();
      s = ((MetricType)t).getMaxNumber() -o;
      s = (s > 0) ? (n-1+2*x)/s : 1.0;
      if (s > 0) o -= (1-x)/s;  /* compute color range parameters */
      for (k = c.getRowCount(); --k >= 0; ) {
        if (c.isNull(k)) continue;  /* traverse the column values */
        x = (c.getNumberAt(k) -o) *s;
        i = (int)x;             /* get the scaled attribute value */
        if      (i < 0) h = cols[0];
        else if (i > n) h = cols[n+1];
        else h = ScatterPlot.blend(cols[i+1], cols[i], x-i);
        this.panel.setColor(k, h);
      }                         /* interpolate colors linearly */
    }                           /* and set the computed color */
    this.panel.repaint();       /* repaint the panel */
  }  /* setColors() */

  /*------------------------------------------------------------------*/
  /** Set the table to display.
   *  @param  tab the table to display
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTable (Table tab)
  {                             /* --- set the table to display */
    int     i, k, n;            /* loop variables, counters */
    String  name;               /* buffer for column name */
    Column  c;                  /* to traverse the columns */
    ColType t;                  /* to traverse the column  types */
    double  min, max;           /* buffers for minimum and maximum */

    this.table = tab;           /* note the table */
    this.getAttSelDlg();        /* create attribute selector */

    /* --- collect table columns --- */
    n = (tab != null) ? tab.getColumnCount() : 0;
    for (i = k = 0; i < n; i++){/* traverse the table columns */
      t = tab.getColumn(i).getType();
      if ((t instanceof NominalType) || (t instanceof MetricType))
        k++;                    /* count metric and nominal columns */
    }                           /* (for column array allocation) */
    this.atts = new Column[k+1];
    for (i = k = 0; i < n; i++) {
      c = tab.getColumn(i);     /* traverse the table columns again */
      t = c.getType();          /* and evaluate their types */
      if ((t instanceof NominalType) || (t instanceof MetricType))
        this.atts[k++] = c;     /* collect the relevant table columns */
    }                           /* (nominal and metric attributes) */
    name = "<none>";            /* create a name for an add. column */
    for (i = 1; tab.getColumn(name) != null; i++)
      name = "<none>_" +i;      /* make sure it does not occur */
    t = new NominalType();      /* create an additional column */
    t.addValue("default");      /* for the default color/no attribute */
    this.atts[k++] = new Column(name, t, 0);

    /* --- determine scaling parameters --- */
    this.mins = (k > 0) ? new double[k] : null;
    this.maxs = (k > 0) ? new double[k] : null;
    for (i = 0; i < k; i++) {   /* traverse the columns */
      t = this.atts[i].getType();
      if (t instanceof MetricType) {
        min = ((MetricType)t).getMinNumber(); /* get range of values */
        max = ((MetricType)t).getMaxNumber(); /* for metric columns */
        if (min >= Double.POSITIVE_INFINITY) { max = +1;   min = -1; }
        if (max <= min)                      { max += min; min =  0; }
        if (max <= min)                      { max += 1;   min -= 1; } }
      else {                    /* if nominal column */
        min = 0; max = ((NominalType)t).getValueCount()-1;
        if (max < 0) max = 0;   /* get the range of values */
      }                         /* for each nominal column */
      this.mins[i] = min;       /* adapt the range of values, */
      this.maxs[i] = max;       /* so that it is not empty, and */
    }                           /* note this range of values */

    /* --- build attribute selectors --- */
    this.xatt.removeAllItems();
    this.yatt.removeAllItems();
    this.zatt.removeAllItems();
    this.over.removeAllItems();
    for (i = 0; i < k; i++) {   /* traverse the columns/attributes */
      this.xatt.addItem(name = this.atts[i].getName());
      this.yatt.addItem(name);  /* add the names of all columns */
      this.zatt.addItem(name);  /* for all dimensions (x, y, z) */
      this.over.addItem(name);  /* and for the overlay selector */
    }
    if (k <= 0) {                /* if there are no columns/attributes */
      this.xmin.setText(""); this.xmax.setText("");
      this.ymin.setText(""); this.ymax.setText("");
      this.zmin.setText(""); this.zmax.setText(""); }
    else {                      /* if there are columns/attributes */
      this.xatt.setSelectedIndex(i = 0);
      this.xmin.setText(String.valueOf(this.mins[i]));
      this.xmax.setText(String.valueOf(this.maxs[i]));
      this.yatt.setSelectedIndex(i = 1 % k);
      this.ymin.setText(String.valueOf(this.mins[i]));
      this.ymax.setText(String.valueOf(this.maxs[i]));
      this.zatt.setSelectedIndex(i = 2 % k);
      this.zmin.setText(String.valueOf(this.mins[i]));
      this.zmax.setText(String.valueOf(this.maxs[i]));
      for (i = k-1; --i >= 0; ) /* find last nominal attribute */
        if (this.atts[i].getType() instanceof NominalType) break;
      this.over.setSelectedIndex((i < 3) ? 3 % k : i);
    }                           /* set the column names and ranges */

    /* --- initialize the scatter plot --- */
    this.setColorAtts();        /* set the color attributes */
    this.setAxesAtts();         /* and the initial selection and */
    this.attsel.pack();         /* reformat the attribute selector */
    this.status.setText(tab.getName());
  }  /* setTable() */

  /*------------------------------------------------------------------*/
  /** Get the currently displayed table.
   *  @return the currently displayed table
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getTable ()
  { return this.table; }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void reportError (String msg)
  {                             /* --- report an i/o error */
    this.status.setText(msg);   /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this, msg,
      "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load the table to display.
   *  @param  file the file to load the table from
   *  @return whether the file was successfully loaded
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadTable (File file)
  {                             /* --- load a data table */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get the selected file */
    this.getFormatDlg();        /* create format dialog if necessary */
    try {                       /* and create corresp. table reader */
      System.err.print("reading " +file +" ... ");
      long        t      = System.currentTimeMillis();
      TableReader reader = this.format.createReader(file);
      Table       tab    = new Table(file.getPath());
      tab.read(reader, this.format.getTableMode());
      reader.close();           /* read table from the given file */
      tab.autoType();           /* determine types automatically */
      this.setTable(tab);       /* set the loaded table */
      t = System.currentTimeMillis() -t;
      System.err.print("[" +tab.getColumnCount() +" column(s), ");
      System.err.print(     tab.getRowCount()    +" row(s)] done");
      System.err.println(" [" +(t/(float)1000.0) +"s]."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    this.panel.resetView();     /* reset the view of the panel */
    if ((this.atts == null)     /* if there are no metric columns */
    ||  (this.atts.length <= 1)) {
      JOptionPane.showMessageDialog(this,
        "file " +file.getName() +":\nno usable columns",
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show an alert box */
    this.status.setText(file.getPath());
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadTable() */

  /*------------------------------------------------------------------*/
  /** Save a PNG image of the panel.
   *  @param  file the file to save the image to
   *  @return whether the file was successfully written
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveImage (File file)
  {                             /* --- save image to a file */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* let the user choose a file name */
    try {                       /* open an output stream */
      System.err.print("writing " +file +" ... ");
      long             t      = System.currentTimeMillis();
      FileOutputStream stream = new FileOutputStream(file);
      ImageIO.write(this.panel.makeImage(), "png", stream);
      stream.close();           /* save the scatter plot image */
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/(float)1000.0) +"s]."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(e.getMessage()); return false; }
    return true;                /* return 'ok' */
  }  /* saveImage() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    ScatterPlot sp = new ScatterPlot(PROGRAM);
    if (args.length > 0) sp.loadTable(new File(args[0]));
    sp.setVisible(true);        /* create and show a scatter plot */
  }  /* main() */

}  /* class ScatterPlot */
