/*----------------------------------------------------------------------
  File    : Point3D.java
  Contents: colored 3D point management
  Author  : Christian Borgelt
  History : 2004.06.02 file created
            2004.06.05 made a separate file
            2007.02.07 javadoc added
            2014.01.27 function scale() added
----------------------------------------------------------------------*/
package draw;

/*--------------------------------------------------------------------*/
/** Class for colored 3D points and their projection.
 *  @author Christian Borgelt
 *  @since  2004.06.02 */
/*--------------------------------------------------------------------*/
public class Point3D implements Comparable<Point3D> {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the x-coordinate of the point in 3D space */
  protected double   x;
  /** the y-coordinate of the point in 3D space */
  protected double   y;
  /** the z-coordinate of the point in 3D space */
  protected double   z;
  /** the color of the point */
  protected int      c;
  /** the projection of the point in 2D space */
  protected double[] p;

  /*------------------------------------------------------------------*/
  /** Create a colored 3D point.
   *  @param  x the x-coordinate of the point
   *  @param  y the y-coordinate of the point
   *  @param  z the z-coordinate of the point
   *  @param  c the color of the point
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Point3D (double x, double y, double z, int c)
  {                             /* --- create a point */
    this.x = x; this.y = y; this.z = z;
    this.c = c;                 /* note coordinates and color */
    this.p = new double[3];     /* allocate projected point */
  }  /* Point3D() */

  /*------------------------------------------------------------------*/
  /** Create an uncolored 3D point (color 0).
   *  @param  x the x-coordinate of the point
   *  @param  y the y-coordinate of the point
   *  @param  z the z-coordinate of the point
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Point3D (double x, double y, double z)
  { this(x, y, z, 0); }

  /*------------------------------------------------------------------*/
  /** Scale a colored 3D point.
   *  @param  s the scaling factor for multiplying the coordinates
   *  @since  2014.01.27 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void scale (double s)
  { this.x *= s; this.y *= s; this.z *= s; }

  /*------------------------------------------------------------------*/
  /** Project a colored 3D point.
   *  @param  proj the 3D to 2D projection to use
   *  @return whether the point is inside the viewing frustrum
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int project (Proj3D proj)
  {                             /* --- compute projection to 2d */
    int r = proj.project(this.x, this.y, this.z, this.p);
    if (r < 0) this.p[2] = -1;  /* project the point */
    return r;                   /* and return the result */
  }  /* project() */

  /*------------------------------------------------------------------*/
  /** Compare the depths of the projections of two points.
   *  @param  obj the point to compare to
   *  @return -1, if this point is nearer  to   the eye,<br>
   *          +1, if this point is farther from the eye,<br>
   *          0, if both points have the same distance
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int compareTo (Point3D obj)
  {                             /* --- compare depth of projections */
    if (this.p[2] < obj.p[2]) return -1;
    if (this.p[2] > obj.p[2]) return +1;
    return 0;                   /* return sign of depth difference */
  }  /* compareTo() */

}  /* Point3D */
