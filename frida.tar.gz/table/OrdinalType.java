/*----------------------------------------------------------------------
  File    : OrdinalType.java
  Contents: Management of ordinal types for data tables
  Author  : Christian Borgelt
  History : 2006.09.16 file created as NumericType.java
            2007.02.02 split into OrdinalType and MetricType
            2007.02.18 storing additional information added
            2013.04.22 adapted to class name change Type -> ColType
----------------------------------------------------------------------*/
package table;

/*--------------------------------------------------------------------*/
/** Class for ordinal types for data tables.
 *  @author Christian Borgelt
 *  @since  2006.09.16 */
/*--------------------------------------------------------------------*/
public abstract class OrdinalType extends ColType
  implements Cloneable {

  /*------------------------------------------------------------------*/
  /*  instance variable                                               */
  /*------------------------------------------------------------------*/
  /** the information stored with the minimum value */
  protected Object mininfo = null;
  /** the information stored with the maximum value */
  protected Object maxinfo = null;

  /*------------------------------------------------------------------*/
  /** Get the value associated with an identifier.
   *  @param  id the value identifier
   *  @return <code>"minimum"</code> if <code>id &le; 0</code> and
   *          <code>"maximum"</code> otherwise
   *  @since  2007.07.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValue (int id)
  { return (id <= 0) ? "minimum" : "maximum"; }

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Object getMin ();

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Object getMax ();

  /* In addition to these generic functions, which return the values  */
  /* as object types, subclasses of this type should define functions */
  /* getMinRaw() and getMaxRaw() that return the minimal and maximal  */
  /* value in the storage class type. */

  /*------------------------------------------------------------------*/
  /** Get the information associated with the minimal value.
   *  @return the information associated with the minimal value
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMinInfo ()
  { return this.mininfo; }

  /*------------------------------------------------------------------*/
  /** Set the information for the minimal value.
   *  @param  info the information to store with the minimal value
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMinInfo (Object info)
  { this.mininfo = info; }

  /*------------------------------------------------------------------*/
  /** Get the information associated with the maximal value.
   *  @return the information associated with the maximal value
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMaxInfo ()
  { return this.maxinfo; }

  /*------------------------------------------------------------------*/
  /** Set the information for the maximal value.
   *  @param  info the information to store with the maximal value
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMaxInfo (Object info)
  { this.maxinfo = info; }

  /*------------------------------------------------------------------*/
  /** Get the number of pieces of additional information.
   *  <p>Additional information can be stored with the minimum and
   *  the maximum value.</p>
   *  @return always <code>2</code>
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getInfoCount ()
  { return 2; }

  /*------------------------------------------------------------------*/
  /** Get the information associated with a value.
   *  @param  value the value for which to get the information
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (Object value)
  {                             /* --- get additional information */
    String s = value.toString();
    return (s.equalsIgnoreCase("maximum") || s.equalsIgnoreCase("max"))
         ? this.maxinfo : this.mininfo;
  }  /* getInfo() */

  /*------------------------------------------------------------------*/
  /** Get the information associated with a value.
   *  <p>If <code>value.toString().equals("maximum")</code> or
   *  <code>value.toString().equals("max")</code>, the additional
   *  information associated with the maximum value, otherwise the
   *  additional information associated with the minimum value is
   *  set.</p>
   *  @param  value the value for which to set the information
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (Object value, Object info)
  {                             /* --- set additional information */
    String s = value.toString();
    if (s.equalsIgnoreCase("maximum") || s.equalsIgnoreCase("max"))
         this.maxinfo = info;
    else this.mininfo = info;
  }  /* setInfo() */

  /*------------------------------------------------------------------*/
  /** Get the information associated with a value.
   *  <p>If <code>id &le; 0</code>, the additional information
   *  associated with the minimum value, otherwise the additional
   *  information associated with the maximum value is retrieved.</p>
   *  @param  id the identifier of the value
   *  @return the information associated with the value
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (int id)
  { return (id <= 0) ? this.mininfo : this.maxinfo; }

  /*------------------------------------------------------------------*/
  /** Set the information associated with a value.
   *  <p>If <code>id &le; 0</code>, the additional information
   *  associated with the minimum value, otherwise the additional
   *  information associated with the maximum value is set.</p>
   *  @param  id   the identifier of the value
   *  @param  info the information to set
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (int id, Object info)
  { if (id <= 0) this.mininfo = info; else this.maxinfo = info; }

  /*------------------------------------------------------------------*/
  /** Compare two values of this type.
   *  @param  a the first  value
   *  @param  b the second value
   *  @return -1 if the first  value is smaller,<br>
   *          +1 if the second value is smaller,<br>
   *          0  if the value are equal
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract int compare (Object a, Object b);

}  /* class OrdinalType */
