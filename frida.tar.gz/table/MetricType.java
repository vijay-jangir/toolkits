/*----------------------------------------------------------------------
  File    : MetricType.java
  Contents: Management of metric types for data tables
  Author  : Christian Borgelt
  History : 2006.09.16 file created as NumericType.java
            2007.02.02 min/max moved to OrdinalType, subtraction added
            2007.02.09 functions getNumberAt, getMin/MaxNumber added
            2013.04.22 adapted to class name change Type -> ColType
            2015.12.03 bug in function setInfo() fixed
----------------------------------------------------------------------*/
package table;

import util.IdMap;

/*--------------------------------------------------------------------*/
/** Class for metric types for data tables.
 *  @author Christian Borgelt
 *  @since  2006.09.16 */
/*--------------------------------------------------------------------*/
public abstract class MetricType extends OrdinalType {

  /*------------------------------------------------------------------*/
  /*  instance variable                                               */
  /*------------------------------------------------------------------*/
  /** the information stored with values/value levels */
  private IdMap info = null;

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract double getMinNumber ();

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract double getMaxNumber ();

  /*------------------------------------------------------------------*/
  /** Clear all additional information.
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clearInfo ()
  { this.info = null; }

  /*------------------------------------------------------------------*/
  /** Get the number of values with additional information.
   *  <p>Different numbers of (numeric) levels can be associated
   *  with additional information.</p>
   *  @return the number of values
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getInfoCount ()
  { return (this.info != null) ? this.info.size() : 0; }

  /*------------------------------------------------------------------*/
  /** Get the additional information for a value.
   *  @param  value the value for which
   *                to get the additional information
   *  @return the additional information associated with the identifier
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (Object value)
  { return (this.info != null) ? this.info.getValue(value) : null; }

  /*------------------------------------------------------------------*/
  /** Set the additional information for a value.
   *  @param  value the value to add/modify
   *  @param  info  the additional information to store
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (Object value, Object info)
  {                             /* --- set information for a value */
    if (this.info == null) this.info = new IdMap();
    if (this.info.get(value) < 0) this.info.add     (value, info);
    else                          this.info.setValue(value, info);
  }  /* setInfo() */

  /*------------------------------------------------------------------*/
  /** Get the additional information for a value given its identifier.
   *  @param  id the identifier of the value
   *  @return the additional information associated with the identifier
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (int id)
  { return (this.info != null) ? this.info.getValue(id) : null; }

  /*------------------------------------------------------------------*/
  /** Set the additional information for a value given its identifier.
   *  @param  id   the identifier of the value
   *  @param  info the additional information to store
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (int id, Object info)
  { if (this.info != null) this.info.setValue(id, info); }

  /*------------------------------------------------------------------*/
  /** Sum two values.
   *  @param  a the first  value
   *  @param  b the second value
   *  @return the sum of the two values
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Object sum (Object a, Object b);

  /*------------------------------------------------------------------*/
  /** Compute the difference of two values
   *  @param  a the value from which to subtract
   *  @param  b the value to subtract
   *  @return the difference of the two values
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Object diff (Object a, Object b);

}  /* class MetricType */
