/*----------------------------------------------------------------------
  File    : DateType.java
  Contents: Management of date-valued types for data tables
  Author  : Christian Borgelt
  History : 2006.10.04 file created
            2006.10.06 cloning added
            2007.01.31 functions isNull, setNull, getFormat added
            2007.02.01 function getStringAt added
            2007.02.13 function getName added
            2007.02.16 function parseType added
            2013.04.22 adapted to class name change Type -> ColType
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package table;

import java.io.IOException;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for date-valued types for data tables.
 *  @author Christian Borgelt
 *  @since  2006.10.04 */
/*--------------------------------------------------------------------*/
public class DateType extends OrdinalType {

  /*------------------------------------------------------------------*/
  /*  constants
  /*------------------------------------------------------------------*/
  /** a null value (of the storage class) */
  public static final long NULL = Long.MIN_VALUE;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the date format (for parsing and describing) */
  private DateFormat fmt;
  /** the minimal value */
  private long       min;
  /** the minimal value as an object */
  private Date       minobj;
  /** the maximal value */
  private long       max;
  /** the maximal value */
  private Date       maxobj;
  /** the current value of the type */
  private long       curr;

  /*------------------------------------------------------------------*/
  /** Create a date-valued type.
   *  The range of values is set empty (<code>max &lt; min</code>).
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DateType ()
  { this(new SimpleDateFormat("yyyy.MM.dd.HH:mm:ss")); }

  /*------------------------------------------------------------------*/
  /** Create a date-valued type.
   *  The range of values is set empty (<code>max &lt; min</code>).
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DateType (DateFormat fmt)
  { this(fmt, Long.MAX_VALUE, Long.MIN_VALUE+1); }

  /*------------------------------------------------------------------*/
  /** Create a date-valued type.
   *  @param  min the minimum value
   *  @param  max the maximum value
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DateType (DateFormat fmt, long min, long max)
  {                             /* --- create a date type */
    this.fmt    = fmt;          /* note the data format */
    this.max    = max;          /* and the range of values */
    this.min    = (min > NULL) ? min : NULL+1;
    this.minobj = this.maxobj = null;
    this.curr   = NULL;         /* clear the current value */
  }  /* DateType() */

  /*------------------------------------------------------------------*/
  /** Create a clone of a date-valued type.
   *  @param  t the date-valued type to clone
   *  @since  2006.11.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DateType (DateType t)
  { this((DateFormat)t.fmt.clone(), t.min, t.max); }

  /*------------------------------------------------------------------*/
  /** Clone this type.
   *  @return a clone of this type
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone ()
  { return new DateType(this); }

  /*------------------------------------------------------------------*/
  /** Get the name of the type.
   *  @return the name of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return "date"; }

  /*------------------------------------------------------------------*/
  /** Get the class used to access values of this type, that is,
   *  <code>Date.class</code>.
   *  @return <code>Date.class</code>
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getValueClass ()
  { return Date.class; }

  /*------------------------------------------------------------------*/
  /** Get the class used to store values of this type, that is,
   *  <code>long.class</code>.
   *  @return <code>long.class</code>
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getStorageClass ()
  { return long.class; }

  /*------------------------------------------------------------------*/
  /** Check whether an array fits this type.
   *  <p>This function need not really be here, since the generic
   *  version in ColType.java yields the same result. However, this
   *  version is more efficient.</p>
   *  @return whether the array has the correct type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean fits (Object array)
  { return (array == null) || (array instanceof long[]); }

  /*------------------------------------------------------------------*/
  /** Get the format used for parsing and formatting.
   *  @return the format used for parsing and printing
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DateFormat getFormat ()
  { return this.fmt; }

  /*------------------------------------------------------------------*/
  /** Add a value. The range of values is adapted.
   *  @param  value the value to add, must be an object of class
   *                <code>Long</code>, <code>Date</code>, or
   *                <code>String</code>
   *  @return a value that can be used efficiently with
   *          <code>setValueAt()</code>
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value)
  {                             /* --- add a value from an object */
    if (value == null) {        /* check for a null value */
      this.curr = NULL; return null; }
    if      (value instanceof Long) {
      this.addValue(((Long)value).longValue());
      if (this.curr <= NULL) return null; }
    else if (value instanceof Date) {
      this.addValue(((Date)value).getTime());
      if (this.curr <= NULL) return null; }
    else if (value instanceof String)
      try { this.addValue(this.fmt.parse((String)value).getTime());
            if (this.curr <= NULL) return null; }
      catch (ParseException e) {
        this.curr = NULL; return null; }
    else this.curr = NULL;      /* get and set the given value */
    return ColType.CURRENT;     /* return special object */
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Add a value. The range of values is adapted.
   *  @param  value the value to add
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addValue (long value)
  {                             /* --- add a value */
    this.curr = value;          /* note value and update range */
    if (value < this.min) this.min = value;
    if (value > this.max) this.max = value;
    this.minobj = this.maxobj = null;
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Clear the range of values.
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clear ()
  {                             /* --- clear the range of values */
    this.min    = Long.MAX_VALUE;
    this.max    = Long.MIN_VALUE+1;
    this.minobj = this.maxobj = null;
    this.curr   = NULL;         /* clear the current value */
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMin ()
  {                             /* --- get the minimal value */
    if (this.min > this.max)    /* if the range is empty/unset, */
      return null;              /* abort the function */
    if (this.minobj == null)    /* create date if necessary */
      this.minobj = new Date(this.min);
    return this.minobj;         /* return the minimal value */
  }  /* getMin() */

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMax ()
  {                             /* --- get the minimal value */
    if (this.min > this.max)    /* if the range is empty/unset, */
      return null;              /* abort the function */
    if (this.maxobj == null)    /* create date if necessary */
      this.maxobj = new Date(this.max);
    return this.maxobj;         /* return the maximal value */
  }  /* getMax() */

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public long getMinRaw ()
  { return this.min; }

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public long getMaxRaw ()
  { return this.max; }

  /*------------------------------------------------------------------*/
  /** Get an array element as an object.
   *  @param  array an array of dates, i.e. <code>long[]</code>
   *  @param  index the index of the array element to get
   *  @return the value as an object
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (Object array, int index)
  { this.curr = ((long[])array)[index];
    return (this.curr > NULL) ? new Date(this.curr) : null; }

  /*------------------------------------------------------------------*/
  /** Set an array element from an object.
   *  @param  array an array of dates, i.e. <code>long[]</code>
   *  @param  index the index of the array element to set
   *  @param  value the value to set, must be an object of class
   *                <code>String</code>, <code>Long</code>, or
   *                <code>Date</code>
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object array, int index, Object value)
  {                             /* --- add a value from an object */
    if (value != ColType.CURRENT) { /* if not to use current value */
      if      (value instanceof Long)
        this.curr = ((Long)value).longValue();
      else if (value instanceof Date)
        this.curr = ((Date)value).getTime();
      else if (value instanceof String)
        try { this.curr = this.fmt.parse((String)value).getTime(); }
        catch (ParseException e) { this.curr = NULL; }
      else this.curr = NULL;    /* get the value to set and */
    }                           /* store it in the array element */
    ((long[])array)[index] = this.curr;
  }  /* setValueAt() */

  /*------------------------------------------------------------------*/
  /** Get an array element as a string.
   *  @param  array an array of dates, i.e. <code>long[]</code>
   *  @param  index the index of the array element to get
   *  @return the created string description
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (Object array, int index)
  {                             /* --- get array element as a string */
    long d = ((long[])array)[index];
    if (d <= NULL) return null; /* get the data to describe */
    return this.fmt.format(new Date(d));   /* and format it */
  }  /* getStringAt() */

  /*------------------------------------------------------------------*/
  /** Check whether an array element is null.
   *  @param  array an array of dates, i.e. <code>long[]</code>
   *  @param  index the index of the array element to check
   *  @return whether the array element is null
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isNull (Object array, int index)
  { return ((long[])array)[index] <= NULL; }

  /*------------------------------------------------------------------*/
  /** Set an array element to a null value.
   *  @param  array an array of dates, i.e. <code>long[]</code>
   *  @param  index the index of the array element to set
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int index)
  { ((long[])array)[index] = NULL; }

  /*------------------------------------------------------------------*/
  /** Set a range of array elements to a null value.
   *  @param  array an array of dates
   *  @param  beg   the index of the first array element (inclusive)
   *  @param  end   the index of the last  array element (exclusive)
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int beg, int end)
  { while (--end >= beg) ((long[])array)[end] = NULL; }

  /*------------------------------------------------------------------*/
  /** Parse an instance from a string.
   *  @param  desc the string description to parse
   *  @return the parsed object or <code>null</code> if parsing failed
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object parseValue (String desc)
  { try { return this.fmt.parse(desc); }
    catch (ParseException e) { return null; } }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return a string description of the type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  {                             /* --- create a string description */
    if (this.min > this.max)    /* if the range is empty, */
      return "date";            /* only return the type name */
    StringBuilder s = new StringBuilder("date [");
    if (this.minobj == null) this.minobj = new Date(this.min);
    s.append(this.fmt.format(this.minobj)); s.append(", ");
    if (this.maxobj == null) this.maxobj = new Date(this.max);
    s.append(this.fmt.format(this.maxobj)); s.append("]");
    return s.toString();        /* add the range of values */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Compare two date values.
   *  @param  a the first  value
   *  @param  b the second value
   *  @return -1 if the first  value is smaller,<br>
   *          +1 if the second value is smaller,<br>
   *          0  if the value are equal
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int compare (Object a, Object b)
  { return ((Date)a).compareTo((Date)b); }

  /*------------------------------------------------------------------*/
  /** Parse a type description.
   *  @param  scan the scanner to read from
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ColType parseType (Scanner scan) throws IOException
  {                             /* --- parse a type description */
    DateType type;              /* created type */

    scan.getID();               /* check for an identifier */
    if (!scan.value.equals("date") && !scan.value.equals("D"))
      throw new IOException("'date' expected instead of '"
                            +scan.value +"'" +scan.lno());
    if (scan.nextToken() != '(') {
      scan.pushBack();         /* if no date format follows, */
      type = new DateType(); } /* create a default format type */
    else {                     /* if a date format follows */
      scan.getID();            /* check for an identifier */
      type = new DateType(new SimpleDateFormat(scan.value));
      scan.getChar(')');        /* create type with the given format */
    }                           /* and check for ')' */
    if (scan.nextToken() != '[')/* if no range of values follows, */
      scan.pushBack();          /* push back the token */
    else {                      /* if a range of values follows */
      scan.getNumber();         /* check for a number and get minimum */
      try { type.min = type.fmt.parse(scan.value).getTime(); }
      catch (ParseException e) {
        throw new IOException("illegal date '" +scan.value +"'"
                              +scan.lno()); }
      scan.getChar(',');        /* check for ',' */
      scan.getNumber();         /* check for a number and get maximum */
      try { type.max = type.fmt.parse(scan.value).getTime(); }
      catch (ParseException e) {
        throw new IOException("illegal date '" +scan.value +"'"
                              +scan.lno()); }
      scan.getChar(']');        /* check for ']' */
    }                           /* create and return the type */
    return type;                /* return the created type */
  }  /* parseType() */

}  /* class DateType */
