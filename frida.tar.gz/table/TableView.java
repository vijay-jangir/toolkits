/*----------------------------------------------------------------------
  File    : TableView.java
  Contents: frame class for a simple table viewer
  Author  : Christian Borgelt
  History : 2007.02.09 file created
            2007.02.10 some cleaning up and restructuring
            2007.02.11 isProg flag replaced by mode flags
            2007.02.12 returned to delayed dialog box creation
            2007.03.12 function setMessage added
            2007.06.07 loading and saving simplified
            2007.07.10 auto resize switched off for JTable
            2007.07.17 time measurements for loading and saving added
            2007.07.26 error reporting improved (file name added)
            2014.09.25 column resize behavior reverted to default
            2014.10.23 changed from LGPL license to MIT license
----------------------------------------------------------------------*/
package table;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import util.TableReader;
import util.TableWriter;
import dialog.FormatPanel;
import dialog.FormatDialog;
import dialog.AboutDialog;
import draw.ScatterPlot;
import draw.BarChart;

/*--------------------------------------------------------------------*/
/** Class for a simple table viewer.
 *  @author Christian Borgelt
 *  @since  2007.02.09 */
/*--------------------------------------------------------------------*/
public class TableView extends JFrame implements Runnable {

  private static final long serialVersionUID = 0x00010008L;
  public  static final String VERSION = "1.8 (2014.10.23)";

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** mode flag: the table viewer is a stand-alone program */
  public final static int PROGRAM    = 1;
  /** mode flag: add menu items for loading tables */
  public final static int LOAD_ITEMS = 2;
  /** mode flag: add menu items for saving  tables */
  public final static int SAVE_ITEMS = 4;
  /** mode flag: add menu items for loading and saving tables */
  public final static int FILE_ITEMS = LOAD_ITEMS | SAVE_ITEMS;
  /** mode flag: add menu items for visualization */
  public final static int VIEW_ITEMS = 8;
  /** mode flag: all optional menu items */
  public final static int ALL_ITEMS  = FILE_ITEMS | VIEW_ITEMS;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this table viewer */
  private Component    owner   = null;
  /** the mode flags */
  private int          mode    = 0;
  /** the displayed table */
  private Table        table   = null;
  /** the context sensitive menu items */
  private JMenuItem[]  items   = null;
  /** the scroll pane for the viewport */
  private JScrollPane  scroll  = null;
  /** the table view */
  private JTable       view    = null;
  /** the status bar for messages */
  private JTextField   stat    = null;
  /** the file chooser */
  private JFileChooser chooser = null;
  /** the current table file */
  private File         curr    = null;
  /** the data format dialog box */
  private FormatDialog format  = null;
  /** the "About..." dialog box */
  private AboutDialog  about   = null;

  /*------------------------------------------------------------------*/
  /** Create a simple table viewer.
   *  @param  mode the mode flags
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableView (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create a simple table viewer.
   *  @param  owner the component that is to own this table viewer
   *  @param  mode  the mode flags
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableView (Component owner, int mode)
  {                             /* --- create a table viewer */
    this.owner = owner;         /* note the owner */
    this.mode  = mode;          /* and the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* TableView() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */

    if ((this.mode & PROGRAM) != 0)
      this.mode |= LOAD_ITEMS;  /* check and adapt the mode */
    this.items = new JMenuItem[5];

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    if ((this.mode & LOAD_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Load Table...", 'l'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          TableView.this.loadTable(null); } } );
      item = menu.add(new JMenuItem("Reload Table", 'r'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          TableView.this.loadTable(TableView.this.curr); } } );
      menu.addSeparator();
    }
    if ((this.mode & SAVE_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Save Table...", 's'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          TableView.this.saveTable(TableView.this.curr); } } );
      this.items[0] = item; item.setEnabled(false);
      item = menu.add(new JMenuItem("Save Table As...", 'a'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          TableView.this.saveTable(null); } } );
      this.items[1] = item; item.setEnabled(false);
      menu.addSeparator();
      item = menu.add(new JMenuItem("Save Domains...", 's'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          TableView.this.saveDomains(null); } } );
      this.items[2] = item; item.setEnabled(false);
      menu.addSeparator();
    }
    if ((this.mode & FILE_ITEMS) != 0) {
      item = menu.add(new JMenuItem("Data Format...", 'f'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          TableView.this.getFormatDialog().setVisible(true);
          TableView.this.format.toFront();
        } } );
      menu.addSeparator();
    }
    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          TableView.this.setVisible(false); } } );
    }                           /* close the window */

    if ((this.mode & VIEW_ITEMS) != 0) {
      menu = mbar.add(new JMenu("View"));
      menu.setMnemonic('v');
      item = menu.add(new JMenuItem("ScatterPlot...", 's'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          if (TableView.this.table == null) return;
          ScatterPlot scplot =  /* create a scatter plot */
            new ScatterPlot(TableView.this, ScatterPlot.LOAD_ITEMS);
          scplot.setVisible(true); scplot.toFront();
          scplot.setTable(TableView.this.table);
        } } );
      this.items[3] = item; item.setEnabled(false);
      item = menu.add(new JMenuItem("BarChart...", 'b'));
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          if (TableView.this.table == null) return;
          BarChart bchart =       /* create a bar chart */
            new BarChart(TableView.this, BarChart.LOAD_ITEMS);
          bchart.setVisible(true); bchart.toFront();
          bchart.setTable(TableView.this.table);
        } } );
      this.items[4] = item; item.setEnabled(false);
    }

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (TableView.this.about == null)
          TableView.this.about = new AboutDialog(TableView.this,
             "About TableView...", "TableView\n"
            +"A simple Table Viewer\n"
            +"Version " +TableView.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        TableView.this.about.setVisible(true);
        TableView.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    this.view   = new JTable(); /* create a table viewer */
    //this.view.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    //this.view.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
    this.scroll = new JScrollPane(this.view);
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(this.scroll, BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    this.stat = new JTextField("");
    this.stat.setEditable(false);
    content.add(this.stat,   BorderLayout.SOUTH);

    /* --- configure and show the frame window --- */
    this.setTitle("TableView");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);
    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the file chooser (create if necessary).
   *  @return the file chooser
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure file chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Get the data format dialog (create if necessary).
   *  @return the data format dialog
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatDialog getFormatDialog ()
  {                             /* --- get the data format dialog */
    if (this.format == null)    /* if it does not exist, create it */
      this.format = new FormatDialog(this);
    return this.format;         /* return the data format dialog */
  }  /* getFormatDialog() */

  /*------------------------------------------------------------------*/
  /** Get the data format panel.
   *  @return the data format panel
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public FormatPanel getFormatPanel ()
  { return this.getFormatDialog().getPanel(); }

  /*------------------------------------------------------------------*/
  /** Set the data format.
   *  @param  fmt the data format panel from which to copy the format
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setFormat (FormatPanel fmt)
  { this.getFormatDialog().getPanel().copyFrom(fmt); }

  /*------------------------------------------------------------------*/
  /** Get the read mode.
   *  <p>In the returned value the flags
   *  <code>FormatPanel.HEADER</code> and/or
   *  <code>FormatPanel.WEIGHT</code>
   *  (or <code>FormatPanel.TAWGT</code>) may be set,
   *  depending on the selection in the dialog panel.</p>
   *  @return the read/write mode
   *  @since  2012.12.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getMode ()
  { return this.getFormatDialog().getPanel().getMode(); }

  /*------------------------------------------------------------------*/
  /** Set the read mode.
   *  @param  mode the read mode to set
   *  @since  2012.12.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMode (int mode)
  { this.getFormatDialog().getPanel().setMode(mode); }

  /*------------------------------------------------------------------*/
  /** Set the message to display in the status line.
   *  @param  msg the message to display
   *  @since  2007.03.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.stat.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Set the table to display.
   *  @param  tab the table to display
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTable (Table tab)
  {                             /* --- set the table to display */
    this.table = tab;           /* store the new table */
    this.view.setModel(tab);    /* and set it for the view */
    Dimension size = this.view.getPreferredSize();
    if (size.width  > 400) size.width  = 400;
    if (size.height > 400) size.height = 400;
    this.view.setPreferredScrollableViewportSize(size);
    this.stat.setText(tab.getName());
    this.pack();                /* re-layout the window */
    for (int i = this.items.length; --i >= 0; )
      if (this.items[i] != null)/* enable/disable menu items */
        this.items[i].setEnabled(tab != null);
  }  /* setTable() */

  /*------------------------------------------------------------------*/
  /** Get the currently displayed table.
   *  @return the currently displayed table
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getTable ()
  { return this.table; }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void reportError (String msg)
  {                             /* --- report an i/o error */
    this.stat.setText(msg);     /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this, msg,
      "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load the table to display.
   *  @param  file the file to load the table from
   *  @return whether the file was successfully loaded
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadTable (File file)
  {                             /* --- load a data table */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a reader for the file */
      System.err.print("reading " +file +" ... ");
      long        t      = System.currentTimeMillis();
      TableReader reader = this.getFormatDialog().createReader(file);
      Table       tab    = new Table(file.getPath());
      tab.read(reader, this.format.getTableMode());
      reader.close();           /* read table from the given file */
      tab.autoType();           /* automatically determine types */
      this.setTable(tab);       /* set the loaded table */
      t = System.currentTimeMillis() -t;
      System.err.print("[" +tab.getColumnCount() +" column(s), ");
      System.err.print(     tab.getRowCount()    +" row(s)] done");
      System.err.println(" [" +(t/(float)1000.0) +"s]."); }
    catch (FileNotFoundException e) {
      this.reportError(e.getMessage()); return false; }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(file.getPath() +":\n" +e.getMessage());
      return false;
    }
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadTable() */

  /*------------------------------------------------------------------*/
  /** Save the displayed table.
   *  @param  file the file to save the table to
   *  @return whether the file was successfully saved
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveTable (File file)
  {                             /* --- save the displayed table */
    if (this.table == null)     /* if there is no table */
      return false;             /* simply abort the function */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get the selected file */
    try {                       /* create a writer for the file */
      System.err.print("writing " +file +" ... ");
      long        t      = System.currentTimeMillis();
      TableWriter writer = this.getFormatDialog().createWriter(file);
      this.table.write(writer, this.format.getTableMode());
      writer.close();           /* write the table to a file */
      t = System.currentTimeMillis() -t;
      System.err.print("["+this.table.getColumnCount() +" column(s), ");
      System.err.print(    this.table.getRowCount() +" row(s)] done");
      System.err.println(" [" +(t/(float)1000.0) +"s]."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(file.getPath() +":\n" +e.getMessage());
      return false;
    }
    this.curr = file;           /* note the new file name */
    return true;                /* return 'saving successful' */
  }  /* saveTable() */

  /*------------------------------------------------------------------*/
  /** Save domain descriptions of the displayed table.
   *  @param  file the file to save the domain descriptions to
   *  @return whether the file was successfully saved
   *  @since  2007.05.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveDomains (File file)
  {                             /* --- save domain descriptions */
    if (this.table == null)     /* if there is no table */
      return false;             /* simply abort the function */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get the selected file */
    try {                       /* load the data table */
      System.err.print("writing " +file +" ... ");
      long       t      = System.currentTimeMillis();
      FileWriter writer = new FileWriter(file);
      writer.write(this.table.toString("domains"));
      writer.close();           /* write the domains descriptions */
      t = System.currentTimeMillis() -t;
      System.err.print("[" +this.table.getColumnCount());
      System.err.print(" attribute(s)] done");
      System.err.println(" [" +(t/(float)1000.0) +"s]."); }
    catch (IOException e) {     /* catch and report an i/o error */
      this.reportError(file.getPath() +":\n" +e.getMessage());
      return false;
    }
    return true;                /* return 'saving successful' */
  }  /* saveDomains() */

  /*------------------------------------------------------------------*/
  /** Main function for command line invocation.
   *  @param  args the command line arguments
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    TableView tv = new TableView(PROGRAM|ALL_ITEMS);
    if (args.length > 0) tv.loadTable(new File(args[0]));
    tv.setVisible(true);        /* create and show a table viewer */
  }  /* main() */

}  /* class TableView */
