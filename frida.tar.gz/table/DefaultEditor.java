/*----------------------------------------------------------------------
  File    : DefaultEditor.java
  Contents: editor for the values of types
  Author  : Christian Borgelt
  History : 2007.07.17 file created
            2013.04.22 adapted to class name change Type -> ColType
----------------------------------------------------------------------*/
package table;

/*--------------------------------------------------------------------*/
/** Class for an editor for the values of types.
 *  @author Christian Borgelt
 *  @since  2007.07.17 */
/*--------------------------------------------------------------------*/
public class DefaultEditor extends TypeEditor {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /** Create a default type editor.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DefaultEditor ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create a default type editor.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DefaultEditor (ColType type)
  {                             /* --- create default type editor */
    this.type = type;           /* note the type to edit */
    this.addHelp("No type editor available.");
    this.addFiller(0);          /* set a default message */
  }  /* DefaultEditor() */

  /*------------------------------------------------------------------*/
  /** Set the type to edit.
   *  @param  type the type to edit
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setType (ColType type)
  { this.type = type; }

  /*------------------------------------------------------------------*/
  /** Get the edited type.
   *  @return the edited type
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColType getType ()
  { return this.type; }

}  /* DefaultEditor() */
