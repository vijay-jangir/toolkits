/*----------------------------------------------------------------------
  File    : DomainsFinder.java
  Contents: Class for table column domain determination
  Author  : Christian Borgelt
  History : 2007.05.08 file created
            2007.07.26 additional operations added (AUTOTYPE, SORTVALS)
            2007.07.26 input parameter setting with several functions
----------------------------------------------------------------------*/
package table;

import java.io.IOException;
import java.io.Writer;
import java.io.FileWriter;
import java.io.FileReader;

import util.Executable;
import util.TableReader;

/*--------------------------------------------------------------------*/
/** Class for table column domain determination.
 *  @author Christian Borgelt
 *  @since  2007.05.08 */
/*--------------------------------------------------------------------*/
public class DomainsFinder implements Executable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** operation: determine types automatically */
  public static final int AUTOTYPE = 1;
  /** operation: sort nominal attribute values */
  public static final int SORTVALS = 2;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the name of the table file */
  private String      fn_tab  = null;
  /** the record  separators */
  private String      recseps = null;
  /** the field   separators */
  private String      fldseps = null;
  /** the blank   characters */
  private String      blanks  = null;
  /** the null value characters */
  private String      nullchs = null;
  /** the comment characters */
  private String      comment = null;
  /** the table reader for reading the table file */
  private TableReader reader  = null;
  /** the read mode for the data table */
  private int         mode    = 0;
  /** the table for reading */
  private Table       table   = null;
  /** the additional operations */
  private int         ops     = AUTOTYPE|SORTVALS;
  /** the name of the domain file */
  private String      fn_dom  = null;
  /** the writer for the domain file */
  private Writer      writer  = null;
  /** whether externally aborted */
  private volatile boolean stop = false;

  /*------------------------------------------------------------------*/
  /** Create a table domain finder.
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsFinder ()
  { }

  /*------------------------------------------------------------------*/
  /** Set the table reader and read mode.
   *  @param  reader the table reader
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (TableReader reader)
  { this.reader = reader; }

  /*------------------------------------------------------------------*/
  /** Set the table input file.
   *  @param  fn_tab the name of the data table file
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInput (String fn_tab)
  { this.fn_tab = fn_tab; }

  /*------------------------------------------------------------------*/
  /** Set the format characters.
   *  @param  recseps the record     separators
   *  @param  fldseps the field      separators
   *  @param  blanks  the blank      characters
   *  @param  nullchs the null value characters
   *  @param  comment the comment    characters
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setChars (String recseps, String fldseps,
                        String blanks,  String nullchs, String comment)
  {                             /* --- set the format characters */
    this.recseps = recseps; this.fldseps = fldseps;
    this.blanks  = blanks;  this.nullchs = nullchs;
    this.comment = comment;     /* note the characters */
  }  /* setChars() */

  /*------------------------------------------------------------------*/
  /** Set the read mode.
   *  @param  mode the read mode
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMode (int mode)
  { this.mode = mode; }

  /*------------------------------------------------------------------*/
  /** Set additional operations.
   *  @param  ops the additional operations
   *  @since  2007.07.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOps (int ops)
  { this.ops = ops; }

  /*------------------------------------------------------------------*/
  /** Set the output file writer.
   *  @param  writer the output file writer
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutput (Writer writer)
  { this.writer = writer; }

  /*------------------------------------------------------------------*/
  /** Set the output file.
   *  @param  fn_dom the name of the output file
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setOutput (String fn_dom)
  { this.fn_dom = fn_dom; }

  /*------------------------------------------------------------------*/
  /** Get the table used for determining the domains.
   *  @return the table used for determining the domains
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getTable ()
  { return this.table; }

  /*------------------------------------------------------------------*/
  /** Execute the domain finder.
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void find () throws IOException
  {                             /* --- execute the domain finder */
    int  n;                     /* number of rows read */
    long t = 0;                 /* for time measurements */

    this.stop = false;          /* execution has not been stopped */
    if (this.fn_tab != null) {  /* if to read a table file */
      System.err.print("reading " +this.fn_tab +" ... ");
      t = System.currentTimeMillis();
      this.reader = new TableReader(new FileReader(this.fn_tab));
      this.reader.setCharsCoded(this.recseps, this.fldseps, this.blanks,
                                this.nullchs, this.comment);
    }                           /* create a table reader */
    this.table = new Table();   /* create an empty table */
    if (this.stop) return;
    n = this.table.read(this.reader, this.mode);
    this.reader.close();        /* read the table file */
    if ((this.ops & AUTOTYPE) != 0)
      this.table.autoType();    /* determine the types automatically */
    if ((this.ops & SORTVALS) != 0)
      this.table.sortTypes();   /* sort the nominal values */
    if (this.fn_tab != null) {  /* if to read a table file */
      System.err.print("[" +n +" tuple(s)] ");
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/1000.0) +"s].");
    }                           /* write a log message */
    if (this.fn_dom != null) {  /* if a file name is given */
      System.err.print("writing " +this.fn_dom +" ... ");
      t = System.currentTimeMillis();
      if (this.writer == null)  /* open the output file */
        this.writer = new FileWriter(this.fn_dom);
    }
    this.writer.write(this.table.toString("domains"));
    this.writer.close();        /* write the domain file */
    if (this.fn_dom != null) {  /* if a file name is given */
      System.err.print("[" +this.table.getColumnCount()
                      +" attribute(s)] ");
      t = System.currentTimeMillis() -t;
      System.err.println("done [" +(t/1000.0) +"s].");
    }                           /* write a log message */
  }  /* find() */

  /*------------------------------------------------------------------*/
  /** Execute the domain finder.
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void exec () throws Exception
  { this.find(); }

  /*------------------------------------------------------------------*/
  /** Abort the execution.
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void abort ()
  { this.stop = true; if (this.table != null) this.table.abort(); }

}  /* class DomainsFinder */
