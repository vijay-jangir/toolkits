/*----------------------------------------------------------------------
  File    : ColType.java
  Contents: Class for column types for data tables
  Author  : Christian Borgelt
  History : 2006.09.11 file created
            2006.10.04 access and storage class methods added
            2006.10.06 cloning added
            2007.01.31 functions isNull and setNull added
            2007.02.01 getStringAt, parseValue, constant CURRENT added
            2007.02.02 function toString added
            2007.02.13 function getName added, type maps added
            2007.02.16 generic functions improved, parseType added
            2007.06.07 some static functions added
            2007.07.13 several functions from NominalType added
            2010.01.25 parseType() made compatible with generics
            2013.04.22 renamed to ColType (due to java.awt.Window.Type)
----------------------------------------------------------------------*/
package table;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.io.IOException;

import util.IdMap;
import util.TableReader;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for (column) types for data tables.
 *  <p>The values of a type can be represented by objects of two
 *  different types: one for unified external access and one for
 *  internal storage. The reason is that it is wasteful to use real
 *  Java objects to represent values of the basic types (like int,
 *  double etc), but that it is sometimes necessary to convert them
 *  to the corresponding object types (for example, for displaying
 *  data in a <code>JTable</code>). These two classes can be retrieved
 *  by <code>getValueClass()</code> and <code>getStorageClass</code>.
 *  @author Christian Borgelt
 *  @since  2006.09.11 */
/*--------------------------------------------------------------------*/
public abstract class ColType implements Cloneable {

  /*------------------------------------------------------------------*/
  /*  constants
  /*------------------------------------------------------------------*/
  /** indicates that the internal current value should be used */
  public static final Object CURRENT = new Object();

  /*------------------------------------------------------------------*/
  /*  class variables
  /*------------------------------------------------------------------*/
  /** the map of (non-abstract) types: type names to classes */
  private static final IdMap map = new IdMap();

  /*------------------------------------------------------------------*/
  /*  class initialization code                                       */
  /*------------------------------------------------------------------*/

  static {                      /* --- initialize the class */
    ColType.map.add("nominal", NominalType.class);
    ColType.map.add("integer", IntegerType.class);
    ColType.map.add("real",    RealType.class);
    ColType.map.add("date",    DateType.class);
    ColType.map.add("string",  StringType.class);
  }                             /* register all standard types */

  /*------------------------------------------------------------------*/
  /** Add a type, that is, register it.
   *  @return whether the type was registered
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static boolean addType (String name, Class<?> cls)
  {                             /* --- add a type */
    if (ColType.map.get(name) >= 0) return false;
    ColType.map.add(name, cls);     return true;
  }  /* addType() */

  /*------------------------------------------------------------------*/
  /** Get the number of types.
   *  @return the number of registered types
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static int getTypeCount ()
  { return ColType.map.size(); }

  /*------------------------------------------------------------------*/
  /** Get identifier for a type name.
   *  @param  name the name of the type
   *  @return the identifier of the type
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static int getTypeId (String name)
  { return ColType.map.get(name); }

  /*------------------------------------------------------------------*/
  /** Get identifier for a type.
   *  @param  type the type
   *  @return the identifier of the type
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static int getTypeId (ColType type)
  { return ColType.map.get(type.getName()); }

  /*------------------------------------------------------------------*/
  /** Get type class for a name.
   *  @return the class of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Class<?> getTypeClass (String name)
  { return (Class<?>)ColType.map.getValue(name); }

  /*------------------------------------------------------------------*/
  /** Get type class for a type identifier.
   *  @return the class of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Class<?> getTypeClass (int id)
  { return (Class<?>)ColType.map.getValue(id); }

  /*------------------------------------------------------------------*/
  /** Get type name for a type identifier.
   *  @return the name of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String getTypeName (int id)
  { return (String)ColType.map.get(id); }

  /*------------------------------------------------------------------*/
  /** Get all type names.
   *  @return an array of type names
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String[] getAllTypeNames ()
  { return ColType.getAllTypeNames(ColType.map.size()); }

  /*------------------------------------------------------------------*/
  /** Get all type names.
   *  @param  cnt the maximum number of names
   *  @return an array of type names
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String[] getAllTypeNames (int cnt)
  {                             /* --- get all type names */
    String[] list = new String[cnt];
    while (--cnt >= 0) list[cnt] = (String)ColType.map.get(cnt);
    return list;                /* collect the type names */
  }  /* getAllTypeNames() */

  /*------------------------------------------------------------------*/
  /** Clone this type.
   *  @return a clone of this type
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Object clone ();

  /*------------------------------------------------------------------*/
  /** Get the name of the type.
   *  @return the name of the type
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return this.getClass().getName(); }

  /*------------------------------------------------------------------*/
  /** Get the class used to access values of this type.
   *  <p>This is the class of objects returned by
   *  <code>getValueAt()</code> and may differ from the class used
   *  for the internal storage (as used by <code>setValueAt()</code>).
   *  </p>
   *  @return the class used for accessing values of this type
   *  @see    ColType#getValueAt(Object,int)
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Class<?> getValueClass ();

  /*------------------------------------------------------------------*/
  /** Get the class used to store values of this type.
   *  <p>This is the class used for the internal storage (that is, the
   *  class converted to by <code>setValueAt()</code>) and may differ
   *  from the class of objects returned by <code>getValueAt()</code>.
   *  </p>
   *  @return the class used for storing values of this type
   *  @see    ColType#setValueAt(Object,int,Object)
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Class<?> getStorageClass ();

  /*------------------------------------------------------------------*/
  /** Check whether an array fits this type.
   *  <p>This function is generic and yields the correct result for
   *  all subclasses. Nevertheless it may be useful to overload it
   *  with a more efficient specific version.</p>
   *  @return whether the array has the storage type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean fits (Object array)
  { return (array == null) || (array.getClass().getComponentType()
                               == this.getStorageClass()); }

  /*------------------------------------------------------------------*/
  /** Get the number of values.
   *  <p>This function should be overriden by types having (only)
   *  a finite number of values.</p>
   *  @return always <code>-1</code>
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getValueCount ()
  { return -1; }

  /*------------------------------------------------------------------*/
  /** Add a value, that is, adapt the range of values.
   *  <p>By default this function simply returns its argument,
   *  since not all types need to keep track of the range of values.
   *  However, if they do, the result may be the argument, a different
   *  object (for example, of the storage class of this type), the
   *  specific object <code>ColType.CURRENT</code> that can be used
   *  efficiently with the function <code>setValueAt()</code> (and
   *  which refers to an internal value buffer), or <code>null</code>
   *  if the object cannot be converted to a value of the type.</p>
   *  @param  value the value to add
   *  @return the argument, possibly in a different form
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value)
  { return value; }

  /*------------------------------------------------------------------*/
  /** Add a value, that is, adapt the range of values.
   *  <p>The additional information is ignored. This function should
   *  be overridden by types that can store additional information
   *  for values or properties.</p>
   *  @param  value the value to add
   *  @param  info  the additional information to store with the value
   *  @return the argument, possibly in a different form
   *  @see    #addValue(Object)
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value, Object info)
  { return this.addValue(value); }

  /*------------------------------------------------------------------*/
  /** Get the identifier of a value.
   *  @param  value the value as an object
   *  @return always <code>-1</code>
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int findValue (Object value)
  { return -1; }

  /*------------------------------------------------------------------*/
  /** Get the identifier of a value.
   *  @param  value the value as an object
   *  @return always <code>-1</code>
   *  @see    #findValue(Object)
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getValueId (Object value)
  { return -1; }

  /*------------------------------------------------------------------*/
  /** Get the value associated with an identifier.
   *  <p>This function should be overriden by types having (only)
   *  a finite number of values.</p>
   *  @param  id the value identifier
   *  @return always <code>null</code>
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValue (int id)
  { return null; }

  /*------------------------------------------------------------------*/
  /** Clear the range of values.
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract void clear ();

  /*------------------------------------------------------------------*/
  /** Clear all additional information.
   *  <p>This function should be overriden by types supporting
   *  additional information for values or properties.</p>
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clearInfo ()
  { }

  /*------------------------------------------------------------------*/
  /** Get the number of values with additional information.
   *  <p>This function should be overriden by types supporting
   *  additional information for values or properties.</p>
   *  @return always <code>0</code>
   *  @since  2007.06.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getInfoCount ()
  { return 0; }

  /*------------------------------------------------------------------*/
  /** Get the information for a value or a property.
   *  <p>This function should be overridden by types that can store
   *  additional information for values or properties.</p>
   *  @param  value the value for which to get additional information
   *  @return always <code>null</code>
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (Object value)
  { return null; }

  /*------------------------------------------------------------------*/
  /** Set the additional information for a value.
   *  <p>The additional information is ignored. This function should
   *  be overridden by types that can store additional information
   *  for values or properties.</p>
   *  @param  value the value to modify
   *  @param  info  the additional information to store
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (Object value, Object info)
  { }

  /*------------------------------------------------------------------*/
  /** Get the additional information for a value given its identifier.
   *  <p>This function should be overridden by types that can store
   *  additional information for values or properties.</p>
   *  @param  id the identifier of the value
   *  @return always <code>null</code>
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (int id)
  { return null; }

  /*------------------------------------------------------------------*/
  /** Set the additional information for a value given its identifier.
   *  <p>The additional information is ignored. This function should be
   *  overridden by types that can store information with values.</p>
   *  @param  id   the identifier of the value
   *  @param  info the additional information to store
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (int id, Object info)
  { }

  /*------------------------------------------------------------------*/
  /** Get an array element as an object.
   *  @param  array an array of values
   *                (the entries of which are instances of the class
   *                returned by <code>getStorageClass()</code>)
   *  @param  index the index of the array element to access
   *  @return the value as an object
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (Object array, int index)
  { return Array.get(array, index); }

  /*------------------------------------------------------------------*/
  /** Set an array element from an object.
   *  @param  array an array of values
   *                (the entries of which are instances of the class
   *                returned by <code>getStorageClass()</code>)
   *  @param  index the index of the array element to set
   *  @param  value the value to set
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object array, int index, Object value)
  {                             /* --- set an array element */
    if (value instanceof String)
      value = this.parseValue((String)value);
    Array.set(array, index, value);
  }  /* setValueAt() */

  /*------------------------------------------------------------------*/
  /** Get an array element as a string.
   *  @param  array an array of values (of the storage class)
   *  @param  index the index of the array element to access
   *  @return the created string description
   *  @see    #getStorageClass()
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (Object array, int index)
  { return Array.get(array, index).toString(); }

  /*------------------------------------------------------------------*/
  /** Get an array element as a number.
   *  <p>This function should be overridden by numeric types.</p>
   *  @return always <code>0</code>
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getNumberAt (Object array, int index)
  { return 0; }

  /*------------------------------------------------------------------*/
  /** Check whether an array element is null.
   *  @param  array an array of values (of the storage class)
   *  @param  index the index of the array element to check
   *  @return whether the array element is null
   *  @see    #getStorageClass()
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isNull (Object array, int index)
  { return Array.get(array, index) == null; }

  /*------------------------------------------------------------------*/
  /** Set an array element to a null value.
   *  @param  array an array of values
   *  @param  index the index of the array element to set
   *  @see    #getStorageClass()
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int index)
  { Array.set(array, index, null); }

  /*------------------------------------------------------------------*/
  /** Set a range of array elements to a null value.
   *  @param  array an array of values
   *  @param  beg   the index of the first array element (inclusive)
   *  @param  end   the index of the last  array element (exclusive)
   *  @see    #getStorageClass()
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int beg, int end)
  { while (--end >= beg) Array.set(array, end, null); }

  /*------------------------------------------------------------------*/
  /** Parse a value from a string.
   *  @param  desc the string description to parse
   *  @return the parsed object or <code>null</code> if parsing failed
   *  @see    #getValueClass()
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract Object parseValue (String desc);

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return the name of the type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  { return this.getName(); }

  /*------------------------------------------------------------------*/
  /** Parse a type description.
   *  <p>This function <b>must</b> be overloaded in all subclasses.</p>
   *  @param  scan the scanner to read from
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ColType parseType (Scanner scan) throws IOException
  {                             /* --- parse a type description */
    int        tok;             /* first token of description */
    String     val;             /* value of the first token */
    Class<?>   nstc;            /* class  of non-standard type */
    Method     parser;          /* parser of non-standard type */
    Class<?>[] clss;            /* argument classes for getMethod */
    Object[]   args;            /* arguments for invoke */

    tok = scan.nextToken();     /* get the first token */
    val = scan.value;           /* and its associated value */
    scan.pushBack();            /* and push it back immediately */

    /* --- parse standard type --- */
    if (tok != Scanner.T_ID) {  /* check for a nominal type */
      if (tok == '{') return NominalType.parseType(scan);
      throw new IOException("identifier expected instead of '"
                            +val +"'" +scan.lno());
    }                           /* all but nominal types need an id */
    if (val.equals("int")    || val.equals("integer")
    ||  val.equals("Z")      || val.equals("ZZ"))
      return IntegerType.parseType(scan);
    if (val.equals("real")   || val.equals("float")
    ||  val.equals("R")      || val.equals("IR"))
      return RealType.parseType(scan);
    if (val.equals("date")   || val.equals("D"))
      return DateType.parseType(scan);
    if (val.equals("string") || val.equals("S"))
      return StringType.parseType(scan);

    /* --- parse non-standard type --- */
    nstc = (Class<?>)ColType.map.getValue(val);
    if  (nstc == null) try { nstc = Class.forName(val); }
                       catch (ClassNotFoundException e) { }
    if ((nstc == null) || !ColType.class.isAssignableFrom(nstc))
      throw new IOException("unknown type '" +val +"'" +scan.lno());
    clss = new Class<?>[1]; clss[0] = TableReader.class;
    args = new Object[1];   args[0] = scan;
    try { parser = nstc.getMethod("parseType", clss); }
    catch (NoSuchMethodException     e) {
      throw new IOException("parsing '" +val +"' failed" +scan.lno()); }
    try { return (ColType)parser.invoke(null, args); }
    catch (InvocationTargetException e) {
      throw new IOException("parsing '" +val +"' failed" +scan.lno()); }
    catch (IllegalAccessException    e) {
      throw new IOException("parsing '" +val +"' failed" +scan.lno()); }
  }  /* parseType() */

}  /* class ColType */
