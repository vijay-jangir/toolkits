/*----------------------------------------------------------------------
  File    : Table.java
  Contents: Class for data tables
  Author  : Christian Borgelt
  History : 2006.07.11 file created
            2006.10.04 made a subclass of AbstractTableModel
            2006.10.06 function addColumn added, cloning added
            2007.01.31 (re)moveColumn, reorderColumns etc. added
            2007.02.02 function autoType added
            2007.02.08 read/write functionality extended
            2007.02.13 function toString added
            2007.03.15 fewer constructors, table reading improved
            2007.03.18 function getColumnClass() added
            2007.04.13 adapted to modes of identifier maps
            2007.05.02 read mode NODATA added (only type adaptation)
            2007.05.08 external abort of i/o operations made possible
            2007.05.15 function cloneDomains(), readHeader() etc. added
            2007.05.17 read mode NONULLS added (disallow null values)
            2007.05.20 adapted to new class TableWriter
            2007.06.07 getColumnType() and getColumnDir() added
            2007.07.19 TableException replaced by return code
            2007.07.26 functions to sort the columns and values added
            2013.04.22 adapted to class name change Type -> ColType
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package table;

import java.util.Comparator;
import java.io.IOException;
import java.io.FileReader;
import javax.swing.table.AbstractTableModel;

import util.IdMap;
import util.Scanner;
import util.TableReader;
import util.TableWriter;

/*--------------------------------------------------------------------*/
/** Class for data tables.
 *  <p>This data table class is implemented as a subclass of
 *  <code>AbstractTableModel</code> so that it can be displayed
 *  directly in a <code>JTable</code>.</p>
 *  @author Christian Borgelt
 *  @since  2006.09.16 */
/*--------------------------------------------------------------------*/
public class Table extends AbstractTableModel implements Cloneable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010000L;
  /** the block size for the column arrays */
  private static final int BLKSIZE  = 32;
  /** read/write mode: no header present/do not write a header */
  public  static final int NOHEADER = 0x0001;
  /** read mode: only adapt types, but do not load data */
  public  static final int NODATA   = 0x0002;
  /** read mode: do not add new columns (no extension) */
  public  static final int NOEXTEND = 0x0004;
  /** read mode: do not allow null values */
  public  static final int NONULLS  = 0x0008;
  /** read/write mode: read/write only marked columns (non-negative) */
  public  static final int MARKED   = 0x0010;
  /** read/write mode: tuple weight in last field (currently unused) */
  public  static final int WEIGHT   = 0x0020;
  /** read/write mode: verbose message output (print tuple counter) */
  public  static final int VERBOSE  = 0x0040;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the name of the table */
  private String    name;
  /** the map for column names to column indices */
  private IdMap     colmap;
  /** the number of rows of the data table */
  private int       rowcnt;
  /** the column permutation map */
  private int[]     perm;
  /** the column read flags */
  private boolean[] read;
  /** the buffer for a first table record */
  private String[]  buf;
  /** whether an i/o operation has been aborted */
  private volatile boolean stop;

  /*------------------------------------------------------------------*/
  /** Create a data table.
   *  @since  2007.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create a data table.
   *  @param  name the name of the table
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table (String name)
  { this(name, new IdMap(IdMap.REJECT), 0); }

  /*------------------------------------------------------------------*/
  /** Create a data table.
   *  @param  name   the name of the table
   *  @param  colmap the column name to column identifier map
   *  @param  rowcnt the number of rows of the table
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private Table (String name, IdMap colmap, int rowcnt)
  {                             /* --- create a data table */
    this.name   = name;         /* store the table name, */
    this.colmap = colmap;       /* the column map, */
    this.rowcnt = rowcnt;       /* and the number of rows */
    this.perm   = null;         /* clear the i/o variables */
    this.read   = null;
    this.buf    = null;
    this.stop   = false;
  }  /* Table() */

  /*------------------------------------------------------------------*/
  /** Clone this table.
   *  <p>The clone is not a fully deep copy, as it keeps the types and
   *  the data arrays of the columns. However, the structure managing
   *  the column organization (order, naming etc) is independent of
   *  the old table and thus it is possible to rename/reorder columns
   *  and to add new columns without affecting the original table.</p>
   *  <p>If a deeper copy of the table is needed, the table should
   *  first be cloned with this function (i.e. <code>clone()</code>)
   *  and then the clone deepened with <code>cloneAllColumns()</code>,
   *  <code>cloneAllTypes()</code> or <code>cloneAllData()</code>.</p>
   *  @return a clone of this table
   *  @see    Table#cloneAllColumns()
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone ()
  {                             /* --- clone the table */
    int   i, n;                 /* loop variables */
    IdMap cm = new IdMap();     /* column map of the new table */
    for (n = this.colmap.size(), i = 0; i < n; i++)
      cm.add((Column)this.getColumn(i).clone());
    return new Table(this.name, cm, this.rowcnt);
  }  /* clone() */              /* basically clone the column map */

  /*------------------------------------------------------------------*/
  /** Clone the domain descriptions of this table.
   *  @return a clone of this table without the data
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table cloneDomains ()
  {                             /* --- clone the domain descriptions */
    int   i, n;                 /* loop variables */
    IdMap cm = new IdMap();     /* column map of the new table */
    for (n = this.colmap.size(), i = 0; i < n; i++)
      cm.add(this.getColumn(i).cloneAsType());
    return new Table(this.name, cm, 0);
  }  /* cloneDomains() */       /* basically clone the column map */

  /*------------------------------------------------------------------*/
  /** Clone a column's type and value array and replace originals.
   *  <p>With this method the shallow copy of the table as returned by
   *  <code>clone()</code> can be deepened for particular columns, when
   *  changes to the type and the contents of a column become necessary
   *  and the state of the original column must be preserved.</p>
   *  @param  index the index of the column to clone
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void cloneColumn (int index)
  {                             /* --- clone a column of the table */
    Column col = this.getColumn(index);
    col.cloneType();            /* clone both the column's type */
    col.cloneData();            /* and the column's data array */
  }  /* cloneColumn() */

  /*------------------------------------------------------------------*/
  /** Clone all columns' type and data arrays and replace originals.
   *  <p>With this method the shallow copy of the table as returned by
   *  <code>clone()</code> can be fully deepened.</p>
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void cloneAllColumns ()
  {                             /* --- clone all columns of the table */
    for (int i = this.colmap.size(); --i >= 0; )
      this.cloneColumn(i);      /* traverse and clone the columns */
  }  /* cloneAllColumns() */

  /*------------------------------------------------------------------*/
  /** Clone all columns' types and replace originals.
   *  <p>With this method the shallow copy of the table as returned by
   *  <code>clone()</code> can be partially deepened.</p>
   *  @since  2005.05.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void cloneAllTypes ()
  {                             /* --- clone all types of the table */
    for (int i = this.colmap.size(); --i >= 0; )
      this.getColumn(i).cloneType();
  }  /* cloneAllTypes() */      /* traverse and clone the types */

  /*------------------------------------------------------------------*/
  /** Clone all columns' types and replace originals.
   *  <p>With this method the shallow copy of the table as returned by
   *  <code>clone()</code> can be partially deepened.</p>
   *  @since  2005.05.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void cloneAllData ()
  {                             /* --- clone all data of the table */
    for (int i = this.colmap.size(); --i >= 0; )
      this.getColumn(i).cloneData();
  }  /* cloneAllData() */       /* traverse and clone the data arrays */

  /*------------------------------------------------------------------*/
  /** Clear this table, that is, remove all rows.
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clear ()
  { this.resize(0, false); }

  /*------------------------------------------------------------------*/
  /** Get the name of the table.
   *  @return the name of the table
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return this.name; }

  /*------------------------------------------------------------------*/
  /** Set the name of the table.
   *  @param  name the new name of the table
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setName (String name)
  { this.name = name; }

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return this.rowcnt; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return the number of columns of the table
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return this.colmap.size(); }

  /*------------------------------------------------------------------*/
  /** Get a column given its index.
   *  @param  index the index of the column to get
   *  @return the column with the given index
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column getColumn (int index)
  { return (Column)this.colmap.getValue(index); }

  /*------------------------------------------------------------------*/
  /** Get a column given its name.
   *  @param  name the index of the column to get
   *  @return the column with the given name
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column getColumn (String name)
  { return (Column)this.colmap.getValue(name); }

  /*------------------------------------------------------------------*/
  /** Get the name of a column given its index.
   *  @param  col the index of the column
   *  @return the name of the column with the given index
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int col)
  { return (String)this.colmap.get(col); }

  /*------------------------------------------------------------------*/
  /** Get the index of a column given its name.
   *  <p>This function is equivalent to <code>findColumn()</code>.
   *  @param  name the name of the column
   *  @return the index of the column or <code>-1</code>
   *          if there is no column with the given name
   *  @see    Table#findColumn(String)
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnIndex (String name)
  { return this.colmap.get(name); }

  /*------------------------------------------------------------------*/
  /** Get the index of a column given its name.
   *  <p>This function is equivalent to <code>getColumnIndex()</code>.
   *  @param  name the name of the column
   *  @return the index of the column or <code>-1</code>
   *          if there is no column with the given name
   *  @see    Table#getColumnIndex(String)
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int findColumn (String name)
  { return this.colmap.get(name); }

  /*------------------------------------------------------------------*/
  /** Get the type of a column given its index.
   *  @param  col the index of the column
   *  @return the type of the column with the given index
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColType getColumnType (int col)
  { return this.getColumn(col).getType(); }

  /*------------------------------------------------------------------*/
  /** Set the type of a column given its index.
   *  @param  col  the index of the column
   *  @param  type the type to set
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setColumnType (int col, ColType type)
  { this.getColumn(col).setType(type); }

  /*------------------------------------------------------------------*/
  /** Get the value class of a column given its index.
   *  @param  col the index of the column
   *  @return the value class of the column with the given index
   *  @since  2007.03.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getColumnClass (int col)
  { return this.getColumn(col).getType().getValueClass(); }

  /*------------------------------------------------------------------*/
  /** Get the direction of a column given its index.
   *  @param  col the index of the column
   *  @return the direction of the column
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnDir (int col)
  { return this.getColumn(col).getDir(); }

  /*------------------------------------------------------------------*/
  /** Set the direction of a column given its index.
   *  @param  col the index of the column
   *  @param  dir the direction to set
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setColumnDir (int col, int dir)
  { this.getColumn(col).setDir(dir); }

  /*------------------------------------------------------------------*/
  /** Get the weight of a column given its index.
   *  @param  col the index of the column
   *  @return the weight of the column
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getColumnWeight (int col)
  { return this.getColumn(col).getWeight(); }

  /*------------------------------------------------------------------*/
  /** Set the weight of a column given its index.
   *  @param  col the index of the column
   *  @param  wgt the weight to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setColumnWeight (int col, double wgt)
  { this.getColumn(col).setWeight(wgt); }

  /*------------------------------------------------------------------*/
  /** Add a column to the table.
   *  <p>It is assumed that the column has the same number of rows
   *  as any column already present in the table. The first column
   *  added to a table determines the table's number of rows.</p>
   *  @param  col the column to add
   *  @return the index of the added column or <code>-1</code>
   *          if a column with the same name already exists
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addColumn (Column col)
  {                             /* --- add a column to the table */
    if (this.colmap.size() <= 0)/* set the number of rows for first */
      this.rowcnt = col.getRowCount();
    return this.colmap.add(col.getName(), col);
  }  /* addColumn() */          /* add the column to the column map */

  /*------------------------------------------------------------------*/
  /** Add a column to the table.
   *  @param  name the name of the column to add
   *  @param  type the type of the column to add
   *  @return the added column or <code>null</code>
   *          if a column with the same name already exists
   *  @since  2007.07.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column addColumn (String name, ColType type)
  {                             /* --- add a column to the table */
    Column col = new Column(name, type, this.rowcnt);
    return (this.colmap.add(name, col) >= 0) ? col : null;
  }  /* addColumn() */          /* add the column to the column map */

  /*------------------------------------------------------------------*/
  /** Rename a column, that is, give it a new name.
   *  @param  index the index of the column
   *  @param  name  the new name of the column
   *  @return the index of the column, that is, <code>index</code> or
   *          <code>-1</code> if replacing would create a duplicate
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int renameColumn (int index, String name)
  {                             /* --- rename a column */
    int i = this.colmap.get(name);
    if (i == index) return  i;  /* check whether a column */
    if (i >= 0)     return -1;  /* with the same name already exists */
    ((Column)this.colmap.getValue(index)).name = name;
    this.colmap.replace(index, name);
    return index;               /* replace the old column name */
  }  /* renameColumn() */

  /*------------------------------------------------------------------*/
  /** Remove a column from the table.
   *  @param  index the index of the column to remove
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void removeColumn (int index)
  { this.colmap.remove(index); }

  /*------------------------------------------------------------------*/
  /** Remove a column from the table.
   *  @param  name the name of the column to remove
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void removeColumn (String name)
  { this.colmap.remove(name); }

  /*------------------------------------------------------------------*/
  /** Move a column to a new position.
   *  @param  src the index of the column to move
   *  @param  dst the index to which to move the column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void moveColumn (int src, int dst)
  { this.colmap.move(src, dst); }

  /*------------------------------------------------------------------*/
  /** Reorder the columns of the table.
   *  <p>The desired reordering has to be stated as a permutation of
   *  the integer numbers 0 to <code>size()-1</code>, with each entry
   *  stating the new index for the column that is identified by the
   *  array index (forward map).</p>
   *  <p>If the reordering map is not such a permutation, the table
   *  will get into an inconsistent state that may lead to serious
   *  errors.</p>
   *  @param  map an integer array containing a permutation of the
   *              integer numbers 0 to <code>getColumnCount()-1</code>
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void reorderColumns (int[] map)
  { this.colmap.reorder(map); }

  /*------------------------------------------------------------------*/
  /** Sort the columns of the table by name.
   *  @return a map from the old indices (array indices)
   *          to the new indices (contents of array elements)
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int[] sortColumns ()
  {                             /* --- sort the columns */
    return this.colmap.sort(new Comparator<Object> () {
      public int compare (Object o1, Object o2) {
        return ((Column)o1).getName().compareTo(((Column)o2).getName());
      } } );
  }  /* sortColumns() */

  /*------------------------------------------------------------------*/
  /** Sort the columns of the table.
   *  @param  cmp the comparator for the columns
   *  @return a map from the old indices (array indices)
   *          to the new indices (contents of array elements)
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int[] sortColumns (Comparator<Object> cmp)
  { return this.colmap.sort(cmp); }

  /*------------------------------------------------------------------*/
  /** Automatically determine the type of columns.
   *  <p>Note that it is only tried to convert nominal columns.</p>
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void autoType ()
  {                             /* --- determine types automatically */
    for (int i = this.colmap.size(); --i >= 0; )
      this.getColumn(i).autoType();
  }  /* autoType() */           /* auto-type all columns */

  /*------------------------------------------------------------------*/
  /** Automatically determine the direction of columns.
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void autoDir ()
  {                             /* --- determine directions */
    for (int i = this.colmap.size(); --i >= 0; )
      this.getColumn(i).setDir(Column.DIR_IN);
  }  /* autoDir() */

  /*------------------------------------------------------------------*/
  /** Sort the values of the nominal columns.
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sortTypes ()
  { this.sortTypes(null); }

  /*------------------------------------------------------------------*/
  /** Sort the values of the nominal columns.
   *  @param  cmp the comparator for the values
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sortTypes (Comparator<Object> cmp)
  {                             /* --- sort the nominal value */
    for (int i = this.colmap.size(); --i >= 0; )
      this.getColumn(i).sortType(cmp);
  }  /* sortTypes() */

  /*------------------------------------------------------------------*/
  /** Returns whether a table cell is editable.
   *  <p>Editing is currently not supported, therefore this function
   *  always returns <code>false</code>.</p>
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return whether the specified cell is editable
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isCellEditable (int row, int col)
  { return false; }

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as an object.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return an object representing the value in the specified cell
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  { return this.getColumn(col).getValueAt(row); }

  /*------------------------------------------------------------------*/
  /** Set the value of a table cell from an object.
   *  @param  value the value to set in the specified cell
   *  @param  row   the row    of the cell to set
   *  @param  col   the column of the cell to set
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object value, int row, int col)
  { this.getColumn(col).setValueAt(value, row); }

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as a string.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return a string description of the value in the specified cell
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (int row, int col)
  { return this.getColumn(col).getStringAt(row); }

  /*------------------------------------------------------------------*/
  /** Resize the table, that is, change the number of rows.
   *  <p>Note that new value arrays are allocated regardless of whether
   *  the new number of rows coincides with the old number or not.
   *  Hence calling this function with the old number of rows
   *  effectively clones the value arrays of all columns.</p>
   *  @param  newcnt the new number of rows
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void resize (int newcnt)
  { this.resize(newcnt, true); }

  /*------------------------------------------------------------------*/
  /** Resize the value arrays of the table.
   *  @param  newcnt the new number of rows
   *  @param  init   whether to initialize new rows to null values
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void resize (int newcnt, boolean init)
  {                             /* --- resize the table */
    for (int i = this.colmap.size(); --i >= 0; )
      this.getColumn(i).resize(newcnt, init);
    this.rowcnt = newcnt;       /* resize all table columns and */
  }  /* resize() */             /* note the new number of rows */

  /*------------------------------------------------------------------*/
  /** Read table header from an input stream.
   *  @param  reader the table reader to read from
   *  @see    #readHeader(TableReader,int)
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void readHeader (TableReader reader) throws IOException
  { this.readHeader(reader, 0); }

  /*------------------------------------------------------------------*/
  /** Read table header from an input stream.
   *  <p>If <code>(mode &amp; NOHEADER) != 0</code>, default field names
   *  are generated and the first data record is read into an internal
   *  buffer, which is processed on the next call to any of the
   *  <code>readRow()</code> functions.</p>
   *  @param  reader the table reader to read from
   *  @param  mode   the read mode
   *  @throws IOException if a read error occurs
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void readHeader (TableReader reader, int mode)
    throws IOException
  {                             /* --- read a table header */
    int    i, k;                /* loop variable, buffer */
    int    cms, cnt;            /* numbers of columns */
    Column col;                 /* to traverse the columns */
    String s;                   /* buffer for a column name */
    Object tmp;                 /* buffer for reallocation */

    /* --- initialize variables --- */
    this.perm = new int    [cms = this.colmap.size()];
    this.read = new boolean[cms];
    this.buf  = ((mode & NOHEADER) != 0) ? new String[cms] : null;
    for (i = cms; --i >= 0; )   /* initialize permutation map, */
      this.read[i] = false;     /* read flags, and record buffer */

    /* --- read a table record --- */
    cnt = 0;                    /* init. the number of read columns */
    do {                        /* read the column names */
      if (reader.nextField() < 0)  /* if at the end of the input, */
        break;                     /* there is no table to read */
      /* Note that nextField() can return a negative value only   */
      /* on the first call, since a value of 0 (field separator)  */
      /* cannot be followed immediately by a negative value and   */
      /* a positive value (record separator) terminates the loop. */
      s = (this.buf != null) ? String.valueOf(cnt+1) : reader.field;
      i = this.colmap.get(s);   /* get the corresp. column index */
      if (i >= 0) {             /* if the column already exists, */
        if (this.read[i])       /* check for unique column names */
          throw new IOException("duplicate column: " +s);
        if (this.buf != null)   /* if there is no table header, */
          this.buf[i] = reader.field;  /* buffer field contents */
        col = this.getColumn(i);/* do not read unmarked columns */
        if (((mode & MARKED) != 0) && (col.getMark() < 0)) i = -1;
        else this.read[i] = true; }  /* otherwise set read flag */
      else if ((mode & NOEXTEND) == 0) {  /* if new columns are */
        if (cms >= this.read.length) {    /* allowed (extension) */
          k = cms +((cms > BLKSIZE) ? cms >> 1 : BLKSIZE);
          System.arraycopy(this.read, 0, tmp = new boolean[k], 0, cms);
          this.read = (boolean[])tmp;
          if (this.buf != null) {
            System.arraycopy(this.buf, 0, tmp = new String[k], 0, cms);
            this.buf = (String[])tmp;
          }                     /* enlarge the read flag array and */
        }                       /* the buffer for a table record */
        i = this.addColumn(new Column(s, null, this.rowcnt));
        this.read[i] = true;    /* add a new default column and */
        cms++;                  /* increment the number of columns */
        if (this.buf != null)   /* if there is no table header, */
          this.buf[i] = reader.field;  /* buffer field contents */
      }
      if (cnt >= this.perm.length) {
        k = cnt +((cnt > BLKSIZE) ? cnt >> 1 : BLKSIZE);
        System.arraycopy(this.perm, 0, tmp = new int[k], 0, cnt);
        this.perm = (int[])tmp; /* if the permutation map is full, */
      }                         /* enlarge the permutation map */
      this.perm[cnt++] = i;     /* note the column index in the map */
    } while (reader.delim == 0);/* while in the first record */

    /* --- finalize reading --- */
    System.arraycopy(this.perm, 0, tmp = new int[cnt],     0, cnt);
    this.perm = (int[])tmp;     /* shrink the permutation map */
    System.arraycopy(this.read, 0, tmp = new boolean[cms], 0, cms);
    this.read = (boolean[])tmp; /* shrink the read flag array */
    if (this.buf != null) {     /* if there is a buffer for a record */
      System.arraycopy(this.buf, 0, tmp = new String[cms], 0, cms);
      this.buf = (String[])tmp; /* shrink the record buffer */
    }                           /* to the needed size */
    for (i = 0; i < cms; i++) { /* check which attributes were read */
      if (this.read[i]) continue;
      col = this.getColumn(i);  /* get an unread column */
      k   = col.getMark();      /* and retrieve its marker */
      if (((mode & MARKED) == 0) || (k >  0))
        throw new IOException("missing column: " +col.getName());
      if (((mode & MARKED) != 0) && (k == 0))
        col.setMark(-1);        /* unmark optional columns to */
    }                           /* indicate that they are missing */
  }  /* readHeader() */

  /*------------------------------------------------------------------*/
  /** Clear the internal record buffer.
   *  <p>The internal record buffer of a table gets filled if one
   *  of the <code>readHeader()</code> functions is called with
   *  <code>(mode &amp; NOHEADER) != 0</code>. This internal buffer
   *  would be processed on the next call to one of the
   *  <code>readRow()</code> functions. If this is not desired, the
   *  internal buffer can be cleared by calling this function.</p>
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clearBuffer ()
  { this.buf = null; }

  /*------------------------------------------------------------------*/
  /** Read a table row.
   *  <p>The row is not stored in the table, only the column types
   *  are adapted.</p>
   *  @param  reader the table reader to read from
   *  @return whether a record was read
   *  @throws IOException if a read error occurs
   *  @see    #readRow(int,TableReader,int)
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean readRow (TableReader reader) throws IOException
  { return this.readRow(-1, reader, 0); }

  /*------------------------------------------------------------------*/
  /** Read a table row.
   *  <p>If <code>row &lt; 0</code>, the row is not stored in the table,
   *  only the column types are adapted. If <code>row &ge; 0</code>,
   *  the corresponding table row must already exist in the table
   *  (that is, it must be <code>getRowCount() &gt; row</code>).</p>
   *  @param  row    the table row in which to store the read record
   *  @param  reader the table reader to read from
   *  @return whether a record was read
   *  @throws IOException if a read error occurs
   *  @see    #readRow(int,TableReader,int)
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean readRow (int row, TableReader reader)
    throws IOException
  { return this.readRow(row, reader, 0); }

  /*------------------------------------------------------------------*/
  /** Read a table row.
   *  <p>If <code>row &lt; 0</code>, the row is not stored in the table,
   *  only the column types are adapted. If <code>row &ge; 0</code>,
   *  the corresponding table row must already exist in the table
   *  (that is, it must be <code>getRowCount() &gt; row</code>).</p>
   *  @param  row    the table row in which to store the record
   *  @param  reader the table reader to read from
   *  @param  mode   the read mode
   *  @return whether a record was read
   *  @throws IOException if a read error occurs
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean readRow (int row, TableReader reader, int mode)
    throws IOException
  {                             /* --- read a table row */
    int    i, k;                /* loop variable, column index */
    int    cnt;                 /* number of columns */
    Column col;                 /* to traverse the columns */
    String s;                   /* contents of the next field */

    if ((this.buf == null)      /* if there is no buffered record */
    &&  (reader.nextField() < 0))   /* and no next field to read, */
      return false;             /* abort the function */
    cnt = this.perm.length;     /* get the number of read columns */
    for (i = 0; i < cnt; ) {    /* traverse the read columns */
      k = this.perm[i];         /* get the next column index */
      if (k >= 0) {             /* if to read the column */
        s   = (this.buf != null) ? this.buf[k] : reader.field;
        col = this.getColumn(k);/* get field and corresp. column */
        if (((mode & NONULLS) != 0)    /* check for a null value */
        &&  ((s == null) || (s.length() <= 0)))
          throw new IOException("value is null "
                      +reader.rno((this.buf != null) ? 0 : -1));
        if (((mode & NODATA) != 0) || (row < 0))
          col.getType().addValue(s);
        else                    /* add the value to the type */
          col.setValueAt(s, row);
      }                         /* or set the value in the column */
      if (++i >= cnt) break;    /* if all columns read, abort */
      if (this.buf != null)     /* if there is a buffered record, */
        continue;               /* no field reading is necessary */
      if (reader.delim != 0)    /* check the number of fields */
        throw new IOException("too few fields" +reader.rno(-1));
      reader.nextField();       /* get the next field contents */
    }                           /* (previous field is not last) */
    if ((this.buf == null)      /* if there is no buffered record, */
    &&  (reader.delim == 0))    /* check the number of fields */
      throw new IOException("too many fields" +reader.rno());
    this.buf = null;            /* clear the internal recoird buffer */
    if (row < 0) return true;   /* set unread columns to null */
    for (i = this.read.length; --i >= 0; )
      if (!this.read[i]) this.getColumn(i).setNull(row);
    return true;                /* return that a row was read */
  }  /* readRow() */

  /*------------------------------------------------------------------*/
  /** Read table from an input stream.
   *  @param  reader the table reader to read from
   *  @return the number of rows read
   *  @throws IOException if a read error occurs
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int read (TableReader reader) throws IOException
  { return this.read(reader, 0); }

  /*------------------------------------------------------------------*/
  /** Read a table from an input stream.
   *  @param  reader the table reader to read from
   *  @param  mode   the read mode
   *  @return the number of rows read
   *  @throws IOException if a read error occurs
   *  @since  2007.02.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int read (TableReader reader, int mode) throws IOException
  {                             /* --- read table */
    int    k, row;              /* loop variable, current row */
    String s;                   /* buffer for a message */

    this.stop = false;          /* clear the stop flag */
    this.readHeader(reader, mode); /* read the table header */
    row = this.rowcnt;          /* get the current number of rows */
    while (!this.stop) {        /* record read loop */
      if ((row >= this.rowcnt)  /* if the value arrays are full */
      &&  ((mode & NODATA) == 0)) {
        k = row +((row > 1024) ? row >> 1 : 1024);
        this.resize(k, false);  /* compute a new array size */
      }                         /* and resize the value arrays */
      if (!this.readRow(row, reader, mode))
        break;                  /* read the next table row and */
      row++;                    /* count it if it could be read */
      if (((mode & VERBOSE) == 0) || ((row & 0x3ff) != 0))
        continue;               /* check for row number output */
      s = "        " +row;      /* if it is divisible by 1024 */
      System.err.print(s.substring(s.length() -8));
      System.err.print("\b\b\b\b\b\b\b\b");
    }                           /* print the row counter */
    if (row < this.rowcnt)      /* if there are more rows than */
      this.resize(row, false);  /* have been read, remove them */
    return row;                 /* return the number of rows */
  }  /* read() */

  /*------------------------------------------------------------------*/
  /** Write a table header.
   *  @param  writer the table writer
   *  @throws IOException if a write error occurs
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void writeHeader (TableWriter writer) throws IOException
  { this.writeHeader(writer, 0); }

  /*------------------------------------------------------------------*/
  /** Write a table header.
   *  @param  writer the table writer
   *  @param  mode   the write mode
   *  @throws IOException if a write error occurs
   *  @since  2007.05.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void writeHeader (TableWriter writer, int mode)
    throws IOException
  {                             /* --- write a table header */
    int    i, n;                /* loop variables, number of columns */
    Column col;                 /* to traverse the columns */
    String s = null;            /* next column name to write */

    for (n = this.colmap.size(), i = 0; i < n; i++) {
      col = this.getColumn(i);  /* traverse the columns */
      if (((mode & MARKED) != 0) && (col.getMark() < 0))
        continue;               /* skip unmarked columns if necessary */
      if (s != null) writer.write(s, 0, false);
      s = col.getName();        /* write the previous column name */
    }                           /* and note the next one */
    writer.write(s, 0, true);   /* write the last column name */
  }  /* writeHeader() */

  /*------------------------------------------------------------------*/
  /** Write a table row.
   *  @param  row    the table row to write
   *  @param  writer the table writer
   *  @throws IOException if a write error occurs
   *  @since  2007.05.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void writeRow (int row, TableWriter writer) throws IOException
  { this.writeRow(0, writer, 0); }

  /*------------------------------------------------------------------*/
  /** Write a table row.
   *  @param  row    the table row to write
   *  @param  writer the writer to write the table row to
   *  @param  mode   the write mode
   *  @throws IOException if a write error occurs
   *  @since  2007.05.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void writeRow (int row, TableWriter writer, int mode)
    throws IOException
  {                             /* --- write a table row */
    int    i, n;                /* loop variables, number of columns */
    Column col;                 /* to traverse the columns */
    String s = null;            /* next field contents to write */

    for (n = this.colmap.size(), i = 0; i < n; i++) {
      col = this.getColumn(i);  /* traverse the columns */
      if (((mode & MARKED) != 0) && (col.getMark() < 0))
        continue;               /* skip unmarked columns if necessary */
      if (s != null) writer.write(s, 0, false);
      s = col.getStringAt(row); /* write the previous field */
    }                           /* and note the next one */
    writer.write(s, 0, true);   /* write the last field */
  }  /* writeRow() */

  /*------------------------------------------------------------------*/
  /** Write the table.
   *  @param  writer the table writer
   *  @throws IOException if a write error occurs
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void write (TableWriter writer) throws IOException
  { this.write(writer, 0); }

  /*------------------------------------------------------------------*/
  /** Write the table.
   *  @param  writer the writer to write the table to
   *  @param  mode   the write mode
   *  @throws IOException if a write error occurs
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void write (TableWriter writer, int mode) throws IOException
  {                             /* --- write table */
    this.stop = false;          /* clear the stop flag */
    if ((mode & NOHEADER) == 0) /* write a table header if requested */
      this.writeHeader(writer, mode);
    for (int i = 0; i < this.rowcnt; i++) {
      if (this.stop) return;    /* check the stop flag each row */
      this.writeRow(i, writer, mode);
    }                           /* write the table rows */
  }  /* write() */

  /*------------------------------------------------------------------*/
  /** Abort an i/o operation.
   *  <p>Reading or writing a table with one of the <code>read()</code>
   *  or <code>write()</code> functions, respectively, is aborted after
   *  the next table row.</p>
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void abort ()
  { this.stop = true; }

  /*------------------------------------------------------------------*/
  /** Create a string description of the table type.
   *  @param  header the text to add as a header
   *  @return a string description of the table type
   *  @since  2007.05.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString (String header)
  {                             /* --- describe the column type */
    int           i, n;         /* loop variables */
    StringBuilder s = new StringBuilder();

    if (header != null) {       /* if to add a header */
      s.append("/*");           /* create domain description header */
      for (i = 70; --i >= 0; ) s.append('-');
      s.append("\n  " +header +"\n");
      for (i = 70; --i >= 0; ) s.append('-');
      s.append("*/\n");         /* terminate the header */
    }
    for (n = this.colmap.size(), i = 0; i < n; i++) {
      s.append(this.colmap.getValue(i));
      s.append('\n');           /* traverse the table columns and */
    }                           /* concatenate their descriptions */
    return s.toString();        /* return the created description */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Create a string description of the table type.
   *  @return a string description of the table type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  { return this.toString(this.name); }

  /*------------------------------------------------------------------*/
  /** Parse a table description.
   *  @param  name the name of the table to create
   *  @param  scan the scanner to read from
   *  @throws IOException if an i/o error occurs or
   *                      a duplicate column name is found
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Table parse (String name, Scanner scan)
    throws IOException
  {                             /* --- parse a table description */
    int    tok;                 /* next token */
    String val;                 /* value of the next token */
    Table  tab;                 /* created table */

    tab = new Table(name);      /* create an empty table */
    while (true) {              /* column read loop */
      tok = scan.nextToken();   /* get the next token */
      val = scan.value;         /* and its associated value */
      scan.pushBack();          /* and push it back immediately */
      if ((tok != Scanner.T_ID) || !val.equals("dom"))
        break;                  /* if no more columns, abort */
      if (tab.addColumn(Column.parse(scan)) < 0)
        throw new IOException("duplicate column: " +val +scan.lno());
    }                           /* parse and add the column */
    return tab;                 /* return the created table */
  }  /* parse() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2004.06.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    Scanner scan;               /* scanner to read from */
    Table   tab;                /* created table */

    if (args.length <= 0) {     /* if no arguments are given */
      System.out.println("usage: java table.Table <domfile>");
      return;                   /* print a usage message */
    }                           /* and abort the program */
    try {                       /* basic functionality test */
      scan = new Scanner(new FileReader(args[0]));
      tab  = Table.parse(args[0], scan);
      if (scan.nextToken() != Scanner.T_EOF)
        throw new IOException("garbage at end of file " +scan.lno());
      scan.close();             /* parse the domain descriptions */
      System.out.println(tab);} /* and print them afterwards */
    catch (IOException e) {     /* catch any i/o errors */
      System.out.println(e.getMessage()); return; }
  }  /* main() */

}  /* class Table */
