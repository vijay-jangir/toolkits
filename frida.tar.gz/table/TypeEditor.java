/*----------------------------------------------------------------------
  File    : TypeEditor.java
  Contents: editor for the values of types
  Author  : Christian Borgelt
  History : 2007.07.17 file created
            2013.04.22 adapted to class name change Type -> ColType
            2016.05.02 newly required serialVersionUID added
----------------------------------------------------------------------*/
package table;

import dialog.DialogPanel;

/*--------------------------------------------------------------------*/
/** Class for an editor for the values of types.
 *  @author Christian Borgelt
 *  @since  2007.07.17 */
/*--------------------------------------------------------------------*/
public abstract class TypeEditor extends DialogPanel {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the type to edit */
  protected ColType type = null;

  /*------------------------------------------------------------------*/
  /** Set the type to edit.
   *  @param  type the type to edit
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract void setType (ColType type);

  /*------------------------------------------------------------------*/
  /** Get the edited type.
   *  @return the edited type
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract ColType getType ();

}  /* TypeEditor() */
