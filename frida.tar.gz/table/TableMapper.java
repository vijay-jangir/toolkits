/*----------------------------------------------------------------------
  File    : TableMapper.java
  Contents: Class for mapping data table rows to real-valued vectors
  Author  : Christian Borgelt
  History : 2007.05.16 file created
            2007.05.17 function getVarName() added
----------------------------------------------------------------------*/
package table;

import java.io.IOException;
import java.io.FileReader;

import util.TableReader;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for mapping data table rows to real-valued vectors.
 *  @author Christian Borgelt
 *  @since  2007.05.16 */
/*--------------------------------------------------------------------*/
public class TableMapper {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** map only marked columns (non-negative) */
  public static final int MARKED  = 1;
  /** use two columns for binary attributes (default: one column) */
  public static final int BIN2COL = 2;
  /** map only the input attributes */
  public static final int INPUTS  = 1;
  /** map only the target attribute */
  public static final int TARGET  = ~1;
  /** map both input and target attributes */
  public static final int BOTH    = ~0;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the table to map */
  private Table  tab;
  /** the ids of the mapped columns */
  private int[]  ids;
  /** the offset to the first vector element per attribute */
  private int[]  offs;
  /** the number of vector elements per attribute */
  private int[]  cnts;
  /** the number of input vector elements */
  private int    incnt;
  /** the number of output vector elements */
  private int    outcnt;
  /** the value for 1-in-n encoding */
  private double one;

  /*------------------------------------------------------------------*/
  /** Create a data table mapper.
   *  @param  tab the table to map
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableMapper (Table tab)
  { this(tab, 0, 1.0); }

  /*------------------------------------------------------------------*/
  /** Create a data table mapper.
   *  @param  tab  the table to map
   *  @param  mode the mapping mode
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableMapper (Table tab, int mode)
  { this(tab, mode, 1.0); }

  /*------------------------------------------------------------------*/
  /** Create a data table mapper.
   *  @param  tab  the table to map
   *  @param  mode the mapping mode
   *  @param  one  the value for 1-in-n encoding
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private TableMapper (Table tab, int mode, double one)
  {                             /* --- create a data table mapper */
    int     i, k, n, off, cnt;  /* loop variables, buffers */
    Column  col;                /* to traverse the columns */
    ColType type;               /* to traverse the column types */

    this.tab = tab;             /* note the underlying table and */
    this.one = one;             /* the value for 1-in-n encoding */
    n = tab.getColumnCount();   /* get the number of table columns */
    for (i = k = 0; i < n; i++) {
      col = tab.getColumn(i);   /* traverse the table columns */
      if (((mode & MARKED) != 0) && (col.getMark() < 0))
        continue;               /* skip unmarked columns if necessary */
      type = col.getType();     /* evaluate the column type */
      if ((type instanceof MetricType)
      ||  (type instanceof NominalType))
        k++;                    /* count the attributes to map */
    }                           /* (needed for the memory allocation) */
    this.ids  = new int[k];     /* allocate the arrays */
    this.offs = new int[k];     /* for the columns to map */
    this.cnts = new int[k];
    for (i = k = off = 0; i < n; i++) {
      col = tab.getColumn(i);   /* traverse the table columns */
      if (((mode & MARKED) != 0) && (col.getMark() < 0))
        continue;               /* skip unmarked columns if necessary */
      type = col.getType();     /* evaluate the column type */
      if      (type instanceof MetricType)
        cnt = 1;                /* metric columns are copied */
      else if (type instanceof NominalType) {
        cnt = ((NominalType)type).getValueCount();
        if ((cnt == 2) && ((mode & BIN2COL) == 0)) cnt = 1; }
      else continue;            /* nominal columns are encoded */
      this.ids [k  ] = i;       /* note the column id, */
      this.offs[k  ] = off;     /* the current offset, and */
      this.cnts[k++] = cnt;     /* the number of vector elements */
      off           += cnt;     /* advance the offset by the number */
    }                           /* of vector elements mapped to */
    this.incnt  = off;          /* note the number of inputs */
    this.outcnt = 0;            /* and  the number of outputs */
  }  /* TableMapper() */

  /*------------------------------------------------------------------*/
  /** Get the underlying table.
   *  @return the underlying table
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getTable ()
  { return this.tab; }

  /*------------------------------------------------------------------*/
  /** Get the number of mapped columns.
   *  @return the number of mapped columns
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return this.ids.length; }

  /*------------------------------------------------------------------*/
  /** Get a mapped column.
   *  <p>Note that the column id in the table mapper may differ from
   *  the column id in the underlying table if not all columns were
   *  mapped or the target column is not the last column of the table.
   *  The target column (if it has been set) can be accessed with a
   *  negative column index or with <code>getColumnCount()-1</code>.</p>
   *  @param  id the id of the mapped column
   *  @return the <code>id</code>-th mapped column
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column getColumn (int id)
  { return this.tab.getColumn(
      this.ids[(id < 0) ? this.ids.length-1 : id]); }

  /*------------------------------------------------------------------*/
  /** Get the target column.
   *  @return the target column
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column getTarget ()
  { return (this.outcnt > 0)
         ? this.tab.getColumn(this.ids[this.ids.length-1]) : null; }

  /*------------------------------------------------------------------*/
  /** Get the target column id.
   *  @return the target column id
   *  @since  2007.05.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getTargetId ()
  { return (this.outcnt > 0) ? this.ids[this.ids.length-1] : -1; }

  /*------------------------------------------------------------------*/
  /** Get the number of input elements.
   *  @return the number of input elements
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getInputCount ()
  { return this.incnt; }

  /*------------------------------------------------------------------*/
  /** Get the number of output elements.
   *  @return the number of output elements
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getOutputCount ()
  { return this.outcnt; }

  /*------------------------------------------------------------------*/
  /** Get the total number of elements.
   *  @return the total number of elements
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getInOutCount ()
  { return this.incnt +this.outcnt; }

  /*------------------------------------------------------------------*/
  /** Get the offset to the first element a column is mapped to.
   *  @param  id the id of the column
   *  @return the offset to the first element a column is mapped to
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getOffset (int id)
  { return this.offs[(id < 0) ? this.ids.length-1 : id]; }

  /*------------------------------------------------------------------*/
  /** Get the number of elements a column is mapped to.
   *  @param  id the id of the column
   *  @return the number of elements a column is mapped to
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getCount (int id)
  { return this.cnts[(id < 0) ? this.ids.length-1 : id]; }

  /*------------------------------------------------------------------*/
  /** Get the name of a mapped variable.
   *  @param  id the id of the variable (vector index)
   *  @return the name of the mapped variable
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getVarName (int id)
  {                             /* --- get name of mapped variable */
    int    l, r, m;             /* variables for binary search */
    Column col;                 /* buffer for corresp. column */
    String name;                /* name of the column/variable */

    l = 0; r = this.offs.length;
    while (l < r) {             /* do a binary search */
      m = (l+r) >> 1;           /* in the offsets */
      if (this.offs[m] < id) l = m+1;
      else                   r = m;
    }                           /* l is the index of the column */
    col  = this.tab.getColumn(this.ids[l]);
    name = col.getName();       /* get the corresponding column name */
    if (this.cnts[l] <= 1) return name;
    id -= this.offs[l];         /* compute the value index and */
    return name +"_"            /* add value name for 1-in-n encoding */
          +((NominalType)col.getType()).getValue(id);
  }  /* getVarName() */

  /*------------------------------------------------------------------*/
  /** Set the target column.
   *  @param  trgid the column id of the target attribute
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTarget (int trgid)
  {                             /* --- set the target */
    int i, k, n;                /* loop variables */

    if (this.outcnt > 0) {      /* if there is an old target */
      k = this.ids [i = this.ids.length -1];
      n = this.cnts[i];         /* note the mapping information */
      while ((--i >= 0) && (k < this.ids[i])) {
        this.ids [i+1] = this.ids [i];
        this.cnts[i+1] = this.cnts[i];
      }                         /* shift up the preceding columns */
      this.ids [i] = k;         /* store the old target information */
      this.cnts[i] = n;         /* at the proper place in the vectors */
      this.outcnt  = 0;         /* clear the number of outputs */
    }
    if (trgid >= 0) {           /* if to set a new target column */
      for (i = this.ids.length; --i >= 0; )
        if (this.ids[i] == trgid) break;
      if (i >= 0) {             /* find the new target column */
        n = this.cnts[i];       /* note the mapping information */
        while (++i < this.ids.length) {
          this.ids [i-1] = this.ids [i];
          this.cnts[i-1] = this.cnts[i];
        }                       /* shift down the successor columns */
        this.ids [--i] = trgid; /* to close the gap and */
        this.cnts[  i] = n;     /* store the new target */
        this.outcnt    = n;     /* as the last column */
      }                         /* set the (new) number of outputs */
    }
    for (i = k = 0; i < this.ids.length; i++) {
      this.offs[i] = k;         /* update the mapping offsets */
      k += this.cnts[i];        /* (may no longer be valid */
    }                           /* due to shifts of columns) */
    this.incnt = k-this.outcnt; /* compute the number of inputs */
  }  /* setTarget() */

  /*------------------------------------------------------------------*/
  /** Execute the table map for a given row.
   *  @param  row  the index of the row to map
   *  @return the numeric vector the row is mapped to
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double[] exec (int row)
  { return this.exec(row, BOTH, null); }

  /*------------------------------------------------------------------*/
  /** Execute the table map for a given row.
   *  @param  row  the index of the row to map
   *  @param  mode the mapping mode (e.g. <code>INPUTS</code>)
   *  @return the numeric vector the row is mapped to
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double[] exec (int row, int mode)
  { return this.exec(row, mode, null); }

  /*------------------------------------------------------------------*/
  /** Execute the table map for a given row.
   *  @param  row  the index of the row to map
   *  @param  vec  the vector in which to store the mapped row
   *  @return the numeric vector the row is mapped to
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double[] exec (int row, double[] vec)
  { return this.exec(row, BOTH, vec); }

  /*------------------------------------------------------------------*/
  /** Execute the table map for a given row.
   *  @param  row  the index of the row to map
   *  @param  mode the mapping mode (e.g. <code>INPUTS</code>)
   *  @param  vec  the vector in which to store the mapped row
   *  @return the numeric vector the row is mapped to
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double[] exec (int row, int mode, double[] vec)
  {                             /* --- execute a table map */
    int    i, k, n, v, cnt;     /* loop variables, buffers */
    Column col;                 /* to traverse the columns */

    if (vec == null) {          /* if no result vector is given, */
      n = 0;                    /* compute the number of elements */
      if ((mode & INPUTS) != 0) n += this.incnt;
      if ((mode & TARGET) != 0) n += this.outcnt;
      vec = new double[n];      /* allocate a result vector */
    }                           /* of the appropriate size */
    if (this.outcnt > 0) { n = this.ids.length -1; }
    else                 { n = this.ids.length; mode &= INPUTS; }
    i = ((mode & INPUTS) != 0) ? 0 : n; /* get the column range: */
    if  ((mode & TARGET) != 0) n++;     /* from i to n-1 (incl.) */
    for (k = 0; i < n; i++) {   /* traverse the columns to map */
      col = this.tab.getColumn(this.ids[i]);
      cnt = this.cnts[i];       /* evaluate the column type */
      if (col.getType() instanceof MetricType)
        vec[k++] = col.getNumberAt(row);
      else if (cnt < 2) {       /* map metric and binary directly */
        v = ((int[])col.getData())[row];
        vec[k++] = ((v < 0) || (v > 1) ? 0.5 : v) *Math.abs(this.one); }
      else {                    /* if the column is nominal */
        for (v = cnt; --v >= 0;)/* clear all vector elements */
          vec[k+v] = 0;         /* corresponding to this column */
        v = ((int[])col.getData())[row];
        if ((v >= 0) && (v < cnt))
          vec[k+v] = (this.one < 0) ? -this.one /cnt : this.one;
        k += cnt;               /* get the nominal value and */
      }                         /* set the corresponding element */
    }                           /* then advance the vector index */
    return vec;                 /* return the mapping result */
  }  /* exec() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.05.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    int         i;              /* loop variable */
    Scanner     scan;           /* scanner to read domains from */
    TableReader reader;         /* reader  to read table from */
    Table       tab;            /* created table */
    TableMapper map;            /* mapper for the table */
    double[]    vec = null;     /* vector for mapping result */

    if (args.length != 2) {     /* if wrong number of arguments */
      System.out.println("usage: java " +TableMapper.class.getName()
                              +" domfile tabfile");
      return;                   /* print a usage message */
    }                           /* and abort the program */
    try {                       /* basic functionality test */
      scan = new Scanner(new FileReader(args[0]));
      tab  = Table.parse(args[0], scan);
      if (scan.nextToken() != Scanner.T_EOF)
        throw new IOException("garbage at end of file " +scan.lno());
      scan.close();             /* parse the domain descriptions */
      tab.resize(1);            /* and create a table with one row */
      map    = new TableMapper(tab);
      reader = new TableReader(new FileReader(args[1]));
      tab.readHeader(reader);   /* read the table header */
      while (tab.readRow(reader)) {
        vec = map.exec(0, vec); /* read the table rows */
        for (i = 0; i < vec.length-1; i++)
          System.out.print(vec[i] +" ");
        System.out.println(vec[i]);
      }                         /* map each table row to a vector */
      reader.close(); }         /* and then print this vector */
    catch (IOException e) {     /* catch any i/o errors */
      System.out.println(e.getMessage()); return; }
  }  /* main() */

}  /* class TableMapper */
