/*----------------------------------------------------------------------
  File    : NominalType.java
  Contents: Class for nominal types for data tables
  Author  : Christian Borgelt
  History : 2006.09.11 file created
            2006.10.06 cloning added
            2007.02.01 function getStringAt added
            2007.01.31 functions isNull and setNull added
            2007.02.13 function getName added
            2007.02.16 function parseType added
            2007.02.18 storing of additional information added
            2013.04.22 adapted to class name change Type -> ColType
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package table;

import java.util.Comparator;
import java.io.IOException;

import util.IdMap;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for nominal types for data tables.
 *  @author Christian Borgelt
 *  @since  2006.09.11 */
/*--------------------------------------------------------------------*/
public class NominalType extends ColType {

  /*------------------------------------------------------------------*/
  /*  constants
  /*------------------------------------------------------------------*/
  /** a null value (of the storage class) */
  public static final int NULL = -1;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** mapping between value names and value identifiers */
  private final IdMap valmap;
  /** the current value of the type */
  private       int   curr;

  /*------------------------------------------------------------------*/
  /** Create for a nominal type.
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public NominalType ()
  { this.valmap = new IdMap(); this.curr = NULL; }

  /*------------------------------------------------------------------*/
  /** Create for a nominal type.
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public NominalType (Object[] values)
  {                             /* --- create a nominal type */
    this();                     /* initialize the nominal type */
    for (int i = 0; i < values.length; )
      this.addValue(values[i]); /* add the given values */
  }  /* NominalType() */

  /*------------------------------------------------------------------*/
  /** Create a clone of a nominal type.
   *  @param  type the nominal type to clone
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public NominalType (NominalType type)
  { this.valmap = (IdMap)type.valmap.clone(); this.curr = NULL; }

  /*------------------------------------------------------------------*/
  /** Clone this type.
   *  @return a clone of this type
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone ()
  { return new NominalType(this); }

  /*------------------------------------------------------------------*/
  /** Get the name of the type.
   *  @return the name of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return "nominal"; }

  /*------------------------------------------------------------------*/
  /** Get the class used to access values of this type, that is,
   *  <code>Object.class</code>.
   *  @return <code>Object.class</code>
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getValueClass ()
  { return Object.class; }

  /*------------------------------------------------------------------*/
  /** Get the class used to store values of this type, that is,
   *  <code>int.class</code>.
   *  @return <code>int.class</code>
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getStorageClass ()
  { return int.class; }

  /*------------------------------------------------------------------*/
  /** Check whether an array fits this type.
   *  <p>This function need not really be here, since the generic
   *  version in ColType.java yields the same result. However, this
   *  version is more efficient.</p>
   *  @return whether the array has the correct type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean fits (Object array)
  { return (array == null) || (array instanceof int[]); }

  /*------------------------------------------------------------------*/
  /** Get the number of values.
   *  @return the number of values
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getValueCount ()
  { return this.valmap.size(); }

  /*------------------------------------------------------------------*/
  /** Add a value, that is, adapt the range of values.
   *  @param  value the value to add
   *  @return a value that can be used efficiently with
   *          <code>setValueAt()</code>
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value)
  {                             /* --- add a nominal value */
    if (value == null) { this.curr = NULL; return null; }
    this.curr = this.valmap.add(value);
    return ColType.CURRENT;     /* add the value to the value map */
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Add a value, that is, adapt the range of values.
   *  @param  value the value to add
   *  @param  info  the additional information to store with the value
   *  @return a value that can be used efficiently with
   *          <code>setValueAt()</code>
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value, Object info)
  {                             /* --- add a nominal value */
    if (value == null) { this.curr = NULL; return null; }
    this.curr = this.valmap.add(value, info);
    return ColType.CURRENT;     /* add the value to the value map */
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Get the identifier of a value.
   *  @param  value the value as an object
   *  @return the identifier that is assigned to the value
   *          or <code>-1</code> if the value is not in the type
   *  @see    NominalType#getValueId(Object)
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int findValue (Object value)
  { return (value != null) ? this.valmap.get(value) : NULL; }

  /*------------------------------------------------------------------*/
  /** Get the identifier of a value.
   *  @param  value the value as an object
   *  @return the identifier that is assigned to the value or
   *          <code>-1</code> if the value is not in the type
   *  @see    NominalType#findValue(Object)
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getValueId (Object value)
  { return (value != null) ? this.valmap.get(value) : NULL; }

  /*------------------------------------------------------------------*/
  /** Get a value given its identifier.
   *  @param  id the identifier of the value
   *  @return the object that is associated with the identifier
   *  @throws ArrayIndexOutOfBoundsException
   *          if the identifier is outside the allowed range of
   *          0 to <code>getValueCount()-1</code>
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValue (int id)
  { return this.valmap.get(id); }

  /*------------------------------------------------------------------*/
  /** Clear the range of values.
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clear ()
  { this.valmap.clear(); this.curr = NULL; }

  /*------------------------------------------------------------------*/
  /** Replace a value by another.
   *  @param  id    the identifier of the value to replace
   *  @param  value the new value
   *  @return the identifier of the type, that is, <code>id</code> or
   *          <code>-1</code> if replacing would create a duplicate
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int replaceValue (int id, Object value)
  {                             /* --- replace a value */
    int i = this.valmap.get(value);
    if (i == id) return  i;     /* check whether the value */
    if (i >= 0)  return -1;     /* already exists in the type */
    this.valmap.replace(id, value);
    return id;                  /* otherwise replace the value */
  }  /* replaceValue() */

  /*------------------------------------------------------------------*/
  /** Remove a value.
   *  @param  id the identifier of the value to remove
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void removeValue (int id)
  { this.valmap.remove(id); }

  /*------------------------------------------------------------------*/
  /** Remove a value.
   *  @param  value the value to remove
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void removeValue (Object value)
  { this.valmap.remove(value); }

  /*------------------------------------------------------------------*/
  /** Move a value, that is, change its identifier.
   *  @param  src the old identifier of the value
   *  @param  dst the new identifier of the value
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void moveValue (int src, int dst)
  { this.valmap.move(src, dst); }

  /*------------------------------------------------------------------*/
  /** Reorder the values.
   *  <p>The desired reordering has to be stated as a permutation of
   *  the integer numbers 0 to <code>getValueCount()-1</code>, with
   *  each entry stating the new index for the value that is identified
   *  by the array index (forward map).</p>
   *  <p>If the reordering map is not such a permutation, the type
   *  will get into an inconsistent state that may lead to serious
   *  errors.</p>
   *  @param  map an integer array containing a permutation of the
   *              integer numbers 0 to <code>getColumnCount()-1</code>
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void reorderValues (int[] map)
  { this.valmap.reorder(map); }

  /*------------------------------------------------------------------*/
  /** Sort the values by their string representation.
   *  @return a map from the old indices (array indices)
   *          to the new indices (contents of array elements)
   *  @since  2007.07.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int[] sort ()
  {                             /* --- sort the values */
    return this.sort(new Comparator<Object> () {
      public int compare (Object o1, Object o2) {
        return o1.toString().compareTo(o2.toString()); } } );
  }  /* sort() */

  /*------------------------------------------------------------------*/
  /** Sort the values.
   *  @param  cmp the comparator for the values
   *  @return a map from the old indices (array indices)
   *          to the new indices (contents of array elements)
   *  @since  2007.07.25 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int[] sort (Comparator<Object> cmp)
  { return this.valmap.sort(cmp); }

  /*------------------------------------------------------------------*/
  /** Clear all additional information.
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clearInfo ()
  {                             /* --- clear all additional info. */
    for (int i = this.valmap.size(); --i >= 0; )
      this.valmap.setValue(i, null);
  }  /* clearInfo() */

  /*------------------------------------------------------------------*/
  /** Get the number of values with additional information.
   *  <p>Each value can be associated with additional information.</p>
   *  @return the number of values
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getInfoCount ()
  { return this.valmap.size(); }

  /*------------------------------------------------------------------*/
  /** Get the additional information for a value.
   *  @param  value the value for which
   *                to get the additional information
   *  @return the additional information associated with the identifier
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (Object value)
  { return this.valmap.getValue(value); }

  /*------------------------------------------------------------------*/
  /** Set the additional information for a value.
   *  @param  value the value to modify
   *  @param  info  the additional information to store
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (Object value, Object info)
  { this.valmap.setValue(value, info); }

  /*------------------------------------------------------------------*/
  /** Get the additional information for a value given its identifier.
   *  @param  id the identifier of the value
   *  @return the additional information associated with the identifier
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (int id)
  { return this.valmap.getValue(id); }

  /*------------------------------------------------------------------*/
  /** Set the additional information for a value given its identifier.
   *  @param  id   the identifier of the value
   *  @param  info the additional information to store
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (int id, Object info)
  { this.valmap.setValue(id, info); }

  /*------------------------------------------------------------------*/
  /** Get an array element as an object.
   *  @param  array an array of identifiers, i.e. <code>int[]</code>
   *  @param  index the index of the array element to access
   *  @return the value as an object
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (Object array, int index)
  { this.curr = ((int[])array)[index];
    return (this.curr > NULL) ? this.valmap.get(this.curr) : null; }

  /*------------------------------------------------------------------*/
  /** Set an array element from a string.
   *  @param  array an array of identifiers, i.e. <code>int[]</code>
   *  @param  index the index of the array element to set
   *  @param  value the value to set
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object array, int index, Object value)
  {                             /* --- set an array element */
    if (value != ColType.CURRENT) { /* get the value to set */
      this.curr = (value != null) ? this.valmap.get(value) : NULL; }
    ((int[])array)[index] = this.curr;
  }  /* setValueAt() */

  /*------------------------------------------------------------------*/
  /** Get an array element as a string.
   *  @param  array an array of identifiers, i.e. <code>int[]</code>
   *  @param  index the index of the array element to get
   *  @return the created string description
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (Object array, int index)
  {                             /* --- get array element as a string */
    int i = ((int[])array)[index];
    if (i <= NULL) return null; /* get the value identifier */
    return this.valmap.get(i).toString();
  }  /* getStringAt() */        /* return the value as a string */

  /*------------------------------------------------------------------*/
  /** Check whether an array element is null.
   *  @param  array an array of identifiers, i.e. <code>int[]</code>
   *  @param  index the index of the array element to check
   *  @return whether the array element is null
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isNull (Object array, int index)
  { return ((int[])array)[index] < 0; }

  /*------------------------------------------------------------------*/
  /** Set an array element to a null value.
   *  @param  array an array of identifiers, i.e. <code>int[]</code>
   *  @param  index the index of the array element to set
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int index)
  { ((int[])array)[index] = NULL; }

  /*------------------------------------------------------------------*/
  /** Parse an instance from a string.
   *  @param  desc the string description to parse
   *  @return the parsed nominal value (identical to the argument)
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object parseValue (String desc)
  { return desc; }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return a string description of the type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  {                             /* --- create a string description */
    int           i, n;         /* loop variables */
    StringBuilder s;            /* created string description */

    s = new StringBuilder("{ ");/* start with opening curly brace */
    for (n = this.valmap.size(), i = 0; i < n; i++) {
      if (i > 0) s.append(", ");/* traverse the nominal values */
      s.append(Scanner.format(this.valmap.get(i).toString(), false));
    }                           /* print separator and value */
    s.append(" }");             /* append closing curly brace */
    return s.toString();        /* return the created description */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Parse a type description.
   *  @param  scan the scanner to read from
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ColType parseType (Scanner scan) throws IOException
  {                             /* --- parse a type description */
    NominalType nom;            /* created nominal type */

    nom = new NominalType();    /* create a nominal type */
    scan.getChar('{');          /* check for '{' */
    if (scan.nextToken() == '}')
      return nom;               /* check for an empty value list */
    scan.pushBack();            /* push back the token read */
    while (true) {              /* value read loop */
      scan.getID();             /* check for an identifier */
      nom.addValue(scan.value); /* add the value read */
      if (scan.nextToken() == '}') break;
      else scan.pushBack();     /* check for end of value list */
      scan.getChar(',');        /* if not at end, check for ',' */
    }
    return nom;                 /* return the created type */
  }  /* parseType() */

}  /* class NominalType */
