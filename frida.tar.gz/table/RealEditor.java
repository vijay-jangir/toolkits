/*----------------------------------------------------------------------
  File    : RealEditor.java
  Contents: editor for the range of values of real-valued types
  Author  : Christian Borgelt
  History : 2007.07.17 file created
            2013.04.22 adapted to class name change Type -> ColType
----------------------------------------------------------------------*/
package table;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

/*--------------------------------------------------------------------*/
/** Class for an editor for the range of values of real-valued types.
 *  @author Christian Borgelt
 *  @since  2007.07.17 */
/*--------------------------------------------------------------------*/
public class RealEditor extends TypeEditor {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the input for the minimum value */
  private JTextField min = null;
  /** the input for the maximum value */
  private JTextField max = null;

  /*------------------------------------------------------------------*/
  /** Create a real range editor.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RealEditor ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create an real range editor.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RealEditor (ColType type)
  {                             /* --- create default type editor */
    this.addLabel("Minimum value:");
    this.min = this.addNumberInput(null);
    this.addLabel("Maximum value:");
    this.max = this.addNumberInput(null);
    this.addLabel("");          /* create range of value inputs */
    this.addButton("clear").addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        RealEditor ed = RealEditor.this;
        if (ed.type != null) ed.type.clear();
        ed.min.setText(""); ed.max.setText("");
      } } );                    /* create button for clearing */
    this.addFiller(0);          /* fill the editor pane */
    this.setType(type);         /* set the given type */
  }  /* RealEditor() */

  /*------------------------------------------------------------------*/
  /** Set the type to edit.
   *  @param  type the type to edit
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setType (ColType type)
  {                             /* --- set the type to edit */
    Object m;                   /* to access minimum and maximum */
    String s;                   /* to set the text fields */
    this.type = type;           /* note the type to edit */
    m = (type != null) ? ((RealType)type).getMin() : null;
    s = (m    != null) ? m.toString() : "";
    this.min.setText(s);        /* set the minimum value */
    m = (type != null) ? ((RealType)type).getMax() : null;
    s = (m != null) ? m.toString() : "";
    this.max.setText(s);        /* set the maximum value */
  }  /* setType() */

  /*------------------------------------------------------------------*/
  /** Get the edited type.
   *  @return the edited type
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColType getType ()
  {                             /* --- get the edited type */
    if (this.type == null) return null;
    this.type.clear();          /* set the edited range of values */
    this.type.addValue(this.min.getText());
    this.type.addValue(this.max.getText());
    return this.type;           /* return the created type */
  }  /* getType() */

}  /* RealEditor() */
