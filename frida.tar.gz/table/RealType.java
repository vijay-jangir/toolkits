/*----------------------------------------------------------------------
  File    : RealType.java
  Contents: Class for real-valued types for data tables
  Author  : Christian Borgelt
  History : 2006.09.11 file created
            2006.10.06 cloning added
            2007.01.31 functions isNull and setNull added
            2007.02.01 function getStringAt added
            2007.02.09 functions getNumberAt, getMin/MaxNumber added
            2007.02.13 function getName added
            2007.02.16 function parseType added
            2016.04.07 StringBuffer replaced by StringBuilder
            2019.03.31 fixed some deprecated functions etc.
----------------------------------------------------------------------*/
package table;

import java.io.IOException;

import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for real-valued types for data tables.
 *  @author Christian Borgelt
 *  @since  2006.09.11 */
/*--------------------------------------------------------------------*/
public class RealType extends MetricType {

  /*------------------------------------------------------------------*/
  /*  constants
  /*------------------------------------------------------------------*/
  /** a null value (of the storage class) */
  public static final double NULL = Double.NaN;

  /*------------------------------------------------------------------*/
  /*  instance variables
  /*------------------------------------------------------------------*/
  /** the current value of the type */
  private double curr;
  /** the minimal value */
  private double min;
  /** the minimal value as an object */
  private Double minobj;
  /** the maximal value */
  private double max;
  /** the minimal value as an object */
  private Double maxobj;

  /*------------------------------------------------------------------*/
  /** Create a real-valued type.
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RealType ()
  { this(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY); }

  /*------------------------------------------------------------------*/
  /** Create a real-valued type.
   *  @param  min the minimum value
   *  @param  max the maximum value
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RealType (double min, double max)
  {                             /* --- create a real-valued type */
    this.min    = min;          /* note the range of values and */
    this.max    = max;          /* clear the corresp. objects */
    this.minobj = this.maxobj = null;
    this.curr   = NULL;         /* clear the current value */
  }  /* RealType() */

  /*------------------------------------------------------------------*/
  /** Create a clone of a real-valued type.
   *  @param  t the real-valued type to clone
   *  @since  2006.11.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public RealType (RealType t)
  { this(t.min, t.max); }

  /*------------------------------------------------------------------*/
  /** Clone this type.
   *  @return a clone of this type
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone ()
  { return new RealType(this); }

  /*------------------------------------------------------------------*/
  /** Get the name of the type.
   *  @return the name of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return "real"; }

  /*------------------------------------------------------------------*/
  /** Get the class used to access values of this type, that is,
   *  <code>Double.class</code>.
   *  @return <code>Double.class</code>
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getValueClass ()
  { return Double.class; }

  /*------------------------------------------------------------------*/
  /** Get the class used to store values of this type, that is,
   *  <code>double.class</code>.
   *  @return <code>double.class</code>
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getStorageClass ()
  { return double.class; }

  /*------------------------------------------------------------------*/
  /** Check whether an array fits this type.
   *  <p>This function need not really be here, since the generic
   *  version in ColType.java yields the same result. However, this
   *  version is more efficient.</p>
   *  @return whether the array has the correct type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean fits (Object array)
  { return (array == null) || (array instanceof double[]); }

  /*------------------------------------------------------------------*/
  /** Add a value. The range of values is adapted.
   *  @param  value the value to add, must either be a
   *                <code>String<code> or a <code>Number</code>
   *  @return a value that can be used efficiently with
   *          <code>setValueAt()</code>
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value)
  {                             /* --- add a value from an object */
    if (value == null) {        /* check for a null value */
      this.curr = NULL; return null; }
    if      (value instanceof Number) {
      this.addValue(((Number)value).doubleValue());
      if (this.curr <= NULL) return null; }
    else if (value instanceof String)
      try { this.addValue(Double.parseDouble((String)value));
            if (this.curr <= NULL) return null; }
      catch (NumberFormatException nfe) {
        this.curr = NULL; return null; }
    else {                      /* get and set the given value */
      this.curr = NULL; return null; }
    return ColType.CURRENT;     /* return special object */
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Add a value. The range of values is adapted.
   *  @param  value the value to add
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addValue (double value)
  {                             /* --- add a value */
    this.curr = value;          /* note value and update range */
    if (value < this.min) this.min = value;
    if (value > this.max) this.max = value;
    this.minobj = this.maxobj = null;
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Clear the range of values.
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clear ()
  {                             /* --- clear the range of values */
    this.min    = Double.POSITIVE_INFINITY;
    this.max    = Double.NEGATIVE_INFINITY;
    this.minobj = this.maxobj = null;
    this.curr   = NULL;         /* clear the current value */
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMin ()
  {                             /* --- get the minimal value */
    if (this.min > this.max)    /* if the range is empty/unset, */
      return null;              /* abort the function */
    if (this.minobj == null)    /* create date if necessary */
      this.minobj = Double.valueOf(this.min);
    return this.minobj;         /* return the minimal value */
  }  /* getMin() */

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMax ()
  {                             /* --- get the minimal value */
    if (this.min > this.max)    /* if the range is empty/unset, */
      return null;              /* abort the function */
    if (this.maxobj == null)    /* create date if necessary */
      this.maxobj = Double.valueOf(this.max);
    return this.maxobj;         /* return the maximal value */
  }  /* getMax() */

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMinNumber ()
  { return this.min; }

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMaxNumber ()
  { return this.max; }

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMinRaw ()
  { return this.min; }

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMaxRaw ()
  { return this.max; }

  /*------------------------------------------------------------------*/
  /** Get an array element as an object.
   *  @param  array an array of double values,
   *                i.e., <code>double[]</code>
   *  @param  index the index of the array element to access
   *  @return the value as an object (of class <code>Double</code>)
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (Object array, int index)
  { this.curr = ((double[])array)[index];
    return Double.isNaN(this.curr) ? null : Double.valueOf(this.curr); }

  /*------------------------------------------------------------------*/
  /** Set an array element from an object.
   *  @param  array an array of real values, i.e. <code>double[]</code>
   *  @param  index the index of the array element to set
   *  @param  value the value to set, must either be a
   *                <code>String<code> or a <code>Number</code>
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object array, int index, Object value)
  {                             /* --- add a value from an object */
    if (value != ColType.CURRENT) { /* if not to use current value */
      if      (value instanceof Number)
         this.curr = ((Number)value).doubleValue();
      else if (value instanceof String)
        try { this.curr = Double.parseDouble((String)value); }
        catch (NumberFormatException nfe) { this.curr = NULL; }
      else this.curr = NULL;    /* get the value to set and */
    }                           /* store it in the array element */
    ((double[])array)[index] = this.curr;
  }  /* setValueAt() */

  /*------------------------------------------------------------------*/
  /** Describe an array element as a string.
   *  @param  array an array of real values, i.e. <code>double[]</code>
   *  @param  index the index of the array element to check
   *  @return the created string description
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (Object array, int index)
  {                             /* --- get array element as a string */
    double r = ((double[])array)[index];
    if (Double.isNaN(r)) return null;
    return String.valueOf(r);   /* get the value to describe */
  }  /* getStringAt() */        /* and turn it into a string */

  /*------------------------------------------------------------------*/
  /** Get an array element as a number.
   *  @return the array element as a number
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getNumberAt (Object array, int index)
  { return ((double[])array)[index]; }

  /*------------------------------------------------------------------*/
  /** Check whether an array element is null.
   *  @param  array an array of real values, i.e. <code>double[]</code>
   *  @param  index the index of the array element to check
   *  @return whether the array element is null
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isNull (Object array, int index)
  { return Double.isNaN(((double[])array)[index]); }

  /*------------------------------------------------------------------*/
  /** Set an array element to a null value.
   *  @param  array an array of real values, i.e. <code>double[]</code>
   *  @param  index the index of the array element to set
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int index)
  { ((double[])array)[index] = NULL; }

  /*------------------------------------------------------------------*/
  /** Set a range of array elements to a null value.
   *  @param  array an array of real values
   *  @param  beg   the index of the first array element (inclusive)
   *  @param  end   the index of the last  array element (exclusive)
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int beg, int end)
  { while (--end >= beg) ((double[])array)[end] = NULL; }

  /*------------------------------------------------------------------*/
  /** Parse a double value from a string.
   *  @param  desc the string description to parse
   *  @return the parsed double as a <code>Double</code> object
   *          or <code>null</code> if parsing failed
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object parseValue (String desc)
  { try { return Double.valueOf(desc); }
    catch (NumberFormatException nfe) { return null; } }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return a string description of the type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  {                             /* --- create a string description */
    if (this.min > this.max)    /* if the range is empty, */
      return "IR";              /* only return the type name */
    StringBuilder s = new StringBuilder("IR [");
    s.append(this.min); s.append(", ");
    s.append(this.max); s.append("]");
    return s.toString();        /* add the range of values */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Compare two real values.
   *  @param  a the first  value
   *  @param  b the second value
   *  @return -1 if the first  value is smaller,<br>
   *          +1 if the second value is smaller,<br>
   *          0  if the value are equal
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int compare (Object a, Object b)
  { return ((Double)a).compareTo((Double)b); }

  /*------------------------------------------------------------------*/
  /** Sum two values.
   *  @param  a the first  value
   *  @param  b the second value
   *  @return the sum of the two values
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object sum (Object a, Object b)
  { return Double.valueOf(((Double)a).doubleValue()
                        + ((Double)b).doubleValue()); }

  /*------------------------------------------------------------------*/
  /** Compute the difference of two values
   *  @param  a the value from which to subtract
   *  @param  b the value to subtract
   *  @return the difference of the two values
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object diff (Object a, Object b)
  { return Double.valueOf(((Double)a).doubleValue()
                        - ((Double)b).doubleValue()); }

  /*------------------------------------------------------------------*/
  /** Parse a type description.
   *  @param  scan the scanner to read from
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ColType parseType (Scanner scan) throws IOException
  {                             /* --- parse a type description */
    RealType type;              /* created type */

    if (( scan.nextToken() != Scanner.T_ID)
    ||  (!scan.value.equals("real") && scan.value.equals("float")
    &&   !scan.value.equals("R")    && scan.value.equals("IR")))
      throw new IOException("'real' expected instead of '"
                            +scan.value +"'" +scan.lno());
    type = new RealType();      /* create a real-valued type */
    if (scan.nextToken() != '[')/* if no range of values follows, */
      scan.pushBack();          /* push back the token */
    else {                      /* if a range of values follows, */
      scan.getNumber();         /* check for a number and get minimum */
      try { type.min = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) {
        throw new IOException("illegal number '" +scan.value +"'"
                              +scan.lno()); }
      scan.getChar(',');        /* check for ',' */
      scan.getNumber();         /* check for a number and get maximum */
      try { type.max = Double.parseDouble(scan.value); }
      catch (NumberFormatException e) {
        throw new IOException("illegal number '" +scan.value +"'"
                              +scan.lno()); }
      scan.getChar(']');        /* check for ']' */
    }
    return type;                /* return the created type */
  }  /* parseType() */

}  /* class RealType */
