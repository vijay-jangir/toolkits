/*----------------------------------------------------------------------
  File    : NominalEditor.java
  Contents: an editor for the values of nominal types
  Author  : Christian Borgelt
  History : 2007.07.17 file created
            2013.04.22 adapted to class name change Type -> ColType
----------------------------------------------------------------------*/
package table;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;
import javax.swing.ListSelectionModel;

/*--------------------------------------------------------------------*/
/** Class for a table of nominal values.
 *  @author Christian Borgelt
 *  @since  2007.06.11 */
/*--------------------------------------------------------------------*/
class ValueTable extends AbstractTableModel {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the type providing the values */
  private NominalType type = null;

  /*------------------------------------------------------------------*/
  /** Create a table of nominal values.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ValueTable ()
  { }

  /*------------------------------------------------------------------*/
  /** Create a table of nominal values.
   *  @param  type the type providing the nominal values
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ValueTable (NominalType type)
  { this.setValues(type); }

  /*------------------------------------------------------------------*/
  /** Set the nominal values.
   *  @param  type the type providing the nominal values
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValues (NominalType type)
  {                             /* --- set the nominal values */
    int o = this.getRowCount(); /* get the old and new number of rows */
    int n = (type != null) ? type.getValueCount() : 0;
    this.type = type;           /* store the new values */
    if (o > n) this.fireTableRowsDeleted (n, o-1);
    this.fireTableDataChanged();/* update the display */
    if (n > o) this.fireTableRowsInserted(o, n-1);
  }  /* setValues() */

  /*------------------------------------------------------------------*/
  /** Get the (possibly edited) nominal values (as a type).
   *  @return the (possibly edited) nominal values
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public NominalType getValues ()
  { return this.type; }

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.type != null) ? this.type.getValueCount() : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return always <code>1</code>
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return 1; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column given its index.
   *  @param  col the index of the column
   *  @return always the string <code>"Values"</code>
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int col)
  { return "Values"; }

  /*------------------------------------------------------------------*/
  /** Returns whether a table cell is editable.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return always <code>true</code>
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isCellEditable (int row, int col)
  { return true; }

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as an object.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return an object representing the value in the specified cell
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  { return this.type.getValue(row); }

  /*------------------------------------------------------------------*/
  /** Set the value of a table cell from an object.
   *  @param  value the value to set in the specified cell
   *  @param  row   the row    of the cell to set
   *  @param  col   the column of the cell to set
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object value, int row, int col)
  {                             /* --- set a table cell to a value */
    this.type.replaceValue(row, value);
    this.fireTableCellUpdated(row, col);
  }  /* setValueAt() */

  /*------------------------------------------------------------------*/
  /** Move a row.
   *  @param  row the index of the row to move
   *  @param  dst the destination index
   *  @return whether the row was moved
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean moveRow (int row, int dst)
  {                             /* --- move a row */
    int n = this.getRowCount(); /* check the row indices */
    if ((row < 0) || (row >= n) || (dst < 0) || (dst >= n))
      return false;             /* return that value was not moved */
    this.type.moveValue(row, dst);   /* move the value in the type */
    if (row <= dst) this.fireTableRowsUpdated(row, dst);
    else            this.fireTableRowsUpdated(dst, row);
    return true;                /* return the the row was moved */
  }  /* moveRow() */

  /*------------------------------------------------------------------*/
  /** Add a row.
   *  @return the index of the new row
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addRow ()
  {                             /* --- add a row */
    String name = "value";      /* get a default value name */
    for (int i = 1; this.type.findValue(name) >= 0; i++)
      name = "value_" +i;       /* make sure the name does not occur */
    this.type.addValue(name);   /* add the value to the type */
    int row = this.type.getValueCount() -1;
    this.fireTableRowsInserted(row, row);
    return row;                 /* return the index of the new row */
  }  /* addRow() */

  /*------------------------------------------------------------------*/
  /** Delete a row.
   *  @param  row the index of the row to delete
   *  @return the index of the next row to select
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int deleteRow (int row)
  {                             /* --- add a row */
    int n = this.getRowCount(); /* check the row index */
    if ((row < 0) || (row > --n)) return -1;
    this.type.removeValue(row); /* remove the value from the type */
    this.fireTableRowsDeleted(row, row);
    if (--n < 0) return -1;     /* check for remaining rows */
    return (row > n) ? n : row; /* return the index of the next row */
  }  /* deleteRow() */

}  /* ValueTable() */


/*--------------------------------------------------------------------*/
/** Class for an editor for the values of nominal types.
 *  @author Christian Borgelt
 *  @since  2007.07.17 */
/*--------------------------------------------------------------------*/
public class NominalEditor extends TypeEditor {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the table model for displaying the values */
  private ValueTable vals  = null;
  /** the table view for displaying the values */
  private JTable     table = null;

  /*------------------------------------------------------------------*/
  /** Create an editor for the values of nominal types.
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public NominalEditor ()
  { this(null); }

  /*------------------------------------------------------------------*/
  /** Create an editor for the values of nominal types.
   *  @param  type the nominal type to edit
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public NominalEditor (NominalType type)
  {                             /* --- create a nominal type editor */
    JPanel  bbar;               /* panel for buttons/tables */
    JButton button;             /* for buttons up/down/add/delete */

    this.vals  = new ValueTable(type);
    this.table = new JTable(this.vals);
    this.table.getTableHeader().setFont(TypeEditor.BOLD);
    this.table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    this.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
    this.setLayout(new BorderLayout());
    this.add(new JScrollPane(this.table), BorderLayout.CENTER);
    bbar = new JPanel(new GridLayout(1, 4, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    bbar.add(button = new JButton("Up"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        NominalEditor ed = NominalEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.table.getSelectedRow();
        if (ed.vals.moveRow(row, row-1))
          ed.table.setRowSelectionInterval(row-1,row-1);
      } } );
    bbar.add(button = new JButton("Down"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        NominalEditor ed = NominalEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.table.getSelectedRow();
        if (ed.vals.moveRow(row, row+1))
          ed.table.setRowSelectionInterval(row+1, row+1);
      } } );
    bbar.add(button = new JButton("Add"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        NominalEditor ed = NominalEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.vals.addRow();
        ed.table.setRowSelectionInterval(row, row);
      } } );
    bbar.add(button = new JButton("Delete"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        NominalEditor ed = NominalEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.table.getSelectedRow();
        row = ed.vals.deleteRow(row);
        if (row >= 0) ed.table.setRowSelectionInterval(row, row);
      } } );
    this.add(bbar, BorderLayout.SOUTH);
    this.table.setPreferredScrollableViewportSize(
      this.table.getPreferredSize());
  }  /* NominalEditor() */

  /*------------------------------------------------------------------*/
  /** Set the nominal type to edit.
   *  @param  type the nominal type to edit
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setType (ColType type)
  {                             /* --- set the type to edit */
    this.vals.setValues((NominalType)type);
    Dimension size = this.table.getPreferredSize();
    if (size.height > 400) size.height = 400;
    this.table.setPreferredScrollableViewportSize(size);
    if (this.vals.getRowCount() > 0)
      this.table.setRowSelectionInterval(0, 0);
  }  /* setType() */

  /*------------------------------------------------------------------*/
  /** Get the edited nominal type.
   *  @return the edited nominal type
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColType getType ()
  { return this.vals.getValues(); }

}  /* NominalEditor() */
