/*----------------------------------------------------------------------
  File    : DomainsEditor.java
  Contents: editor for attribute domains
  Author  : Christian Borgelt
  History : 2007.06.07 file created
            2007.07.24 first version completed
            2013.04.22 adapted to type argument of JComboBox
            2013.04.22 adapted to class name change Type -> ColType
            2014.10.23 changed from LGPL license to MIT license
            2019.03.31 fixed some deprecated functions etc.
----------------------------------------------------------------------*/
package table;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.ListSelectionModel;
import javax.swing.DefaultCellEditor;
import javax.swing.table.AbstractTableModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

import util.IdMap;
import util.Scanner;
import dialog.DialogPanel;
import dialog.AboutDialog;
import dialog.MiniEditor;

/*--------------------------------------------------------------------*/
/** Class for a table of attribute domains.
 *  @author Christian Borgelt
 *  @since  2007.06.07 */
/*--------------------------------------------------------------------*/
class AttTable extends AbstractTableModel {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00010000L;
  /** the names of the columns */
  protected static final String[] names = {
    "Name", "Type", "Direction", "Weight" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the containing domain editor */
  private DomainsEditor ed    = null;
  /** the number of columns */
  private int           cnt   = 0;
  /** the domains of the attributes as a table */
  private Table         atts  = null;
  /** the created types */
  private ColType[][]   types = null;

  /*------------------------------------------------------------------*/
  /** Create a table of attribute domains.
   *  @param  ed the containing domain editor
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public AttTable (DomainsEditor ed)
  { this(ed, AttTable.names.length); }

  /*------------------------------------------------------------------*/
  /** Create a table of attribute domains.
   *  @param  ed  the containing domain editor
   *  @param  cnt the number of columns (properties)
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public AttTable (DomainsEditor ed, int cnt)
  { this.ed = ed; this.cnt = cnt; }

  /*------------------------------------------------------------------*/
  /** Set the domains to edit.
   *  @param  atts the domains to edit as a table
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomains (Table atts)
  {                             /* --- set the domains */
    int o = this.getRowCount(); /* get the old and new number of rows */
    int n = (atts != null) ? atts.getColumnCount() : 0;
    this.atts  = atts;          /* store the new domains and */
    this.types = new ColType[n][];    /* create a type table */
    if (o > n) this.fireTableRowsDeleted (n, o-1);
    this.fireTableDataChanged();/* update the display */
    if (n > o) this.fireTableRowsInserted(o, n-1);
  }  /* setDomains() */

  /*------------------------------------------------------------------*/
  /** Get the (possibly edited) domains.
   *  @return the (possibly edited) domains
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getDomains ()
  { return this.atts; }

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the table.
   *  @return the number of rows of the table
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.atts != null) ? this.atts.getColumnCount() : 0; }

  /*------------------------------------------------------------------*/
  /** Get the number of columns of the table.
   *  @return the number of columns of the table
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getColumnCount ()
  { return this.cnt; }

  /*------------------------------------------------------------------*/
  /** Get the name of a column given its index.
   *  @param  col the index of the column
   *  @return the name of the column with the given index
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getColumnName (int col)
  { return AttTable.names[col]; }

  /*------------------------------------------------------------------*/
  /** Returns whether a table cell is editable.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return always <code>true</code>
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isCellEditable (int row, int col)
  { return true; }

  /*------------------------------------------------------------------*/
  /** Get the value of a table cell as an object.
   *  @param  row the row    of the cell to access
   *  @param  col the column of the cell to access
   *  @return an object representing the value in the specified cell
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row, int col)
  {                             /* --- get contents of a table cell */
    switch (col) {              /* evaluate the column index */
      case 0: return this.atts.getColumnName(row);
      case 1: return this.atts.getColumnType(row).getName();
      case 2: return Column.getDirName(this.atts.getColumnDir(row));
      case 3: return Double.valueOf(this.atts.getColumnWeight(row));
    }                           /* return the name, type, or dir. */
    return null;                /* no value for other columns */
  }  /* getValueAt() */

  /*------------------------------------------------------------------*/
  /** Set the value of a table cell from an object.
   *  @param  value the value to set in the specified cell
   *  @param  row   the row    of the cell to set
   *  @param  col   the column of the cell to set
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object value, int row, int col)
  {                             /* --- set contents of a table cell */
    String s = value.toString();/* get the value to set as a string */
    if      (col <= 0) {        /* rename a column */
      this.atts.renameColumn(row, s); }
    else if (col == 2) {        /* set the direction of a column */
      this.atts.setColumnDir(row, Column.getDirId(s)); }
    else if (col >= 3) {        /* set the weight of a column */
      double wgt;               /* parse the weight to set */
      try { wgt = Double.parseDouble(s); }
      catch (NumberFormatException e) { wgt = 1.0; }
      this.atts.setColumnWeight(row, wgt); }
    else {                      /* set the type of a column */
      Column    c   = this.atts.getColumn(row);
      ColType   t   = c.getType(); /* get the current column type */
      int       i   = ColType.getTypeId(t);
      ColType[] buf = this.types[row];
      if      (buf == null)     /* if there are no stored types */
        this.types[row] = new ColType[i+1];
      else if (buf.length <= i){/* if there is not enough space */
        this.types[row] = new ColType[i+1];
        System.arraycopy(buf, 0, this.types[row], 0, buf.length);
      }                         /* create a new type array */
      this.types[row][i] = t;   /* store the current column type */
      i = ColType.getTypeId(s); /* get the new type identifier */
      t = null;                 /* clear the type buffer */
      if (this.types[row].length > i)
        t = this.types[row][i]; /* get the type from the type table */
      if (t == null) {          /* if the type does not exist */
        try { t = (ColType)ColType.getTypeClass(i)
                  .getConstructor().newInstance(); }
        catch (IllegalAccessException    e) { }
        catch (InstantiationException    e) { }
        catch (NoSuchMethodException     e) { }
        catch (InvocationTargetException e) { }
      }                         /* create the new type */
      c.setType(t);             /* set the new column type */
      this.ed.setAtt(-1);       /* and update the type editor */
    }                           /* afterwards update the display */
    this.fireTableCellUpdated(row, col);
  }  /* setValueAt() */

  /*------------------------------------------------------------------*/
  /** Get the type of an attribute.
   *  @param  row the index of the row of the attribute
   *  @return the type of the attribute in the given row
   *  @since  2007.07.23 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColType getType (int row)
  { return this.atts.getColumnType(row); }

  /*------------------------------------------------------------------*/
  /** Move a row.
   *  @param  row the index of the row to move
   *  @param  dst the destination index
   *  @return whether the row was moved
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean moveRow (int row, int dst)
  {                             /* --- move a row */
    int n = this.getRowCount(); /* check the row indices */
    if ((row < 0) || (row >= n) || (dst < 0) || (dst >= n))
      return false;             /* return that attrib. was not moved */
    this.atts.moveColumn(row, dst);    /* move the att. in the table */
    if (row <= dst) this.fireTableRowsUpdated(row, dst);
    else            this.fireTableRowsUpdated(dst, row);
    return true;                /* return the the row was moved */
  }  /* moveRow() */

  /*------------------------------------------------------------------*/
  /** Add a row.
   *  @return the index of the new row
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int addRow ()
  {                             /* --- add a row */
    int         n   = this.atts.getColumnCount();
    ColType[][] buf = this.types;  /* get the current type table */
    if ((buf == null) || (buf.length <= n)) {
      this.types = new ColType[n +(n >> 1)][];
      if (buf != null) System.arraycopy(buf, 0, this.types, 0, n);
    }                           /* enlarge the type table */
    String name = "attribute";  /* get a default attribute name */
    for (int i = 1; this.atts.findColumn(name) >= 0; i++)
      name = "attribute_" +i;   /* make sure the name does not occur */
    this.atts.addColumn(name, new NominalType());
                                /* add an attribute to the table */
    this.fireTableRowsInserted(n, n);
    return n;                   /* return the index of the new row */
  }  /* addRow() */

  /*------------------------------------------------------------------*/
  /** Delete a row.
   *  @param  row the index of the row to delete
   *  @return the index of the next row to select
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int deleteRow (int row)
  {                             /* --- add a row */
    int n = this.getRowCount(); /* check the row index */
    if ((row < 0) || (row > --n)) return -1;
    this.atts.removeColumn(row);/* remove the att. from the table */
    this.fireTableRowsDeleted(row, row);
    if (--n < 0) return -1;     /* check for remaining rows */
    return (row > n) ? n : row; /* return the index of the next row */
  }  /* deleteRow() */

}  /* AttTable() */


/*--------------------------------------------------------------------*/
/** Class for a domain editor.
 *  @author Christian Borgelt
 *  @since  2007.06.07 */
/*--------------------------------------------------------------------*/
public class DomainsEditor extends JFrame implements Runnable {

  private static final long serialVersionUID = 0x00010003L;
  public  static final String VERSION = "1.3 (2014.10.23)";

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** mode flag: the viewer is a stand-alone program */
  public final static int PROGRAM = 1;
  /** mode flag: show direction column */
  public final static int DIRS    = 2;
  /** mode flag: show weight column */
  public final static int WEIGHTS = 4;

  /*------------------------------------------------------------------*/
  /*  class variables                                                 */
  /*------------------------------------------------------------------*/
  /** the map for the type editors */
  private static final IdMap      map     = new IdMap();
  /** the default type editor */
  private static final TypeEditor DEFAULT = new DefaultEditor();

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the owner of this domain editor */
  private Component    owner   = null;
  /** the mode flags */
  private int          mode    = 0;
  /** the main panel */
  private JPanel       main    = null;
  /** the attribute domains to edit */
  private AttTable     atts    = null;
  /** the table view for displaying the attributes */
  private JTable       table   = null;
  /** the identifier of the current attribute */
  private int          attid   = 0;
  /** the editors for the different types */
  private TypeEditor[] editors = null;
  /** the current type editor */
  private TypeEditor   ed      = null;
  /** the status bar for messages */
  private JTextField   stat    = null;
  /** the file chooser */
  private JFileChooser chooser = null;
  /** the "About..." dialog box */
  private AboutDialog  about   = null;
  /** the current domains file */
  private File         curr    = null;

  /*------------------------------------------------------------------*/
  /*  class initialization code                                       */
  /*------------------------------------------------------------------*/

  static {                      /* --- initialize the class */
    DomainsEditor.map.add("nominal", NominalEditor.class);
    DomainsEditor.map.add("integer", IntegerEditor.class);
    DomainsEditor.map.add("real",    RealEditor.class);
    DomainsEditor.map.add("date",    null);
    DomainsEditor.map.add("string",  null);
  }                             /* register all standard types */

  /*------------------------------------------------------------------*/
  /** Add a type editor, that is, register it.
   *  @return whether the type was registered
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static boolean addTypeEditor (String name, Class<?> cls)
  {                             /* --- add a type editor */
    if (DomainsEditor.map.get(name) >= 0) return false;
    DomainsEditor.map.add(name, cls);     return true;
  }  /* addTypeEditor() */

  /*------------------------------------------------------------------*/
  /** Get a type editor.
   *  @param  type the type for which to get an editor
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TypeEditor getTypeEditor (ColType type)
  { return DomainsEditor.getTypeEditor(type.getName()); }

  /*------------------------------------------------------------------*/
  /** Get a type editor.
   *  @param  name the name of the type
   *  @since  2007.07.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static TypeEditor getTypeEditor (String name)
  {                             /* --- get a type editor */
    Class<?> cls = (Class<?>)DomainsEditor.map.getValue(name);
    if (cls == null) return DomainsEditor.DEFAULT;
    try { return (TypeEditor)cls.getConstructor().newInstance(); }
    catch (InstantiationException    e) { return null; }
    catch (IllegalAccessException    e) { return null; }
    catch (NoSuchMethodException     e) { return null; }
    catch (InvocationTargetException e) { return null; }
  }  /* getTypeEditor() */

  /*------------------------------------------------------------------*/
  /** Create a domain editor.
   *  @param  mode the mode flags
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsEditor (int mode)
  { this(null, mode); }

  /*------------------------------------------------------------------*/
  /** Create a domain editor.
   *  @param  owner the component that is to own this viewer
   *  @param  mode  the mode flags
   *  @since  2004.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public DomainsEditor (Component owner, int mode)
  {                             /* --- create a domain editor */
    this.owner = owner;         /* note the owner */
    this.mode  = mode;          /* and the mode flags */
    if (EventQueue.isDispatchThread()) { this.run(); return; }
    try { EventQueue.invokeAndWait(this); }
    catch (Exception e) {}      /* create the user interface */
  }  /* DomainsEditor() */

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2006.07.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create the user interface */
    int       n;                /* number of columns */
    Container content;          /* content pane of this frame */
    JMenuBar  mbar;             /* menu bar */
    JMenu     menu;             /* to create menu titles */
    JMenuItem item;             /* to create menu items */
    JPanel    attsel;           /* panel for attribute selector */
    JPanel    bbar;             /* panel for buttons/tables */
    JButton   button;           /* for buttons up/down/add/delete */
    String[]  types;            /* type names */
    String[]  dirs;             /* direction names */
    DefaultCellEditor ce;       /* cell editor for types and dirs */

    /* --- configure and show the frame window --- */
    this.setTitle("DomainsEditor");
    this.setDefaultCloseOperation(((this.mode & PROGRAM) != 0)
      ? JFrame.EXIT_ON_CLOSE : JFrame.HIDE_ON_CLOSE);
    if (this.owner == null) this.setLocation(48, 48);
    else                    this.setLocationRelativeTo(this.owner);

    /* --- create and set the menu bar --- */
    this.setJMenuBar(mbar = new JMenuBar());

    menu = mbar.add(new JMenu("File"));
    menu.setMnemonic('f');
    item = menu.add(new JMenuItem("Load Domains...", 'l'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor.this.loadDomains(null); } } );
    item = menu.add(new JMenuItem("Reload Domains", 'r'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor.this.loadDomains(DomainsEditor.this.curr); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Save Domains", 's'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor.this.saveDomains(DomainsEditor.this.curr); } } );
    item = menu.add(new JMenuItem("Save Domains as...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor.this.saveDomains(null); } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Edit as Text...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        MiniEditor ed = new MiniEditor(0);
        ed.loadText(DomainsEditor.this.curr);
        ed.setVisible(true);
      } } );
    menu.addSeparator();
    item = menu.add(new JMenuItem("Quit", 'q'));
    if ((this.mode & PROGRAM) != 0) { /* if stand-alone program */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          System.exit(0); } } ); }     /* terminate the program */
    else {                      /* if only visualization module */
      item.addActionListener(new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          DomainsEditor.this.setVisible(false); } } );
    }                           /* close the window */

    menu = mbar.add(new JMenu("Help"));
    menu.setMnemonic('h');
    item = menu.add(new JMenuItem("About...", 'a'));
    item.addActionListener(new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        if (DomainsEditor.this.about == null)
          DomainsEditor.this.about = new AboutDialog(DomainsEditor.this,
             "About DomainsEditor...", "DomainsEditor\n"
            +"A Simple Domains Editor\n"
            +"Version " +DomainsEditor.VERSION +"\n\n"
            +"written by Christian Borgelt\n"
            +"European Center for Soft Computing\n"
            +"c/ Gonzalo Gutierrez Quiros s/n\n"
            +"33600 Mieres, Asturias, Spain\n"
            +"christian@borgelt.net");
        DomainsEditor.this.about.setVisible(true);
        DomainsEditor.this.about.toFront();
      } } );

    /* --- create and set the main panel --- */
    dirs  = Column.getAllDirNames(3);
    types = ColType.getAllTypeNames(3);
    this.editors = new TypeEditor[types.length];
    for (int i = 0; i < types.length; i++)
      this.editors[i] = DomainsEditor.getTypeEditor(types[i]);
    if      ((this.mode & WEIGHTS) != 0) n = 4;
    else if ((this.mode & DIRS)    != 0) n = 3;
    else                                 n = 2;
    this.atts  = new AttTable(this, n);
    this.table = new JTable(this.atts);
    this.table.getTableHeader().setFont(DialogPanel.BOLD);
    this.table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    if (n > 1) {                /* set the editor for types */
      ce = new DefaultCellEditor(new JComboBox<String>(types));
      this.table.getColumn(AttTable.names[1]).setCellEditor(ce);
    }
    if (n > 2) {                /* set the editor for directions */
      ce = new DefaultCellEditor(new JComboBox<String>(dirs));
      this.table.getColumn(AttTable.names[2]).setCellEditor(ce);
    }
    this.table.getSelectionModel().addListSelectionListener(
      new ListSelectionListener () {
      public void valueChanged (ListSelectionEvent e) {
        DomainsEditor de  = DomainsEditor.this;
        int          row = de.table.getSelectedRow();
        if ((row < 0) || (row == de.attid)) return;
        de.setAtt(row);         /* set the listener for a type change */
      } } );                    /* (update the type editor) */

    attsel = new JPanel(new BorderLayout());
    attsel.add(new JScrollPane(this.table), BorderLayout.CENTER);
    bbar = new JPanel(new GridLayout(1, 4, 4, 4));
    bbar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    bbar.add(button = new JButton("Up"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor ed = DomainsEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.table.getSelectedRow();
        if (ed.atts.moveRow(row, row-1))
          ed.table.setRowSelectionInterval(row-1,row-1);
      } } );
    bbar.add(button = new JButton("Down"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor ed = DomainsEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.table.getSelectedRow();
        if (ed.atts.moveRow(row, row+1))
          ed.table.setRowSelectionInterval(row+1, row+1);
      } } );
    bbar.add(button = new JButton("Add"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor ed = DomainsEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.atts.addRow();
        ed.table.setRowSelectionInterval(row, row);
      } } );
    bbar.add(button = new JButton("Delete"));
    button.addActionListener(new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        DomainsEditor ed = DomainsEditor.this;
        if (ed.table.isEditing()) return;
        int row = ed.table.getSelectedRow();
        row = ed.atts.deleteRow(row);
        if (row >= 0) ed.table.setRowSelectionInterval(row, row);
      } } );
    attsel.add(bbar, BorderLayout.SOUTH);

    this.main = new JPanel(new GridLayout(1, 2, 4, 0));
    this.main.add(attsel);
    this.main.add(this.ed = DomainsEditor.DEFAULT);
    content = this.getContentPane();
    content.setLayout(new BorderLayout());
    content.add(this.main, BorderLayout.CENTER);

    /* --- create and set a status bar --- */
    this.stat = new JTextField();
    this.stat.setEditable(false);
    content.add(this.stat, BorderLayout.SOUTH);

    this.pack();                /* configure the frame */
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the attribute selector dialog box (create if necessary).
   *  @return the attribute selector dialog box
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private JFileChooser getFileChooser ()
  {                             /* --- get the file chooser */
    if (this.chooser != null)   /* if the chooser already exists, */
      return this.chooser;      /* simply return it */
    this.chooser = new JFileChooser();
    this.chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    this.chooser.setCurrentDirectory(new File("."));
    this.chooser.setFileHidingEnabled(true);
    this.chooser.setAcceptAllFileFilterUsed(true);
    this.chooser.setMultiSelectionEnabled(false);
    this.chooser.setFileView(null);
    return this.chooser;        /* create and configure the chooser */
  }  /* getFileChooser() */

  /*------------------------------------------------------------------*/
  /** Set the message to display in the status line.
   *  @param  msg the message to display in the status line
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMessage (String msg)
  { this.stat.setText(msg); }

  /*------------------------------------------------------------------*/
  /** Set the attribute to edit.
   *  @param  id the identifier of the attribute to edit
   *  @since  2007.07.21 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setAtt (int id)
  {                             /* --- set the attribute to edit */
    this.main.remove(1);        /* remove the value editor */
    if (id < 0) id = this.attid;
    this.attid = id;            /* store the attribute identifier */
    if ((id < 0) || (this.atts == null)
    ||  (id >= this.atts.getRowCount()))
      this.ed = DomainsEditor.DEFAULT;
    else {                      /* check for a valid attribute id */
      this.table.setRowSelectionInterval(id, id);
      ColType t = this.atts.getType(id);
      this.ed   = this.editors[ColType.getTypeId(t)];
      this.ed.setType(t);       /* get the proper type editor */
    }                           /* and set the attribute to edit */
    this.main.add(this.ed);     /* add the type editor */
    this.pack();                /* adapt size and repack components */
    this.ed.repaint();          /* repaint the type editor */
  }  /* setAtt() */

  /*------------------------------------------------------------------*/
  /** Set the attribute domains to edit.
   *  @param  atts the attribute domains to edit as a table
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomains (Table atts)
  {                             /* --- set the domains to edit */
    ((AttTable)this.table.getModel()).setDomains(atts);
    if (atts != null)           /* set the given domains */
      this.stat.setText(atts.getName());
    this.table.setPreferredScrollableViewportSize(
      this.table.getPreferredSize());
    this.setAtt(0);             /* set the initial attribute */
  }  /* setDomains() */

  /*------------------------------------------------------------------*/
  /** Get the edited attribute domains.
   *  @return the edited attribute domains as a table
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Table getDomains ()
  { return this.atts.getDomains(); }

  /*------------------------------------------------------------------*/
  /** Report an I/O error.
   *  @param  msg the error message to report
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void reportError (String msg)
  {                             /* --- report an i/o error */
    this.stat.setText(msg);     /* set message in status bar, */
    System.err.println();       /* print message to stderr, */
    System.err.println(msg);    /* and show alert dialog box */
    JOptionPane.showMessageDialog(this, msg,
      "Error", JOptionPane.ERROR_MESSAGE);
  }  /* reportError() */

  /*------------------------------------------------------------------*/
  /** Load the attribute domains to edit.
   *  @param  file the file to load the domains from
   *  @return whether the file was successfully loaded
   *  @since  2005.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean loadDomains (File file)
  {                             /* --- load attribute domains */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a scanner for the file */
      System.err.print("reading " +file +" ... ");
      Scanner scan = new Scanner(new FileReader(file));
      Table   tab  = Table.parse(file.getPath(), scan);
      if (tab.getColumnCount() <= 0)
        throw new IOException(file +":\nno domain descriptions found");
      scan.close();             /* load the attribute domains */
      this.setDomains(tab);     /* and set it for editing */
      System.err.print("[" +tab.getColumnCount());
      System.err.println(" attribute(s)] done."); }
    catch (IOException e) {     /* catch and report i/o errors */
      this.reportError(e.getMessage()); return false; }
    this.curr = file;           /* note the new file name */
    return true;                /* return 'loading successful' */
  }  /* loadDomains() */

  /*------------------------------------------------------------------*/
  /** Save the displayed attribute domains.
   *  @param  file the file to save the domains to
   *  @return whether the file was successfully written
   *  @since  2005.05.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean saveDomains (File file)
  {                             /* --- save attribute domains */
    if (file == null) {         /* if no file name is given */
      int r = this.getFileChooser().showSaveDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return false;
      file = this.chooser.getSelectedFile();
    }                           /* get a selected file */
    try {                       /* create a writer for the file */
      System.err.print("writing " +file +" ... ");
      Table tab = this.getDomains();
      if (tab == null) return false;
      FileWriter writer = new FileWriter(file);
      writer.write(tab.toString());
      writer.close();           /* write the attribute domains */
      System.err.print("[" +tab.getColumnCount());
      System.err.println(" attribute(s)] done."); }
    catch (IOException e) {     /* catch and report i/o errors */
      this.reportError(e.getMessage()); return false; }
    this.stat.setText(file.getName());
    this.curr = file;           /* note the new file name */
    return true;                /* return 'saving successful' */
  }  /* saveDomains() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    DomainsEditor de = new DomainsEditor(PROGRAM);
    if (args.length > 0) de.loadDomains(new File(args[0]));
    de.setVisible(true);        /* create and show a domain editor */
  }  /* main() */

}  /* class DomainsEditor */
