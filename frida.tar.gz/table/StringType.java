/*----------------------------------------------------------------------
  File    : StringType.java
  Contents: Class for string types for data tables
  Author  : Christian Borgelt
  History : 2007.02.13 file created
            2007.02.16 function parseType added
            2013.04.22 adapted to class name change Type -> ColType
----------------------------------------------------------------------*/
package table;

import java.io.IOException;

import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for string types for data tables.
 *  <p>A string type is similar to a nominal type. However, the values
 *  are not recoded to integers for storing, but stored directly, that
 *  is, they are stored as strings.</p>
 *  @author Christian Borgelt
 *  @since  2007.02.13 */
/*--------------------------------------------------------------------*/
public class StringType extends ColType {

  /*------------------------------------------------------------------*/
  /*  constants
  /*------------------------------------------------------------------*/
  /** a null value (of the storage class) */
  public static final String NULL = null;

  /*------------------------------------------------------------------*/
  /*  instance variables
  /*------------------------------------------------------------------*/
  /** the current value of the type */
  private String curr;

  /*------------------------------------------------------------------*/
  /** Create a string type.
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public StringType ()
  { this.curr = NULL; }

  /*------------------------------------------------------------------*/
  /** Create a clone of a string type.
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public StringType (StringType t)
  { this.curr = t.curr; }

  /*------------------------------------------------------------------*/
  /** Clone this type.
   *  @return a clone of this type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone ()
  { return new StringType(this); }

  /*------------------------------------------------------------------*/
  /** Get the name of the type.
   *  @return the name of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return "string"; }

  /*------------------------------------------------------------------*/
  /** Get the class used to access values of this type.
   *  @return the class used for accessing values of this type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getValueClass ()
  { return String.class; }

  /*------------------------------------------------------------------*/
  /** Get the class used to store values of this type.
   *  @return the class used for storing values of this type
   *  @see    ColType#setValueAt(Object,int,Object)
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getStorageClass ()
  { return String.class; }

  /*------------------------------------------------------------------*/
  /** Check whether an array fits this type.
   *  <p>This function need not really be here, since the generic
   *  version in ColType.java yields the same result. However, this
   *  version is more efficient.</p>
   *  @return whether the array has the storage type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean fits (Object array)
  { return (array == null) || (array instanceof String[]); }

  /*------------------------------------------------------------------*/
  /** Add a value, that is, adapt the range of values.
   *  @param  value the value to add
   *  @return a value that can be used efficiently with
   *          <code>setValueAt()</code>
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value)
  { return value; }

  /*------------------------------------------------------------------*/
  /** Clear the range of values.
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clear ()
  { this.curr = NULL; }

  /*------------------------------------------------------------------*/
  /** Get an array element as an object.
   *  @param  array an array of string values,
   *                i.e. <code>String[]</code>
   *  @param  index the index of the array element to access
   *  @return the value as an object
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (Object array, int index)
  { return ((String[])array)[index]; }

  /*------------------------------------------------------------------*/
  /** Set an array element from an object.
   *  @param  array an array of string values,
   *                i.e. <code>String[]</code>
   *  @param  index the index of the array element to set
   *  @param  value the value to set
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object array, int index, Object value)
  { ((String[])array)[index] = (String)value; }

  /*------------------------------------------------------------------*/
  /** Get an array element as a string.
   *  @param  array an array of string values,
   *                i.e. <code>String[]</code>
   *  @param  index the index of the array element to access
   *  @return the created string description
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (Object array, int index)
  { return ((String[])array)[index]; }

  /*------------------------------------------------------------------*/
  /** Check whether an array element is null.
   *  @param  array an array of string values,
   *                i.e. <code>String[]</code>
   *  @param  index the index of the array element to check
   *  @return whether the array element is null
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isNull (Object array, int index)
  { return ((String[])array)[index] == null; }

  /*------------------------------------------------------------------*/
  /** Set an array element to a null value.
   *  @param  array an array of string values,
   *                i.e. <code>String[]</code>
   *  @param  index the index of the array element to set
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int index)
  { ((String[])array)[index] = null; }

  /*------------------------------------------------------------------*/
  /** Set a range of array elements to a null value.
   *  @param  array an array of string values
   *  @param  beg   the index of the first array element (inclusive)
   *  @param  end   the index of the last  array element (exclusive)
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int beg, int end)
  { while (--end >= beg) ((String[])array)[end] = null; }

  /*------------------------------------------------------------------*/
  /** Parse a value from a string.
   *  @param  desc the string description to parse
   *  @return the parsed object or <code>null</code> if parsing failed
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object parseValue (String desc)
  { return desc; }

  /*------------------------------------------------------------------*/
  /** Parse a type description.
   *  @param  scan the scanner to read from
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ColType parseType (Scanner scan) throws IOException
  {                             /* --- parse a type description */
    scan.getID();               /* check for an identifier */
    if (!scan.value.equals("string") && !scan.value.equals("S"))
      throw new IOException("'string' expected instead of '"
                            +scan.value +"'" +scan.lno());
    return new StringType();    /* create and return a string type */
  }  /* parseType() */

}  /* class StringType */
