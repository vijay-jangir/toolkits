/*----------------------------------------------------------------------
  File    : IntegerType.java
  Contents: Class for integer types for data tables
  Author  : Christian Borgelt
  History : 2006.09.11 file created
            2006.10.06 cloning added
            2007.01.31 functions isNull and setNull added
            2007.02.01 function getStringAt added
            2007.02.09 functions getNumberAt, getMin/MaxNumber added
            2007.02.13 function getName added
            2007.02.16 function parseType added
            2013.04.22 adapted to class name change Type -> ColType
            2016.04.07 StringBuffer replaced by StringBuilder
            2019.03.31 fixed some deprecated functions etc.
----------------------------------------------------------------------*/
package table;

import java.io.IOException;

import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for integer types for data tables.
 *  @author Christian Borgelt
 *  @since  2006.09.11 */
/*--------------------------------------------------------------------*/
public class IntegerType extends MetricType {

  /*------------------------------------------------------------------*/
  /*  constants
  /*------------------------------------------------------------------*/
  /** a null value (of the storage class) */
  public static final int NULL = Integer.MIN_VALUE;

  /*------------------------------------------------------------------*/
  /*  instance variables
  /*------------------------------------------------------------------*/
  /** the current value of the type */
  private int     curr;
  /** the minimal value */
  private int     min;
  /** the minimal value as an object */
  private Integer minobj;
  /** the maximal value */
  private int     max;
  /** the minimal value as an object */
  private Integer maxobj;

  /*------------------------------------------------------------------*/
  /** Create an integer type.
   *  The range of values is set empty (<code>max &lt; min</code>).
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public IntegerType ()
  { this(Integer.MAX_VALUE, Integer.MIN_VALUE+1); }

  /*------------------------------------------------------------------*/
  /** Create an integer type.
   *  @param  min  the minimum attribute value
   *  @param  max  the maximum attribute value
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public IntegerType (int min, int max)
  {                             /* --- create an integer type */
    this.max    = max;          /* note the range of values */
    this.min    = (min > NULL) ? min : NULL+1;
    this.minobj = this.maxobj = null;
    this.curr   = NULL;         /* clear the current value */
  }  /* IntegerType() */

  /*------------------------------------------------------------------*/
  /** Create a clone of an integer type.
   *  @since  2006.11.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public IntegerType (IntegerType t)
  { this(t.min, t.max); }

  /*------------------------------------------------------------------*/
  /** Clone this type.
   *  @return a clone of this type
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone ()
  { return new IntegerType(this); }

  /*------------------------------------------------------------------*/
  /** Get the name of the type.
   *  @return the name of the type
   *  @since  2007.02.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return "integer"; }

  /*------------------------------------------------------------------*/
  /** Get the class used to access values of this type.
   *  @return the class used for accessing values of this type
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getValueClass ()
  { return Integer.class; }

  /*------------------------------------------------------------------*/
  /** Get the class used to store values of this type.
   *  @return the class used for storing values of this type
   *  @since  2006.10.04 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Class<?> getStorageClass ()
  { return int.class; }

  /*------------------------------------------------------------------*/
  /** Check whether an array fits this type.
   *  <p>This function need not really be here, since the generic
   *  version in ColType.java yields the same result. However, this
   *  version is more efficient.</p>
   *  @return whether the array has the correct type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean fits (Object array)
  { return (array == null) || (array instanceof int[]); }

  /*------------------------------------------------------------------*/
  /** Add a value. The range of values is adapted.
   *  @param  value the value to add, must either be
   *                <code>Number</code> or <code>String<code>
   *  @return a value that can be used efficiently with
   *          <code>setValueAt()</code>
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value)
  {                             /* --- add a value from an object */
    if (value == null) {        /* check for a null value */
      this.curr = NULL; return null; }
    if      (value instanceof Number) {
      this.addValue(((Number)value).intValue());
      if (this.curr <= NULL) return null; }
    else if (value instanceof String)
      try { this.addValue(Integer.parseInt((String)value));
            if (this.curr <= NULL) return null; }
      catch (NumberFormatException nfe) {
        this.curr = NULL; return null; }
    else {                      /* get and set the given value */
      this.curr = NULL; return null; }
    return ColType.CURRENT;     /* return special object */
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Add a value. The range of values is adapted.
   *  @param  value the value to add
   *  @since  2006.09.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void addValue (int value)
  {                             /* --- add a value */
    this.curr = value;          /* note value and update range */
    if (value <= Integer.MIN_VALUE) return;
    if (value < this.min) this.min = value;
    if (value > this.max) this.max = value;
    this.minobj = this.maxobj = null;
  }  /* addValue() */

  /*------------------------------------------------------------------*/
  /** Clear the range of values.
   *  @since  2007.07.19 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clear ()
  {                             /* --- clear the range of values */
    this.min    = Integer.MAX_VALUE;
    this.max    = Integer.MIN_VALUE+1;
    this.minobj = this.maxobj = null;
    this.curr   = NULL;         /* clear the current value */
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMin ()
  {                             /* --- get the minimal value */
    if (this.min > this.max)    /* if the range is empty/unset, */
      return null;              /* abort the function */
    if (this.minobj == null)    /* create date if necessary */
      this.minobj = Integer.valueOf(this.min);
    return this.minobj;         /* return the minimal value */
  }  /* getMin() */

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getMax ()
  {                             /* --- get the minimal value */
    if (this.min > this.max)    /* if the range is empty/unset, */
      return null;              /* abort the function */
    if (this.maxobj == null)    /* create date if necessary */
      this.maxobj = Integer.valueOf(this.max);
    return this.maxobj;         /* return the maximal value */
  }  /* getMax() */

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMinNumber ()
  { return (double)this.min; }

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2006.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getMaxNumber ()
  { return (double)this.max; }

  /*------------------------------------------------------------------*/
  /** Get the minimal value.
   *  @return the minimal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getMinRaw ()
  { return this.min; }

  /*------------------------------------------------------------------*/
  /** Get the maximal value.
   *  @return the maximal value
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getMaxRaw ()
  { return this.max; }

  /*------------------------------------------------------------------*/
  /** Get an array element as an object.
   *  @param  array an array of integer values, i.e. <code>int[]</code>
   *  @param  index the index of the array element to access
   *  @return the value as an object (of class <code>Integer<code>)
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (Object array, int index)
  { this.curr = ((int[])array)[index];
    return (this.curr > NULL) ? Integer.valueOf(this.curr) : null; }

  /*------------------------------------------------------------------*/
  /** Set an array element from an object.
   *  @param  array an array of integer values, i.e. <code>int[]</code>
   *  @param  index the index of the array element to set
   *  @param  value the value to set, must be an instance of
   *                <code>Number</code>, <code>String<code>, or
   *                <code>IntegerType</code>
   *  @since  2006.09.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object array, int index, Object value)
  {                             /* --- set an array element */
    if (value != ColType.CURRENT) { /* if not to use current value */
      if      (value instanceof Number)
        this.curr = ((Number)value).intValue();
      else if (value instanceof String)
        try { this.curr = Integer.parseInt((String)value); }
        catch (NumberFormatException nfe) { this.curr = NULL; }
      else this.curr = NULL;    /* get the value to set and */
    }                           /* store it in the array element */
    ((int[])array)[index] = this.curr;
  }  /* setValueAt() */

  /*------------------------------------------------------------------*/
  /** Get an array element as a string.
   *  @param  array an array of integer values; i.e. <code>int[]</code>
   *  @param  index the index of the array element to get
   *  @return the created string description
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (Object array, int index)
  {                             /* --- get array element as a string */
    int i = ((int[])array)[index];
    if (i <= NULL) return null; /* get the value to describe */
    return String.valueOf(i);   /* and turn it into a string */
  }  /* getStringAt() */

  /*------------------------------------------------------------------*/
  /** Get an array element as a number.
   *  @return the array element as a number
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getNumberAt (Object array, int index)
  { return (double)((int[])array)[index]; }

  /*------------------------------------------------------------------*/
  /** Check whether an array element is null.
   *  @param  array an array of integer values; i.e. <code>int[]</code>
   *  @param  index the index of the array element to check
   *  @return whether the array element is null
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isNull (Object array, int index)
  { return ((int[])array)[index] <= NULL; }

  /*------------------------------------------------------------------*/
  /** Set an array element to a null value.
   *  @param  array an array of integer values; i.e. <code>int[]</code>
   *  @param  index the index of the array element to set
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int index)
  { ((int[])array)[index] = NULL; }

  /*------------------------------------------------------------------*/
  /** Set a range of array elements to a null value.
   *  @param  array an array of integer values
   *  @param  beg   the index of the first array element (inclusive)
   *  @param  end   the index of the last  array element (exclusive)
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (Object array, int beg, int end)
  { while (--end >= beg) ((int[])array)[end] = NULL; }

  /*------------------------------------------------------------------*/
  /** Parse an integer from a string.
   *  @param  desc the string description to parse
   *  @return the parsed integer as an <code>Integer</code> object
   *          or <code>null</code> if parsing failed
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object parseValue (String desc)
  { try { return Integer.valueOf(desc); }
    catch (NumberFormatException e) { return null; } }

  /*------------------------------------------------------------------*/
  /** Create a string description.
   *  @return a string description of the type
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  {                             /* --- create a string description */
    if (this.min > this.max)    /* if the range is empty, */
      return "ZZ";              /* only return the type name */
    StringBuilder s = new StringBuilder("ZZ [");
    s.append(this.min); s.append(", ");
    s.append(this.max); s.append("]");
    return s.toString();        /* add the range of values */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Compare two integer values.
   *  @param  a the first  value
   *  @param  b the second value
   *  @return -1 if the first  value is smaller,<br>
   *          +1 if the second value is smaller,<br>
   *          0  if the value are equal
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int compare (Object a, Object b)
  { return ((Integer)a).compareTo((Integer)b); }

  /*------------------------------------------------------------------*/
  /** Sum two values.
   *  @param  a the first  value
   *  @param  b the second value
   *  @return the sum of the two values
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object sum (Object a, Object b)
  { return Integer.valueOf(((Integer)a).intValue()
                         + ((Integer)b).intValue()); }

  /*------------------------------------------------------------------*/
  /** Compute the difference of two values
   *  @param  a the value from which to subtract
   *  @param  b the value to subtract
   *  @return the difference of the two values
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object diff (Object a, Object b)
  { return Integer.valueOf(((Integer)a).intValue()
                         - ((Integer)b).intValue()); }

  /*------------------------------------------------------------------*/
  /** Parse a type description.
   *  @param  scan the scanner to read from
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static ColType parseType (Scanner scan) throws IOException
  {                             /* --- parse a type description */
    IntegerType type;           /* created type */

    if (( scan.nextToken() != Scanner.T_ID)
    ||  (!scan.value.equals("int") && scan.value.equals("integer")
    &&   !scan.value.equals("Z")   && scan.value.equals("ZZ")))
      throw new IOException("'int' expected instead of '"
                            +scan.value +"'" +scan.lno());
    type = new IntegerType();   /* create an integer-valued type */
    if (scan.nextToken() != '[')/* if no range of values follows, */
      scan.pushBack();          /* push back the token */
    else {                      /* if a range of values follows, */
      scan.getNumber();         /* check for a number and get minimum */
      try { type.min = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) {
        throw new IOException("illegal number '" +scan.value +"'"
                              +scan.lno()); }
      scan.getChar(',');        /* check for ',' */
      scan.getNumber();         /* check for a number and get maximum */
      try { type.max = Integer.parseInt(scan.value); }
      catch (NumberFormatException e) {
        throw new IOException("illegal number '" +scan.value +"'"
                              +scan.lno()); }
      scan.getChar(']');        /* check for ']' */
    }
    return type;                /* return the created type */
  }  /* parseType() */

}  /* class IntegerType */
