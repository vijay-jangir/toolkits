/*----------------------------------------------------------------------
  File    : Column.java
  Contents: column management for data tables
  Author  : Christian Borgelt
  History : 2007.01.31 file created
            2007.02.01 several functions for value arrays added
            2007.02.02 direction and marker and range update added
            2007.02.07 function autoType added (replaces setType(null))
            2007.02.09 functions hasNulls, describe, toString etc. added
            2007.02.12 ColType.addValue() called in Column.setValueAt()
            2007.02.16 automatic typing of string types added
            2007.02.17 column weights added
            2007.02.18 storing additional informtion with values added
            2007.03.15 function setNull(int,int) added
            2007.03.18 function getClass() added
            2007.04.13 function cloneAsType() added
            2007.06.07 several static functions added
            2013.04.22 adapted to class name change Type -> ColType
            2016.04.07 StringBuffer replaced by StringBuilder
            2019.03.31 fixed some deprecated functions etc.
----------------------------------------------------------------------*/
package table;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.util.Comparator;
import java.io.IOException;

import util.IdMap;
import util.Scanner;

/*--------------------------------------------------------------------*/
/** Class for columns of a data table.
 *  @author Christian Borgelt
 *  @since  2007.01.31 */
/*--------------------------------------------------------------------*/
public class Column implements Cloneable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** direction: do not use column */
  public static final int DIR_NONE = 0;
  /** direction: input column */
  public static final int DIR_IN   = 1;
  /** direction: output column */
  public static final int DIR_OUT  = 2;
  /** direction: (unique) identifier */
  public static final int DIR_ID   = 3;
  /** direction: weight column (tuple occurrences) */
  public static final int DIR_WGT  = 4;

  /*------------------------------------------------------------------*/
  /*  class variables
  /*------------------------------------------------------------------*/
  /** the map of (non-abstract) types: type names to classes */
  private static final IdMap dirmap = new IdMap();

  /*------------------------------------------------------------------*/
  /*  class initialization code                                       */
  /*------------------------------------------------------------------*/

  static {                      /* --- initialize the class */
    Column.dirmap.add("none");
    Column.dirmap.add("in");
    Column.dirmap.add("out");
    Column.dirmap.add("id");
    Column.dirmap.add("weight");
  }                             /* register all directions */

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the name of the column */
  protected String  name;
  /** the type of the column */
  protected ColType type;
  /** the data of the column (array of row values) */
  protected Object  data;
  /** the direction of the column */
  protected int     dir;
  /** the marker of the column */
  protected int     mark;
  /** the weight of the column */
  protected double  weight;

  /*------------------------------------------------------------------*/
  /** Get the identifier for a direction name.
   *  @return the identifier of the direction
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static int getDirId (String name)
  { return Column.dirmap.get(name); }

  /*------------------------------------------------------------------*/
  /** Get the name for a direction identifier.
   *  @return the name of the direction
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String getDirName (int id)
  { return (String)Column.dirmap.get(id); }

  /*------------------------------------------------------------------*/
  /** Get all direction names.
   *  @return an array of direction names
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String[] getAllDirNames ()
  { return Column.getAllDirNames(Column.dirmap.size()); }

  /*------------------------------------------------------------------*/
  /** Get the name for a direction identifier.
   *  @param  cnt the maximum number of names
   *  @return an array of direction names
   *  @since  2007.06.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String[] getAllDirNames (int cnt)
  {                             /* --- get all direction names */
    String[] list = new String[cnt];
    while (--cnt >= 0) list[cnt] = (String)Column.dirmap.get(cnt);
    return list;                /* collect the type names */
  }  /* getAllDirNames() */

  /*------------------------------------------------------------------*/
  /** Create a column of a data table.
   *  <p>The direction of the column is set to <code>DIR_IN</code>
   *  and its marker is initialized to 0.</p>
   *  @param  name the name of the column
   *  @param  type the type of the column
   *  @param  data the data of the column (array of row values)
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column (String name, ColType type, Object data)
  { this(name, type, data, DIR_IN, 1.0, 0); }

  /*------------------------------------------------------------------*/
  /** Create a column of a data table.
   *  <p>It is assumed that the data type of the <code>data</code>
   *  parameter fits the storage class of the given type.</p>
   *  @param  name   the name of the column
   *  @param  type   the type of the column
   *  @param  data   the data of the column (array of row values)
   *  @param  dir    the direction of the column
   *  @param  weight the marker of the column
   *  @param  mark   the marker of the column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private Column (String name, ColType type, Object data,
                  int dir, double weight, int mark)
  {                             /* --- create a data table column */
    if (type == null)           /* if no type is given, */
      type = new NominalType(); /* create a nominal type as default */
    this.name   = name;         /* store the column name, */
    this.type   = type;         /* the column type, */
    this.data   = data;         /* the value array, */
    this.dir    = dir;          /* the direction, */
    this.weight = weight;       /* the weight, */
    this.mark   = mark;         /* and the marker */
  }  /* Column() */

  /*------------------------------------------------------------------*/
  /** Create a column of a data table.
   *  @param  name   the name of the column
   *  @param  type   the type of the column
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column (String name, ColType type)
  { this(name, type, 0); }

  /*------------------------------------------------------------------*/
  /** Create a column of a data table.
   *  @param  name   the name of the column
   *  @param  type   the type of the column
   *  @param  rowcnt the number of rows of the column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column (String name, ColType type, int rowcnt)
  {                             /* --- create a data table column */
    if (type == null)           /* if no type is given, */
      type = new NominalType(); /* create a nominal type as default */
    this.name   = name;         /* store the column name */
    this.type   = type;         /* and the column type */
    this.dir    = DIR_IN;       /* set the direction and */
    this.weight = 1.0;          /* the weight to defaults */
    this.mark   = 0;            /* clear the marker */
    if (rowcnt <= 0) { this.data = null; return; }
    this.data = Array.newInstance(type.getStorageClass(), rowcnt);
    while (--rowcnt >= 0) type.setNull(this.data, rowcnt);
  }  /* Column() */             /* create a value array and fill it */

  /*------------------------------------------------------------------*/
  /** Clone this column.
   *  <p>The clone is a shallow copy: it keeps the type and the value
   *  array of the original column. If a deep copy is desired, the
   *  functions <code>cloneType()</code> and <code>cloneData()</code>
   *  must be called afterwards.</p>
   *  @return a clone of this column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object clone ()
  {                             /* --- clone this column */
    return new Column(this.name, this.type, this.data,
                      this.dir, this.weight, this.mark);
  }  /* clone() */

  /*------------------------------------------------------------------*/
  /** Clone a column as a type/domain description.
   *  <p>The column as well as its type are cloned, while the data
   *  is omitted (the new column has a size of 0).</p>
   *  @return a clone of the column as a type/domain description
   *  @since  2007.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Column cloneAsType ()
  {                             /* --- clone this column */
    return new Column(this.name, (ColType)this.type.clone(), null,
                      this.dir, this.weight, this.mark);
  }  /* cloneAsType() */

  /*------------------------------------------------------------------*/
  /** Clone the type of the column.
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void cloneType ()
  { this.type = (ColType)this.type.clone(); }

  /*------------------------------------------------------------------*/
  /** Clone the type of the column.
   *  <p>Note that if <code>update == true</code> this function may
   *  also clone the value array if an update of the range of values
   *  requires recoding the values (e.g. for a nominal type).</p>
   *  @param  update whether to update the range of values
   *  @see    Column#setType(ColType)
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void cloneType (boolean update)
  {                             /* --- clone the column type */
    if (!update) {              /* if not to update the range */
      this.type = (ColType)this.type.clone(); return; }
    try { this.setType((ColType)this.type.getClass()
                       .getConstructor().newInstance()); }
    catch (IllegalAccessException    e) { }
    catch (InstantiationException    e) { }
    catch (NoSuchMethodException     e) { }
    catch (InvocationTargetException e) { }
  }  /* cloneType() */

  /*------------------------------------------------------------------*/
  /** Clone the value array of the column.
   *  <p>Note, however, that this does <b>not</b> clone the row values
   *  itself if they are object instances (rather than basic types).
   *  Only the array containing them is cloned.</p>
   *  @see    Column#resize(int)
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void cloneData ()
  { if (this.data != null) this.resize(Array.getLength(this.data)); }

  /*------------------------------------------------------------------*/
  /** Get the name of the column.
   *  <p>Note that there is no corresponding <code>setName()</code>
   *  function, because when a column is part of a table, it may not
   *  be renamed directly, since the column access structure of the
   *  table needs to be updated.</p>
   *  @return the name of the column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getName ()
  { return this.name; }

  /*------------------------------------------------------------------*/
  /** Get the type of the column.
   *  @return the type of the column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ColType getType ()
  { return this.type; }

  /*------------------------------------------------------------------*/
  /** Set the type of the column, that is, convert its type.
   *  <p>Note that the type to convert to may coincide with the current
   *  type of the column. In this case the value array is cloned, maybe
   *  recoded, and the new range of values is determined.</p>
   *  @param  type the new type of the column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setType (ColType type)
  {                             /* --- set the type of a column */
    int         i;              /* loop variable */
    Object      tmp;            /* buffer for new value array */
    String      desc;           /* buffer for conversion */
    IntegerType tint;           /* specific column type: integer */
    RealType    real;           /* specific column type: real */
    DateType    date;           /* specific column type: date */
    int[]       iva;            /* typed value array for integer */
    double[]    rva;            /* typed value array for real */
    long[]      dva;            /* typed value array for date */

    if (this.data == null) {    /* check whether there is data */
      this.type = type; return; }
    i = Array.getLength(this.data);
    if      (type instanceof NominalType) {
      tmp = new int[i];         /* -- if to convert to nominal */
      if (this.data instanceof Object[]) {
        while (--i >= 0)        /* if to convert from object type, */
          type.setValueAt(tmp,i,/* convert with generic functions */
                          type.addValue(((Object[])this.data)[i])); }
      else {                    /* if to convert from basic type */
        while (--i >= 0) {      /* turn all values into strings */
          desc = this.type.getStringAt(this.data, i);
          type.setValueAt(tmp, i, type.addValue(desc));
        }                       /* (works for all basic types) */
      } }
    else if (type instanceof IntegerType) {
      tint = (IntegerType)type; /* -- if to convert to integer */
      if      (this.type instanceof IntegerType) {
        tmp = iva = (int[])this.data;
        while (--i >= 0)        /* convert values from integer */
          tint.addValue(iva[i]); }
      else if (this.type instanceof RealType) {
        tmp = iva = new int[i]; /* create a new value array */
        while (--i >= 0)        /* convert values from real */
          tint.addValue(iva[i] = (int)((double[])this.data)[i]); }
      else if (this.type instanceof DateType) {
        tmp = iva = new int[i]; /* create a new value array */
        while (--i >= 0)        /* convert values from date */
          tint.addValue(iva[i] = (int)  ((long[])this.data)[i]); }
      else {                    /* convert with generic functions */
        tmp = new int[i];       /* create a new value array */
        while (--i >= 0)        /* from nominal or other types */
          type.setValueAt(tmp, i,
               type.addValue(this.type.getValueAt(this.data, i)));
      } }
    else if (type instanceof RealType) {
      real = (RealType)type;    /* -- if to convert to real */
      if      (this.type instanceof RealType) {
        tmp = rva = (double[])this.data;
        while (--i >= 0)        /* convert values from real */
          real.addValue(rva[i]); }
      else if (this.type instanceof IntegerType) {
        tmp = rva = new double[i]; /* create a new value array */
        while (--i >= 0)        /* convert values from integer */
          real.addValue(rva[i] = (double) ((int[])this.data)[i]); }
      else if (this.type instanceof DateType) {
        tmp = rva = new double[i]; /* create a new value array */
        while (--i >= 0)        /* convert values from date */
          real.addValue(rva[i] = (double)((long[])this.data)[i]); }
      else {                    /* convert with generic functions */
        tmp = new double[i];    /* create a new value array */
        while (--i >= 0)        /* from nominal or other types */
          type.setValueAt(tmp, i,
               type.addValue(this.type.getValueAt(this.data, i)));
      } }
    else if (type instanceof DateType) {
      date = (DateType)type;    /* -- if to convert to date */
      if      (this.type instanceof DateType) {
        tmp = dva = (long[])this.data;
        while (--i >= 0)        /* convert values from date */
          date.addValue(dva[i]); }
      else if (this.type instanceof IntegerType) {
        tmp = dva = new long[i];/* create a new value array */
        while (--i >= 0)        /* convert values from integer */
          date.addValue(dva[i] = (long)   ((int[])this.data)[i]); }
      else if (this.type instanceof RealType) {
        tmp = dva = new long[i];/* create a new value array */
        while (--i >= 0)        /* convert values from real */
          date.addValue(dva[i] = (long)((double[])this.data)[i]); }
      else {                    /* convert with generic functions */
        tmp = new long[i];      /* create a new value array */
        while (--i >= 0)        /* from nominal or other types */
          type.setValueAt(tmp, i,
               type.addValue(this.type.getValueAt(this.data, i)));
      } }
    else if (type.getClass() == this.type.getClass()) {
      tmp = this.data;          /* get the existing data array */
      while (--i >= 0)          /* if same class, only update range */
        type.addValue(this.type.getValueAt(this.data, i)); }
    else {                      /* if any other type combination */
      tmp = Array.newInstance(type.getStorageClass(), i);
      while (--i >= 0)          /* convert with generic functions */
        type.setValueAt(tmp, i, /* using the stored objects */
             type.addValue(this.type.getValueAt(this.data, i)));
    }                           /* (this is always possible) */
    this.type = type;           /* set the new type and */
    this.data = tmp;            /* the new value array */
  }  /* setType() */

  /*------------------------------------------------------------------*/
  /** Automatically determine the type of a nominal or string column.
   *  @since  2007.02.07 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void autoType ()
  {                             /* --- determine type automatically */
    int         i, cnt;         /* loop variable, number of values */
    NominalType src;            /* type to convert from: nominal */
    ColType     dst;            /* type to convert to */

    if (this.type instanceof NominalType) {
      src = (NominalType)this.type;
      cnt = src.getValueCount();  /* get type and number of values */
      dst = new IntegerType();    /* try to convert to integer */
      for (i = cnt; --i >= 0; )   /* traverse the values */
        if (dst.addValue(src.getValue(i)) == null)
          break;                  /* if all values can be parsed, */
      if (i < 0) {                /* decide to convert to integer */
        this.setType(dst); return; }
      dst = new RealType();       /* try to convert to real */
      for (i = cnt; --i >= 0; )   /* traverse the values */
        if (dst.addValue(src.getValue(i)) == null)
          break;                  /* if all values can be parsed, */
      if (i < 0) {                /* decide to convert to real */
        this.setType(dst); return; }
      dst = new DateType();       /* try to convert to date */
      for (i = cnt; --i >= 0; )   /* traverse the values */
        if (dst.addValue(src.getValue(i)) == null)
          break;                  /* if all values can be parsed, */
      if (i < 0) {                /* decide to convert to date */
        this.setType(dst); return; }
      return;                     /* otherwise keep old type */
    }
    if (this.type instanceof StringType) {
      cnt = this.getRowCount();   /* get the number of rows */
      dst = new IntegerType();    /* try to convert to integer */
      for (i = cnt; --i >= 0; )   /* traverse the values */
        if (dst.addValue(((String[])this.data)[i]) == null)
          break;                  /* if all values can be parsed, */
      if (i < 0) {                /* decide to convert to integer */
        this.setType(dst); return; }
      dst = new RealType();       /* try to convert to real */
      for (i = cnt; --i >= 0; )   /* traverse the values */
        if (dst.addValue(((String[])this.data)[i]) == null)
          break;                  /* if all values can be parsed, */
      if (i < 0) {                /* decide to convert to real */
        this.setType(dst); return; }
      dst = new DateType();       /* try to convert to date */
      for (i = cnt; --i >= 0; )   /* traverse the values */
        if (dst.addValue(((String[])this.data)[i]) == null)
          break;                  /* if all values can be parsed, */
      if (i < 0) {                /* decide to convert to date */
        this.setType(dst); return; }
      return;                     /* otherwise keep old type */
    }
  }  /* autoType() */

  /*------------------------------------------------------------------*/
  /** Sort the values of the column type by their string description.
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sortType ()
  { this.sortType(null); }

  /*------------------------------------------------------------------*/
  /** Sort the values of the column type.
   *  @param  cmp the comparator for the values
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void sortType (Comparator<Object> cmp)
  {                             /* --- sort the values of the type */
    if (!(this.type instanceof NominalType))
      return;                   /* check for a nominal column */
    int[] map  = (cmp != null) ? ((NominalType)this.type).sort(cmp)
                               : ((NominalType)this.type).sort();
    int[] vals = (int[])this.data;
    if (vals == null) return;   /* sort the values and get the map */
    for (int i = vals.length; --i >= 0; )
      vals[i] = map[vals[i]];   /* map the column values */
  }  /* sortType() */

  /*------------------------------------------------------------------*/
  /** Get the number of values.
   *  @return the number of values
   *  @see    ColType#getValueCount()
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getValueCount ()
  { return this.type.getValueCount(); }

  /*------------------------------------------------------------------*/
  /** Add a value, that is, adapt the range of values.
   *  @param  value the value to add
   *  @see    ColType#addValue(Object)
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object addValue (Object value)
  { return this.type.addValue(value); }

  /*------------------------------------------------------------------*/
  /** Get the value associated with an identifier.
   *  @param  id the value identifier
   *  @return the value with the given identifier
   *  @see    ColType#getValue(int)
   *  @since  2007.07.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValue (int id)
  { return this.type.getValue(id); }

  /*------------------------------------------------------------------*/
  /** Clear all additional information.
   *  @since  2013.12.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void clearInfo ()
  { this.type.clearInfo(); }

  /*------------------------------------------------------------------*/
  /** Get the number of values for which there is information.
   *  @return the number of values for which there is information
   *  @see    ColType#getInfoCount()
   *  @since  2007.06.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getInfoCount ()
  { return this.type.getInfoCount(); }

  /*------------------------------------------------------------------*/
  /** Get the information associated with a value.
   *  @param  value the value for which to get the information
   *  @return the additional information stored with the value
   *  @see    ColType#getInfo(Object)
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (Object value)
  { return this.type.getInfo(value); }

  /*------------------------------------------------------------------*/
  /** Set the information associated with a value.
   *  @param  value the value for which to set the information
   *  @param  info  the information to set
   *  @see    ColType#setInfo(Object,Object)
   *  @since  2007.02.18 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (Object value, Object info)
  { this.type.setInfo(value, info); }

  /*------------------------------------------------------------------*/
  /** Get the information associated with a value.
   *  @param  id the identifier of the value or property
   *  @return the information associated with the value
   *  @see    ColType#getInfo(int)
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getInfo (int id)
  { return this.type.getInfo(id); }

  /*------------------------------------------------------------------*/
  /** Set the information associated with a value or property.
   *  @param  id   the identifier of the value or property
   *  @param  info the information to set
   *  @see    ColType#setInfo(int,Object)
   *  @since  2007.02.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setInfo (int id, Object info)
  { this.type.setInfo(id, info); }

  /*------------------------------------------------------------------*/
  /** Get the value array of the column.
   *  @return the value array of the column
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getData ()
  { return this.data; }

  /*------------------------------------------------------------------*/
  /** Set the value array of the column.
   *  <p>Note that this function does <b>not</b> update the range
   *  of values of the column type. This may be achieved afterwards
   *  (except for nominal columns) by calling the function
   *  <code>cloneType(true)</code>.</p>
   *  @param  data the value array of the column
   *  @see    Column#cloneType(boolean)
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setData (Object data)
  { this.data = data; }

  /*------------------------------------------------------------------*/
  /** Get the number of rows of the column.
   *  @return the number of rows of the column
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getRowCount ()
  { return (this.data != null) ? Array.getLength(this.data) : 0; }

  /*------------------------------------------------------------------*/
  /** Get the direction of the column.
   *  @return the direction of the column
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getDir ()
  { return this.dir; }

  /*------------------------------------------------------------------*/
  /** Set the direction of the column.
   *  @param  dir the direction of the column
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDir (int dir)
  { this.dir = dir; }

  /*------------------------------------------------------------------*/
  /** Get the weight of the column.
   *  @return the weight of the column
   *  @since  2007.02.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getWeight ()
  { return this.weight; }

  /*------------------------------------------------------------------*/
  /** Set the weight of the column.
   *  @param  weight the weight of the column
   *  @since  2007.02.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setWeight (double weight)
  { this.weight = weight; }

  /*------------------------------------------------------------------*/
  /** Get the marker value of the column.
   *  @return the marker value of the column
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getMark ()
  { return this.mark; }

  /*------------------------------------------------------------------*/
  /** Set the marker value of the column.
   *  @param  mark the marker value of the column
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setMark (int mark)
  { this.mark = mark; }

  /*------------------------------------------------------------------*/
  /** Get the value of a column row as an object.
   *  @param  row the row to access
   *  @return an object representing the value in the specified row
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Object getValueAt (int row)
  { return this.type.getValueAt(this.data, row); }

  /*------------------------------------------------------------------*/
  /** Set the value of a column row from an object.
   *  @param  value the value to set in the specified cell
   *  @param  row   the row to set
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setValueAt (Object value, int row)
  { this.type.setValueAt(this.data, row, this.type.addValue(value)); }

  /*------------------------------------------------------------------*/
  /** Get the value of a column row as a string.
   *  @param  row the row to access
   *  @return the created string description
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getStringAt (int row)
  { return this.type.getStringAt(this.data, row); }

  /*------------------------------------------------------------------*/
  /** Get the value of a column row as a number.
   *  @param  row the row to get
   *  @return the row entry as a number
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public double getNumberAt (int row)
  { return this.type.getNumberAt(this.data, row); }

  /*------------------------------------------------------------------*/
  /** Check whether a column row is null.
   *  @param  row the row to check
   *  @return whether the column row is null
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean isNull (int row)
  { return this.type.isNull(this.data, row); }

  /*------------------------------------------------------------------*/
  /** Set a column row to a null value.
   *  @param  row the row to set
   *  @since  2007.02.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (int row)
  { this.type.setNull(this.data, row); }

  /*------------------------------------------------------------------*/
  /** Set a range of column rows to a null value.
   *  @param  beg the index of the first row (inclusive)
   *  @param  end the index of the last  row (exclusive)
   *  @since  2007.03.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setNull (int beg, int end)
  { this.type.setNull(this.data, beg, end); }

  /*------------------------------------------------------------------*/
  /** Check whether a column contains null values.
   *  @return whether the column contains null values
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public boolean hasNulls ()
  {                             /* --- check for null values */
    for (int i = this.getRowCount(); --i >= 0; )
      if (this.type.isNull(this.data, i)) return true;
    return false;               /* traverse and check the rows */
  }  /* hasNulls() */

  /*------------------------------------------------------------------*/
  /** Resize the value array of the column.
   *  <p>If the new number of rows is greater than the old, the
   *  additional fields are initialized with null values.</p>
   *  <p>Note that a new value array is allocated regardless of whether
   *  the new number of rows coincides with the old number or not.
   *  Hence calling this function with the old number of rows
   *  effectively clones the value array of the column.</p>
   *  @param  newcnt the new number of rows
   *  @see    Column#cloneData()
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void resize (int newcnt)
  { this.resize(newcnt, true); }

  /*------------------------------------------------------------------*/
  /** Resize the value array of the column.
   *  <p>Note that a new value array is allocated regardless of whether
   *  the new number of rows coincides with the old number or not.
   *  Hence calling this function with the old number of columns
   *  effectively clones the value array of the column.</p>
   *  @param  newcnt the new number of rows
   *  @param  init   whether new fields should be initialized
   *                 with null values
   *  @see    Column#cloneData()
   *  @since  2007.02.01 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void resize (int newcnt, boolean init)
  {                             /* --- resize the value array */
    int    cnt;                 /* old length of the value array */
    Object tmp;                 /* buffer for reallocation */

    if (newcnt <= 0) { this.data = null; return; }
    cnt = (this.data != null) ? Array.getLength(this.data) : 0;
    tmp = Array.newInstance(this.type.getStorageClass(), newcnt);
    if (cnt > newcnt) cnt = newcnt;
    if (cnt > 0) System.arraycopy(this.data, 0, tmp, 0, cnt);
    this.data = tmp;            /* copy values into a new value array */
    if (!init) return;          /* if not to initialize, abort */
    while (--newcnt >= cnt)     /* set all new fields to null */
      this.type.setNull(this.data, newcnt);
  }  /* resize() */

  /*------------------------------------------------------------------*/
  /** Create a string description of the column type.
   *  @return a string description of the column type
   *  @since  2007.02.09 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String toString ()
  {                             /* --- describe the column type */
    StringBuilder b = new StringBuilder("dom(");
    b.append(this.name); b.append(") = "); b.append(this.type);
    if ((this.dir >= DIR_NONE) && (this.dir <= DIR_WGT)
    &&  (this.dir != DIR_IN)) { /* if direction indicator needed */
      b.append(" : "); b.append(Column.getDirName(this.dir)); }
    if (this.weight != 1.0) {   /* if a weight indicator is needed */
      b.append(", ");  b.append(this.weight); }
    b.append(";");              /* terminate the description */
    return b.toString();        /* and turn it into a string */
  }  /* toString() */

  /*------------------------------------------------------------------*/
  /** Parse a column description.
   *  @param  scan the scanner to read from
   *  @since  2007.02.16 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static Column parse (Scanner scan) throws IOException
  {                             /* --- parse a column description */
    int    i;                   /* loop variable */
    String name;                /* name of the column */
    Column col;                 /* created column */

    scan.getID("dom");          /* check for keyword "dom" */
    scan.getChar('(');          /* check for '(' */
    scan.getID();               /* check for any identifier */
    name = scan.value;          /* note the column name */
    scan.getChar(')');          /* check for ')' */
    scan.getChar('=');          /* check for '=' */
    col = new Column(name, ColType.parseType(scan));
    if (scan.nextToken() != ':')/* if no direction indicator follows */
      scan.pushBack();          /* push back the token */
    else {                      /* if a direction indicator follows */
      scan.getID();             /* check for an identifier */
      i = Column.getDirId(scan.value);
      if (i < 0) throw new IOException("illegal direction '"
                                       +scan.value +"'" +scan.lno());
      col.dir = i;              /* get the direction code and */
    }                           /* set the direction of the column */
    if (scan.nextToken() != ',')/* if no weight follows */
      scan.pushBack();          /* push back the token */
    else {                      /* if a column weight follows, */
      scan.getNumber();         /* check for a number */
      col.weight = Double.parseDouble(scan.value);
    }                           /* get and set the column weight */
    scan.getChar(';');          /* check for ';' */
    return col;                 /* return the created column */
  }  /* parse() */

}  /* class Column */
