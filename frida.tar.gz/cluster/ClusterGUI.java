/*----------------------------------------------------------------------
  File    : ClusterGUI.java
  Contents: fuzzy and probabilistic clustering graphical user interface
  Author  : Christian Borgelt
  History : 2007.02.12 file created
            2007.05.08 adapted to new executor classes
            2007.07.07 adapted to new class DialogPanel
            2007.07.08 first version of all tabs completed
            2008.04.08 adapted to version 3.0 of clustering program
            2013.04.22 adapted to type argument of JComboBox
            2014.10.20 trimming of spaces from number arguments added
            2014.10.23 terminal added, changed from LGPL to MIT license
            2018.11.14 replaced some deprecated functions
----------------------------------------------------------------------*/
package cluster;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JSpinner;

import util.Executable;
import util.Executor;
import util.ObjExecutor;
import util.CmdExecutor;
import dialog.TabbedGUI;
import dialog.DialogPanel;
import dialog.FormatPanel;
import dialog.DomainsPanel;
import dialog.AboutPanel;

/*--------------------------------------------------------------------*/
/** Class for a graphical user interface to the C clustering programs.
 *  @author Christian Borgelt
 *  @since  2007.02.12 */
/*--------------------------------------------------------------------*/
public class ClusterGUI extends TabbedGUI {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final long serialVersionUID = 0x00020006L;
  public  static final String VERSION = "2.6 (2018.11.14)";

  /** tab index: domain determination */
  private static final int DOMAINS   = 1;
  /** tab index: cluster parameters */
  private static final int CLUSTERS  = 2;
  /** tab index: membership parameters */
  private static final int MEMSHIPS  = 3;
  /** tab index: initialization parameters */
  private static final int INIT      = 4;
  /** tab index: initialization parameters */
  private static final int POINTS    = 5;
  /** tab index: update parameters */
  private static final int UPDATE    = 6;
  /** tab index: update modifiers */
  private static final int MODIFY    = 7;
  /** tab index: regularization parameters */
  private static final int REGULAR   = 8;
  /** tab index: multilayer perceptron training */
  private static final int INDUCTION = 9;
  /** tab index: multilayer perceptron execution */
  private static final int EXECUTION = 10;

  /** the names of the radial functions */
  private static final String[] radnames = {
    "Cauchy", "Gauss" };
  /** the names of the shape parameters */
  private static final String[] shapenames = {
    "none", "variances", "covariances" };
  private static final String[] ctrnames = {
    "none", "unit length", "fixed at origin" };
  /** the names of the normalization modes */
  private static final String[] nrmnames = {
    "none", "sum 1", "max 1", "hard" };
  /** the codes of the normalization modes */
  private static final String[] nrmcodes = {
    "none", "sum1", "max1", "hard" };
  /** the names of the initialization modes */
  private static final String[] ininames = {
    "center", "uniform", "diagonal", "latin hypercube", "points" };
  /** the names of the initialization modes */
  private static final String[] inicodes = {
    "center", "uniform", "diag", "latin", "points" };
  /** the names of the update methods */
  private static final String[] updnames = {
    "alternating", "competitive" };
  private static final String[] updcodes = {
    "altopt", "complrn" };
  /** the names of the update modifiers */
  private static final String[] modnames = {
    "none", "expand", "momentum", "adaptive", "resilient", "quick" };
  /** the codes of the update modifiers */
  private static final String[] modcodes = {
    "none", "expand", "momentum", "adaptive", "resilient", "quick" };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /* --- clusters --- */
  /** the number of clusters */
  private JSpinner          clscnt;
  /** the radial function type */
  private JComboBox<String> radial;
  /** the radial function parameter 0 */
  private JTextField        param0;
  /** the radial function parameter 1 */
  private JTextField        param1;
  /** the adaptable cluster shape (variances/covariances) */
  private JComboBox<String> shape;
  /** the flag for adaptable size */
  private JCheckBox         size;
  /** the flag for adaptable weights */
  private JCheckBox         weights;
  /** the flag for joint shape/size parameters */
  private JCheckBox         joint;
  /** the flag for normalization to unit integral */
  private JCheckBox         uinteg;
  /** the special modes for centers */
  private JComboBox<String> centers;

  /* --- memberships --- */
  /** the membership to the noise cluster */
  private JTextField        noise;
  /** the membership transformation parameter 0 */
  private JTextField        trans0;
  /** the membership transformation parameter 1 */
  private JTextField        trans1;
  /** the normalization mode */
  private JComboBox<String> norm;
  /** the membership exponent for the data point weight */
  private JTextField        msexp;
  /** the feature weight exponent */
  private JTextField        ftexp;

  /* --- initialization --- */
  /** the initialization mode */
  private JComboBox<String> init;
  /** the random offset range */
  private JTextField        range;
  /** the initial cluster radius */
  private JTextField        radius;
  /** the seed for random numbers */
  private JTextField        seed;

  /* --- points --- */
  /** the maximum number of epochs */
  private JSpinner          epochs;
  /** the number of epochs to update centers only */
  private JSpinner          conly;
  /** the number of data points between updates */
  private JSpinner          ptcnt;
  /** the flag for data point shuffling */
  private JCheckBox         shuffle;
  /** the flag for normalized input ranges */
  private JCheckBox         irnorm;

  /* --- update --- */
  /** the parameter update method */
  private JComboBox<String> update;
  /** the learning rate for the cluster centers */
  private JTextField        lrate0;
  /** the learning rate for the (co)variances */
  private JTextField        lrate1;
  /** the learning rate for the cluster weights */
  private JTextField        lrate2;
  /** the learning rate decay for the cluster centers */
  private JTextField        decay0;
  /** the learning rate decay for the (co)variances */
  private JTextField        decay1;
  /** the learning rate decay for the cluster weights */
  private JTextField        decay2;
  /** the maximum change for termination */
  private JTextField        term;

  /* --- modifiers --- */
  /** the parameter update modifier */
  private JComboBox<String> modif;
  /** the flag for applying the modifier only to centers */
  private JCheckBox         modctr;
  /** the momentum term */
  private JTextField        moment;
  /** the growth factor for learning rate or weight change */
  private JTextField        growth;
  /** the shrink factor for learning rate or weight change */
  private JTextField        shrink;
  /** the maximal change of learning rate or weight change  */
  private JTextField        maxchg;

  /* --- regularization --- */
  /** the shape regularization parameter */
  private JTextField        rshape;
  /** the size regularization parameter 0 */
  private JTextField        rsize0;
  /** the size regularization parameter 1 */
  private JTextField        rsize1;
  /** the size regularization parameter 2 */
  private JTextField        rsize2;
  /** the weight regularization parameter */
  private JTextField        regwgt;

  /* --- induction --- */
  /** the name of the domain file */
  private JTextField        fn_dom;
  /** the name of the target attribute */
  private JTextField        target;
  /** the name of the table file */
  private JTextField        fn_tab;
  /** the name of the cluster model file */
  private JTextField        fn_cls;

  /* --- execution --- */
  /** the name of the cluster file */
  private JTextField        fn_exec;
  /** the name of the table input file */
  private JTextField        fn_in;
  /** the name of the cluster index field */
  private JTextField        pred;
  /** the name of the membership field */
  private JTextField        mship;
  /** the output format for membership degrees */
  private JTextField        outfmt;
  /** whether to write the field names to the first record */
  private JCheckBox         write;
  /** the name of the table output file */
  private JTextField        fn_out;

  /*------------------------------------------------------------------*/
  /** Create a fuzzy and probabilistic clustering GUI.
   *  <p>The dialog is created as a stand-alone program.
   *  That is, closing or quitting it terminates the program.</p>
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ClusterGUI ()
  { this.init(null, true); }

  /*------------------------------------------------------------------*/
  /** Create a fuzzy and probabilistic clustering GUI.
   *  @param  owner the component that is to own this dialog
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ClusterGUI (Component owner)
  { this.init(owner, false); }

  /*------------------------------------------------------------------*/
  /** Create the user interface.
   *  <p>Following the recommendations in the Java tutorial, the user
   *  interface is created in the "run" method, which is invoked from
   *  the event queue, in order to avoid problems with threads.</p>
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- create a dec. tree toolbox */
    DialogPanel tab;            /* current tab of the tabbed pane */
    JPanel      bar;            /* bar of input fields */

    /* --- basic tabs --- */
    this.base("Fuzzy and Probabilistic Clustering Tools");
    this.addFormatTab (FormatPanel.HEADER
                     | FormatPanel.WEIGHT
                     | FormatPanel.NONULLS);
    this.addDomainsTab(DomainsPanel.LOCATE);

    /* --- Clusters --- */
    tab = this.addTab("Clusters");

    tab.addLabel("Number of clusters:");
    this.clscnt = tab.addSpinner(2, 1, 1000, 1);

    tab.addLabel("Radial function:");
    this.radial = tab.addComboBox(ClusterGUI.radnames);
    this.radial.setSelectedIndex(0);
    tab.addLabel("Function parameters:");
    this.param0 = tab.addNumberInput("2", DialogPanel.MIDDLE);
    this.param1 = tab.addNumberInput("0", DialogPanel.RIGHT);

    tab.addLabel("Adaptable shapes:");
    this.shape   = tab.addComboBox(ClusterGUI.shapenames);
    tab.addLabel("Adaptable sizes:");
    this.size    = tab.addCheckBox(false);
    tab.addLabel("Joint shape/size:");
    this.joint   = tab.addCheckBox(false);
    tab.addLabel("Adaptable weights:");
    this.weights = tab.addCheckBox(false);

    tab.addLabel("Normalize to unit integral:");
    this.uinteg  = tab.addCheckBox(false);
    tab.addHelp("Necessary for probabilistic clustering "
               +"(probability density).");

    tab.addLabel("Constraint on centers:");
    this.centers = tab.addComboBox(ClusterGUI.ctrnames);
    tab.addHelp("These constraints can be useful when clustering "
               +"documents\nthat are coded in a vector space model.");
    tab.addFiller(0);

    /* --- Memberships --- */
    tab = this.addTab("Memberships");

    tab.addLabel("Membership to noise cluster:");
    this.noise = tab.addNumberInput("");
    tab.addHelp("All data points are assumed to have the same "
               +"membership\n(or distance if the number is negative) "
               +"to a noise cluster.\nA noise cluster helps to deal "
               +"with outliers/noise in the data.");

    tab.addLabel("Membership transformation:");
    this.trans0 = tab.addNumberInput("1", DialogPanel.MIDDLE);
    this.trans1 = tab.addNumberInput("0", DialogPanel.RIGHT);
    tab.addHelp("The membership degrees are computed by evaluating "
               +"the\nradial function. They may be then transformed "
               +"linearly.");

    tab.addLabel("Membership normalization:");
    this.norm = tab.addComboBox(ClusterGUI.nrmnames);
    this.norm.setSelectedIndex(1);
    tab.addHelp("The membership degrees are normalized "
               +"over the clusters.\nChoose \"hard\" for classical "
               +"c-means clustering.");

    tab.addLabel("Membership exponent:");
    this.msexp = tab.addNumberInput("2");
    tab.addHelp("The membership degrees are transformed in order "
               +"to obtain\nthe data point weights for the cluster "
               +"parameter update.");

    tab.addLabel("Feature weight exponent:");
    this.ftexp = tab.addNumberInput("0");
    tab.addHelp("Feature weights are an alternative interpretation "
               +"of\nthe (co)variances to compute the cluster shape.");
    tab.addFiller(0);

    /* --- Initialization --- */
    tab = this.addTab("Initialization");

    tab.addLabel("Initialization mode:");
    this.init = tab.addComboBox(ClusterGUI.ininames);
    this.init.setSelectedIndex(4);
    tab.addHelp("The initial cluster centers are chosen randomly, "
               +"either by\nsampling from the given data set or "
               +"by sampling from a\ndistribution on (a subset) of "
               +"the data space");

    tab.addLabel("Random offset range:");
    this.range = tab.addNumberInput("");
    tab.addHelp("A random offset may be added to the initial "
               +"cluster centers\nin order to avoid equal centers "
               +"(e.g. mode \"center\").");

    tab.addLabel("(Initial) cluster size:");
    this.radius = tab.addNumberInput("1");
    tab.addHelp("Depending on the choice of the radial function, the "
               +"cluster\nsize may have an influence on the "
               +"clustering result.\nIf sizes are adaptable, "
               +"an initial cluster size is needed.");

    tab.addFiller(0);
    tab.addLabel("Seed for random numbers:");
    this.seed = tab.addNumberInput("");
    tab.addHelp("If no value is given, "
               +"the current time is used as a seed.");

    /* --- Data Points --- */
    tab = this.addTab("Data Points");

    tab.addLabel("Maximum update epochs:");
    this.epochs = tab.addSpinner(1000, 0, 999999, 1);

    tab.addLabel("Epochs for only centers:");
    this.conly = tab.addSpinner(0, 0, 999999, 1);
    tab.addHelp("The number of epochs at the beginning of the process\n"
               +"in which only the cluster centers are updated.");

    tab.addLabel("Points between updates:");
    this.ptcnt = tab.addSpinner(0, 0, 999999, 1);
    tab.addHelp("If no number of data points to be processed between "
               +"cluster\nupdates is given, parameters are updated "
               +"once per traversal\nof the data set (epoch). "
               +"A value of 1 means online update.");

    tab.addLabel("Shuffle between epochs:");
    this.shuffle = tab.addCheckBox(true);
    tab.addHelp("If the number of data points to be processed between "
               +"cluster\nupdates is less than the number of available "
               +"data points,\nshuffling is recommended to avoid order "
               +"effects.");

    tab.addLabel("Normalize input ranges:");
    this.irnorm = tab.addCheckBox(true);
    tab.addHelp("If this box is checked, all data attributes "
               +"are normalized\nto mean 0 and variance 1 "
               +"in order to avoid scaling effects.");
    tab.addFiller(0);

    /* --- Update --- */
    tab = this.addTab("Update");

    tab.addLabel("Update method:");
    this.update = tab.addComboBox(ClusterGUI.updnames);
    this.update.setSelectedIndex(0);
    tab.addHelp("Choose \"alternating\" for fuzzy and probabilistic "
               +"clustering\nand \"competitive\" for learning vector "
               +"quantization.");
    tab.addFiller(8);

    tab.addLabel("Learning rates:");
    bar = new JPanel(new GridLayout(1, 3, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.lrate0 = DialogPanel.createNumberInput("0.2"));
    bar.add(this.lrate1 = DialogPanel.createNumberInput("0.2"));
    bar.add(this.lrate2 = DialogPanel.createNumberInput("0.2"));

    tab.addLabel("Learning rate decays:");
    bar = new JPanel(new GridLayout(1, 3, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.decay0 = DialogPanel.createNumberInput("-0.2"));
    bar.add(this.decay1 = DialogPanel.createNumberInput("-0.2"));
    bar.add(this.decay2 = DialogPanel.createNumberInput("-0.2"));
    tab.addHelp("Learning rates and decays are used for learning "
               +"vector\nquantization. The first learning rate/decay "
               +"refers to the\ncenter coordinates, the second to "
               +"the (co)variances/sizes,\nand the third to the "
               +"cluster weights.\n"
               +"Positive decay values specify exponential decay,\n"
               +"negative decay values specify hyperbolic decay.");
    tab.addFiller(8);

    tab.addLabel("Change for termination:");
    this.term = tab.addNumberInput("");
    tab.addHelp("If the changes of the center coordinates do not "
               +"exceed\nthis value, the cluster update/adaptation "
               +"is terminated.");
    tab.addFiller(0);

    /* --- Modifiers --- */
    tab = this.addTab("Modifiers");

    tab.addLabel("Update modifier:");
    this.modif = tab.addComboBox(ClusterGUI.modnames);
    this.modif.setSelectedIndex(0);
    tab.addHelp("Neural network techniques can speed up "
               +"the induction.\nThe difference between two update "
               +"steps is interpreted\nas a (negative) gradient"
               +"which is modified with techniques\nthat were "
               +"orginally developed to improve backpropagation.");

    tab.addLabel("Apply only to centers:");
    this.modctr = tab.addCheckBox(false);
    tab.addHelp("Apply update modifiers only "
               +"to the center coordinates.");

    tab.addLabel("Momentum coefficient:");
    this.moment = tab.addNumberInput("");
    tab.addHelp("The previous parameter change, "
               +"multiplied with this\ncoefficient, "
               +"is added to the current parameter change.");

    tab.addLabel("Growth and shrink factor:");
    this.growth = tab.addNumberInput("1.2", DialogPanel.MIDDLE);
    this.shrink = tab.addNumberInput("0.7", DialogPanel.RIGHT);
    tab.addHelp("The expansion factor and the growth and shrink "
               +"factors\nfor adaptive expansion and resilient "
               +"update.");

    tab.addLabel("Maximal change/factor:");
    this.maxchg = tab.addNumberInput("2", DialogPanel.RIGHT);
    tab.addHelp("The maximal factor by which an update step "
               +"is expanded.");
    tab.addFiller(0);

    /* --- Regularization --- */
    tab = this.addTab("Regularization");

    tab.addLabel("Shape regularization:");
    this.rshape = tab.addNumberInput("0");
    tab.addHelp("Cluster shape regularization introduces a tendency "
               +"towards\nspherical clusters (positive value) or "
               +"limits the length ratio\nof the longest to the "
               +"shortest major axis (negative value).");

    tab.addLabel("Size regularization:");
    bar = new JPanel(new GridLayout(1, 3, 0, 0));
    tab.add(bar, DialogPanel.RIGHT);
    bar.add(this.rsize0 = DialogPanel.createNumberInput("0"));
    this.rsize0.setFont(DialogPanel.BOLD);
    bar.add(this.rsize1 = DialogPanel.createNumberInput("1"));
    this.rsize1.setFont(DialogPanel.BOLD);
    bar.add(this.rsize2 = DialogPanel.createNumberInput("1"));
    this.rsize2.setFont(DialogPanel.BOLD);
    tab.addHelp("Cluster size regularization introduces a tendency "
               +"towards\nequally sized clusters (positive value) "
               +"or limits the size ratio\nof the largest to the "
               +"smallest cluster radius (negative value).\n"
               +"The second parameter specifies how the size is "
               +"measured\n(stated as an exponent of the equivalent "
               +"isotropic radius).\nThe third parameter is a "
               +"scaling factor.");

    tab.addLabel("Weight regularization:");
    this.regwgt = tab.addNumberInput("0");
    tab.addHelp("Cluster weight regularization introduces a tendency "
               +"towards\nequally weighted clusters (positive value) "
               +"limits the weight\nratio of the heaviest to the "
               +"lightest cluster (negative value).\nThe weight "
               +"measures how many data points are covered.");
    tab.addFiller(8);
    tab.addHelp("Regularization is performed after each update step.");
    tab.addFiller(0);

    /* --- Induction --- */
    tab = this.addTab("Induction");

    tab.addLabel("Domains file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.getFileName(ClusterGUI.this.fn_dom); } } );
    tab.addButton("Edit", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.editDomains(ClusterGUI.this.fn_dom); } } );
    this.fn_dom = tab.addFileInput("noname.dom");
    tab.addHelp("The domains file may also be a cluster model "
               +"containing the\ndescription of an already induced "
               +"model. In this case the\nadaptation of this model "
               +"is continued (no reinitialization).");

    tab.addLabel("Target to exclude:           ");
    this.target = tab.addTextInput("");
    tab.addHelp("A target field must be excluded if the clustering "
               +"result is\nto be used for initializing "
               +"a radial basis function network.\nThe domain "
               +"description of the chosen target attribute is\n"
               +"written to the cluster model file, but not "
               +"used in the model.");

    tab.addLabel("Data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.getFileName(ClusterGUI.this.fn_tab); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.showTable(ClusterGUI.this.fn_tab); } } );
    this.fn_tab = tab.addFileInput("noname.tab");

    tab.addLabel("Cluster model file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.getFileName(ClusterGUI.this.fn_cls); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.showCluster(ClusterGUI.this.fn_cls,
                                    ClusterGUI.this.fn_tab); } } );
    this.fn_cls = tab.addFileInput("noname.cls");
    tab.addFiller(0);

    /* --- Execution --- */
    tab = this.addTab("Execution");

    tab.addLabel("Cluster model file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.getFileName(ClusterGUI.this.fn_exec); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.showCluster(ClusterGUI.this.fn_exec,
                                    ClusterGUI.this.fn_in); } } );
    this.fn_exec = tab.addFileInput("noname.cls");

    tab.addLabel("Input data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.getFileName(ClusterGUI.this.fn_in); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.showTable(ClusterGUI.this.fn_in); } } );
    this.fn_in = tab.addFileInput("noname.tab");

    tab.addLabel("Cluster index field name:");
    this.pred = tab.addTextInput("");
    tab.addHelp("By default the membership degrees "
               +"to all clusters are written.");

    tab.addLabel("Membership field name:");
    this.mship = tab.addTextInput("");

    tab.addLabel("Number output format:");
    this.outfmt = tab.addTextInput("%g");

    tab.addLabel("Write field names:");
    this.write = tab.addCheckBox(true);

    tab.addLabel("Output data file:");
    tab.addButton("Select", DialogPanel.MIDDLE).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.getFileName(ClusterGUI.this.fn_out); } } );
    tab.addButton("View", DialogPanel.RIGHT).addActionListener(
      new ActionListener () {
      public void actionPerformed (ActionEvent e) {
        ClusterGUI.this.showTable(ClusterGUI.this.fn_out); } } );
    this.fn_out = tab.addFileInput("noname.out");
    tab.addFiller(0);

    /* --- Terminal --- */
    this.addTerminalTab("Terminal output of external programs");

    /* --- About --- */
    this.addTab("About", new AboutPanel(
       "Fuzzy and Probabilistic Clustering Tools",
       "A simple user interface for the cluster programs.\n\n"
      +"Version " +ClusterGUI.VERSION +"\n"
      +"written by Christian Borgelt\n"
      +"European Center for Soft Computing\n"
      +"c/ Gonzalo Gutierrez Quiros s/n\n"
      +"33600 Mieres, Asturias, Spain\n"
      +"christian@borgelt.net"));

    /* --- finalize --- */
    this.pack();
    this.selectTab(INDUCTION);
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Show a cluster model.
   *  @param  model the text field with the cluster model file name
   *  @param  data  the text field with the data file name
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showCluster (JTextField model, JTextField data)
  { this.showCluster(new File(model.getText()),
                     new File( data.getText())); }

  /*------------------------------------------------------------------*/
  /** Show a cluster model.
   *  @param  model the file to load the cluster model tree from
   *  @param  data  the file to load the table data from
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void showCluster (File model, File data)
  {                             /* --- show a cluster model */
    String cmd[] = new String[3];
    cmd[0] = System.getProperty("os.name").startsWith("Windows")
           ? "wbcview" : "xbcview";
    cmd[1] = model.getPath();
    cmd[2] = data.getPath();
    try { Runtime.getRuntime().exec(cmd); }
    catch (IOException e) {     /* try to start the process */
      System.err.println(e.getMessage()); }
  }  /* showCluster() */

  /*------------------------------------------------------------------*/
  /** Set the domains file.
   *  @param  file the domains file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDomainsFile (File file)
  {                             /* --- set the domains file */
    this.domains.setDomainsFile(file);
    this.fn_dom.setText(file.getPath());
  }  /* setDomainsFile() */

  /*------------------------------------------------------------------*/
  /** Set the data file.
   *  @param  file the data file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setDataFile (File file)
  {                             /* --- set the data file */
    this.domains.setDataFile(file);
    this.fn_tab.setText(file.getPath());
  }  /* setDataFile() */

  /*------------------------------------------------------------------*/
  /** Set the test file.
   *  @param  file the test file to set
   *  @since  2007.07.24 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void setTestFile (File file)
  { this.fn_in.setText(file.getPath()); }

  /*------------------------------------------------------------------*/
  /** Create a command to induce a Bayes classifier.
   *  @return the command to inducea Bayes classifier
   *  @since  2007.06.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createInductionCmd ()
  {                             /* --- induce a Bayes classifier */
    int      n = 0, i;          /* number of arguments, buffer */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s, p, q;           /* buffers for arguments */

    cmd    = new String[48];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"cli";
    n = this.format.addFormatArgs(cmd);
    cmd[n++] = "-c" +this.clscnt.getValue();
                                /* number of clusters */
    if (this.radial.getSelectedIndex() > 0)
      cmd[n++] = "-G";          /* radial function type */
    s = this.param0.getText().trim();
    if (s.length() <= 0) s = "1";
    p = this.param1.getText().trim();
    if (p.length() <= 0) p = "0";
    cmd[n++] = "-p" +s +":" +p; /* radial function parameters */
    i = this.shape.getSelectedIndex();
    if      (i == 1) cmd[n++] = "-v";  /* adaptable variances */
    else if (i == 2) cmd[n++] = "-V";  /* adaptable covariances */
    if (this.size.isSelected())
      cmd[n++] = "-Z";          /* adaptable size */
    if (this.joint.isSelected())
      cmd[n++] = "-j";          /* joint size/shape parameters */
    if (this.weights.isSelected())
      cmd[n++] = "-w";          /* adaptable weights */
    if (this.uinteg.isSelected())
      cmd[n++] = "-N";          /* normalize to unit integral */
    i = this.centers.getSelectedIndex();
    if      (i == 1) cmd[n++] = "-1";  /* unit length centers */
    else if (i == 2) cmd[n++] = "-0";  /* fix centers at origin */
    s = this.noise.getText().trim();   /* membership to noise cluster */
    if (s.length() > 0) cmd[n++] = "-y" +s;
    s = this.trans0.getText().trim(); if (s.length() <= 0) s = "1";
    p = this.trans1.getText().trim(); if (p.length() <= 0) p = "0";
    cmd[n++] = "-J" +s +":" +p; /* membership transformation params. */
    i = this.norm.getSelectedIndex();  /* normalization mode */
    cmd[n++] = "-E" +ClusterGUI.nrmcodes[i];
    s = this.msexp.getText().trim(); if (s.length() <= 0) s = "1";
    cmd[n++] = "-x" +s;         /* membership exponent */
    s = this.ftexp.getText().trim(); if (s.length() <= 0) s = "0";
    cmd[n++] = "-F" +s;         /* feature weight exponent */
    i = this.init.getSelectedIndex();  /* initialization mode */
    cmd[n++] = "-i" +ClusterGUI.inicodes[i];
    s = this.range.getText().trim();   /* random offset range */
    if (s.length() > 0) cmd[n++] = "-o" +s;
    s = this.radius.getText().trim();  /* initial cluster radius */
    if (s.length() > 0) cmd[n++] = "-I" +s;
    s = this.seed.getText().trim();    /* seed for random numbers */
    if (s.length() > 0) cmd[n++] = "-S" +s;
    cmd[n++] = "-e" +this.epochs.getValue();
                                /* maximum number of epochs */
    cmd[n++] = "-Y" +this.conly.getValue();
                                /* number of epochs centers only */
    cmd[n++] = "-k" +this.ptcnt.getValue();
                                /* number of points between updates */
    if (!this.shuffle.isSelected())
      cmd[n++] = "-s";          /* do not shuffle between updates */
    if (!this.irnorm.isSelected())
      cmd[n++] = "-q";          /* normalize input ranges */
    i = this.update.getSelectedIndex();  /* update method */
    cmd[n++] = "-a" +ClusterGUI.updcodes[i];
    i = this.modif.getSelectedIndex();
    if (i > 0) {                /* update modifier */
      cmd[n++] = "-A" +ClusterGUI.modcodes[i];
      if (this.modctr.isSelected())
        cmd[n++] = "-K";        /* modifier for centers only */
      s = this.lrate0.getText().trim(); if (s.length() <= 0) s = "0";
      p = this.lrate1.getText().trim(); if (p.length() <= 0) p = "0";
      q = this.lrate2.getText().trim(); if (q.length() <= 0) q = "0";
      cmd[n++] = "-t" +s +":" +p +":" +q;  /* learning rates */
      s = this.decay0.getText().trim(); if (s.length() <= 0) s = "0";
      p = this.decay1.getText().trim(); if (p.length() <= 0) p = "0";
      q = this.decay2.getText().trim(); if (q.length() <= 0) q = "0";
      cmd[n++] = "-D" +s +":" +p +":" +q;  /* learning rates */
      s = this.moment.getText().trim();    /* momentum coefficient */
      if (s.length() > 0) cmd[n++] = "-m" +s;
      s = this.growth.getText().trim(); if (s.length() <= 0) s = "1";
      p = this.shrink.getText().trim(); if (p.length() <= 0) p = "1";
      cmd[n++] = "-g" +s +":" +p;      /* growth and shrink factor */
      p = this.maxchg.getText().trim(); if (p.length() <= 0) p = "2";
      cmd[n++] = "-z" +p;              /* maximal change/factor */
    }
    s = this.term.getText().trim();    /* change for termination */
    if (s.length() > 0) cmd[n++] = "-T" +s;
    s = this.rshape.getText().trim();  /* shape regularization */
    if (s.length() > 0) cmd[n++] = "-H" +s;
    s = this.rsize0.getText().trim(); if (s.length() <= 0) s = "0";
    p = this.rsize1.getText().trim(); if (p.length() <= 0) p = "1";
    q = this.rsize2.getText().trim(); if (q.length() <= 0) q = "1";
    cmd[n++] = "-R" +s +":" +p +":" +q;  /* size regularization */
    s = this.regwgt.getText().trim();  /* weight regularization */
    if (s.length() > 0) cmd[n++] = "-W" +s;
    s = this.target.getText().trim();  /* target attribute to exclude */
    if (s.length() > 0) cmd[n++] = "-X" +s;
    cmd[n++] = this.fn_dom.getText();
    cmd[n++] = this.fn_tab.getText();
    cmd[n++] = this.fn_cls.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createInductionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Create a command to execute a multilayer perceptron.
   *  @return the command to execute a multilayer perceptron
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private String[] createExecutionCmd ()
  {                             /* --- execute a Bayes classifier */
    int      n = 0;             /* number of arguments */
    String[] cmd;               /* command and arguments */
    File     path;              /* the path to the programs */
    String   s;                 /* buffer for arguments */

    cmd    = new String[20];    /* create a command array */
    path   = this.getPath();    /* and get the program path */
    cmd[0] = ((path != null) ? path +File.separator : "") +"clx";
    n = this.format.addFormatArgs(cmd);
    s = this.pred.getText();    /* prediction field name */
    if (s.length() > 0) cmd[n++] = "-c" +s;
    s = this.mship.getText();   /* membership field name */
    if (s.length() > 0) cmd[n++] = "-m" +s;
    s = this.outfmt.getText();  /* output number format */
    if (s.length() > 0) cmd[n++] = "-o" +s;
    if (!this.write.isSelected())
      cmd[n++] = "-w";          /* do not write field names */
    cmd[n++] = this.fn_exec.getText();
    cmd[n++] = this.fn_in.getText();
    cmd[n++] = this.fn_out.getText();
    return TabbedGUI.shrinkCmd(cmd, n);
  }  /* createExecutionCmd() */ /* build and return the command */

  /*------------------------------------------------------------------*/
  /** Get command for the current dialog tab.
   *  @return the command to execute
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected Executor createExecutor (int i)
  {                             /* --- get a dialog tab executor */
    String[]   cmd;             /* command for external program */
    Executable obj;             /* executable object */

    if (this.domains.useExternal()) {
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS  : cmd = this.createDomainsCmd();     break;
        case CLUSTERS : case MEMSHIPS: case INIT:
        case POINTS   : case UPDATE  : case REGULAR:
        case INDUCTION: cmd = this.createInductionCmd();   break;
        case EXECUTION: cmd = this.createExecutionCmd();   break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new CmdExecutor(cmd, this); }
    else {                      /* if to use internal programs */
      switch (i) {              /* evaluate the dialog tab */
        case DOMAINS: obj = this.createDomainsObj(); break;
        default: return null;   /* create the object to execute, */
      }                         /* return null if not executable */
      return new ObjExecutor(obj, this);
    }                           /* create and return the executor */
  }  /* createExecutor() */

  /*------------------------------------------------------------------*/
  /** Get the result message on successful termination.
   *  @return the result message
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected String getResultMsg ()
  {                             /* --- get result message */
    if (this.index == DOMAINS)  /* if domain determination */
      return this.getDomainsMsg();
    if ((this.index >= CLUSTERS)/* if cluster model induction */
    &&  (this.index <= INDUCTION)) {
      String msg = ((CmdExecutor)this.executor).getErrorData();
      int    i   = msg.lastIndexOf("inducing clusters ... [");
      i = msg.indexOf("[", i);  /* extract epoch information */
      return "Cluster model induced\nin "
           + msg.substring(i+1, msg.indexOf("]", i)) +".";
    }                           /* extract model description */
    if (this.index == EXECUTION)/* if cluster model execution */
      return "Cluster model successfully executed.";
    return null;                /* otherwise there is no message */
  }  /* getResultMsg() */

  /*------------------------------------------------------------------*/
  /** Load a configuration file and set the input fields.
   *  @param  file the file to load the configuration from
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void loadConfig (File file)
  {                             /* --- load configuration file */
    if (file == null) {         /* if no file name is given */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Load Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileReader reader = new FileReader(file);
      /* --- Format & Domains --- */
      this.format.loadConfig(reader);
      this.domains.loadConfig(reader);
      /* --- text parameters --- */
      /* --- Clusters --- */
      this.param0.setText (this.readLine(reader));
      this.param1.setText (this.readLine(reader));
      /* --- Memberships --- */
      this.noise.setText  (this.readLine(reader));
      this.trans0.setText (this.readLine(reader));
      this.trans1.setText (this.readLine(reader));
      this.msexp.setText  (this.readLine(reader));
      this.ftexp.setText  (this.readLine(reader));
      /* --- Initialization --- */
      this.range.setText  (this.readLine(reader));
      this.radius.setText (this.readLine(reader));
      this.seed.setText   (this.readLine(reader));
      /* --- Update --- */
      this.lrate0.setText (this.readLine(reader));
      this.lrate1.setText (this.readLine(reader));
      this.lrate2.setText (this.readLine(reader));
      this.decay0.setText (this.readLine(reader));
      this.decay1.setText (this.readLine(reader));
      this.decay2.setText (this.readLine(reader));
      this.term.setText   (this.readLine(reader));
      /* --- Modifiers --- */
      this.moment.setText (this.readLine(reader));
      this.growth.setText (this.readLine(reader));
      this.shrink.setText (this.readLine(reader));
      this.maxchg.setText (this.readLine(reader));
      /* --- Regularization --- */
      this.rshape.setText (this.readLine(reader));
      this.rsize0.setText (this.readLine(reader));
      this.rsize1.setText (this.readLine(reader));
      this.rsize2.setText (this.readLine(reader));
      this.regwgt.setText (this.readLine(reader));
      /* --- Induction --- */
      this.fn_dom.setText (this.readLine(reader));
      this.fn_tab.setText (this.readLine(reader));
      this.fn_cls.setText (this.readLine(reader));
      this.target.setText (this.readLine(reader));
      /* --- Execution --- */
      this.fn_exec.setText(this.readLine(reader));
      this.fn_in.setText  (this.readLine(reader));
      this.fn_out.setText (this.readLine(reader));
      this.pred.setText   (this.readLine(reader));
      this.mship.setText  (this.readLine(reader));
      this.outfmt.setText (this.readLine(reader));
      /* --- flags & indices --- */
      /* --- Clusters --- */
      this.clscnt.setValue(Integer.valueOf(this.readInt(reader)));
      this.radial.setSelectedIndex (this.readInt(reader));
      this.shape.setSelectedIndex  (this.readInt(reader));
      this.size.setSelected        (this.readInt(reader) != 0);
      this.joint.setSelected       (this.readInt(reader) != 0);
      this.weights.setSelected     (this.readInt(reader) != 0);
      this.uinteg.setSelected      (this.readInt(reader) != 0);
      this.centers.setSelectedIndex(this.readInt(reader));
      /* --- Memberships --- */
      this.norm.setSelectedIndex   (this.readInt(reader));
      /* --- Initialization --- */
      this.init.setSelectedIndex   (this.readInt(reader));
      /* --- Data Points --- */
      this.epochs.setValue(Integer.valueOf(this.readInt(reader)));
      this.conly.setValue (Integer.valueOf(this.readInt(reader)));
      this.ptcnt.setValue (Integer.valueOf(this.readInt(reader)));
      this.shuffle.setSelected     (this.readInt(reader) != 0);
      this.irnorm.setSelected      (this.readInt(reader) != 0);
      /* --- Update --- */
      this.update.setSelectedIndex (this.readInt(reader));
      /* --- Modifiers --- */
      this.modif.setSelectedIndex  (this.readInt(reader));
      this.modctr.setSelected      (this.readInt(reader) != 0);
      /* --- Execution --- */
      this.write.setSelected       (this.readInt(reader) != 0);
      reader.close(); }         /* read the configuration values */
    catch (IOException e) {     /* and close the input file */
      JOptionPane.showMessageDialog(this,
        "Error reading configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* check for successful reading */
    this.status.setText("configuration loaded: " +file.getName());
  }  /* loadConfig() */

  /*------------------------------------------------------------------*/
  /** Save a configuration file
   *  @param  file the file to save the current configuration to
   *  @since  2007.07.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected void saveConfig (File file)
  {                             /* --- save configuration file */
    if (file == null) {         /* if no file name is given, */
      JFileChooser c = this.getFileChooser();
      c.setDialogTitle("Save Configuration...");
      int r = c.showOpenDialog(this);
      if (r != JFileChooser.APPROVE_OPTION) return;
      file = c.getSelectedFile();
    }                           /* let the user choose a file */
    try {                       /* open the configuration file */
      FileWriter writer = new FileWriter(file);
      /* --- Format & Domains --- */
      this.format.saveConfig(writer);
      this.domains.saveConfig(writer);
      /* --- text parameters --- */
      /* --- Clusters --- */
      writer.write(this.param0.getText());  writer.write('\n');
      writer.write(this.param1.getText());  writer.write('\n');
      /* --- Memberships --- */
      writer.write(this.noise.getText());   writer.write('\n');
      writer.write(this.trans0.getText());  writer.write('\n');
      writer.write(this.trans1.getText());  writer.write('\n');
      writer.write(this.msexp.getText());   writer.write('\n');
      writer.write(this.ftexp.getText());   writer.write('\n');
      /* --- Initialization --- */
      writer.write(this.range.getText());   writer.write('\n');
      writer.write(this.radius.getText());  writer.write('\n');
      writer.write(this.seed.getText());    writer.write('\n');
      /* --- Update --- */
      writer.write(this.lrate0.getText());  writer.write('\n');
      writer.write(this.lrate1.getText());  writer.write('\n');
      writer.write(this.lrate2.getText());  writer.write('\n');
      writer.write(this.decay0.getText());  writer.write('\n');
      writer.write(this.decay1.getText());  writer.write('\n');
      writer.write(this.decay2.getText());  writer.write('\n');
      writer.write(this.term.getText());    writer.write('\n');
      /* --- Modifiers --- */
      writer.write(this.moment.getText());  writer.write('\n');
      writer.write(this.growth.getText());  writer.write('\n');
      writer.write(this.shrink.getText());  writer.write('\n');
      writer.write(this.maxchg.getText());  writer.write('\n');
      /* --- Regularization --- */
      writer.write(this.rshape.getText());  writer.write('\n');
      writer.write(this.rsize0.getText());  writer.write('\n');
      writer.write(this.rsize1.getText());  writer.write('\n');
      writer.write(this.rsize2.getText());  writer.write('\n');
      writer.write(this.regwgt.getText());  writer.write('\n');
      /* --- Induction --- */
      writer.write(this.fn_dom.getText());  writer.write('\n');
      writer.write(this.fn_tab.getText());  writer.write('\n');
      writer.write(this.fn_cls.getText());  writer.write('\n');
      writer.write(this.target.getText());  writer.write('\n');
      /* --- Execution --- */
      writer.write(this.fn_exec.getText()); writer.write('\n');
      writer.write(this.fn_in.getText());   writer.write('\n');
      writer.write(this.fn_out.getText());  writer.write('\n');
      writer.write(this.pred.getText());    writer.write('\n');
      writer.write(this.mship.getText());   writer.write('\n');
      writer.write(this.outfmt.getText());  writer.write('\n');
      /* --- flags & indices --- */
      /* --- Clusters --- */
      writer.write(((Integer)this.clscnt.getValue()).intValue() +",");
      writer.write(this.radial.getSelectedIndex() +",");
      writer.write(this.shape.getSelectedIndex()  +",");
      writer.write(this.size.isSelected()    ? "1," : "0,");
      writer.write(this.joint.isSelected()   ? "1," : "0,");
      writer.write(this.weights.isSelected() ? "1," : "0,");
      writer.write(this.uinteg.isSelected()  ? "1," : "0,");
      writer.write(this.centers.getSelectedIndex() +",");
      /* --- Memberships --- */
      writer.write(this.norm.getSelectedIndex() +",");
      /* --- Initialization --- */
      writer.write(this.init.getSelectedIndex() +",");
      /* --- Data Points --- */
      writer.write(((Integer)this.epochs.getValue()).intValue() +",");
      writer.write(((Integer)this.conly.getValue()).intValue()  +",");
      writer.write(((Integer)this.ptcnt.getValue()).intValue()  +",");
      writer.write(this.shuffle.isSelected() ? "1," : "0,");
      writer.write(this.irnorm.isSelected()  ? "1," : "0,");
      /* --- Update --- */
      writer.write(this.update.getSelectedIndex() +",");
      /* --- Modifiers --- */
      writer.write(this.modif.getSelectedIndex()  +",");
      writer.write(this.modctr.isSelected()  ? "1," : "0,");
      /* --- Execution --- */
      writer.write(this.write.isSelected()   ? "1," : "0,");
      writer.write('\n');       /* write the configuration values */
      writer.close(); }         /* and close the output file */
    catch (IOException e) {     /* check for successful writing */
      JOptionPane.showMessageDialog(this,
        "Error writing configuration file:\n" +e.getMessage(),
        "Error", JOptionPane.ERROR_MESSAGE);
    }                           /* show a status message */
    this.status.setText("configuration saved: " +file.getName());
  }  /* saveConfig() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @param  args the command line arguments
   *  @since  2007.02.12 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function */
    ClusterGUI gui = new ClusterGUI();
    if (args.length > 0)        /* load configuration if necessary */
      gui.loadConfig(new File(args[0]));
    gui.setVisible(true);       /* show the user interface */
  }  /* main() */

}  /* class ClusterGUI */
