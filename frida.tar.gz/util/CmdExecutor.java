/*----------------------------------------------------------------------
  File    : CmdExecutor.java
  Contents: execute an external command as a process
  Author  : Christian Borgelt
  History : 2007.02.10 file created as Runner.java
            2007.05.02 renamed to CmdExecutor.java
            2007.05.03 adapted to abstract class Executor
            2007.05.08 function run() considerably restructured
            2007.05.18 proper treatment of backspace added
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package util;

import java.io.IOException;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*--------------------------------------------------------------------*/
/** Class for executing an external program as a process.
 *  <p>If the process cannot be created, is aborted, is externally
 *  interrupted, or terminates normally or with failure, a listener
 *  function is notified, with an identifier of the event that
 *  occurred. The exit value of the process can be retrieved with
 *  <code>getResult()</code> as an <code>Integer</code>.</p>
 *  <p>The output of the process (<code>stdout</code> and
 *  <code>stderr</code>) is copied and also stored in internal
 *  buffers, which can be accessed to check the process result.</p>
 *  @author Christian Borgelt
 *  @since  2007.02.10 */
/*--------------------------------------------------------------------*/
public class CmdExecutor extends Executor {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the external command to execute */
  private String[]          command = null;
  /** the process executing the external command */
  private Process           process = null;
  /** the reader for the output stream of the process */
  private InputStreamReader outsrdr = null;
  /** the reader for the output stream of the process */
  private InputStreamReader errsrdr = null;
  /** the output stream data of the process */
  private StringBuilder     outdata = null;
  /** the error  stream data of the process */
  private StringBuilder     errdata = null;
  /** the exit value of the program */
  private int               exit    = 0;

  /*------------------------------------------------------------------*/
  /** Create a command executor.
   *  <p>On termination, the listener is notified. The identifier of
   *  the action event that is passed to the listener is <p>OK</p> if
   *  the process terminated successfully, <code>ABORTED</code> if
   *  the process was aborted by a call to the <code>abort()</code>
   *  function, <code>INTERRUPTED</code> if the process was externally
   *  interrupted, and <code>FAILED</code> if the process could not
   *  be started it returned a non-zero exit code.</p>
   *  @param  command  the command to be executed
   *  @param  listener the listener to be notified on termination
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public CmdExecutor (String[] command, ActionListener listener)
  {                             /* --- create a program runner */
    this.command  = command;    /* note the command and */
    this.listener = listener;   /* the action listener */
    this.status   = IDLE;       /* the program has not been started */
    this.aborted  = false;      /* and not been aborted either */
    this.message  = null;       /* there is no result message yet */
    this.process  = null;       /* there is no process yet */
    this.exit     = 0;          /* and thus no process data */
    this.outsrdr  = this.errsrdr = null;
    this.outdata  = this.errdata = null;
  }  /* CmdExecutor() */

  /*------------------------------------------------------------------*/
  /** Copy the output and error streams.
   *  @since  2007.05.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private void copyStreams () throws IOException
  {                             /* --- copy output and error stream */
    int c, n;                   /* character, number of characters */

    n = this.errdata.length();  /* get current length of output */
    while (this.errsrdr.ready()) {
      c = this.errsrdr.read();  /* read the next character */
      if (c < 0) break;         /* and append it to the buffer */
      if (c == '\b') this.errdata.setLength(--n);
      else {    n++; this.errdata.append((char)c); }
      System.err.print((char)c);
    }                           /* copy the error stream */
    n = this.outdata.length();  /* get current length of output */
    while (this.outsrdr.ready()) {
      c = this.outsrdr.read();  /* read the next character */
      if (c < 0) break;         /* and append it to the buffer */
      if (c == '\b') this.outdata.setLength(--n);
      else {    n++; this.outdata.append((char)c); }
      System.out.print((char)c);
    }                           /* copy the output stream */
  }  /* copyStreams() */

  /*------------------------------------------------------------------*/
  /** Function for thread execution.
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- execute an external program */
    if (this.status == RUNNING) return;
    this.status  = RUNNING;     /* set the status to running */
    this.aborted = false;       /* and not aborted */
    this.message = null;        /* clear the status message */
    this.exit    = 0;           /* and the exit code */
    try { this.process = Runtime.getRuntime().exec(this.command); }
    catch (IOException e) {     /* try to start the process */
      this.status  = FAILED;    /* and check for success */
      this.message = e.getMessage();
      if (this.listener != null)
        this.listener.actionPerformed(
          new ActionEvent(this, this.status, this.message));
      return;                   /* notify listener on failure, */
    }                           /* then abort the function */
    this.outsrdr = new InputStreamReader(this.process.getInputStream());
    this.errsrdr = new InputStreamReader(this.process.getErrorStream());
    this.outdata = new StringBuilder();
    this.errdata = new StringBuilder();
    while (this.status == RUNNING) {
      if (this.aborted) {       /* if internal abort, */
        this.process.destroy(); /* destroy the process, */
        this.status = ABORTED;  /* set aborted status, */
        break;                  /* and abort the loop */
      }
      try {                     /* loop to watch process execution */
        Thread.sleep(100);      /* wait for some time (0.1 seconds) */
        this.copyStreams();     /* copy the output and error stream */
        this.exit = this.process.exitValue();
        this.copyStreams();     /* poll exit value and copy streams */
        if (this.exit == 0)     /* if the exit code is zero, */
          this.status  = OK;    /* set success status (no message) */
        else {                  /* if the exit code is non-zero, */
          this.status  = FAILED;/* set failure status and message */
          this.message = this.getLastErrorLine();
        } }
      catch (IOException e) {   /* if an i/o error occurred, */
        this.process.destroy(); /* destroy the process and */
        this.status  = FAILED;  /* set failure status and message */
        this.message = e.getMessage(); }
      catch (InterruptedException e) {
        this.status  = INTERRUPTED;  /* if external interrupt */
        this.message = e.getMessage(); }
      catch (IllegalThreadStateException e)
        { }                     /* if the process is still running, */
    }                           /* do nothing */
    this.process = null;        /* delete the process */
    if (this.listener != null)  /* notify the listener */
      this.listener.actionPerformed(
        new ActionEvent(this, this.status, this.message));
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Get the command to execute as a process.
   *  @return the command to execute as a process
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String[] getCommand ()
  { return this.command; }

  /*------------------------------------------------------------------*/
  /** Get the exit value of the executed command.
   *  <p>The exit value of the command is available only after the
   *  process terminated, that is, after the status of the executor
   *  has changed to either <code>OK</code> or <code>FAILED</code>.
   *  Note that in case the command could not be started (and thus
   *  could not produce an exit value), this function returns 0.</p>
   *  @return the exit value of the executed command
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int exitValue ()
  { return this.exit; }

  /*------------------------------------------------------------------*/
  /** Get the output stream data of the process.
   *  <p>This function may be called any time and yields the output
   *  of the process (to the standard output stream) that has been
   *  generated up to that point. If the process has not been started
   *  yet, the result is <code>null</code>.</p>
   *  @return the output stream data of the process as a string
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getOutputData ()
  { return (this.outdata != null) ? this.outdata.toString() : null; }

  /*------------------------------------------------------------------*/
  /** Get the last line of the output stream data of the process.
   *  @return the last line of the output stream data of the process
   *  @see    #getOutputData()
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getLastOutputLine ()
  {                             /* --- get the last output line */
    int i, k;                   /* indices in error stream data */

    if (this.outdata == null) return "";
    k = this.outdata.length();  /* check for empty output */
    if (k <= 0) return "";      /* and for '\n' at the end */
    if (this.outdata.charAt(k-1) == '\n') k--;
    i = this.outdata.lastIndexOf("\n", k-1);
    return this.outdata.substring(i+1, k);
  }  /* getLastOutputLine() */  /* extract last line (without '\n') */

  /*------------------------------------------------------------------*/
  /** Get the error stream data of the process.
   *  <p>This function may be called any time and yields the output
   *  of the process (to the standard error stream) that has been
   *  generated up to that point. If the process has not been started
   *  yet, the result is <code>null</code>.</p>
   *  @return the error stream data of the process as a string
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getErrorData ()
  { return (this.errdata != null) ? this.errdata.toString() : null; }

  /*------------------------------------------------------------------*/
  /** Get the last line of the error stream data of the process.
   *  @return the last line of the error stream data of the process
   *  @see    #getErrorData()
   *  @since  2007.02.10 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getLastErrorLine ()
  {                             /* --- get the last error output line */
    int i, k;                   /* indices in error stream data */

    if (this.errdata == null) return "";
    k = this.errdata.length();  /* check for empty output */
    if (k <= 0) return "";      /* and for '\n' at the end */
    if (this.errdata.charAt(k-1) == '\n') k--;
    i = this.errdata.lastIndexOf("\n", k-1);
    return this.errdata.substring(i+1, k);
  }  /* getLastErrorLine() */   /* extract last line (without '\n') */

}  /* class CmdExecutor */
