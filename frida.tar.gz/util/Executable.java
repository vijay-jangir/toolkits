/*----------------------------------------------------------------------
  File    : Executable.java
  Contents: interface for an executable object
  Author  : Christian Borgelt
  History : 2007.05.03 file created
----------------------------------------------------------------------*/
package util;

/*--------------------------------------------------------------------*/
/** Interface for an executable object.
 *  @author Christian Borgelt
 *  @since  2007.05.03 */
/*--------------------------------------------------------------------*/
public interface Executable {

  /*------------------------------------------------------------------*/
  /** Execute the object.
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void exec () throws Exception;

  /*------------------------------------------------------------------*/
  /** Abort the execution.
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void abort ();

}  /* class Executable */
