/*----------------------------------------------------------------------
  File    : IdMap.java
  Contents: Specialized map for keys to identifiers and vice versa
  Author  : Christian Borgelt
  History : 2006.09.11 file created
            2006.10.06 replace, reorder, and cloning added
            2006.10.17 removal of keys added (function remove())
            2006.11.02 comparison of hash values added
            2007.01.31 clear() and move() and associated values added
            2007.04.13 mode for reacting to adding an existing key added
            2007.05.17 bug in function clone() fixed
            2007.07.19 bug in function move()  fixed
            2007.07.25 function sort() added
            2017.06.14 functions getMapFrom() and getMapTo() added
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package util;

import java.util.Arrays;
import java.util.Comparator;

/*--------------------------------------------------------------------*/
/** Internal class to manage elements of identifier maps.
 *  @author Christian Borgelt
 *  @since  2006.09.11 */
/*--------------------------------------------------------------------*/
class IdMapElem implements Cloneable, Comparable<IdMapElem> {

  private static final long serialVersionUID = 0x00010000L;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the key to associate with an identifier */
  protected Object    key;
  /** the identifier associated with the key */
  protected int       id;
  /** the value to associate with a key/identifier */
  protected Object    value;
  /** the hashcode of the key */
  protected int       hash;
  /** the successor in hash bin list */
  protected IdMapElem succ;

  /*------------------------------------------------------------------*/
  /** Create an element of an identifier map.
   *  @param  key   the key to associate with an identifier
   *  @param  id    the identifier associated with the key
   *  @param  value the value to associate with a key/identifier
   *  @param  hash  hash value of the key
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected IdMapElem (Object key, int id, Object value, int hash)
  {                             /* --- create a hash table element */
    this.key   = key;           /* note the key, */
    this.id    = id;            /* the associated identifier, */
    this.value = value;         /* the associated value, */
    this.hash  = hash;          /* and the object's hash code */
  }  /* IdMapElem() */

  /*------------------------------------------------------------------*/
  /** Clone this identifier map element.
   *  @return a clone of this identifier map element
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final Object clone ()
  { return new IdMapElem(this.key, this.id, this.value, this.hash); }

  /*------------------------------------------------------------------*/
  /** Compare this identifier map element to another.
   *  @return the sign of the difference of the identifiers of
   *          <code>this</code> and the given identifier map element
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int compareTo (IdMapElem obj)
  {                             /* --- compare two map elements */
    if (obj.id > this.id) return -1;
    if (obj.id < this.id) return +1;
    return 0;                   /* return sign of id difference */
  }  /* compareTo() */

}  /* class IdMapElem */


/*--------------------------------------------------------------------*/
/** Class to manage identifier maps.
 *  <p>With an identifier map a key can be mapped to an identifier
 *  (an integer value) and vice versa. In addition, an optional value
 *  may be associated with each key/identifier. When being added to
 *  the map, the keys are numbered consecutively, starting with 0.
 *  That is, the identifiers of the keys always range from 0 to
 *  <code>size()-1</code>.</p>
 *  @author Christian Borgelt
 *  @since  2006.09.11 */
/*--------------------------------------------------------------------*/
public class IdMap implements Cloneable, Comparator<Object> {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** when adding an existing key: replace old associated value */
  public    static final int REPLACE  = 0;
  /** when adding an existing key: reject key (return negative id) */
  public    static final int REJECT   = 1;
  /** a mask to ensure that the hash values are positive */
  protected static final int HASHMASK = Integer.MAX_VALUE;
  /** the block size for the inverse map array */
  protected static final int BLKSIZE  = 32;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the mode for reacting to adding an existing key to the map */
  protected int         mode;
  /** the maximum load factor */
  protected float       load;
  /** the maximum number of elements */
  protected int         max;
  /** the current number of elements */
  protected int         size;
  /** the array of hash bins */
  protected IdMapElem[] bins;
  /** the inverse map (identifier to key) */
  protected IdMapElem[] imap;
  /** the comparator for sorting the map */
  protected Comparator<Object> cmp;

  /*------------------------------------------------------------------*/
  /** Create an identifier map.
   *  @param  mode the mode for reacting to adding an existing key
   *  @param  init the initial size of the map (hash table size)
   *  @param  load the maximum load factor for the hash table
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public IdMap (int mode, int init, float load)
  {                             /* --- create identifier map */
    if (init < BLKSIZE) init = BLKSIZE;
    this.mode = mode;           /* note the parameters */
    this.max  = (int)(load *init);
    this.bins = new IdMapElem[init];
    this.imap = new IdMapElem[this.max];
    this.load = load;           /* create the hash bins and */
    this.size = 0;              /* initialize the fields */
  }  /* IdMap() */

  /*------------------------------------------------------------------*/
  /** Create an identifier map.
   *  @param  mode the mode for reacting to adding an existing key
   *  @param  init the initial size of the map (hash table size)
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public IdMap (int mode, int init)
  { this(mode, init, 0.75F); }

  /*------------------------------------------------------------------*/
  /** Create an identifier map.
   *  @param  mode the mode for reacting to adding an existing key
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public IdMap (int mode)
  { this(mode, 31, 0.75F); }

  /*------------------------------------------------------------------*/
  /** Create an identifier map.
   *  <p>Equivalent to <code>IdMap(REPLACE)</code>.</p>
   *  @since  2007.04.13 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public IdMap ()
  { this(REPLACE, 31, 0.75F); }

  /*------------------------------------------------------------------*/
  /** Clone this identifier map.
   *  <p>The created clone is a deep copy, with the exception of
   *  the keys and values that are associated with identifiers.</p>
   *  @return a clone of this identifier map
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object clone ()
  {                             /* --- clone an identifier map */
    int n = this.bins.length;   /* create a new identifier map */
    IdMap clone = new IdMap(this.mode, n, this.load);
    for (int k = 0; k < this.size; k++) {
      IdMapElem e = (IdMapElem)this.imap[k].clone();
      clone.imap[k] = e;        /* clone each map element and */
      int i = e.hash % n;       /* add it to the hash bin list */
      e.succ = clone.bins[i];   /* (note that there is no need for */
      clone.bins[i] = e;        /*  duplicate checks or rehashing) */
    }
    clone.size = this.size;     /* copy the size of the map */
    return clone;               /* return the created clone */
  }  /* clone() */

  /*------------------------------------------------------------------*/
  /** Clear the identifier map, that is, remove all keys/values.
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void clear ()
  {                             /* --- clear an identifier map */
    for (int i = this.bins.length; --i >= 0; )
      this.bins[i] = null;      /* clear all hash buckets */
    for (int i = this.size; --i >= 0; )
      this.imap[i] = null;      /* clear the inverse map */
    this.size = 0;              /* reinit. the number of elements */
  }  /* clear() */

  /*------------------------------------------------------------------*/
  /** Get the number of mappings in an identifier map.
   *  @return the number of key/identifier pairs stored
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int size ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Get the number of mappings in an identifier map.
   *  @return the number of key/identifier pairs stored
   *  @since  2017.06.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getSize ()
  { return this.size; }

  /*------------------------------------------------------------------*/
  /** Enlarge the hash bin array and rehash the map elements.
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final void rehash ()
  {                             /* --- reorganize the hash table */
    int n = (this.bins.length*2)+1; /* create a new hash table */
    this.bins = new IdMapElem[n];
    for (int i = this.size; --i >= 0; ) {
      IdMapElem e = this.imap[i];
      int k = e.hash % n;       /* traverse the inverse map */
      e.succ = this.bins[k];    /* add the element at the head */
      this.bins[k] = e;         /* of the appropriate hash bin list */
    }
    this.max = (int)(load *n);  /* compute a new maximum number */
  }  /* rehash() */             /* of elements for rehashing */

  /*------------------------------------------------------------------*/
  /** Add a key to an identifier map.
   *  <p>If the key is already present, no new mapping is added,
   *  but the identifier already associated with the key is
   *  returned, thus automatically avoiding duplicate entries.
   *  In addition, a possibly associated value is deleted.</p>
   *  @param  key the key to add to the map
   *  @return the identifier assigned to the key
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int add (Object key)
  { return this.add(key, null); }

  /*------------------------------------------------------------------*/
  /** Add a key/value pair to an identifier map.
   *  <p>If the key is already present, no new mapping is added,
   *  but the identifier already associated with the key is
   *  returned, thus automatically avoiding duplicate entries.
   *  In addition, the associated value is replaced.</p>
   *  @param  key   the key to add to the map
   *  @param  value the value associated with the key
   *  @return the identifier assigned to the key
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int add (Object key, Object value)
  {                             /* --- add a key to the map */
    int hash = key.hashCode() & HASHMASK;  /* traverse the */
    int i    = hash % this.bins.length;    /* hash bin list */
    IdMapElem e;                /* traverse the hash bin list */
    for (e = this.bins[i]; e != null; e = e.succ) {
      if ((hash == e.hash) && key.equals(e.key)) {
        if (this.mode == REJECT) return -1;
        e.value = value;         return e.id;
      }                         /* if the key exists, return its id */
    }                           /* or a negative value (reject) */
    e = new IdMapElem(key, this.size, value, hash);
    e.succ = this.bins[i];      /* create a new hash table element */
    this.bins[i] = e;           /* and add it to the hash bin list */
    if (this.size >= this.imap.length) {
      i = this.size +((this.size > BLKSIZE) ? this.size >> 1 : BLKSIZE);
      IdMapElem[] v = new IdMapElem[i];
      System.arraycopy(this.imap, 0, v, 0, this.size);
      this.imap = v;            /* enlarge the inverse map array and */
    }                           /* copy the existing map elements */
    this.imap[e.id] = e;        /* store the new map element */
    if (++this.size >= this.max)/* if the hash table has become */
      this.rehash();            /* too full, reorganize it */
    return e.id;                /* return assigned identifier */
  }  /* add() */

  /*------------------------------------------------------------------*/
  /** Look up the identifier associated with a key.
   *  @param  key the key for which to find the associated identifier
   *  @return the identifier assigned to the key or <code>-1</code>
   *          if the key is not contained in the map
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int get (Object key)
  {                             /* --- get identifier for an key */
    if (key == null) return -1; /* check for a null key */
    int hash = key.hashCode() & HASHMASK;  /* traverse the  */
    int i    = hash % this.bins.length;    /* hash bin list */
    for (IdMapElem e = this.bins[i]; e != null; e = e.succ)
      if ((hash == e.hash) && key.equals(e.key))
        return e.id;            /* if key was found, return its id */
    return -1;                  /* if key was not found, return -1 */
  }  /* get() */

  /*------------------------------------------------------------------*/
  /** Look up the identifier associated with a key.
   *  @param  key the key for which to find the associated identifier
   *  @return the identifier assigned to the key or <code>-1</code>
   *          if the key is not contained in the map
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getId (Object key)
  { return this.get(key); }

  /*------------------------------------------------------------------*/
  /** Look up the value associated with a key.
   *  @param  key the key for which to find the associated value
   *  @return the value associated with the identifier
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getValue (Object key)
  { int i = this.get(key); return (i < 0) ? null : this.imap[i].value; }

  /*------------------------------------------------------------------*/
  /** Look up the key associated with an identifier.
   *  @param  id identifier for which to find the associated key
   *  @return the key associated with the identifier
   *  @see    #getKey(int)
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object get (int id)
  { return this.imap[id].key; }

  /*------------------------------------------------------------------*/
  /** Look up the key associated with an identifier.
   *  @param  id identifier for which to find the associated key
   *  @return the key associated with the identifier
   *  @see    #get(int)
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getKey (int id)
  { return this.imap[id].key; }

  /*------------------------------------------------------------------*/
  /** Look up the value associated with an identifier.
   *  @param  id the identifier for which to find the associated value
   *  @return the value associated with the identifier
   *  @since  2006.09.11 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final Object getValue (int id)
  { return this.imap[id].value; }

  /*------------------------------------------------------------------*/
  /** Set the value associated with a key.
   *  @param  key   the key for which to find the associated value
   *  @param  value the value to associate with the key
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setValue (Object key, Object value)
  { int i = this.get(key); if (i >= 0) this.imap[i].value = value; }

  /*------------------------------------------------------------------*/
  /** Set the value associated with an identifier.
   *  @param  id    the identifier for which to set the value
   *  @param  value the value to associate with the identifier
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setValue (int id, Object value)
  { this.imap[id].value = value; }

  /*------------------------------------------------------------------*/
  /** Remove an identifier map element.
   *  @param  e the identifier map element to remove
   *  @since  2007.07.15 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  protected final void remove (IdMapElem e)
  {                             /* --- remove an id map element */
    this.size -= 1;             /* decrease the element counter */
    for (int i = e.id; i < this.size; i++) {
      e = this.imap[i] = this.imap[i+1];
      e.id = i;                 /* shift the succeeding elements */
    }                           /* and adapt their identifiers */
    this.imap[this.size] = null;/* clear the emptied array element */
  }  /* remove() */

  /*------------------------------------------------------------------*/
  /** Remove a key/value pair from an identifier map.
   *  <p>Note that by this operation the identifiers of keys with
   *  higher identifiers than the one to be removed will be reduced,
   *  in order to preserve consecutive identifiers.</p>
   *  @param  key the key to remove
   *  @since  2006.10.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void remove (Object key)
  {                             /* --- remove a key/value pair */
    if (key == null) return;    /* check for a null key */
    int hash = key.hashCode() & HASHMASK;
    int i    = hash % this.bins.length;
    IdMapElem e = this.bins[i]; /* get the corresponding bin list */
    IdMapElem p = null;         /* clear the predecessor buffer */
    while (true) {              /* traverse the hash bin list */
      if (e == null) return;    /* if key was not found, abort */
      if ((hash == e.hash) && key.equals(e.key)) break;
      p = e; e = e.succ;        /* if key was found, abort the loop */
    }                           /* otherwise go to the next element */
    if (p != null) p.succ = e.succ;  /* remove the element */
    else     this.bins[i] = e.succ;  /* from the hash bin list */
    this.remove(e);             /* remove element and adapt the ids */
  }  /* remove() */

  /*------------------------------------------------------------------*/
  /** Remove a key/value pair from an identifier map.
   *  <p>Note that by this operation the identifiers of keys with
   *  higher identifiers than the one to be removed will be reduced,
   *  in order to preserve consecutive identifiers.</p>
   *  @param  id the identifier of the key to remove
   *  @since  2006.10.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void remove (int id)
  {                             /* --- remove a key/value pair */
    IdMapElem x = this.imap[id];/* get map element and hash bin index */
    int       i = x.hash % this.bins.length;
    IdMapElem e = this.bins[i]; /* compute hashcode and get bin list */
    IdMapElem p = null;         /* clear the predecessor buffer */
    while (e != x) {            /* traverse the hash bin list */
      p = e; e = e.succ; }      /* until the list element is found */
    if (p != null) p.succ = e.succ;  /* remove the element */
    else     this.bins[i] = e.succ;  /* from the hash bin list */
    this.remove(e);             /* remove element and adapt the ids */
  }  /* remove() */

  /*------------------------------------------------------------------*/
  /** Rebuild hash table after removal of several key/value pairs.
   *  @return a map from the old (array indices) to the new key
   *          identifiers (content of array elements)
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  private final int[] rebuild ()
  {                             /* --- rebuild hash table */
    for (int i = this.bins.length; --i >= 0; )
      this.bins[i] = null;      /* clear the hash bins */
    int[] map = new int[this.size];
    int id = 0;                 /* create map to the new identifiers */
    for (int i = 0; i < this.size; i++) {
      if (this.imap[i] == null){/* if an element has been deleted, */
        map[i] = -1;            /* note that the new identifier */
        continue;               /* is -1 (indicating removal) */
      }                         /* if it has not been deleted */
      IdMapElem e = this.imap[i];
      this.imap[map[i] = e.id = id++] = e;
      int k = e.hash % this.bins.length;
      e.succ = this.bins[k];    /* add an element to keep */
      this.bins[k] = e;         /* to its hash bin list */
    }
    this.size = id;             /* set the new number of elements */
    return map;                 /* return old to new identifier map */
  }  /* rebuild() */

  /*------------------------------------------------------------------*/
  /** Remove several key/value pair from an identifier map.
   *  @param  ids the array of identifiers of the keys to remove
   *  @return a map from the old (array indices) to the new key
   *          identifiers (content of array elements)
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] remove (int[] ids)
  {                             /* --- remove multiple identifiers */
    for (int i = 0; i < ids.length; i++)
      this.imap[ids[i]] = null; /* clear the requested elements */
    return rebuild();           /* rebuild the identifier map */
  }  /* remove() */

  /*------------------------------------------------------------------*/
  /** Remove several key/value pair from an identifier map.
   *  @param  rem a flag array indicating the keys to remove
   *              (array index corresponds to identifier)
   *  @return a map from the old (array indices) to the new key
   *          identifiers (content of array elements)
   *  @since  2017.06.14 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] remove (boolean[] rem)
  {                             /* --- remove key/value pairs */
    for (int i = 0; i < this.imap.length; i++)
      if ((i < rem.length) && rem[i])
        this.imap[i] = null;    /* delete all requested elements */
    return rebuild();           /* rebuild the identifier map */
  }  /* remove() */

  /*------------------------------------------------------------------*/
  /** Replace a key in an identifier map.
   *  <p>It is assumed that a key equal to the replacing key
   *  (w.r.t. the function <code>equals()</code>) is not associated
   *  with another identifier in this map, because otherwise the map
   *  gets into an inconsistent state. However, replacing a key with
   *  itself or an equal key is harmless and thus permitted.</p>
   *  @param  id  the identifier of the key to replace
   *  @param  key the key to replace it with
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void replace (int id, Object key)
  {                             /* --- replace a key in the map */
    IdMapElem x = this.imap[id];/* get map element and hash bin index */
    int       i = x.hash % this.bins.length;
    if (this.bins[i] == x)      /* if first in hash bin list, */
      this.bins[i] = x.succ;    /* directly remove the element */
    else {                      /* if some later element, */
      IdMapElem e = this.bins[i];  /* traverse the hash bin list */
      while (e.succ != x) e = e.succ;
      e.succ = x.succ;          /* remove the element */
    }                           /* from the hash bin list */
    x.key  = key;               /* store the new key */
    x.hash = key.hashCode() & HASHMASK;
    i      = x.hash % this.bins.length;
    x.succ = this.bins[i];      /* insert the map element into */
    this.bins[i] = x;           /* the proper hash bin list */
  }  /* replace() */

  /*------------------------------------------------------------------*/
  /** Move a key in the identifier map.
   *  @param  src the current identifier of the key to move
   *  @param  dst the desired new identifier of the key
   *  @see    IdMap#reorder(int[])
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void move (int src, int dst)
  {                             /* --- move a key to a new identifier */
    if (src == dst) return;     /* check for actual movement */
    IdMapElem m = this.imap[src]; /* note the map element to move */
    if (dst >= src) {           /* if to move the element upwards */
      for (int i = src; ++i <= dst; ) {
        IdMapElem e = this.imap[i]; this.imap[e.id = i-1] = e; } }
    else {                      /* if to move the element downwards */
      for (int i = src; --i >= dst; ) {
        IdMapElem e = this.imap[i]; this.imap[e.id = i+1] = e; } }
    this.imap[m.id = dst] = m;  /* store element at new position */
  }  /* move() */

  /*------------------------------------------------------------------*/
  /** Reorder an identifier map.
   *  <p>Permute the identifiers, thus reordering the keys.
   *  The desired reordering has to be stated as a permutation of the
   *  integer numbers 0 to <code>size()-1</code>, with each entry
   *  stating the new value for the identifier that is the array index
   *  of the entry (forward map).</p>
   *  <p>If the reordering map is not such a permutation, the identifier
   *  map will get into an inconsistent state that may lead to serious
   *  errors.</p>
   *  @param  map an integer array containing a permutation of
   *              the integer numbers 0 to <code>size()-1</code>
   *  @see    IdMap#move(int,int)
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void reorder (int[] map)
  {                             /* --- reorder an identifier map */
    IdMapElem[] v = new IdMapElem[this.size];
    for (int i = this.size; --i >= 0; ) {
      IdMapElem e = this.imap[i];      /* traverse the map elements, */
      v[e.id = map[i]] = e;     /* move them to their new positions, */
    }                           /* and set their new identifiers */
    this.imap = v;              /* store the new inverse map */
  }  /* reorder() */

  /*------------------------------------------------------------------*/
  /** Compare two identifier map elements.
   *  @param  o1 first  element to compare
   *  @param  o2 second element to compare
   *  @return a negative integer, zero, or a positive integer
   *          as the first argument is less than, equal to, or
   *          greater than the second
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int compare (Object o1, Object o2)
  { return this.cmp.compare(((IdMapElem)o1).key, ((IdMapElem)o2).key); }

  /*------------------------------------------------------------------*/
  /** Reorder an identifier map.
   *  @param  cmp the comparator for the items
   *  @return a map from the old indices (array indices)
   *          to the new indices (contents of array elements)
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int[] sort (Comparator<Object> cmp)
  {                             /* --- sort an identifier map */
    this.cmp = cmp;             /* store comparator and sort array */
    Arrays.sort(this.imap, 0, this.size, this);
    int [] map = new int[this.size];
    for (int i = this.size; --i >= 0; ) {
      map[this.imap[i].id] = i; /* create a map that represents */
      this.imap[i].id = i;      /* the reordering of the key */
    }                           /* (map from old to new index) */
    return map;                 /* return the created map */
  }  /* sort() */

  /*------------------------------------------------------------------*/
  /** Get identifier mapping from another identifier map.
   *  <p>Identifiers that are present only in the identifier map given
   *  as an argument are added to this identifier map.</p>
   *  @param  idmap the other identifier map,
   *                from which to get the mapping
   *  @return an array that is indexed with identifiers referring
   *          to the identifier map given as an argument and contains
   *          identifiers referring to this identifier map
  /*------------------------------------------------------------------*/

  public final int[] getMapFrom (IdMap idmap)
  {                             /* --- get map from another IdMap */
    return idmap.getMapTo(this);
  }  /* getMapFrom() */

  /*------------------------------------------------------------------*/
  /** Get identifier mapping to another identifier map.
   *  <p>Identifiers that are present only in this identifier map are
   *  added to the identifier map given as an argument.</p>
   *  @param  idmap the other identifier map,
   *                to which to get the mapping
   *  @return an array that is indexed with identifiers referring
   *          to this identifier map and contains identifiers referring
   *          to the identifier map given as an argument
  /*------------------------------------------------------------------*/

  public final int[] getMapTo (IdMap idmap)
  {                             /* --- get map from another IdMap */
    int[] map = new int[this.size];
    for (int i = 0; i < this.size; i++) {
      map[i] = idmap.getId(this.imap[i].key);
      if (map[i] < 0)           /* get the corresponding identifier */
        map[i] = idmap.add(this.imap[i].key, this.imap[i].value);
    }                           /* if the key does not exist, add it */
    return map;                 /* return the created map array */
  }  /* getMapTo() */

}  /* class IdMap */
