/*----------------------------------------------------------------------
  File    : ASCIICoder.java
  Contents: encode and decode strings with ASCII escape sequences
  Author  : Christian Borgelt
  History : 2006.10.05 file created from file tfscan.c
            2016.04.07 StringBuffer replaced by StringBuilder
----------------------------------------------------------------------*/
package util;

/*--------------------------------------------------------------------*/
/** Class for encoding and decoding strings with ASCII escape sequences
 *  @author Christian Borgelt
 *  @since  2006.10.05 */
/*--------------------------------------------------------------------*/
public class ASCIICoder {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  private static final char[] hexdigits = {
   '0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f' };

  /*------------------------------------------------------------------*/
  /** Encode a string using ASCII escape sequences.
   *  @param  s the string to encode
   *  @return the string with all non-printable characters replaced
   *          by ASCII escape sequences
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String encode (String s)
  {                             /* --- encode a string */
    int           len, i;       /* string length, loop variable */
    int           c;            /* to traverse the characters */
    StringBuilder buf;          /* buffer for the encoding */

    if (s == null) return null; /* check for a null string */
    buf = new StringBuilder();  /* create an output buffer */
    for (len = s.length(), i = 0; i < len; i++) {
      c = s.charAt(i);          /* traverse the characters */
      if  (c == '\\')               { buf.append("\\\\");  continue; }
      if ((c >= ' ') && (c <= '~')) { buf.append((char)c); continue; }
      switch (c) {              /* evaluate the character */
        case 0x07: buf.append("\\a"); break;
        case 0x08: buf.append("\\b"); break;
        case 0x09: buf.append("\\t"); break;
        case 0x0a: buf.append("\\n"); break;
        case 0x0b: buf.append("\\v"); break;
        case 0x0c: buf.append("\\f"); break;
        case 0x0d: buf.append("\\r"); break;
        default  : buf.append("\\x");
                   buf.append(hexdigits[(c >> 4) & 0x0f]);
                   buf.append(hexdigits[ c       & 0x0f]); break;
      }                         /* encode as a hexadecimal */
    }                           /* escape sequence */
    return buf.toString();      /* return the encoded string */
  }  /* encode() */

  /*------------------------------------------------------------------*/
  /** Decode ASCII escape sequences in a string.
   *  @param  s the string to decode
   *  @return the string with all ASCII escape sequences
   *          replaced by their corresponding characters
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static String decode (String s)
  {                             /* --- decode a string */
    int           len, i;       /* string length, loop variable */
    int           c, code;      /* character and character code */
    StringBuilder buf;          /* buffer for the encoding */

    if (s == null) return null; /* check for a null string */
    buf = new StringBuilder();  /* create an output buffer */
    for (len = s.length(), i = 0; i < len; ) {
      c = s.charAt(i++);        /* traverse the characters */
      if (c != '\\') {          /* check for start of escape sequence */
        buf.append((char)c); continue; }
      c = (i >= len) ? -1 : s.charAt(i++);
      switch (c) {              /* evaluate the next character */
        case 'a': buf.append('\007'); break;  /* 0x07 (BEL) */
        case 'b': buf.append('\b');   break;  /* 0x08 (BS)  */
        case 'f': buf.append('\f');   break;  /* 0x0c (FF)  */
        case 'n': buf.append('\n');   break;  /* 0x0a (NL)  */
        case 'r': buf.append('\r');   break;  /* 0x0d (CR)  */
        case 't': buf.append('\t');   break;  /* 0x09 (HT)  */
        case 'v': buf.append('\013'); break;  /* 0x0b (VT)  */
        case '0': case '1': case '2': case '3':
        case '4': case '5': case '6': case '7':
          code = c -'0';        /* --- octal character code */
          c = (i >= len) ? -1 : s.charAt(i++);
          if ((c >= '0') && (c <= '7')) code = (code << 3) +c -'0';
          else { buf.append((char)code); continue; }
          c = (i >= len) ? -1 : s.charAt(i);
          if ((c >= '0') && (c <= '7')) code = (code << 3) +c -'0';
          else { buf.append((char)code); continue; }
          buf.append((char)(code & 0xff)); i++;
          break;                /* decode octal value */
        case 'x':               /* --- hexadecimal character code */
          c = (i >= len) ? -1 : s.charAt(i);
          if      ((c >= '0') && (c <= '9')) code = c -'0';
          else if ((c >= 'a') && (c <= 'f')) code = c -'a' +10;
          else if ((c >= 'A') && (c <= 'F')) code = c -'A' +10;
          else { buf.append('x'); continue; }
          c = (++i >= len) ? -1 : s.charAt(i);
          if      ((c >= '0') && (c <= '9')) code = (code << 4) +c-'0';
          else if ((c >= 'a') && (c <= 'f')) code = (code << 4) +c-'a'+10;
          else if ((c >= 'A') && (c <= 'F')) code = (code << 4) +c-'A'+10;
          else { buf.append((char)code); continue; }
          buf.append((char)code); i++;
          break;                /* decode hexadecimal value */
        default:                /* non-function characters */
          buf.append((i >= len) ? '\\' : s.charAt(i));
          break;                /* store character or backslash */
      }
    }
    return buf.toString();      /* return the decoded string */
  }  /* decode() */

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    String s;                   /* string to work on */

    if (args.length > 0) s = args[0];
    else                 s = "Test: \\\\\\txx\\by\\n\\r\\x00|";
    System.out.println("original: " +s);
    s = ASCIICoder.decode(s);
    System.out.println("decoded : " +s);
    s = ASCIICoder.encode(s);
    System.out.println("encoded : " +s);
  }  /* main() */

}  /* class ASCIICoder */
