/*----------------------------------------------------------------------
  File    : TableReader.java
  Contents: class for table readers (for files with tabular data)
  Author  : Christian Borgelt
  History : 2006.10.05 file created from file tfscan.c
            2006.10.06 first version completed
            2006.10.16 return value of nextField() changed to String
            2007.01.31 function skipComment included in nextField()
            2007.02.02 null value treatment added
            2007.02.07 function close() added
            2007.03.29 function rno(int offset) added
            2007.05.15 function getRecordNumber() added
            2007.05.17 functions to set all standard chars added
            2007.07.13 bug in function nextField() fixed (null values)
            2007.09.02 made '*' a null value character by default
            2016.04.07 StringBuffer replaced by StringBuilder
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package util;

import java.io.IOException;
import java.io.File;
import java.io.Reader;
import java.io.StringReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/*--------------------------------------------------------------------*/
/** Class for readers for files with tabular data.
 *  <p>The input stream is split into fields (table cell) and records
 *  (table row). Three types/classes of characters are used for this:
 *  record separators, field separators, and blank characters.
 *  The latter are used to fill table fields to a given width (for
 *  example, in order to align the fields in a file) and are removed
 *  when a field is read.</p>
 *  <p>In addition, comment characters can be registered. They are
 *  used to identify comment records by checking whether a record
 *  starts with such a comment character.</p>
 *  <p>Finally, null value characters can be registered.</p>
 *  @author Christian Borgelt
 *  @since  2006.10.05 */
/*--------------------------------------------------------------------*/
public class TableReader {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** class/type flag: record separator */
  public static final int RECSEP  = 0x01;
  /** class/type flag: field separator */
  public static final int FLDSEP  = 0x02;
  /** class/type flag: blank character */
  public static final int BLANK   = 0x04;
  /** class/type flag: null value character */
  public static final int NULL    = 0x08;
  /** class/type flag: comment character */
  public static final int COMMENT = 0x10;
  /** class/type flag: other character type */
  public static final int OTHER   = 0x20;
  /** the codes of the character classes */
  public static final int codes[] =
  { RECSEP, FLDSEP, BLANK, NULL, COMMENT, OTHER };

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the reader to read from */
  private Reader        reader;
  /** the character flags */
  private char[]        cflags;
  /** the buffer for the next table field */
  private StringBuilder buf;
  /** the buffer for a pushed back character */
  private int           pbchar;
  /** the next table field */
  public  String        field;
  /** the last delimiter read: -1 if end of file/input,
   *  0 if field  separator, 1 if record separator */
  public  int           delim;
  /** the current record number */
  public  int           record;

  /*------------------------------------------------------------------*/
  /** Create a table reader with default character flags.
   *  <p>By default the following character settings are used:<br>
   *  record separators: "\n", field separators: " \t", blanks: " \r\t",
   *  null value characters: "?*".</p>
   *  @param  reader the reader to work on
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader (Reader reader)
  {                             /* --- create a table reader */
    this.reader = reader;       /* store the reader to work on */
    this.buf    = new StringBuilder();
    this.cflags = new char[256];
    this.cflags['\n'] = RECSEP; /* initialize the character flags */
    this.cflags['\t'] = this.cflags[' '] = BLANK|FLDSEP;
    this.cflags[',']  = FLDSEP;
    this.cflags['\r'] = BLANK;
    this.cflags['?']  = this.cflags['*'] = NULL;
    this.field  = null;         /* no field has been read yet */
    this.pbchar = -1;           /* there is no pushed back char. */
    this.delim  = -1;           /* set the delimiter to a default */
    this.record =  1;           /* clear the record counter */
  }  /* TableReader() */

  /*------------------------------------------------------------------*/
  /** Create a table reader with default character flags.
   *  @param  string the string to read
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader (String string)
  { this(new StringReader(string)); }

  /*------------------------------------------------------------------*/
  /** Create a table reader with default character flags.
   *  @param  stream the input stream to read
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader (InputStream stream) throws IOException
  { this(new InputStreamReader(stream)); }

  /*------------------------------------------------------------------*/
  /** Create a table reader with default character flags.
   *  @param  file the file to read
   *  @since  2007.07.26 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableReader (File file) throws IOException
  { this(new FileReader(file)); }

  /*------------------------------------------------------------------*/
  /** Set the characters for a specific type/class.
   *  @param  type  the type/class of characters to set; must be
   *                one of the constants <code>RECSEP</code>,
   *                <code>FLDSEP</code>, <code>BLANK</code>,
   *                <code>NULL</code>, <code>COMMENT</code>, or
   *                <code>OTHER</code>
   *                (or a combination of these, by binary or)
   *  @param  chars the characters to set
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setChars (int type, String chars)
  {                             /* --- set the characters of a class */
    for (int i = this.cflags.length; --i >= 0; )
      this.cflags[i] &= ~type;  /* clear flags for all characters */
    for (int i = chars.length(); --i >= 0; )
      this.cflags[chars.charAt(i)] |= type;
  }  /* setChars() */           /* set flags for given characters */

  /*------------------------------------------------------------------*/
  /** Set the characters for all standard types.
   *  <p>If a parameter is <code>null</code>, the corresponding
   *  character flags are maintained.</p>
   *  @param  recseps the record separators
   *  @param  fldseps the field  separators
   *  @param  blanks  the blank  characters
   *  @param  nullchs the null value characters
   *  @param  comment the comment characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setChars (String recseps, String fldseps,
                              String blanks,  String nullchs,
                              String comment)
  {                             /* --- set characters of all classes */
    if (recseps != null) this.setChars(RECSEP,  recseps);
    if (fldseps != null) this.setChars(FLDSEP,  fldseps);
    if (blanks  != null) this.setChars(BLANK,   blanks);
    if (nullchs != null) this.setChars(NULL,    nullchs);
    if (comment != null) this.setChars(COMMENT, comment);
  }  /* setChars() */

  /*------------------------------------------------------------------*/
  /** Set the characters for all standard types.
   *  <p>The strings are assumed to contain the characters in
   *  encoded form, so that they have to be decoded with an
   *  <code>ASCIICoder</code>. If a parameter is <code>null</code>,
   *  the corresponding character flags are maintained.</p>
   *  @param  recseps the record separators
   *  @param  fldseps the field  separators
   *  @param  blanks  the blank  characters
   *  @param  nullchs the null value characters
   *  @param  comment the comment characters
   *  @since  2007.05.17 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setCharsCoded (String recseps, String fldseps,
                                   String blanks, String nullchs,
                                   String comment)
  {                             /* --- set characters of all classes */
    if (recseps != null)        /* record separators */
      this.setChars(RECSEP,  ASCIICoder.decode(recseps));
    if (fldseps != null)        /* field separators */
      this.setChars(FLDSEP,  ASCIICoder.decode(fldseps));
    if (blanks  != null)        /* blank characters */
      this.setChars(BLANK,   ASCIICoder.decode(blanks));
    if (nullchs != null)        /* null value characters */
      this.setChars(NULL,    ASCIICoder.decode(nullchs));
    if (comment != null)        /* comment characters */
      this.setChars(COMMENT, ASCIICoder.decode(comment));
  }  /* setCharsCoded() */

  /*------------------------------------------------------------------*/
  /** Check whether a given character is in a given class
   *  or of a given type.
   *  @param  type the type/class for which to query;
   *               must be one of the constants <code>RECSEP</code>,
   *               <code>FLDSEP</code>, <code>BLANK</code>,
   *               <code>COMMENT</code>, or <code>OTHER</code>.
   *  @param  c    the character to query
   *  @return whether the character is in the given class
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final boolean isType (int type, char c)
  { return (this.cflags[c] & type) != 0; }

  /*------------------------------------------------------------------*/
  /** Get the classes/types of a given character.
   *  @param  c the character to query
   *  @return the classes character is in, as a combination of the
   *          flags <code>RECSEP</code>, <code>FLDSEP</code>,
   *          <code>BLANK</code>, <code>COMMENT</code>, and
   *          <code>OTHER</code>
   *  @since  2006.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int getTypes (char c)
  { return (int)this.cflags[c]; }

  /*------------------------------------------------------------------*/
  /** Get a string stating the current record number.
   *  Useful for error reporting.
   *  @return a string stating the current record number
   *          in the format "(record xxx)"
   *  @since  2007.01.31 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String rno ()
  { return this.rno(0); }

  /*------------------------------------------------------------------*/
  /** Get a string stating the current record number.
   *  Useful for error reporting.
   *  @param  offset the offset to add to the record number
   *  @return a string stating the current record number
   *          in the format "(record xxx)"
   *  @since  2007.03.29 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final String rno (int offset)
  { return " (record " +(this.record +offset) +")"; }

  /*------------------------------------------------------------------*/
  /** Get the next field/cell of the table.
   *  <p>Note that a record separator is (virtually) inserted at the
   *  end of the file/input if the file/input does not end with a
   *  record separator.</p>
   *  @return the type of the delimiter of the field read:
   *          <p><table cellpadding=0 cellspacing=0>
   *          <tr><td>-1,</td><td>if end of file/input,</td></tr>
   *          <tr><td><font color="white">-</font>0,</td>
   *              <td>if field separator,</td>
   *          <tr><td>+1,</td><td>if record separator.</td></tr>
   *          </table></p>
   *  @throws IOException if an I/O error occurs
   *  @since  2006.10.05 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final int nextField () throws IOException
  {                             /* --- get the next field */
    int c, f, i;                /* character, flags, index */

    this.field = null;          /* initialize the field */
    if (this.pbchar >= 0) {     /* check for a pushed back character */
      c = this.pbchar; this.pbchar = -1; }
    else {                      /* if there is no pushed back char. */
      c = this.reader.read();   /* get the next character */
      if (c < 0) return this.delim = -1;
    }                           /* check for end of input */

    /* --- skip comment records --- */
    if (this.delim != 0) {      /* if at the start of a record */
      while ((c < this.cflags.length)     /* comment read loop */
      &&     ((this.cflags[c] & COMMENT) != 0)) {
        this.record++;          /* count the record to be read */
        while ((c >= this.cflags.length)
        ||     ((this.cflags[c] & RECSEP) == 0)) {
          c = this.reader.read();    /* get the next character */
          if (c < 0) return this.delim = -1;
        }                       /* read up to a record separator */
        c = this.reader.read(); /* get the next character */
        if (c < 0) return this.delim = -1;
      }                         /* check for end of file/input */
    }                           /* (comment records are skipped) */

    /* --- skip leading blanks --- */
    while ((c < this.cflags.length)
    &&     ((this.cflags[c] & BLANK) != 0)) {
      c = this.reader.read();   /* get the next character */
      if (c < 0) return this.delim = 1;
    }                           /* get the next character */
    /* Note that after at least one valid character was read, even  */
    /* if it is a blank, the end of file/input is translated into a */
    /* record separator. -1 is returned only if no character could  */
    /* be read before the end of file/input is encountered.         */

    /* --- read the field --- */
    if (c < this.cflags.length) {
      f = this.cflags[c];       /* get the character class and */
      if ((f & RECSEP) != 0) {  /* check for record separator */
        this.record++; return this.delim = 1; }
      if ((f & FLDSEP) != 0) {  /* check for field separator */
                       return this.delim = 0; }
    }                           /* return an empty field */

    this.buf.setLength(0);      /* clear the read buffer */
    while (true) {              /* read the field value */
      this.buf.append((char)c); /* store the character in the buffer */
      c = this.reader.read();   /* get the next character */
      if (c <  0)            { this.delim = 1;                break; }
      if (c >= this.cflags.length) continue;
      f = this.cflags[c];       /* check for record/field separator */
      if ((f & RECSEP) != 0) { this.delim = 1; this.record++; break; }
      if ((f & FLDSEP) != 0) { this.delim = 0;                break; }
    }                           /* read up to a separator */

    /* --- remove trailing blanks --- */
    i = this.buf.length();      /* find index of last non-blank char. */
    do { f = this.buf.charAt(--i); }
    while ((f < this.cflags.length)
    &&     ((this.cflags[f] & BLANK) != 0));
    this.field = this.buf.substring(0, ++i);

    /* --- check for an unknown value --- */
    while (--i >= 0) {          /* traverse the remaining */
      f = this.buf.charAt(i);   /* non-blank characters */
      if ((f < this.cflags.length)
      &&  ((this.cflags[f] & NULL) == 0))
        break;                  /* check whether all characters */
    }                           /* are null value characters and */
    if (i < 0) this.field = null;     /* clear field if they are */

    /* --- skip trailing blanks --- */
    if (this.delim != 0)        /* if not at a field separator, */
      return this.delim;        /* abort the function directly */
    while ((c < this.cflags.length)
    &&     ((this.cflags[c] & BLANK) != 0)) {
      c = this.reader.read();   /* get the next character */
      if (c < 0) return this.delim = 1;
    }                           /* skip trailing blanks */

    f = (c < this.cflags.length) ? this.cflags[c] : 0;
    if ((f & RECSEP) != 0) {    /* check for a record separator */
      this.record++; return this.delim = 1; }
    if ((f & FLDSEP) == 0) { this.pbchar = c; }
    return this.delim = 0;      /* set and return the delimiter type */
  }  /* nextField() */

  /*------------------------------------------------------------------*/
  /** Close the underlying stream.
   *  @throws IOException if an I/O error occurs
   *  @since  2007.02.08 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void close () throws IOException
  { this.reader.close(); }

  /*------------------------------------------------------------------*/
  /** Main function for testing basic functionality.
   *  @since  2004.10.06 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public static void main (String[] args)
  {                             /* --- main function for testing */
    try {                       /* test the table reader */
      TableReader reader;       /* reader for testing */
      switch (args.length) {    /* evaluate the argument list */
        case 0 : reader = new TableReader("This is a test."); break;
        case 1 : reader = new TableReader(args[0]);           break;
        default: reader = new TableReader(new FileReader(args[0]));
                 reader.setChars(FLDSEP, ASCIICoder.decode(args[1]));
                 break;         /* create a table reader */
      }
      reader.setChars(COMMENT, "#");
      do {                      /* input read loop */
        reader.nextField();     /* get the next field */
        System.out.println(reader.delim +" : " +reader.field);
      } while (reader.delim >= 0);  /* print delimiter and field */
      reader.close(); }         /* close the input stream */
    catch (IOException e) {     /* catch and report i/o errors */
      System.err.println(e.getMessage()); }
  }  /* main() */

}  /* class TableReader */
