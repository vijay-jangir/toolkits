/*----------------------------------------------------------------------
  File    : TableWriter.java
  Contents: table writer (for writing files with tabular data)
  Author  : Christian Borgelt
  History : 2007.05.20 file created
            2017.06.29 functions declared final for speed
----------------------------------------------------------------------*/
package util;

import java.io.IOException;
import java.io.Writer;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/*--------------------------------------------------------------------*/
/** Class for writers for files with tabular data.
 *  @author Christian Borgelt
 *  @since  2007.05.20 */
/*--------------------------------------------------------------------*/
public class TableWriter {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the reader for the output file */
  private Writer writer;
  /** the record separator */
  private int    recsep;
  /** the field separator */
  private int    fldsep;
  /** the blank character */
  private int    blank;
  /** the null value character */
  private int    nullch;

  /*------------------------------------------------------------------*/
  /** Create a table writer with default characters.
   *  @param  writer the writer to work on
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableWriter (Writer writer)
  {                             /* --- create a table writer */
    this.writer = writer;       /* note the writer and */
    this.recsep = '\n';         /* set default characters */
    this.fldsep = ' ';
    this.blank  = ' ';
    this.nullch = '?';
  }  /* TableWriter() */

  /*------------------------------------------------------------------*/
  /** Create a table writer with default characters.
   *  @param  stream the output stream to write on
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public TableWriter (OutputStream stream) throws IOException
  { this((Writer)new OutputStreamWriter(stream)); }

  /*------------------------------------------------------------------*/
  /** Set the record separator.
   *  @param  recsep the record separator
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setRecSep (int recsep)
  { this.recsep = recsep; }

  /*------------------------------------------------------------------*/
  /** Set the field separator.
   *  @param  fldsep the field separator
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setFldSep (int fldsep)
  { this.fldsep = fldsep; }

  /*------------------------------------------------------------------*/
  /** Set the blank character.
   *  @param  blank the blank character
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setBlank (int blank)
  { this.blank = blank; }

  /*------------------------------------------------------------------*/
  /** Set the null value character.
   *  @param  nullch the null value character
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setNullChar (int nullch)
  { this.nullch = nullch; }

  /*------------------------------------------------------------------*/
  /** Set all separator characters.
   *  @param  seps the separators to use for writing<br>
   *               char 0: record separator<br>
   *               char 1: field separator<br>
   *               char 2: blank character (optional)<br>
   *               char 3: null value character (optional)
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setChars (String seps)
  {                             /* --- set the characters */
    this.recsep = seps.charAt(0);
    this.fldsep = seps.charAt(1);
    this.blank  = (seps.length() > 2) ? seps.charAt(2) : -1;
    this.nullch = (seps.length() > 3) ? seps.charAt(3) : -1;
  }  /* setChars() */

  /*------------------------------------------------------------------*/
  /** Set all separator characters.
   *  @param  seps the separators to use for writing
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void setCharsCoded (String seps)
  { this.setChars(ASCIICoder.decode(seps)); }

  /*------------------------------------------------------------------*/
  /** Write a field.
   *  @param  s the contents of the field to write
   *  @throws IOException if an I/O error occurs
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (String s) throws IOException
  { this.write(s, 0, false); }

  /*------------------------------------------------------------------*/
  /** Write a field.
   *  @param  s     the contents of the field to write
   *  @param  width the width to which to fill the field
   *  @throws IOException if an I/O error occurs
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (String s, int width) throws IOException
  { this.write(s, width, false); }

  /*------------------------------------------------------------------*/
  /** Write a field.
   *  @param  s    the contents of the field to write
   *  @param  last whether this is the last field of a record
   *  @throws IOException if an I/O error occurs
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (String s, boolean last) throws IOException
  { this.write(s, 0, last); }

  /*------------------------------------------------------------------*/
  /** Write a field.
   *  @param  s     the contents of the field to write
   *  @param  width the width to which to fill the field
   *  @param  last  whether this is the last field of a record
   *  @throws IOException if an I/O error occurs
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void write (String s, int width, boolean last)
    throws IOException
  {                             /* --- write a field */
    if (s != null)              /* if the field is not null, */
      this.writer.write(s);     /* write the field contents */
    else {                      /* if the field is null */
      if (this.nullch < 0) s = "";
      else this.writer.write((char)this.nullch); s = " ";
    }                           /* write a null value */
    if (this.blank >= 0) {      /* if a blank character is given */
      for (int n = s.length(); ++n <= width; )
        this.writer.write((char)this.blank);
    }                           /* fill the field to the given width */
    this.writer.write((char)((last) ? this.recsep : this.fldsep));
  }  /* write() */              /* write field/record separator */

  /*------------------------------------------------------------------*/
  /** Write the last field of a record.
   *  @param  s the contents of the field to write
   *  @throws IOException if an I/O error occurs
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void writeLast (String s) throws IOException
  { this.write(s, 0, true); }

  /*------------------------------------------------------------------*/
  /** Write the last field of a record.
   *  @param  s     the contents of the field to write
   *  @param  width the width to which to fill the field
   *  @throws IOException if an I/O error occurs
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void writeLast (String s, int width) throws IOException
  { this.write(s, width, true); }

  /*------------------------------------------------------------------*/
  /** Close the underlying stream.
   *  @throws IOException if an I/O error occurs
   *  @since  2007.05.20 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public final void close () throws IOException
  { this.writer.close(); }

}  /* class TableWriter */
