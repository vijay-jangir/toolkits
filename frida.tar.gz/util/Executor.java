/*----------------------------------------------------------------------
  File    : Executor.java
  Contents: abstract class for thread/process execution
  Author  : Christian Borgelt
  History : 2007.05.03 file created
----------------------------------------------------------------------*/
package util;

import java.awt.event.ActionListener;

/*--------------------------------------------------------------------*/
/** Abstract class for thread/process execution.
 *  <p>If the thread or process cannot be created, is aborted, is
 *  externally interrupted, or terminates normally or with failure,
 *  a listener function is notified, with an identifier of the
 *  event that occurred.</p>
 *  @author Christian Borgelt
 *  @since  2007.05.03 */
/*--------------------------------------------------------------------*/
public abstract class Executor implements Runnable {

  /*------------------------------------------------------------------*/
  /*  constants                                                       */
  /*------------------------------------------------------------------*/
  /** the object/program could not be invoked or failed */
  public static final int FAILED      = -1;
  /** the object/program terminated normally */
  public static final int OK          =  0;
  /** the object/program is currently running */
  public static final int RUNNING     =  1;
  /** the object/program was aborted */
  public static final int ABORTED     =  2;
  /** the program was externally interrupted */
  public static final int INTERRUPTED =  3;
  /** the runner is idle (no object/program started) */
  public static final int IDLE        =  4;

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the listener to be notified on termination or failure */
  protected ActionListener   listener = null;
  /** whether the object/program has been stopped */
  protected volatile boolean aborted  = false;
  /** the status of the object/program invocation */
  protected volatile int     status   = IDLE;
  /** the status message of the object/program invocation */
  protected String           message  = null;

  /*------------------------------------------------------------------*/
  /** Start the execution as a thread.
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void start ()
  { if (this.status != RUNNING) new Thread(this).start(); }

  /*------------------------------------------------------------------*/
  /** Stop the execution.
   *  <p>Note that this function returns immediately after setting
   *  a flag (it does not wait for the thread to terminate). Once
   *  the thread terminates, the listener function is called with
   *  the identifier <code>ABORTED</code>.</p>
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void abort ()
  { if (this.status == RUNNING) this.aborted = true; }

  /*------------------------------------------------------------------*/
  /** Function for thread execution.
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public abstract void run ();

  /*------------------------------------------------------------------*/
  /** Get the status of the thread/process invocation.
   *  <p>The status is of the runner is <code>IDLE</code>
   *  before the <code>start()</code> function has been called,
   *  <code>FAILED</code> if the thread/process could not be
   *  started or the execution failed, <code>RUNNING</code>
   *  while the thread/process is running, <code>ABORTED</code>
   *  if the thread/process was terminated by a call to the
   *  <code>stop()</code> function, <code>INTERRUPTED</code>
   *  if the process was externally interrupted and <code>OK</code>
   *  after the thread/process terminated successfully.</p>
   *  @return the status of the thread/process invocation
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public int getStatus ()
  { return this.status; }

  /*------------------------------------------------------------------*/
  /** Get the status message of the thread/process invocation.
   *  <p>This function may yield a proper message string only after the
   *  listener function has been called (that is, it may be used in the
   *  listener function). However, the same information is provided
   *  by the <code>ActionEvent</code> passed to the listener.</p>
   *  @return the status message of the thread/process invocation
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public String getMessage ()
  { return this.message; }

}  /* class Executor */
