/*----------------------------------------------------------------------
  File    : ObjExecutor.java
  Contents: execute an object as a thread
  Author  : Christian Borgelt
  History : 2007.05.03 file created
----------------------------------------------------------------------*/
package util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*--------------------------------------------------------------------*/
/** Class for executing an object as a thread.
 *  <p>When the object execution terminates, regardless of whether
 *  it terminates successfully or with failure, a listener function
 *  is notified, with an identifier of the event that occurred.</p>
 *  @author Christian Borgelt
 *  @since  2007.05.02 */
/*--------------------------------------------------------------------*/
public class ObjExecutor extends Executor {

  /*------------------------------------------------------------------*/
  /*  instance variables                                              */
  /*------------------------------------------------------------------*/
  /** the object to execute as a thread */
  private Executable obj;

  /*------------------------------------------------------------------*/
  /** Create an object executor.
   *  <p>On termination, the listener is notified. The identifier of
   *  the action event that is passed to the listener is <p>OK</p> if
   *  the object's <code>exec()</code> method terminated successfully,
   *  <code>ABORTED</code> if the execution was aborted by a call to
   *  the function <code>abort()</code> and <code>FAILURE</code>
   *  otherwise.</p>
   *  @param  obj the object to execute as a thread
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public ObjExecutor (Executable obj, ActionListener listener)
  {                             /* --- create a method runner */
    this.obj      = obj;        /* note the object and */
    this.listener = listener;   /* the action listener */
    this.status   = IDLE;       /* the thread has not been started */
    this.aborted  = false;      /* and not been aborted either */
    this.message  = null;       /* there is no status message yet */
  }  /* Runner() */

  /*------------------------------------------------------------------*/
  /** Function for thread execution.
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void run ()
  {                             /* --- invoke the method */
    if (this.status == RUNNING) return;
    this.status  = RUNNING;     /* set the status to running */
    this.aborted = false;       /* and not aborted */
    this.message = null;        /* clear the status message */
    try {                       /* invoke the object's exec method */
      if (this.obj != null) this.obj.exec();
      this.status  = (this.aborted) ? ABORTED : OK; }
    catch (Exception e) {       /* if an error occurred */
      this.status  = FAILED;    /* set failure status */
      this.message = e.getMessage();
      System.err.println("\n" +this.message);
    }                           /* note and print the error message */
    if (this.listener != null)  /* notify the listener */
      this.listener.actionPerformed(
        new ActionEvent(this, this.status, this.message));
  }  /* run() */

  /*------------------------------------------------------------------*/
  /** Abort the execution.
   *  @since  2007.05.02 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public void abort ()
  {                             /* --- stop the method execution */
    if ((this.status != RUNNING) || this.aborted) return;
    this.aborted = true;        /* set the aborted flag and */
    this.obj.abort();           /* invoke the object's abort method */
  }  /* abort() */

  /*------------------------------------------------------------------*/
  /** Get the object to execute as a thread.
   *  @return the object to execute as a thread
   *  @since  2007.05.03 (Christian Borgelt) */
  /*------------------------------------------------------------------*/

  public Executable getObject ()
  { return this.obj; }

}  /* class ObjExecutor */
